package sdk.pendo.io.reactive.filters;

import io.reactivex.functions.Function;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;

/**
 * RxJava filter for making sure we are in paired / test / capture mode.
 *
 * Returns true if object is not null.
 *
 * Created by assaf on 6/22/15.
 */
public class PairedModeFilter implements Function<Object, Boolean> {
    @Override
    public Boolean apply(Object o) {
        return SocketEventFSM.getInstance().isPairedMode() || SocketEventFSM.getInstance().isTestMode() || SocketEventFSM
                .getInstance().isCaptureMode();
    }
}
