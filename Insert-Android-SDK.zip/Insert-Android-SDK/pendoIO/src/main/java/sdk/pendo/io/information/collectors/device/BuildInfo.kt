package sdk.pendo.io.information.collectors.device

import android.os.Build

import org.json.JSONException
import org.json.JSONObject

import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger

/**
 * Collect information about the device build.

 * Created by assaf on 4/14/15.
 */
internal class BuildInfo : Collector() {

    override fun collectData(json: JSONObject) {

        // General device build information.
        addDeviceBuildInfo(json)
    }

    /**
     * Fills a JSONObject with the device's build information.

     * @param info The JSONObject to receive the device build information.
     */
    private fun addDeviceBuildInfo(info: JSONObject) {
        try {
            //            info.put("sdk", Build.VERSION.RELEASE);
            info.put(DeviceInfoConstants.OS, "Android")
            info.put(DeviceInfoConstants.OS_VERSION, Build.VERSION.SDK_INT.toString())
            info.put(DeviceInfoConstants.BRAND, Build.BRAND)
            info.put(DeviceInfoConstants.MANUFACTURER, Build.MANUFACTURER)
            info.put(DeviceInfoConstants.MODEL, Build.MODEL)
            info.put(DeviceInfoConstants.BOARD, Build.BOARD)
            //            info.put("bootloader", Build.BOOTLOADER);
            //            info.put("id", Build.ID);
            //            info.put("overall_product_name", Build.PRODUCT);
            //            info.put("industrial_design_name", Build.DEVICE);
        } catch (e: JSONException) {
            InsertLogger.e(e, "${e.message}")
        }
    }
}
