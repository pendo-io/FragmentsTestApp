package sdk.pendo.io.actions.configurations;

import android.support.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Pendo's Group.
 * <p/>
 * Created by tomerlevinson on 12/7/15.
 */
public final class InsertGroup {

    @SerializedName(AnalyticsProperties.CONTROL_GROUP_GID)
    private int mGroupId;

    @SerializedName("type")
    private String mType;

    public enum InsertGroupType {
        CONTROL("control"),
        USER("user");

        private final String mType;

        private static final Map<String, InsertGroupType> LOOKUP_TABLE = new HashMap<>();
        static {
            for (InsertGroupType s : EnumSet.allOf(InsertGroupType.class)) {
                LOOKUP_TABLE.put(s.mType, s);
            }
        }

        InsertGroupType(String type) {
            this.mType = type;
        }

        public boolean equals(InsertGroupType insertGroupType) {
            return this.mType.equals(insertGroupType.mType);
        }

        @Nullable
        public static InsertGroupType get(String type) {
            return LOOKUP_TABLE.get(type);
        }
    }

    public final InsertGroupType getGroupType() {
            return InsertGroupType.get(mType);
    }

    public final int getGroupId() { return mGroupId;}

    public void setGroupId(int groupId) {
        mGroupId = groupId;
    }

    public void setType(String type) {
        mType = type;
    }

    @Override
    public String toString() {
        JSONObject insertGroup = new JSONObject();
        try {
            insertGroup.put(AnalyticsProperties.CONTROL_GROUP_GID_SEND,
                    getGroupId());
            insertGroup.put(AnalyticsProperties.CONTROL_GROUP_TYPE,
                    getGroupType().toString().toLowerCase());
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }

        return insertGroup.toString();
    }
}
