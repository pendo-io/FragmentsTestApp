package sdk.pendo.io.views.drawables;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;

import external.sdk.pendo.io.dynamicview.DynamicViewUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.ResourceUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Given a bitmap, a tile/fill mode and a view, this class keep a {@link WeakReference} to the view
 * and makes sure that the tile/fill mode is fulfilled by
 * computing the correct way to show the bitmap in {@link #draw(Canvas)}.
 *
 * Created by assaf on 10/26/15.
 */
public class InsertBitmapDrawable extends BitmapDrawable {

    private final DynamicViewUtils.BackgroundImageTileTypes mTile;
    private final WeakReference<View> mViewWeakReference;
    private Matrix mDrawMatrix = new Matrix();
    private AtomicBoolean mOnce = new AtomicBoolean(false);
    private final Shader.TileMode mTileMode;
    private int mBackgroundColor,mBorderWidth,mBorderColor;
    private float mCornerRadius;


    public InsertBitmapDrawable(Bitmap bitmap, View view, String tile, int backgroundColor,
                                int borderColor, int borderWidth, float cornerRadius)
            throws IllegalArgumentException {
        super(ResourceUtils.getResources(), bitmap);

        mViewWeakReference = new WeakReference<>(view);
        mTile = DynamicViewUtils.BackgroundImageTileTypes.findFillMode(tile);
        mBackgroundColor = backgroundColor;
        mBorderColor = borderColor;
        mBorderWidth = borderWidth;
        mCornerRadius = cornerRadius;

        if (mTile == null) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("reason", "wrong tile given: " + tile);
                AnalyticsUtils.sendErrorReport(
                        GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONFIGURATION,
                        jsonObject);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            throw new IllegalArgumentException("Given bad tile: " + tile);
        }

        mTileMode = mTile.getMode();
        if (mTileMode != null) {
            setTileModeXY(mTileMode, mTileMode);
        }
    }

    @Override
    public final void draw(Canvas canvas) {
        final Bitmap bitmap = getBitmap();
        final View view = mViewWeakReference.get();

        if (mTileMode != null) {
            super.draw(canvas);
        } else if (bitmap != null && view != null) {

            final int bitmapWidth = bitmap.getWidth();
            final int bitmapHeight = bitmap.getHeight();

            final int viewWidth = view.getWidth();
            final int viewHeight = view.getHeight();

            /*
            For the fill value we need to fill the entire view with the bitmap:

                                                     Screen

                                      *-------#####################--------*
                                      |       #          /\       #        |
                                      |       #         / \       #        |
                   Image              |       #        /  \       #        |
                                      |       #       /   \       #   /\   |
               *-----------*          |       #      /     \      #  / \   |
               |    /\     |  Fill    |       #     /      \      # /  \   |
               |   / \ /\  |  --->    |       #    /       \      #/   \   |
               |/\/  \/  \ |          |    /\ #   /        \     /#     \  |
               *-----------*          |   / \ #  /          \   / #     \  |
                                      |  /  \ # /           \  /  #     \  |
                                      | /   \ #/            \ /   #     \  |
                                      |/    \/#             \/    #     \  |
                                      *-------#####################--------*

                                      *--------------------*
                                      |                    |
                                      |                    |
                                      |                    |
                   Image              ######################
                                      #                    #
               *-----------*          #                    #
               |           |          #                    #
               |           |          #                    #
               |           |          #                    #
               |           |  Fill    #                    # Screen
               |     /\    |  --->    #            /\      #
               |    / \    |          #           / \      #
               |   /  \ /\ |          #          /  \      #
               |/\/   \/ \ |          #         /   \      #
               *-----------*          #        /    \   /\ #
                                      ######################
                                      |  /|  /     |  /  \ |
                                      | / \ /      \ /   \ |
                                      |/  \/       \/    \ |
                                      *--------------------*

             */
            if (DynamicViewUtils.BackgroundImageTileTypes.FILL.equals(mTile)) {

                float scale;
                float dx = 0, dy = 0;

                if (bitmapWidth * viewHeight > viewWidth * bitmapHeight) {
                    scale = (float) viewHeight / (float) bitmapHeight;
                    dx = (viewWidth - bitmapWidth * scale) * 0.5f;
                } else {
                    scale = (float) viewWidth / (float) bitmapWidth;
                    dy = (viewHeight - bitmapHeight * scale) * 0.5f;
                }

                if (!mOnce.getAndSet(true)) {
                    mDrawMatrix.setScale(scale, scale);
                    mDrawMatrix.postTranslate(Math.round(dx), Math.round(dy));
                }

            /*
            For the fit value we need to fit the bitmap into the view:
            Compute a scale that will maintain the original src aspect ratio,
            but will also ensure that src fits entirely inside dst.
            At least one axis (X or Y) will fit exactly. The result is centered inside dst.
             */
            } else if (DynamicViewUtils.BackgroundImageTileTypes.FIT.equals(mTile)) {
                mDrawMatrix.setRectToRect(
                        new RectF(0, 0, bitmapWidth, bitmapHeight),
                        new RectF(0, 0, viewWidth, viewHeight),
                        Matrix.ScaleToFit.CENTER);
            }

            // Preparations for drawing. First prepare the paint for the background color under the image.
            Paint colorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            colorPaint.setColor(mBackgroundColor);

            // Next, prepare the paint for the background image bitmap itself.
            BitmapShader shader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            shader.setLocalMatrix(mDrawMatrix);
            Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            bitmapPaint.setShader(shader);

            // Prepare the rounded rectangle where inside we'll draw the view.
            float padding  = mBorderWidth/2.0f;
            RectF rectF = new RectF(padding, padding, viewWidth - padding, viewHeight - padding);

            // Begin drawing.
            canvas.drawRoundRect(rectF, mCornerRadius, mCornerRadius, colorPaint); // Background color under bitmap.
            canvas.drawRoundRect(rectF, mCornerRadius, mCornerRadius, bitmapPaint); // Background bitmap image.

            if (mBorderWidth > 0) {
                // Prepare the paint for the border.
                Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                borderPaint.setStyle(Paint.Style.STROKE);
                borderPaint.setColor(mBorderColor);
                borderPaint.setStrokeWidth(mBorderWidth);

                // Draw the border.
                canvas.drawRoundRect(rectF, mCornerRadius, mCornerRadius, borderPaint);
            }
        }
    }

    @Override
    public final int getIntrinsicHeight() {
        return -1;
    }

    @Override
    public final int getIntrinsicWidth() {
        return -1;
    }
}
