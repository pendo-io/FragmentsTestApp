package sdk.pendo.io.models;

import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.actions.configurations.InsertTransition;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Describes the guide configuration.
 * https://pendo-io.atlassian.net/wiki/spaces/ENG/pages/378765321/New+init+protocol
 */
public class GuideConfigurationModel {

    @SerializedName("transition")
    private JsonElement mTransition;

    @SerializedName("delayMs")
    private long mDelayMs;

    @SerializedName("timeoutMs")
    private long mTimeoutMs;

    public long getTimeoutMs() {
        return mTimeoutMs;
    }

    public long getDelayMs() {
        return mDelayMs;
    }

    public JsonElement getTransition() {
        return mTransition;
    }

    @Nullable
    public final InsertTransition getTransition(String inOut) {
        if (mTransition != null) {
            try {
                if (!mTransition.isJsonArray()) {
                    if (mTransition.isJsonObject()) {
                        InsertLogger.d("Transition should be an array, not an object");
                    }
                    return null;
                }

                final JsonArray jsonArray = mTransition.getAsJsonArray();
                if (jsonArray == null || jsonArray.size() <= 0) {
                    InsertLogger.d("No transitions to return");
                    return null;
                }

                for (JsonElement jsonElementTransition : jsonArray) {
                    JsonObject transition = (JsonObject) jsonElementTransition;
                    JsonElement jsonTypeFieldElement = transition.get(
                            InsertTransition.INSERT_TRANSITION_TYPE_FIELD);
                    if (jsonTypeFieldElement != null
                            && inOut.equals(jsonTypeFieldElement.getAsString())) {
                        return InsertTransition.getInsertTransition(transition);
                    }
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

        return null;
    }
}
