package sdk.pendo.io.information.collectors.device

import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.utilities.add

/**
 * Collect information about applications on the devices.

 * Created by assaf on 4/14/15.
 */
internal class Applications : Collector() {

    override fun collectData(json: JSONObject) {

        // Add installed applications.
        addInstalledApplications(json)
    }

    /**
     * Adds the installed applications on the device to the JSON.

     * @param info The JSON to receive the array of installed application on the device.
     */
    private fun addInstalledApplications(info: JSONObject) {

        val installedApplications = application!!.packageManager
                .getInstalledApplications(PackageManager.GET_META_DATA)

        if (installedApplications != null) {
            val apps = JSONArray()
            for (installedApplication in installedApplications) {
                apps.add(installedApplication.packageName)
            }

            info.add(DeviceInfoConstants.INSTALLED_APPS, apps)
        }
    }
}
