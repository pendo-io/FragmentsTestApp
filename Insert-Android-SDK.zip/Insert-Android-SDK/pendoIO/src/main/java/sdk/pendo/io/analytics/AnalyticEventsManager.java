package sdk.pendo.io.analytics;

import android.content.SharedPreferences;
import android.os.Handler;

import org.json.JSONObject;
import org.reactivestreams.Subscription;

import java.util.List;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.AnalyticsConfigurationModel;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.SetupManager;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.utilities.ConnectivityUtils;
import sdk.pendo.io.utilities.PersistenceUtils;
import sdk.pendo.io.utilities.PreferencesUtils;

import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_BACKGROUND;
import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_FOREGROUND;


/**
 * This singleton class purpose is managing analytic events tracked by SDK:
 * - storing analytic events on disk in specific two buffer waterfall way
 * - send analytic events to backend with responsibility on retry and no network connection cases
 * - maintain disk buffers to clear already handled analytic events
 * - manage disk buffers with appropriate parameters
 * <p>
 * Created by DavidG on 16/12/19.
 */

public class AnalyticEventsManager {
    /**
     * Files on disk
     **/
    private static final String TEMPORARY_BUFFER_FILE_NAME = "TemporaryAnalyticEventsBuffer";
    private static final String MAIN_BUFFER_FILE_NAME = "MainAnalyticEventsBuffer";
    static final String ANALYTIC_EVENTS_DELIMITER = "}|{";
    static final String ANALYTIC_EVENTS_DELIMITER_REGEX = "\\}\\|\\{";
    static final String ANALYTIC_EVENTS_DELIMITER_REPLACEMENT = ",";
    /**
     * Shared Preferences for main buffer configuration parameters
     */
    private static final String MAIN_BUFFER_PARAMS = "MAIN_BUFFER_PARAMS";
    private static final String BUFFER_TIMEOUT = "BUFFER_TIMEOUT";
    private static final String BUFFER_QUEUE_SIZE = "BUFFER_QUEUE_SIZE";
    private static final String BUFFER_MAX_STORAGE = "BUFFER_MAX_STORAGE";
    /**
     * Buffers trigger default parameters
     **/
    private static final int TEMPORARY_BUFFER_TIMEOUT_INTERVAL_SECONDS_DEFAULT = 10;
    private static final int TEMPORARY_BUFFER_QUEUE_SIZE_DEFAULT = 10;
    private static final int MAIN_BUFFER_TIMEOUT_INTERVAL_SECONDS_DEFAULT = 30;
    private static final int MAIN_BUFFER_QUEUE_SIZE_DEFAULT = 20;
    private static final int MAIN_BUFFER_MAX_STORAGE_MB = 1;
    private static final int BYTES_IN_MB_FACTOR = 1024 * 1024;
    private static final float OVERFLOW_CORRECTION_FACTOR = 0.8f;
    private static final int MAIN_BUFFER_MAX_TIMEOUT_INTERVAL_SECONDS = 100;
    private static final int MAIN_BUFFER_MAX_QUEUE_SIZE = 100;
    private static final float MAIN_BUFFER_MAX_MAX_STORAGE_MB = 100f;
    /**
     * Retry limits and factors
     **/
    private static final int MIN_RETRY_TIMEOUT_IN_MILLIS = 1000;
    private static final int MAX_RETRY_TIMEOUT_IN_MILLIS = 64000;
    private static final int RETRY_TIMEOUT_FACTOR = 2;
    /**
     * Buffers
     **/
    private AnalyticEventsBuffer mTemporaryBuffer, mMainBuffer;
    /**
     * Retry handlers
     **/
    private Handler mRetryStrategyHandler = new Handler();
    private Runnable mRetryStrategyRunnable = new Runnable() {
        @Override
        public void run() {
            sendAnalyticEventsToBackend();
        }
    };
    private int mRetryTimeout = 0;
    private boolean mIsRetryMode;
    private static volatile AnalyticEventsManager INSTANCE;
    // Synchronization lock.
    private static final Object LOCK = new Object();
    private Disposable mConnectionObserverDisposable;
    private int mMainBufferMaxStorageSizeBytes = MAIN_BUFFER_MAX_STORAGE_MB * BYTES_IN_MB_FACTOR;
    private int mMainBufferTimeoutInSeconds, mMainBufferQueueSize;

    public static AnalyticEventsManager getInstance() {
        if (INSTANCE == null) {
            synchronized (LOCK) {
                if (INSTANCE == null) {
                    INSTANCE = new AnalyticEventsManager();
                }
            }
        }
        return INSTANCE;
    }

    // TODO: 2020-01-26 Take care to implement support of two modes - DISK AND RAM 
    private AnalyticEventsManager() {
        initializeDefaultMainBufferParameters();
        mTemporaryBuffer = new AnalyticEventsBuffer(TEMPORARY_BUFFER_FILE_NAME, TEMPORARY_BUFFER_TIMEOUT_INTERVAL_SECONDS_DEFAULT,
                TEMPORARY_BUFFER_QUEUE_SIZE_DEFAULT, AnalyticEventsBuffer.UNLIMITED_STORAGE,
                OVERFLOW_CORRECTION_FACTOR, new AnalyticEventsBuffer.ITrigger() {
            @Override
            public void trigger() {
                moveAnalyticEvents(mTemporaryBuffer, mMainBuffer);
            }
        });
        mMainBuffer = new AnalyticEventsBuffer(MAIN_BUFFER_FILE_NAME, mMainBufferTimeoutInSeconds,
                mMainBufferQueueSize, mMainBufferMaxStorageSizeBytes,
                OVERFLOW_CORRECTION_FACTOR, new AnalyticEventsBuffer.ITrigger() {
            @Override
            public void trigger() {
                sendAnalyticEventsToBackend();
            }
        });
    }

    /**
     * This method handle analytic events tracked by SDK, by first of all storing them to disk and
     * then proceed them further to be send to server
     *
     * @param events
     */
    public void handleTrackedAnalyticEvents(List<JSONObject> events, boolean shouldFlush) {
        StringBuilder stringBuilder = new StringBuilder();
        for (JSONObject event : events) {
            stringBuilder.append(ANALYTIC_EVENTS_DELIMITER);
            stringBuilder.append(event.toString());
        }
        mTemporaryBuffer.storeAnalyticEvents(stringBuilder.toString(), events.size());
        if (shouldFlush) {
            flushAnalyticEventsIfExist();
        }
    }

    /**
     * This method handle sending of stored analytics depend on if
     * there is network connection available
     */
    private void sendAnalyticEventsToBackend() {
        if (!ConnectivityUtils.hasConnectivity()) {
            if (mIsRetryMode) {
                stopRetryMode();
            }
            if (mConnectionObserverDisposable == null) {
                mConnectionObserverDisposable = ConnectivityUtils.observeNetworkConnectionIsAvailable(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) {
                        mConnectionObserverDisposable.dispose();
                        mConnectionObserverDisposable = null;
                        sendAnalyticEventsToBackend();
                    }
                });
            }
            mMainBuffer.handleStorageOverflowIfNeeded();
        } else {
            String analyticEvents = mMainBuffer.getStoredAnalyticEvents();
            if (!analyticEvents.isEmpty()) {
                if (analyticEvents.length() > ANALYTIC_EVENTS_DELIMITER.length()) {
                    analyticEvents = analyticEvents.substring(ANALYTIC_EVENTS_DELIMITER.length());
                }
                analyticEvents = analyticEvents.replace(ANALYTIC_EVENTS_DELIMITER, ANALYTIC_EVENTS_DELIMITER_REPLACEMENT);
                BackendApiManager.getInstance().sendAnalytics(analyticEvents, true, null);
            } else {
                handleSendAnalyticsEventsResponse(true);
            }
        }
    }

    /**
     * This method handle sending analytic events depend on response
     * If success removes them from storage
     * If failed performs retry strategy
     *
     * @param isSuccess is response is successful
     */
    public void handleSendAnalyticsEventsResponse(boolean isSuccess) {
        SetupManager.getInstance().setIsFinishedSendingPersistedAnalytics(true);
        if (isSuccess) {
            if (mIsRetryMode) {
                stopRetryMode();
            }
            mMainBuffer.removeHandledAnalyticEvents();
        } else {
            startRetryMode();
            mMainBuffer.handleStorageOverflowIfNeeded();
        }
    }

    /**
     * This method calculates retry strategy timeout and starts it
     */
    private void startRetryMode() {
        mIsRetryMode = true;
        if (mRetryTimeout == 0) {
            mRetryTimeout = MIN_RETRY_TIMEOUT_IN_MILLIS;
        } else if (mRetryTimeout < MAX_RETRY_TIMEOUT_IN_MILLIS) {
            mRetryTimeout *= RETRY_TIMEOUT_FACTOR;
        }
        mRetryStrategyHandler.postDelayed(mRetryStrategyRunnable, mRetryTimeout);
    }

    /**
     * This method stops retry timer and dropped it timeout value
     */
    private void stopRetryMode() {
        mIsRetryMode = false;
        mRetryStrategyHandler.removeCallbacks(mRetryStrategyRunnable);
        mRetryTimeout = 0;
    }

    /**
     * This method check out for stored analytic events from previous app session
     * and if there is any in other then PendingAnalyticEventBuffer disk storage, move
     * them to it and after all if there is analytic events in PendingAnalyticEventBuffer disk
     * storage, send them to the backend
     */
    public void flushAnalyticEventsIfExist() {
        if (mTemporaryBuffer.getWriteAnalyticEventsCounter() > 0) {
            mTemporaryBuffer.stopTimeoutTrigger();
            moveAnalyticEvents(mTemporaryBuffer, mMainBuffer);
        }
        if (mMainBuffer.getWriteAnalyticEventsCounter() > 0) {
            mMainBuffer.stopTimeoutTrigger();
            sendAnalyticEventsToBackend();
        } else {
            SetupManager.getInstance().setIsFinishedSendingPersistedAnalytics(true);
        }
    }

    /**
     * This method removes analytic events from one buffer {@param src}
     * to {@param destination}
     *
     * @param src
     * @param dst
     */
    private void moveAnalyticEvents(AnalyticEventsBuffer src, AnalyticEventsBuffer dst) {
        String analyticEvents = src.getStoredAnalyticEvents();
        dst.storeAnalyticEvents(analyticEvents, src.getHandledAnalyticEventsCount());
        src.removeHandledAnalyticEvents();
    }

    /**
     * This method set analytic configuration main buffer parameters after validating
     * them and storing to Shared Preferences
     */
    public void setMainBufferParameters(AnalyticsConfigurationModel analyticsConfigurationModel) {
        synchronized (LOCK) {
            boolean receivedNewParameters = validateAndStoreMainBufferParameters(
                    analyticsConfigurationModel.getBufferDuration(),
                    analyticsConfigurationModel.getBufferQueueSize(),
                    analyticsConfigurationModel.getMaxStoragesizeMB());
            if (receivedNewParameters) {
                mMainBuffer.setBufferParameters(mMainBufferTimeoutInSeconds, mMainBufferQueueSize, mMainBufferMaxStorageSizeBytes);
            }
            // Update observer, will allow submitting items
            InsertAnalytics.getBufferIsSetObservable().onNext(true);
        }
    }

    /**
     * This method validates main buffer parameters retrieved from server init response and if there
     * is diff between current local stored values, overrides them and set to mMainBuffer
     *
     * @param bufferDurationInSeconds
     * @param bufferQueueSize
     * @param bufferMaxStorageSizeMB
     * @return true if we received new parameters, false otherwise
     */
    private boolean validateAndStoreMainBufferParameters(int bufferDurationInSeconds, int bufferQueueSize, float bufferMaxStorageSizeMB) {
        boolean isNewParameterValues = false;
        if (bufferDurationInSeconds > 0
                && bufferDurationInSeconds <= MAIN_BUFFER_MAX_TIMEOUT_INTERVAL_SECONDS
                && mMainBufferTimeoutInSeconds != bufferDurationInSeconds) {
            mMainBufferTimeoutInSeconds = bufferDurationInSeconds;
            PreferencesUtils.storeInt(MAIN_BUFFER_PARAMS, BUFFER_TIMEOUT, mMainBufferTimeoutInSeconds);
            isNewParameterValues = true;
        }
        if (bufferQueueSize > 0
                && bufferQueueSize <= MAIN_BUFFER_MAX_QUEUE_SIZE
                && mMainBufferQueueSize != bufferQueueSize) {
            mMainBufferQueueSize = bufferQueueSize;
            PreferencesUtils.storeInt(MAIN_BUFFER_PARAMS, BUFFER_QUEUE_SIZE, mMainBufferQueueSize);
            isNewParameterValues = true;
        }
        if (bufferMaxStorageSizeMB > 0
                && bufferMaxStorageSizeMB <= MAIN_BUFFER_MAX_MAX_STORAGE_MB
                && mMainBufferMaxStorageSizeBytes != ((int) bufferMaxStorageSizeMB) * BYTES_IN_MB_FACTOR) {
            mMainBufferMaxStorageSizeBytes = (int) (bufferMaxStorageSizeMB * BYTES_IN_MB_FACTOR);
            PreferencesUtils.storeInt(MAIN_BUFFER_PARAMS, BUFFER_MAX_STORAGE, mMainBufferMaxStorageSizeBytes);
            isNewParameterValues = true;
        }
        return isNewParameterValues;
    }

    /**
     * This method retrieves and initialize main buffer with appropriate default params
     */
    private void initializeDefaultMainBufferParameters() {
        SharedPreferences sharedPreferences = PreferencesUtils.getSharedPreferencesByFileName(MAIN_BUFFER_PARAMS);
        if (sharedPreferences != null) {
            mMainBufferTimeoutInSeconds = sharedPreferences.getInt(BUFFER_TIMEOUT, MAIN_BUFFER_TIMEOUT_INTERVAL_SECONDS_DEFAULT);
            mMainBufferQueueSize = sharedPreferences.getInt(BUFFER_QUEUE_SIZE, MAIN_BUFFER_QUEUE_SIZE_DEFAULT);
            mMainBufferMaxStorageSizeBytes = sharedPreferences.getInt(BUFFER_MAX_STORAGE, MAIN_BUFFER_MAX_STORAGE_MB * BYTES_IN_MB_FACTOR);
        } else {
            mMainBufferTimeoutInSeconds = MAIN_BUFFER_TIMEOUT_INTERVAL_SECONDS_DEFAULT;
            mMainBufferQueueSize = MAIN_BUFFER_QUEUE_SIZE_DEFAULT;
            mMainBufferMaxStorageSizeBytes = MAIN_BUFFER_MAX_STORAGE_MB * BYTES_IN_MB_FACTOR;
        }
    }

    public int getBufferQueueSize() {
        return mMainBufferQueueSize;
    }

    public int getBufferDurationInSeconds() {
        return mMainBufferTimeoutInSeconds;
    }

    public float getMaxStorageSizeMB() {
        return ((float) mMainBufferMaxStorageSizeBytes / BYTES_IN_MB_FACTOR);
    }

}
