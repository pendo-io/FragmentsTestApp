package sdk.pendo.io.views.custom;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;

/**
 * A {@link Drawable} that suppots margins.
 *
 * Created by assaf on 7/18/16.
 */
public class MarginDrawable extends Drawable {

    private static final Paint TRANSPARENT_PAINT = new Paint();
    static {
        TRANSPARENT_PAINT.setColor(Color.TRANSPARENT);
    }
    private final Drawable mDrawable;
    private final int mLeft;
    private final int mTop;
    private final int mBottom;
    private final int mRight;

    private MarginDrawable(Drawable drawable, int left, int top, int right, int bottom) {
        mDrawable = drawable;

        if (left < 0) {
            mLeft = 0;
        } else {
            mLeft = left;
        }

        if (top < 0) {
            mTop = 0;
        } else {
            mTop = top;
        }

        if (right < 0) {
            mRight = 0;
        } else {
            mRight = right;
        }

        if (bottom < 0) {
            mBottom = 0;
        } else {
            mBottom = bottom;
        }

        final Rect bounds = getBounds();
        final int leftBound = bounds.left + mLeft;
        final int topBound = bounds.top + mTop;
        setBounds(leftBound, topBound,
                  leftBound + (getIntrinsicWidth() - mLeft),
                  topBound + (getIntrinsicHeight() - mTop));
    }

    @Override
    public boolean getPadding(Rect padding) {
        return mLeft != 0 || mBottom != 0 || mTop != 0 || mRight != 0;
    }

    @Override
    public int getIntrinsicHeight() {
        return mTop + mDrawable.getIntrinsicHeight() + mBottom;
    }

    @Override
    public int getIntrinsicWidth() {
        return mLeft + mDrawable.getIntrinsicHeight() + mRight;
    }

    public Drawable getDrawable() {
        return mDrawable;
    }

    @Override
    public void draw(Canvas canvas) {
        final Rect drawableBounds = mDrawable.getBounds();
        final Rect bounds = getBounds();
        drawableBounds.offsetTo(bounds.left + mLeft, bounds.top + mTop);
        mDrawable.setBounds(drawableBounds);

        canvas.drawRect(bounds, TRANSPARENT_PAINT);
        mDrawable.draw(canvas);
    }

    @Override
    public void setAlpha(int alpha) {

    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return PixelFormat.UNKNOWN;
    }

    public static final class Builder {

        private final Drawable mDrawable;
        private int mLeft = 0;
        private int mTop = 0;
        private int mRight = 0;
        private int mBottom = 0;

        public Builder(@NonNull Drawable drawable) {
            mDrawable = drawable;
        }

        public Builder setLeftMargin(int left) {
            mLeft = left;
            return this;
        }

        public Builder setTopMargin(int top) {
            mTop = top;
            return this;
        }

        public Builder setRightMargin(int right) {
            mRight = right;
            return this;
        }

        public Builder setBottomMargin(int bottom) {
            mBottom = bottom;
            return this;
        }

        public MarginDrawable build() {
            return new MarginDrawable(mDrawable, mLeft, mTop, mRight, mBottom);
        }
    }
}
