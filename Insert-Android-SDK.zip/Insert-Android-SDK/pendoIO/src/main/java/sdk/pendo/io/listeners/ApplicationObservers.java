package sdk.pendo.io.listeners;

import android.app.Activity;
import android.support.annotation.Nullable;
import android.view.View;

import com.trello.rxlifecycle3.RxLifecycle;
import com.trello.rxlifecycle3.android.ActivityEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Observable;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.reactive.filters.LifeCycleFilter;
import sdk.pendo.io.reactive.observers.InsertApplicationObservers;
import sdk.pendo.io.utilities.Optional;
import sdk.pendo.io.utilities.ViewHierarchyUtility;

/**
 * Singelton class that holds application components observables.
 * <p/>
 * Created by assaf on 7/8/15.
 */
public final class ApplicationObservers {
    private static volatile ApplicationObservers INSTANCE;
    private final InsertApplicationObservers mInsertObservers;

    private ApplicationObservers() {
        mInsertObservers = new InsertApplicationObservers(
                getActivityOnResumeObservable(),
                getActivityOnPauseObservable(),
                getActivityOnCreateObservable());
    }

    public static synchronized ApplicationObservers getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ApplicationObservers();
        }

        return INSTANCE;
    }

    private final BehaviorSubject<ActivityEvent> mLifecycle = BehaviorSubject.create();
    private final BehaviorSubject<ArrayList<Activity>> mVisibleActivities = BehaviorSubject.createDefault(new ArrayList<Activity>());
    private final BehaviorSubject<Optional<Activity>> mLastVisibleActivityNotDestroyed =
            BehaviorSubject.createDefault(new Optional<Activity>(null));
    private final BehaviorSubject<Boolean> mActivityInsideApp = BehaviorSubject.createDefault(true);
    private final AtomicBoolean mIsActivityConfigurationChanged = new AtomicBoolean(false);

    public void activityInsideApp(boolean isInside) {
        mActivityInsideApp.onNext(isInside);
    }

    public Observable<Boolean> getActivityInsideApp() {
        return mActivityInsideApp;
    }

    protected void updateLifecycleEvent(ActivityEvent lifecycleEvent) {
        mLifecycle.onNext(lifecycleEvent);
    }

    public synchronized void addVisibleActivity(Activity activity) {
        if (!mIsActivityConfigurationChanged.getAndSet(false)) {
            ArrayList<Activity> visibleActivities = mVisibleActivities.getValue();
            visibleActivities.add(activity);

            mVisibleActivities.onNext(visibleActivities);
        }
    }

    public synchronized void removeVisibleActivity(Activity activity) {
        if (!mIsActivityConfigurationChanged.getAndSet(false)) {
            ArrayList<Activity> visibleActivities = mVisibleActivities.getValue();
            visibleActivities.remove(activity);

            // If we removed the last visible activity, meaning currently no visible activities, keep
            // this last one before it gets destroyed so we'll have a reference to the last visible activity.
            if (visibleActivities.isEmpty()) {
                mLastVisibleActivityNotDestroyed.onNext(new Optional(activity));
            }

            mVisibleActivities.onNext(visibleActivities);
        }
    }

    public synchronized void removeLastVisibleActivityNotDestroyed(String activityName) {
        Optional<Activity> lastVisibleActivity = mLastVisibleActivityNotDestroyed.getValue();

        if (!lastVisibleActivity.isEmpty() && lastVisibleActivity.getValue().getLocalClassName().equals(activityName)) {
            mLastVisibleActivityNotDestroyed.onNext(new Optional(null));
        }
    }

    public synchronized Activity getLastVisibleActivityNotDestroyed() {
        return mLastVisibleActivityNotDestroyed.getValue().getValue();
    }

    public synchronized void onConfigurationChangedActivityUpdate() {
        mIsActivityConfigurationChanged.set(true);
    }

    public Observable<Activity> getActivitiesUntilLifecycleEventObservable(ActivityEvent event) {
        return mVisibleActivities
                .filter(new Predicate<List<Activity>>() {
                    @Override
                    public boolean test(List<Activity> activities) {
                        return activities != null && !activities.isEmpty();
                    }
                })
                .map(new Function<List<Activity>, Activity>() {
                    @Override
                    public Activity apply(List<Activity> activities) {
                        return activities.get(activities.size() - 1);
                    }
                })
                .compose(RxLifecycle.<Activity, ActivityEvent>bindUntilEvent(mLifecycle, event));
    }

    public Observable<ActivityEvent> getActivityOnResumeObservable() {
        return getLifecycleEventsObservable().filter(new LifeCycleFilter(ActivityEvent.RESUME));
    }

    public Observable<ActivityEvent> getActivityOnPauseObservable() {
        return getLifecycleEventsObservable().filter(new LifeCycleFilter(ActivityEvent.PAUSE));
    }

    public Observable<ActivityEvent> getActivityOnCreateObservable() {
        return getLifecycleEventsObservable().filter(new LifeCycleFilter(ActivityEvent.CREATE));
    }

    public Observable<ActivityEvent> getLifecycleEventsObservable() {
        return mLifecycle;
    }

    public ActivityEvent getCurrentLifecycleEvent() {
        return mLifecycle.getValue();
    }

    public String getCurrentActivityName() {
        Activity activity = getCurrentVisibleActivity();
        if (activity == null) {
            return null;
        }
        return activity.getLocalClassName();
    }

    public synchronized Activity getCurrentVisibleActivity() {
        List<Activity> visibleActivities = mVisibleActivities.getValue();
        int visibleActivitiesIndex = visibleActivities.size() - 1;
        if (visibleActivitiesIndex >= 0) {
            return visibleActivities.get(visibleActivitiesIndex);
        } else {
            return null;
        }
    }

    public List<Activity> getAllVisibleActivities() {
        return mVisibleActivities.getValue();
    }

    @Nullable
    public View getCurrentActivityRootView() {
        final Activity currentActivity = getCurrentVisibleActivity();

        if (currentActivity != null) {
            return ViewHierarchyUtility.INSTANCE.getCurrentRootView(currentActivity);
        }

        return null;
    }
}
