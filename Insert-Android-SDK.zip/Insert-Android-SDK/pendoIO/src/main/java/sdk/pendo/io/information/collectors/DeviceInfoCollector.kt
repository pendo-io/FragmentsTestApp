package sdk.pendo.io.information.collectors

import org.json.JSONObject
import sdk.pendo.io.information.collectors.device.*
import sdk.pendo.io.utilities.AnalyticsUtils
import sdk.pendo.io.utilities.AndroidUtils
import sdk.pendo.io.utilities.add

/**
 * Collector for device information.

 * Created by assaf on 4/2/15.
 */
internal class DeviceInfoCollector : Collector() {

    // All active device collectors:
    private val mDeviceInfoCollectors = arrayOf(
            // new Applications(),
            // new BatteryStatus(),
            BuildInfo(),
            Display(),
            // new Features(),
            Network(),
            Telephony())

    override fun collectData(json: JSONObject) {
        json.add(DEVICE_INFO, deviceInfo)
    }

    private // Iterate over all the collectors and collect their data.
    val deviceInfo: JSONObject
        get() {

            val info = JSONObject()

            var deviceId = AndroidUtils.getDeviceId()

            if (deviceId == null) {
                AnalyticsUtils.sendExceptionReport(IllegalStateException("Cannot get device id!"))
                deviceId = "ERROR"
            }
            info.add(DeviceInfoConstants.DEVICE_ID, deviceId)
            info.add(DeviceInfoConstants.ID_TYPE, "UUID")
            info.add(DeviceInfoConstants.LOCALE,
                    application!!.resources.configuration.locale.toString())
            for (collector in mDeviceInfoCollectors) {
                collector.addInformation(info)
            }

            return info
        }

    private object Holder {
        val INSTANCE = DeviceInfoCollector()
    }

    companion object {
        val DEVICE_INFO = "device_info"
        val instance: DeviceInfoCollector by lazy { Holder.INSTANCE }
    }
}
