package sdk.pendo.io.network;

import android.app.IntentService;
import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.JsonObject;

import org.jose4j.jwt.consumer.InvalidJwtException;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.concurrent.atomic.AtomicBoolean;

import external.sdk.pendo.io.okhttp3.RequestBody;
import external.sdk.pendo.io.okhttp3.ResponseBody;
import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.Retrofit;
import io.reactivex.Observable;
import io.reactivex.ObservableTransformer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Function4;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.analytics.AnalyticEventsManager;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.information.collectors.DeviceInfoCollector;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.InitModel;
import sdk.pendo.io.network.interfaces.AnalyticsData;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.network.interfaces.ErrorData;
import sdk.pendo.io.network.interfaces.GetAuthToken;
import sdk.pendo.io.network.interfaces.Init;
import sdk.pendo.io.network.interfaces.RegisterDevice;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.network.interfaces.SetupProcess;
import sdk.pendo.io.network.killswitch.KillSwitchManager;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.reactive.functions.RetryWithDelay;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.utilities.APIUtils;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.ConnectivityUtils;
import sdk.pendo.io.utilities.ReactiveUtils;

import static sdk.pendo.io.network.interfaces.RestAPI.getAccessToken;
import static sdk.pendo.io.network.responses.converters.gson.InsertGsonRequestBodyConverter.JSON_MEDIA_TYPE;

/**
 * Handles the API protocol vs the Pendo backend.
 * Holds also the state of authentication and registration.
 * This class is singleton in the system.
 */
public final class BackendApiManager {
    private static final AtomicBoolean DO_ONCE = new AtomicBoolean(true);
    private static final String INSERT_SERVER_ERROR = "{error: \"Server is not available?\"}";
    private static final int HTTP_KILL_SWITCH = 451;
    private static final int RETRY_DELAY_MILLIS = 2000;
    private static final int MAX_RETRIES = 3;
    private static final int CONNECTION_ERROR_CODE = 513;

    public enum EventsSenderSourceType {SENDER_FROM_BUFFER, SENDER_FROM_PENDING, OTHER}

    private static BehaviorSubject<Boolean> sStartedInit = BehaviorSubject.createDefault(false);
    private static final int MAX_TRIES_ERROR_500 = 3;
    private static int sErrorsRetry;
    // Holds whether the current device passed all the authentication process.
    private volatile AtomicBoolean mAuthenticated = new AtomicBoolean(true);
    private volatile AtomicBoolean mRegistered = new AtomicBoolean(false);
    private static BehaviorSubject<Boolean> sInitComplete = BehaviorSubject.createDefault(false);

    private static volatile BackendApiManager INSTANCE;
    private Disposable mConnectionObserverDisposable;

    public static synchronized BackendApiManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new BackendApiManager();
        }

        return INSTANCE;
    }

    private BackendApiManager() {
        InsertLogger.d("CTOR backendapimanager");
    }

    /**
     * Sets whether the user has been authenticated against the backend.
     *
     * @param authenticated true if authenticated, false otherwise.
     */
    private void setAuthenticated(boolean authenticated) {
        mAuthenticated.set(authenticated);
    }

    /**
     * Returns whether the user has been authenticated against the backend.
     *
     * @return true if authenticated, false otherwise.
     */
    public boolean isAuthenticated() {
        return mAuthenticated.get();
    }

    /**
     * Sets whether the user has been registered against the backend.
     *
     * @param registered true if registered, false otherwise.
     */
    private void setDeviceRegistered(boolean registered) {
        mRegistered.set(registered);
    }

    /**
     * Returns whether the user has been registered against the backend.
     *
     * @return true if registered, false otherwise.
     */
    private boolean isDeviceRegistered() {
        return mRegistered.get();
    }

    /**
     * Resets the backend manager.
     */
    private void reset() {
        setStartedInit(false);
    }

    public static Observable<Boolean> getIsStartedInitObservable() {
        return sStartedInit;
    }

    private static void setStartedInit(Boolean networkInited) {
        sStartedInit.onNext(networkInited);
    }

    //////////////////////////////////////////////////////////////////
    //
    //          Gateways
    //
    //////////////////////////////////////////////////////////////////

    /**
     * Handles the protocol of backend full initialization.
     * Takes into account whether there is currently connectivity
     * otherwise listen to connectivity change and then
     * initializes against the backend.
     *
     * @param force   should the initialization be forced
     */
    public void startBackendInitialization(boolean force) {
        if (force) {
            DO_ONCE.set(true); // Force doing the init once again.
        }
        if (ConnectivityUtils.hasConnectivity()) {
            startFullBackendInit();
        } else {
            mConnectionObserverDisposable = ConnectivityUtils.observeNetworkConnectionIsAvailable(new Consumer<Boolean>() {
                @Override
                public void accept(Boolean aBoolean) throws Exception {
                    if (SocketIOUtils.getSessionToken() != null) {
                        // In case there is a session token
                        // we should only authorize the user and not do an init process.
                        InsertLogger.d("session token is not null, ");
                        SocketIOUtils.handleMarketerDeviceInit(true, true);
                    } else {
                        // Otherwise we have a standard init against the backend.
                        startBackendInitialization(false);
                    }
                    mConnectionObserverDisposable.dispose();
                }
            });
        }
    }


    /**
     * Start a full backend initialization.
     * schedules the action on a worker thread.
     */
    private void startFullBackendInit() {
        if (DO_ONCE.getAndSet(false)) {
            ReactiveUtils.schedule(new FullBackendInitAction());
        } else {
            InsertLogger.d("Test - Tried to init again.");
        }
    }

    /**
     * Sends analytics information to the backend.
     * schedules the action on a worker thread.
     *
     * @param analyticEvents     string of Json object of analytics events to be sent
     * @param authIfNeeded authenticate against the backend
     *                     in case the device is currently not authenticated.
     */
    public void sendAnalytics(String analyticEvents, boolean authIfNeeded, String endPointUrl) {
        ReactiveUtils.schedule(new SendAnalyticsAction(analyticEvents, authIfNeeded, endPointUrl));
    }


    /**
     * Starts this service to send device info to backend. If the service is already performing a
     * task this action will be queued.
     *
     * @see IntentService
     */
    public void startDeviceAuth() {
        ReactiveUtils.schedule(new GetAccessTokenAction());
    }


    /**
     * Starts this service to send device info to backend. If the service is already performing a
     * task this action will be queued.
     *
     * @see IntentService
     */
    public void sendErrorReport(final String errorInfo) {
        if (!TextUtils.isEmpty(errorInfo) && isAuthenticated() && sErrorsRetry < MAX_TRIES_ERROR_500) {
            ReactiveUtils.schedule(new SendErrorReportAction(errorInfo));
        }
    }

    /**
     * Sends a setup result to the backend.
     *
     * @param json the json request to be sent
     */
    public void sendSetupResult(JSONObject json, boolean isInitActions, boolean isAccountData, boolean isUserData) {
        try {
            json.put(AnalyticsProperties.TIMESTAMP, System.currentTimeMillis());
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
        RequestBody jsonRequest = APIUtils.INSTANCE.getRequestBody(json.toString());
        ReactiveUtils.schedule(new SendSetupResultAction(jsonRequest, isInitActions, isAccountData, isUserData));
    }

    /**
     * Sends a debug data to the backend.
     *
     * @param jsonRequest the json request to be sent
     */
    public void sendDebugData(JSONObject jsonRequest) {
        ReactiveUtils.schedule(new DebugDataResultAction(jsonRequest));
    }

    //////////////////////////////////////////////////////////////////
    //
    //          Actions
    //
    //////////////////////////////////////////////////////////////////

    private class GetAccessTokenAction extends ApiAction {

        @Override
        protected void execute() {
            executeGetAuthToken();
        }
    }

    private class FullBackendInitAction extends ApiAction {
        @Override
        public void execute() {
            reset();
            if (executeGetAuthToken()) {
                executeSetupFromBackend();
                Observable.zip(SetupManager.getInstance().getAccountDataSent().filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean accountDataSent) {
                                return accountDataSent;
                            }
                        }), SetupManager.getInstance().getUserDataSent().filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean userDataSent) {
                                return userDataSent;
                            }
                        }), SetupManager.getInstance().getIsFinishedInitActionsSubject().filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean finishedSendingInitActions) {
                                return finishedSendingInitActions;
                            }
                        }), SetupManager.getInstance().getIsFinishedSendingPersistedAnalytics().filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean finishedSendingPersistedAnalytics) {
                                return finishedSendingPersistedAnalytics;
                            }
                        }),
                        new Function4<Boolean, Boolean, Boolean, Boolean, Boolean>() {
                            @Override
                            public Boolean apply(Boolean accountDataSet,
                                                 Boolean userDataSent,
                                                 Boolean finishedSendingInitActions,
                                                 Boolean finishedSendingPendingAnalytics) {
                                return accountDataSet && userDataSent && finishedSendingInitActions && finishedSendingPendingAnalytics;
                            }
                        }).firstElement().subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) {
                        boolean isSuccessful = executeInitFromBackend();
                        InsertLogger.v("Execute init from backend successful = '"
                                + isSuccessful + "'.");
                    }
                }));
            }
        }
    }

    /**
     * Rx action which handles sending the error data information to the backend
     */
    private class SendErrorReportAction extends ApiAction {

        private String mErrorInfo;

        SendErrorReportAction(String errorInfo) {
            mErrorInfo = errorInfo;
        }

        @Override
        protected void execute() {
            executeErrorReport(mErrorInfo);
        }
    }

    /**
     * Rx action which handles sending the analytics information to the backend
     */
    private class SendAnalyticsAction extends ApiAction {
        private String mAnalyticEvents;
        private boolean mAuthIfNeeded;
        private String mEndPointUrl;

        SendAnalyticsAction(String  analyticEvents, boolean authIfNeeded, String endpointUrl) {
            mAnalyticEvents = analyticEvents;
            mAuthIfNeeded = authIfNeeded;
            mEndPointUrl = endpointUrl;
        }

        @Override
        protected void execute() {
            if (mAnalyticEvents != null && !mAnalyticEvents.isEmpty()) {
                Retrofit retrofit = RestAPI.getAnalyticsRetrofit();
                if (retrofit == null) {
                    InsertLogger.d("Cannot get analytics retrofit.");
                    return;
                }
                if (TextUtils.isEmpty(mEndPointUrl)) {
                    mEndPointUrl = "v" + RestAPI.REST_API_VERSION + "/devices/analyticsData";
                }
                String accessToken = getAccessToken();
                if (TextUtils.isEmpty(accessToken)) {
                    InsertLogger.d("accessToken is empty!");
                    RestAPI.getAccessTokenObservable()
                            .firstElement()
                            .subscribe(InsertMaybeObserver.create(new Consumer<String>() {
                                @Override
                                public void accept(String s) {
                                    sendAnalytics(mAnalyticEvents, false, mEndPointUrl);
                                }
                            }));
                    return;
                }
                AnalyticsData analyticsData = retrofit.create(AnalyticsData.class);
                final RequestBody requestBody = APIUtils.INSTANCE.getRequestBody(
                        new StringBuilder().append("[").append(mAnalyticEvents).append("]").toString());
                final Response<ResponseBody> sendCall = createRequest(
                        analyticsData.send(mEndPointUrl, requestBody));
                // In case analyticsValidator in backend is turned on and we have an analytics
                // problem, it will be logged as: "analyticsValidator error: <<Error here>>"
                if (!sendCall.isSuccessful()) {
                    InsertLogger.d("Failed sending analytics: code = '"
                            + sendCall.code() + "' error: '"
                            + sendCall.errorBody() + "'.");

                    // TODO: 2019-12-19 This parameter{mAuthIfNeeded} is probably not useful in fact that before each send action we already check accessToken
                    if (mAuthIfNeeded && TextUtils.isEmpty(getAccessToken())) {
                        String errorBody = "";

                        try {
                            errorBody = APIUtils.INSTANCE.getResponseBodyAsString(sendCall.errorBody());
                            errorBody = JsonWebTokenValidator.INSTANCE.validate(errorBody);
                            if (sendCall.code() == HttpURLConnection.HTTP_UNAUTHORIZED) {
                                if (executeGetAuthToken()) {
                                    sendAnalytics(mAnalyticEvents, false, mEndPointUrl);
                                }
                            }
                        } catch (InvalidJwtException e) {
                            AnalyticsUtils.sendJwtSecurityException(errorBody, "Analytics", e.getMessage());
                        } catch (IOException e) {
                            InsertLogger.e(e, e.getMessage());
                        }
                    } else {
                        AnalyticEventsManager.getInstance().handleSendAnalyticsEventsResponse(false);
                    }
                } else {
                    AnalyticEventsManager.getInstance().handleSendAnalyticsEventsResponse(true);
                }
            }
        }
    }

    /**
     * Rx action which handles sending the setup result to the backend
     */
    private class SendSetupResultAction extends ApiAction {
        private RequestBody mResponseJson;
        private boolean mIsInitActions;
        private boolean mIsAccountData;
        private boolean mIsUserData;

        SendSetupResultAction(RequestBody responseJson, boolean isInitAction, boolean isAccountData, boolean isUserData) {
            mResponseJson = responseJson;
            mIsInitActions = isInitAction;
            mIsAccountData = isAccountData;
            mIsUserData = isUserData;
        }

        @Override
        protected void execute() {

            // Wait for access token before sending.
            //noinspection ResultOfMethodCallIgnored
            try {
                RestAPI.getAccessTokenObservable().blockingFirst();
            } catch (Exception e) {
                InsertLogger.w(e, "Cannot get access token, not sending '" + mResponseJson.toString() + "'.");
                return;
            }

            Retrofit.Builder retrofitBuilder = RestAPI.getSetupActionRetrofitBuilder();
            if (retrofitBuilder == null) {
                InsertLogger.w("Cannot create a retrofit builder.");
                return;
            }

            Retrofit retrofit = retrofitBuilder.build();
            SetupProcess setupProcessData = retrofit.create(SetupProcess.class);
            final Response<ResponseBody> sendResponse = createRequest(setupProcessData.send(mResponseJson));
            if (sendResponse.isSuccessful()) {
                InsertLogger.i("Sent, status code: " + sendResponse.code());
                if (mIsInitActions) {
                    SetupManager.getInstance().getIsFinishedInitActionsSubject().onNext(true);
                }
                if (mIsAccountData) {
                    SetupManager.getInstance().setAccountDataSent(true);
                }
                if (mIsUserData) {
                    SetupManager.getInstance().setUserDataSent(true);
                }
            } else {
                InsertLogger.d("Failed to send: status code = " + sendResponse.code()
                        + " error: " + sendResponse);
            }
        }
    }

    private class DebugDataResultAction extends ApiAction {
        private JSONObject mJsonRequest;

        DebugDataResultAction(JSONObject jsonRequest) {
            super();
            mJsonRequest = jsonRequest;
        }

        @Override
        protected void execute() {
            RequestBody jsonList = APIUtils.INSTANCE.getRequestBody(mJsonRequest.toString());
            Retrofit retrofit = RestAPI.getAnalyticsRetrofit();

            if (retrofit == null) {
                InsertLogger.w("Cannot create retrofit.");
                return;
            }

            SetupProcess setupProcessData = retrofit.create(SetupProcess.class);
            final Response<ResponseBody> sendCall = createRequest(setupProcessData.sendDebugData(jsonList));

            if (sendCall.isSuccessful()) {
                InsertLogger.i("Sent, status code: " + sendCall.code());
            } else {
                InsertLogger.d("Failed to send: status code = " + sendCall.code()
                        + " error: " + sendCall);
            }
        }

    }

    //////////////////////////////////////////////////////////////////
    //
    //          Executors
    //
    //////////////////////////////////////////////////////////////////

    private void executeErrorReport(String errorInfo) {
        if (isAuthenticated()) {
            Retrofit retrofit = RestAPI.getAnalyticsRetrofit();

            if (retrofit == null) {
                InsertLogger.d("Cannot get analytics retrofit.");
                return;
            }

            ErrorData errorData = retrofit.create(ErrorData.class);

            if (TextUtils.isEmpty(errorInfo)) {
                return;
            }

            final RequestBody requestBody = APIUtils.INSTANCE.getRequestBody(errorInfo);
            final Response<ResponseBody> sendResponse = createRequest(errorData.send(requestBody));
            handleErrorReportResponse(sendResponse);
        }
    }

    private void handleErrorReportResponse(Response<ResponseBody> sendResponse) {

        if (sendResponse == null) {
            InsertLogger.d("Response is null. Cannot send error.");
            return;
        }

        if (!sendResponse.isSuccessful()) {
            if (sendResponse.code() == HttpURLConnection.HTTP_INTERNAL_ERROR) {
                sErrorsRetry++;
            }
            InsertLogger.d("Cannot send error! status = " + sendResponse.code()
                    + " error: ");
        }
    }

    public void executeSetupFromBackend() {
        Retrofit.Builder retrofitBuilder = RestAPI.getSetupActionRetrofitBuilder();

        if (retrofitBuilder == null) {
            InsertLogger.w("Cannot create retrofit setup builder.");
            return;
        }
        Retrofit retrofit = retrofitBuilder.build();

        SetupProcess setupProcessData = retrofit.create(SetupProcess.class);

        Response<JsonObject> setupResponse = createRequest(setupProcessData.getSetup());
        handleSetupResponse(setupResponse);
    }

    private void handleSetupResponse(Response<JsonObject> setupResponse) {
        if (setupResponse != null && setupResponse.isSuccessful()) {
            SetupManager.getInstance().initSetupManager(setupResponse.body());
            setStartedInit(true);
        } else {
            InsertLogger.d("Setup response is not successful");
        }
    }

    /**
     * Handle get inserts from the backend action in the provided background thread.
     */
    private boolean executeInitFromBackend() {
        boolean isSuccessful = false;
        InsertLogger.i("Initializing SDK against the backend.");

        // Create a REST adapter which points the Pendo API.
        Init init = null;
        try {
            Retrofit retrofit = RestAPI.getRetrofitGetInserts();
            if (retrofit == null) {
                return false;
            }
            init = retrofit.create(Init.class);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        if (init != null) {
            Response<InitModel> initModelResponse = createRequest(init.initSdk());
            isSuccessful = handleInitResponse(initModelResponse);
        }

        return isSuccessful;
    }

    public static void setInitProcessComplete(boolean isInitComplete) {
        sInitComplete.onNext(isInitComplete);
    }

    public static Observable<Boolean> getIsInitCompleteAsObservable() {
        return sInitComplete;
    }

    private boolean handleInitResponse(@NonNull Response<InitModel> initModelResponse) {
        boolean isSuccessful = initModelResponse.isSuccessful();
        if (isSuccessful) {
            final InitModel initModel = initModelResponse.body();
            Pendo.storeSessionTimeout(initModel);
            initModel.init();
            if (!RestAPI.getNetworkInited()) {
                RestAPI.setNetworkInited(true);
            }
        } else {
            APIUtils.INSTANCE.logBackendError(initModelResponse.errorBody(),
                    initModelResponse.code());
        }
        return isSuccessful;
    }

    /**
     * Handle get inserts from the backend action in the provided background thread.
     *
     * @return boolean representing if the
     */
    private boolean executeGetAuthToken() {

        InsertLogger.i("Init against the backend.");

        // Create a REST adapter which points the Pendo API.
        Retrofit retrofit = RestAPI.getRetrofitGetAccessToken();
        if (retrofit == null) {
            return false;
        }

        GetAuthToken getAccessTokenCall = retrofit.create(GetAuthToken.class);

        Response<GetAuthToken.GetAuthTokenResponse> response =
                createRequest(getAccessTokenCall.getAccessTokenSigned());
        return handleGetAccessTokenResponse(response);
    }

    private boolean handleGetAccessTokenResponse(
            Response<GetAuthToken.GetAuthTokenResponse> response) {
        boolean isSuccessful = false;

        if (response == null) {
            setAuthenticated(false);
            setDeviceRegistered(false);
            return false;
        }

        if (response.isSuccessful()) {
            String accessToken = response.body().accessToken;
            RestAPI.setAccessToken(accessToken);
            if (!TextUtils.isEmpty(accessToken)) {
                isSuccessful = true;
            }

            Log.i(Pendo.TAG, "Pendo Mobile SDK was successfully"
                    + " integrated and connected to the server."
                    + " App version identified: '" + AndroidUtils.getAppVersionName() + "'.");
        } else {
            String errorBody = "";
            try {
                errorBody = APIUtils.INSTANCE.getResponseBodyAsString(response.errorBody());
                errorBody = JsonWebTokenValidator.INSTANCE.validate(errorBody);
                APIUtils.INSTANCE.logBackendError(response.errorBody(), response.code());

                final int statusCode = response.code();
                if (statusCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
                    // In case we get 401 in an get access token call
                    // we need to register device.
                    if (!isDeviceRegistered()) {
                        // In case the device is not registered,
                        // lets register it and turn successful
                        // if register + internal get access token succeed.
                        isSuccessful = executeDeviceRegisterToBackend();
                    }
                } else if (statusCode == HttpURLConnection.HTTP_INTERNAL_ERROR) {
                    // in case we get 500 in an init
                    // call the system will not operate in this session
                    InsertLogger.d("Error code: " + statusCode);
                } else if (statusCode == HTTP_KILL_SWITCH) {
                    InsertLogger.d("Test got kill switch http code");
                    // In case we get 451 in an auth token
                    // call it means the backend sent us a kill switch operation.
                    // validate it and keep it for next sessions.
                    isSuccessful = !KillSwitchManager.handleKillSwitchResponse(response.errorBody());
                }
            } catch (InvalidJwtException e) {
                AnalyticsUtils.sendJwtSecurityException(errorBody, "getAccessTokenSigned", e.getMessage());
            } catch (IOException e) {
                InsertLogger.e(e, e.getMessage());
            }

        }
        setAuthenticated(isSuccessful);
        setDeviceRegistered(isSuccessful);
        return isSuccessful;
    }

    /**
     * Sends the device info to the backend.
     */
    private boolean executeDeviceRegisterToBackend() {
        boolean isSuccessful = false;

        Pendo pendo = Pendo.getInstance();
        if (pendo != null) {

            JSONObject data = new JSONObject();
            Context applicationContext = Pendo.getApplicationContext();
            if (applicationContext != null) {

                DeviceInfoCollector deviceInfoCollector = pendo.deviceInformationCollector();
                deviceInfoCollector.addInformation(data);

                try {
                    JSONObject deviceInfo = data.getJSONObject(DeviceInfoCollector.Companion
                            .getDEVICE_INFO());
                    RequestBody json = APIUtils.INSTANCE.getRequestBody(deviceInfo.toString());

                    // Create a REST adapter which points the Pendo API.
                    Retrofit retrofit = RestAPI.getRetrofitRegister();
                    if (retrofit == null) {
                        return false;
                    }

                    RegisterDevice registerDevice = retrofit.create(RegisterDevice.class);

                    try {
                        Response<RegisterDevice.RegisterDeviceResponse> registerDeviceResponse =
                                createRequest(registerDevice.registerDevice(json));
                        isSuccessful = handleRegisterDeviceResponse(registerDeviceResponse);
                    } catch (IOException e) {
                        InsertLogger.d(e, e.getMessage());
                    }

                } catch (JSONException e) {
                    InsertLogger.e(e, e.getMessage());
                }

            } else {
                InsertLogger.e("Application context is null.");
            }
        } else {
            InsertLogger.e("Pendo instance is null.");
        }
        return isSuccessful;
    }

    private boolean handleRegisterDeviceResponse(
            Response<RegisterDevice.RegisterDeviceResponse> registerDeviceResponse)
            throws IOException {
        boolean isSuccessful = registerDeviceResponse.isSuccessful();

        if (isSuccessful) {
            InsertLogger.d("Registered the device, got id: "
                    + registerDeviceResponse.body().id);
            setDeviceRegistered(true);
            // The registration is successful, try to get the access token
            isSuccessful = executeGetAuthToken();

        } else {
            // The device is not authenticated for this session.
            final ResponseBody error = registerDeviceResponse.errorBody();
            APIUtils.INSTANCE.logBackendError(error, registerDeviceResponse.code());
            setAuthenticated(false);
            setDeviceRegistered(false);
            InsertLogger.d("Error registering the device: " + error.string());
        }
        return isSuccessful;
    }

    @NonNull
    private <T> Response<T> createRequest(Observable<Response<T>> responseObservable) {
        return responseObservable.compose(this.<T>getTransformer())
                .blockingFirst();
    }

    @NonNull
    private <T> ObservableTransformer<Response<T>, Response<T>> getTransformer() {
        return new ObservableTransformer<Response<T>, Response<T>>() {
            @Override
            public Observable<Response<T>> apply(
                    Observable<Response<T>> responseObservable) {
                return responseObservable
                        .retryWhen(new RetryWithDelay(MAX_RETRIES, RETRY_DELAY_MILLIS))
                        .onErrorReturn(new Function<Throwable, Response<T>>() {
                            @Override
                            public Response<T> apply(Throwable throwable) {
                                // If an error was caused after the retries, ignore the call.
                                return Response.error(CONNECTION_ERROR_CODE,
                                        ResponseBody
                                                .create(JSON_MEDIA_TYPE, INSERT_SERVER_ERROR));
                            }
                        })
                        .subscribeOn(Schedulers.io());
            }
        };
    }
}
