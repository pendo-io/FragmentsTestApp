package sdk.pendo.io.views.wrapper;

import android.support.annotation.Nullable;
import android.view.View;

import java.lang.ref.WeakReference;

/**
 * View wrapper base class.
 * Created by assaf on 12/8/15.
 */
public abstract class ViewWrapperBase {

    private WeakReference<View> mView;

    public ViewWrapperBase(View view) {
        set(view);
    }

    public final void set(View view) {
        mView = new WeakReference<>(view);
    }

    @Nullable
    public final View getView() {
        return mView.get();
    }
}
