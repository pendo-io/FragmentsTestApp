package sdk.pendo.io.async;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;
import android.view.ViewGroup;

import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import sdk.pendo.io.network.responses.ScreenIdentificationData;
import sdk.pendo.io.network.socketio.actions.PrepareToReceiveAction;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.ViewHierarchyUtility;
import sdk.pendo.io.utilities.ViewUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by assaf on 4/6/15.
 */
public class CaptureScreenTask extends AsyncTask<View, Void, Bitmap> {

    private JSONArray mViewTreeJSON;

    private Activity mActivity;
    private final CaptureScreenListener mCaptureListener;
    public interface CaptureScreenListener{
        void onPreCaptureScreen();
        void onScreenCaptured();
    }

    public CaptureScreenTask(Activity activity, CaptureScreenListener listener) {
        mActivity = activity;
        mCaptureListener = listener;
    }

    @Override
    protected void onPreExecute() {

        if (mCaptureListener != null) {
            mCaptureListener.onPreCaptureScreen();
        }
    }

    @Override
    protected Bitmap doInBackground(final View... params) {
        Bitmap screenshotBitmap = null;
        try {
            ScreenManager.INSTANCE.generateAndStoreCapturedScreenData();

            View view = params[0];
            if (view instanceof ViewGroup) {
                final Pair<JSONArray, JSONArray> arrayPair = generateViewTreeAndScreenState(view);

                if (arrayPair != null) {
                    mViewTreeJSON =
                            arrayPair.getLeft();
                }
            } else {
                mViewTreeJSON = new JSONArray();
            }


            try {
                screenshotBitmap = ViewUtils.takeScreenshot(view, mActivity); // FIXME: 1/4/16 Do all of this in RxJava
            } finally {
                mActivity = null;
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return screenshotBitmap;
    }

    protected ScreenIdentificationData generateScreenId(Activity activity) {
        return new ScreenIdentificationData(mActivity);
    }

    protected Pair<JSONArray, JSONArray> generateViewTreeAndScreenState(View view) {
        return ViewHierarchyUtility.INSTANCE
                            .getViewTreeAndScreenState(view);
    }

    protected final JSONArray getViewTree() {
        return mViewTreeJSON;
    }

    protected final CaptureScreenListener getCaptureListener(){
        return mCaptureListener;
    }


    @Override
    protected void onPostExecute(Bitmap bitmap) {
        try {
            prepareScreenData(bitmap);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            if (mCaptureListener != null) {
                mCaptureListener.onScreenCaptured();
            }
        }
    }

    protected void prepareScreenData(Bitmap bitmap) throws JSONException {
        PrepareToReceiveAction.prepareToReceiveScreenAndSend(
                getViewTree(),
                bitmap);
    }
}

