package sdk.pendo.io.logging.profiling;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.network.responses.ElementModel;
import sdk.pendo.io.network.responses.TriggerModel;
import sdk.pendo.io.utilities.InsertProfiler;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Holds the inserts, screens and elements information.
 */
public class InsertsInfoProfiler implements InsertProfiler {

    @Override
    public final String[] getStats() {
        List<String> logs = new ArrayList<>();
        InsertEvent appLaunchEvent = EventsManager.getInstance().getAppLaunchEvent();
        if (appLaunchEvent != null) {
            for (TriggerModel trigger : appLaunchEvent.getTriggers()) {
                logs.add("Application event;insert " + trigger.getInsertIds());
            }
        }

        HashMap<String, List<ElementModel>> screenToElementMapping = EventsManager.getInstance().getScreenToElementMapping();
        for (Map.Entry<String, List<ElementModel>> entry : screenToElementMapping.entrySet()) {
            logs.add("Screen " + entry.getKey());
            List<ElementModel> elementModels = entry.getValue();
            for (ElementModel element : elementModels) {
                try {
                    String data = "";
                    IdentificationData identificationData = element.configuration.getIdentificationData();
                    if (identificationData != null) {
                        data = ";data: " + identificationData.toJSON().toString();
                    }
                    logs.add(genrateIndentedLine(1, "Element " + element.id + "/" + element.name + data));
                } catch (JSONException e) {
                    InsertLogger.e(e, e.getMessage());
                }
                if (element.events != null) {
                    for (InsertEvent event : element.events) {
                        logs.add(genrateIndentedLine(2, "Event " + event.getConfiguration().getAction()));
                        if (event.getTriggers() != null) {
                            for (TriggerModel trigger : event.getTriggers()) {
                                logs.add(genrateIndentedLine(3, "Trigger;insert " + trigger.getInsertIds()));
                            }
                        }
                    }
                }
            }
        }
        return logs.toArray(new String[logs.size()]);
    }

    /**
     * Generates a string which is indendent by the level parameter.
     * @param level - the level of indentation
     * @param message - the string to be appended
     * @return
     */
    private String genrateIndentedLine(int level, String message) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < level; i++) {
            builder.append("    ");
        }
        builder.append(message);
        return builder.toString();
    }

    @Override
    public void mark(String message) {

    }
}
