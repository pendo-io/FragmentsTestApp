package sdk.pendo.io.utilities;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Looper;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.PendoTouchDelegate;
import sdk.pendo.io.listeners.views.InsertDrawerListener;
import sdk.pendo.io.listeners.views.InsertOnItemClickListener;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Utility class for Views.
 * <p>
 * Created by assaf on 5/7/15.
 */
public final class ViewUtils {

    // This is the name of the tabview class used for identification purposes
    public static final String TAB_VIEW_CLASS_NAME = "tabview";

    private ViewUtils() {
    }

    private static final TypedValue S_VALUE = new TypedValue();

    public static Rect getViewVisibleRect(View view) {
        Rect displayRect = new Rect();
        Rect viewRect = new Rect();

        try {
            view.getWindowVisibleDisplayFrame(displayRect);
        } catch (Exception e) {
            InsertLogger.d(e, "Attempt to read from field mVisibleInsets on a null attachInfo of the view in question.");
        }
        boolean visible = view.getGlobalVisibleRect(viewRect);

        if (!visible) {
            InsertLogger.d("Not Visible.");
            return viewRect;
        }

        boolean intersect = displayRect.intersect(viewRect);

        InsertLogger.d("Intersects? " + intersect);

//        int act = getActionBarHeight();
//
//        if (act > 0) {
//            act += getStatusBarHeight();
//        }
//
//        if (displayRect.top < act) {
//            displayRect.top = act;
//        }

        return intersect ? displayRect : viewRect;
    }

    public static boolean isViewInsideDisplay(View view) {
        try {
            if (view.getVisibility() == View.GONE) {
                return false;
            }
            Rect displayRect = new Rect();
            Rect viewRect = new Rect();
            view.getWindowVisibleDisplayFrame(displayRect);
            boolean inSide = view.getGlobalVisibleRect(viewRect);
            return inSide && Rect.intersects(displayRect, viewRect);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
            return false;
        }

//        int[] viewLocation = new int[2];
//        view.getLocationOnScreen(viewLocation);
//
//        /**
//         * Out side of window visible display cases:
//         *
//         *                 |----T----|
//         *                 L Case 1  R
//         *                 |____B____|
//         *             |-------TOP-------|
//         *             |                 |
//         *             |                 |
//         * |----T----| |                 |  |----T----|
//         * L Case 2  R LEFT           RIGHT L Case 3  R
//         * |____B____| |                 |  |____B____|
//         *             |                 |
//         *             |                 |
//         *             |                 |
//         *             |                 |
//         *             |                 |
//         *             |_____BOTTOM______|
//         *                 |----T----|
//         *                 L Case 4  R
//         *                 |____B____|
//         */
//        // Case 1:
//        if (viewLocation[1] + view.getHeight() <= displayRect.top) {
////            InsertLogger.d("Outside: Above.");
//            return false;
//        }
//
//        // Case 2:
//        if (viewLocation[0] + view.getWidth() <= displayRect.left) {
////            InsertLogger.d("Outside: Left.");
//            return false;
//        }
//
//        // Case 3:
//        if (viewLocation[0] >= displayRect.right) {
////            InsertLogger.d("Outside: Right.");
//            return false;
//        }
//
//        // Case 4:
//        if (viewLocation[1] >= displayRect.bottom) {
////            InsertLogger.d("Outside: Below.");
//            return false;
//        }
//
//        return true;
    }

    /**
     * Get the string representation of the view's ID.
     *
     * @param view The view.
     * @return String representation of the view's ID (if available).
     */
    @Nullable
    public static String getViewId(View view) {
        try {
            int id = view.getId();
            if (id != View.NO_ID) {
                return view.getResources().getResourceName(id);
            }
        } catch (Exception ignore) {
            InsertLogger.d(ignore.getMessage());
        }
        return null;
    }

    public static int getNavigationBarHeight() {
        Resources resources = ResourceUtils.getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return resources.getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    public static int getStatusBarHeight() {
        int result = 0;
        Resources resources = ResourceUtils.getResources();
        int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId);
        }
        return result;
    }

    @Nullable
    public static View findViewById(View view, String id) {

        int viewId = ResourceUtils.getIdFromString(id);
        if (viewId != View.NO_ID) {
            return view.findViewById(viewId);
        }

        return null;
    }

    public static int getViewPositionInList(View v) {

        View parentChild = v;
        ViewParent parent = v.getParent();
        while (parent != null) {

            if (parent instanceof View) {
                Integer positionInList = getPositionInList((View) parent, parentChild);
                if (positionInList != null) {
                    return positionInList;
                }

                parentChild = (View) parent;
            }
            parent = parent.getParent();
        }

        return -1;
    }

    /**
     * If {@code view} (or one of its "parents") is in a {@link RecyclerView} set its
     * {@link RecyclerView.ViewHolder#setIsRecyclable(boolean)} to {@code isRecyclable}.
     *
     * @param view         the view to start the search for.
     * @param isRecyclable sets whether the cell is recyclable or not.
     */
    public static void setIsRecyclableView(final View view, boolean isRecyclable) {

        View parentChild = view;
        ViewParent parent = view.getParent();
        while (parent != null) {

            if (parent instanceof View) {
                if (parent instanceof RecyclerView) {
                    final RecyclerView.ViewHolder childViewHolder = ((RecyclerView) parent)
                            .getChildViewHolder(parentChild);
                    childViewHolder.setIsRecyclable(isRecyclable);
                    return;
                }

                parentChild = (View) parent;
            }
            parent = parent.getParent();
        }
    }

    @Nullable
    public static Integer getPositionInList(View parent, View parentChild) {
        if (parent instanceof AbsListView) {
            return ((AbsListView) parent).getPositionForView(parentChild);
        } else if (parent instanceof RecyclerView) {
            return ((RecyclerView) parent).getChildLayoutPosition(parentChild);
        }
        return null;
    }

    public static boolean isViewInsideList(final View view) {
        return getParentList(view) != null;
    }

    @Nullable
    public static View getParentList(final View view) {
        if (view == null) {
            return null;
        }

        ViewParent viewParent = view.getParent();

        if (viewParent instanceof View) {

            View parent = (View) viewParent;
            if (isViewAKnownList(parent)) {
                return parent;
            } else {
                return getParentList(parent); // Recursive call.
            }
        }

        return null;
    }

    public static boolean isViewAKnownList(View view) {
        return view instanceof AbsListView
                || view instanceof RecyclerView;
    }

    protected static void setTouchDelegateOnView(final View view) {
        final View parent = (View) view.getParent();
        parent.post(new Runnable() {
            @Override
            public void run() {
                Rect hit = new Rect();
                view.getHitRect(hit);
                TouchDelegate originalTouchDelegate = view.getTouchDelegate();
                PendoTouchDelegate pendoDelegate = new PendoTouchDelegate(hit, view);
                if (originalTouchDelegate != null) {
                    if (originalTouchDelegate instanceof PendoTouchDelegate) {
                        return;
                    }
                    pendoDelegate.setOriginalTouchDelegate(originalTouchDelegate);
                }
                view.setTouchDelegate(pendoDelegate);
            }
        });
    }

    protected synchronized static void setDrawerListenerForDrawerLayout(DrawerLayout drawerLayout) {

        Object listener =
                InsertDrawerListener.extractDrawerListener(drawerLayout);

        if (listener instanceof ArrayList) {
            ArrayList arrayList = (ArrayList) listener;
            for (int i = (arrayList.size() - 1); i >= 0; i--) {
                if (arrayList.get(i) instanceof InsertDrawerListener) {
                    return;
                }
            }

            InsertDrawerListener drawerListener = new InsertDrawerListener(drawerLayout);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                drawerLayout.addDrawerListener(drawerListener);
            }
        } else if (listener != null && !(listener instanceof InsertDrawerListener)) {

            InsertDrawerListener drawerListener = new InsertDrawerListener(drawerLayout);
            drawerListener.addListener((DrawerLayout.DrawerListener) listener);
            drawerLayout.setDrawerListener(drawerListener);
        }
    }

    protected static void setOnHierarchyChangeListenerForScrollView(ScrollView view) {
        view.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {

            @Override
            public void onChildViewAdded(View parent, View child) {
                InsertLogger.i("parent = " + parent.toString()
                        + " child = " + child.toString());
            }

            @Override
            public void onChildViewRemoved(View parent, View child) {
                InsertLogger.i("parent = " + parent.toString()
                        + " child = " + child.toString());
            }
        });
    }

    protected static void setOnItemClickListenerForGridOrListView(AbsListView listOrGridView) {
        AdapterView.OnItemClickListener onItemClickListener = listOrGridView.getOnItemClickListener();
        if (onItemClickListener != null && !(onItemClickListener instanceof InsertOnItemClickListener)) {

            InsertOnItemClickListener ic = new InsertOnItemClickListener();
            ic.addListener(onItemClickListener);
            listOrGridView.setOnItemClickListener(ic);
        }
    }

    protected static void setAdapterDataSetObserverForGridOrListView(AbsListView listOrGridView) {
        ListAdapter adapter = listOrGridView.getAdapter();
//        InsertLogger.i("View is ListView.");
        if (adapter != null) {
//            InsertLogger.i("Adapter is not null.");
            adapter.registerDataSetObserver(new DataSetObserver() {
                @Override
                public void onChanged() {
                    super.onChanged();
//                    InsertLogger.i("CHANGED!");
                }
            });
        }
    }

//    @Nullable
//    public static CharSequence getTextForView(@Nullable View view) {
//
//        final Bundle result = new Bundle();
//        ViewHierarchyUtility.ViewCallback getTextForView = new ViewHierarchyUtility.ViewCallback() {
//
//            @Override
//            public boolean performActionOnView(@Nullable View view, Bundle oBundle) {
//
//                if (view == null) {
//                    return false;
//                }
//
//                if (view instanceof TextView) {
//                    result.putCharSequence("result", ((TextView) view).getText());
//                    return true;
//                }
//
//                return false;
//            }
//
//            @Override
//            public String getType() {
//                return "getTextForView";
//            }
//        };
//
//        ViewHierarchyUtility.traverseViewHierarchy(view, getTextForView);
//
//        return result.getCharSequence("result");
//    }
//
//    @Nullable
//    public static ArrayList<CharSequence> getAllTextForView(@Nullable View view) {
//
//        final Bundle result = new Bundle();
//        ViewHierarchyUtility.ViewCallback getTextForView = new ViewHierarchyUtility.ViewCallback() {
//
//            @Override
//            public boolean performActionOnView(@Nullable View view, Bundle oBundle) {
//
//                if (view == null || view.getVisibility() != View.VISIBLE) {
//                    return false;
//                }
//
//                if (view instanceof TextView) {
//
//                    ArrayList<CharSequence> list = result.getCharSequenceArrayList("result");
//
//                    if (list == null) {
//                        list = new ArrayList<>();
//                    }
//
//                    list.add(((TextView) view).getText());
//                    result.putCharSequenceArrayList("result", list);
//                }
//
//                return false;
//            }
//
//            @Override
//            public String getType() {
//                return "getTextForView";
//            }
//        };
//
//        ViewHierarchyUtility.traverseViewHierarchy(view, getTextForView);
//
//        return result.getCharSequenceArrayList("result");
//    }
//
//    public static boolean findTextInView(@Nullable View view, @Nullable final CharSequence text) {
//
//        if (view == null || text == null) {
//            return false;
//        }
//
//        final Bundle result = new Bundle();
//        ViewHierarchyUtility.ViewCallback findTextInView = new ViewHierarchyUtility.ViewCallback() {
//
//            @Override
//            public boolean performActionOnView(@Nullable View view, Bundle oBundle) {
//
//                if (view == null) {
//                    return false;
//                }
//
//                if (view instanceof TextView) {
//
//                    CharSequence viewText = ((TextView) view).getText();
//
//                    if (TextUtils.equals(text, viewText)) {
//                        result.putBoolean("result", true);
//                        return true;
//                    }
//                }
//
//                return false;
//            }
//
//            @Override
//            public String getType() {
//                return "findTextInView";
//            }
//        };
//
//        ViewHierarchyUtility.traverseViewHierarchy(view, findTextInView);
//
//        return result.getBoolean("result", false);
//    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    public static Bitmap takeScreenshot(final View view, Activity activity) {
        final Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        if (Looper.myLooper() == Looper.getMainLooper()) {

            // On main thread already, Just Do It™.
            drawDecorViewToBitmap(view, bitmap);
        } else {

            // On a background thread, post to main.
            final CountDownLatch latch = new CountDownLatch(1);
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        drawDecorViewToBitmap(view, bitmap);
                    } finally {
                        latch.countDown();
                    }
                }
            });
            try {
                latch.await();
            } catch (InterruptedException e) {
                InsertLogger.e(e, "Unable to get screenshot for "
                        + activity.getClass().getSimpleName());
            }
        }

        return bitmap;
    }

    private static void drawDecorViewToBitmap(@NonNull View view, Bitmap bitmap) {
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
    }

    /**
     * Convert a Bitmap to Base64 encoded string.
     *
     * @param format  the compression format (e.g. PNG, JPEG)
     * @param quality the compression quality.
     * @param bitmap  the bitmap to encode.
     * @return a Base64 encoded string representation of the bitmap.
     */
    public static String convertBitmapToBase64(Bitmap.CompressFormat format, int quality, Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(format, quality, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();

        if (Pendo.isDebugLogEnabled()) InsertLogger.i("Screenshot size: "
                + Formatter.formatFileSize(Pendo.getApplicationContext(), byteArray.length));

        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    /**
     * Blurs bitmap using {@link android.renderscript.RenderScript}.
     *
     * @param bitmap the bitmap to blur.
     * @return the blurred bitmap.
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public static Bitmap blurBitmap(Bitmap bitmap) {

        // Let's create an empty bitmap with the same size of the bitmap we want to blur
        Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);

        // Instantiate a new Renderscript
        RenderScript rs = RenderScript.create(Pendo.getApplicationContext());

        // Create an Intrinsic Blur Script using the Renderscript
        ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));

        // Create the in/out Allocations with the Renderscript and the in/out bitmaps
        Allocation allIn = Allocation.createFromBitmap(rs, bitmap);
        Allocation allOut = Allocation.createFromBitmap(rs, outBitmap);

        // Set the radius of the blur
        blurScript.setRadius(25.f);

        // Perform the Renderscript
        blurScript.setInput(allIn);
        blurScript.forEach(allOut);

        // Copy the final bitmap created by the out Allocation to the outBitmap
        allOut.copyTo(outBitmap);

        // Recycle the original bitmap
        bitmap.recycle();

        // After finishing everything, we destroy the Renderscript.
        rs.destroy();

        return outBitmap;
    }

    @Nullable
    public static DisplayMetrics getDisplayMetrics() {

        Context context = Pendo.getApplicationContext();
        if (context != null) {
            Resources r = context.getResources();
            return r.getDisplayMetrics();
        }

        return null;
    }

    public static int convertSpToPx(float sp) {
        return convertToPixels(TypedValue.COMPLEX_UNIT_SP, sp);
    }

    public static int convertDpToPx(float dp) {
        return convertToPixels(TypedValue.COMPLEX_UNIT_DIP, dp);
    }

    public static int convertPtToPx(float pt) {
        return convertToPixels(TypedValue.COMPLEX_UNIT_PT, pt);
    }

    public static int convertInToPx(float in) {
        return convertToPixels(TypedValue.COMPLEX_UNIT_IN, in);
    }

    public static int convertMmToPx(float mm) {
        return convertToPixels(TypedValue.COMPLEX_UNIT_MM, mm);
    }

    private static int convertToPixels(int unit, float value) {
        DisplayMetrics displayMetrics = getDisplayMetrics();

        if (displayMetrics != null) {
            return (int) TypedValue.applyDimension(unit, value, displayMetrics);
        }

        return -1;
    }

    public static float convertPxToDp(int px) {
        DisplayMetrics displayMetrics = getDisplayMetrics();

        if (displayMetrics != null) {
            float logicalDensity = getDisplayMetrics().density;
            return px * logicalDensity;
        }

        return -1;
    }

    public static int convertToPixels(TypedValue typedValue, float value) {

        switch (typedValue.type) {
            case TypedValue.COMPLEX_UNIT_PX:
                return (int) value;
            case TypedValue.COMPLEX_UNIT_DIP:
                return convertDpToPx(value);
            case TypedValue.COMPLEX_UNIT_SP:
                return convertSpToPx(value);
            case TypedValue.COMPLEX_UNIT_PT:
                return convertPtToPx(value);
            case TypedValue.COMPLEX_UNIT_IN:
                return convertInToPx(value);
            case TypedValue.COMPLEX_UNIT_MM:
                return convertMmToPx(value);
        }

        return -1;
    }

    public static TypedValue getComplexUnitFromString(String value, float[] num) {

        if (parseFloatAttribute(value, S_VALUE, num)) {
            return S_VALUE;
        }

        return null;
    }

    /**
     * Taken from com.android.layoutlib.bridge.impl.ResourceHelper
     */
    private static final Pattern sFloatPattern = Pattern.compile("(-?[0-9]+(?:\\.[0-9]+)?)(.*)");

    /**
     * Return whether the view has an attached OnClickListener.  Returns
     * true if there is a listener, false if there is none.
     */
    public static boolean hasOnClickListeners(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            return view.hasOnClickListeners();
        }
        return false;
    }

    public static boolean isViewInsideDrawer() {
        return InsertDrawerListener.getIsShowingDrawerValue();
    }

    enum UnitType {
        PX("px", TypedValue.COMPLEX_UNIT_PX),
        DIP("dip", TypedValue.COMPLEX_UNIT_DIP),
        DP("dp", TypedValue.COMPLEX_UNIT_DIP),
        SP("sp", TypedValue.COMPLEX_UNIT_SP),
        PT("pt", TypedValue.COMPLEX_UNIT_PT),
        IN("in", TypedValue.COMPLEX_UNIT_IN),
        MM("mm", TypedValue.COMPLEX_UNIT_MM);

        private final String name;
        private final int unit;
        private static final Map<String, UnitType> lookup = new HashMap<>();

        static {
            for (UnitType s : EnumSet.allOf(UnitType.class)) {
                lookup.put(s.getName(), s);
            }
        }

        UnitType(String name, int unit) {
            this.name = name;
            this.unit = unit;
        }

        public String getName() {
            return name;
        }

        public int getUnit() {
            return unit;
        }

        @Nullable
        public static UnitType get(String name) {
            return lookup.get(name);
        }
    }

    /**
     * Taken from com.android.layoutlib.bridge.impl.ResourceHelper
     * <p>
     * Parse a float attribute and return the parsed value into a given TypedValue.
     *
     * @param value    the string value of the attribute
     * @param outValue the TypedValue to receive the parsed value
     * @param floatOut the float to receive the parsed float value
     * @return true if success.
     */
    public static boolean parseFloatAttribute(@NonNull String value,
                                              TypedValue outValue,
                                              float[] floatOut) {
        // remove the space before and after
        value = value.trim();
        int len = value.length();

        if (len <= 0) {
            return false;
        }

        // check that there's no non ascii characters.
        char[] buf = value.toCharArray();
        for (int i = 0; i < len; i++) {
            if (buf[i] > 255) {
                return false;
            }
        }

        // check the first character
        if ((buf[0] < '0' || buf[0] > '9') && buf[0] != '.' && buf[0] != '-' && buf[0] != '+') {
            return false;
        }

        // now look for the string that is after the float...
        Matcher m = sFloatPattern.matcher(value);
        if (m.matches()) {
            String f_str = m.group(1);
            String end = m.group(2);

            float f;
            try {
                f = Float.parseFloat(f_str);
            } catch (NumberFormatException e) {
                // this shouldn't happen with the regexp above.
                return false;
            }

            if (end.length() > 0 && end.charAt(0) != ' ') {
                // Might be a unit...
                if (parseUnit(end, outValue)) {
                    floatOut[0] = f;
                    return true;
                }
                return true;
            }
        }
        return false;
    }

    private static boolean parseUnit(String str, TypedValue outValue) {
        str = str.trim();

        UnitType unitType = UnitType.get(str.toLowerCase(Locale.US));
        if (unitType != null) {
            outValue.type = unitType.getUnit();
            return true;
        }

        return false;
    }

    /**
     * Took from {@link android.content.pm.ActivityInfo}.<br>
     *
     * @param activityOrientation The preferred screen orientation the activity would like to run in.
     *                            From the {@link android.R.attr#screenOrientation} attribute, one of
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_UNSPECIFIED},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_LANDSCAPE},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_PORTRAIT},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_USER},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_BEHIND},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_SENSOR},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_NOSENSOR},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_SENSOR_LANDSCAPE},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_SENSOR_PORTRAIT},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_REVERSE_LANDSCAPE},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_REVERSE_PORTRAIT},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_FULL_SENSOR},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_USER_LANDSCAPE},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_USER_PORTRAIT},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_FULL_USER},
     *                            {@link android.content.pm.ActivityInfo#SCREEN_ORIENTATION_LOCKED},
     * @return The string representing the orientation.
     */
    public static String activityOrientationToString(int activityOrientation) {
        switch (activityOrientation) {
            case ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED:
                return "SCREEN_ORIENTATION_UNSPECIFIED";
            case ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:
                return "SCREEN_ORIENTATION_LANDSCAPE";
            case ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:
                return "SCREEN_ORIENTATION_PORTRAIT";
            case ActivityInfo.SCREEN_ORIENTATION_USER:
                return "SCREEN_ORIENTATION_USER";
            case ActivityInfo.SCREEN_ORIENTATION_BEHIND:
                return "SCREEN_ORIENTATION_BEHIND";
            case ActivityInfo.SCREEN_ORIENTATION_SENSOR:
                return "SCREEN_ORIENTATION_SENSOR";
            case ActivityInfo.SCREEN_ORIENTATION_NOSENSOR:
                return "SCREEN_ORIENTATION_NOSENSOR";
            case ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:
                return "SCREEN_ORIENTATION_SENSOR_LANDSCAPE";
            case ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT:
                return "SCREEN_ORIENTATION_SENSOR_PORTRAIT";
            case ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE:
                return "SCREEN_ORIENTATION_REVERSE_LANDSCAPE";
            case ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT:
                return "SCREEN_ORIENTATION_REVERSE_PORTRAIT";
            case ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR:
                return "SCREEN_ORIENTATION_FULL_SENSOR";
            case ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE:
                return "SCREEN_ORIENTATION_USER_LANDSCAPE";
            case ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT:
                return "SCREEN_ORIENTATION_USER_PORTRAIT";
            case ActivityInfo.SCREEN_ORIENTATION_FULL_USER:
                return "SCREEN_ORIENTATION_FULL_USER";
            case ActivityInfo.SCREEN_ORIENTATION_LOCKED:
                return "SCREEN_ORIENTATION_LOCKED";
            default:
                return "UNKNOWN";
        }
    }

    public static boolean isViewATabView(View view) {
        return view.getClass().getSimpleName().toLowerCase().contains(TAB_VIEW_CLASS_NAME);
    }
    /**
     * Find the TextView child view of a view (usually a ViewGroup)
     *
     * @param view - the one we want to find text in.
     * @return the first text TextView child view or the view itself if it is a TextView.
     */

    @Nullable
    public static TextView getFirstChildTextView(final View view) {
        if (view instanceof TextView) {
            return (TextView) view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }

        Stack<View> viewStack = new Stack<>();
        viewStack.push(view);
        while (!viewStack.empty()) {
            View currentView = viewStack.pop();
            if (currentView instanceof TextView) {
                return (TextView) currentView;
            }
            if (currentView instanceof ViewGroup) {
                for (int i = 0; i < ((ViewGroup) currentView).getChildCount(); i++) {
                    View currentChildView = ((ViewGroup) currentView).getChildAt(i);
                    if (currentChildView instanceof TextView) {
                        return (TextView) currentChildView;
                    } else if (currentChildView instanceof ViewGroup) {
                        viewStack.push(currentChildView);
                    }
                }
            }

        }

        return null;
    }

    /**
     * @param view
     * @return a concatenation of all of it's sub TextViews content or null if it is empty
     */

    @Nullable
    public static String getSubViewsTextsConcatenation(@Nullable final View view) {
        if (view == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        Stack<View> viewsStack = new Stack<>();
        viewsStack.push(view);
        while (!viewsStack.empty()) {
            View currentView = viewsStack.pop();
            if (currentView instanceof TextView) {
                if (((TextView) currentView).getText() != null) {
                    stringBuilder.append(((TextView) currentView).getText());
                }
            }
            if (currentView instanceof ViewGroup) {
                for (int i = 0; i < ((ViewGroup) currentView).getChildCount(); i++) {
                    viewsStack.push(((ViewGroup) currentView).getChildAt(i));
                }
            }
        }

        String outcome = stringBuilder.toString();
        return TextUtils.isEmpty(outcome) ? null : outcome;
    }
}
