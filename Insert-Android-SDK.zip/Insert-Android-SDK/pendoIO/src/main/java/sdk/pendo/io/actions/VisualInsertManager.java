package sdk.pendo.io.actions;

import android.util.SparseArray;

import com.google.gson.JsonArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.reactivex.Observable;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.network.responses.InsertModel;

/**
 * Responsible for holding and managing the various visual inserts.
 * The VisualInsertManager listens to the visual inserts lifecycle
 * in order to add and remove them from its collection.
 *
 * Created by nirsegev on 5/31/16.
 */

public class VisualInsertManager implements VisualInsertLifecycleListener {
    private static volatile VisualInsertManager INSTANCE;
    private Map<String, VisualInsertBase> mVisualInserts = new HashMap<>();
    private BehaviorSubject<Boolean> mIsFullScreenInsertShowing = BehaviorSubject.createDefault(false);

    private VisualInsertManager() {
    }

    public static synchronized VisualInsertManager getInstance()
            throws IllegalStateException {
        if (INSTANCE == null) {
            INSTANCE = new VisualInsertManager();
        }
        return INSTANCE;
    }

    /**
     * Retrieves a visual insert by its id.
     * @param id the insert id.
     * @return the visual insert.
     */
    public final synchronized VisualInsertBase getVisualInsert(String id) {
        return mVisualInserts.get(id);
    }

    /**
     * Adds a visual insert to the collection
     * @param visualInsert
     */
    public synchronized void addVisualInsert(VisualInsertBase visualInsert) {
        mVisualInserts.put(visualInsert.getGuideId(), visualInsert);
    }

    /**
     * Remove a visual insert from the collection
     * @param id
     */
    public synchronized void removeVisualInsert(String id) {
        GuideModel guideModel = GuideManager.INSTANCE.getGuide(id);
        if (guideModel != null) {
            JsonArray steps = guideModel.getSteps();
            if (steps.size() -1 == StepSeenManager.getInstance().getCurrentStepIndex()) {
                mVisualInserts.remove(id);
            }
        }
    }

    public VisualInsert createVisualInsert(StepGuideModel guideStepModel) {
        VisualInsert visualInsert = new VisualInsert(guideStepModel, this);
        return visualInsert;
    }

    /// VisualInsertLifecycleListener  methods ///
    @Override
    public void onCreate(VisualInsertBase visualInsert) {
        addVisualInsert(visualInsert);
        GuideManager.INSTANCE.populate(Collections.singletonList(visualInsert));
    }

    @Override
    public void onDestroy(String visualInsertId) {
        removeVisualInsert(visualInsertId);
    }

    /**
     * Retrieve whether any insert is currently being shown
     * @return true is there is an insert that is being shown now, false otherwise
     */
    public synchronized boolean isAnyInsertShowing() {
        if (getShowingInserts().size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * Retrieve the list of inserts currently being shown.
     * @return list of visual inserts that are currently being shown.
     */
    private List<VisualInsertBase> getShowingInserts() {
        List<VisualInsertBase> visualInserts = new ArrayList<>();
        for (Map.Entry<String, VisualInsertBase> entry : mVisualInserts.entrySet()) {
            VisualInsertBase visualInsert = entry.getValue();
            if (visualInsert.isShowing()) {
                visualInserts.add(visualInsert);
            }
        }
        return visualInserts;
    }

    public Observable<Boolean> getIsFullScreenInsertShowingObservable() {
        return mIsFullScreenInsertShowing;
    }

    /**
     * @return true if a full screen insert is currently showing. False otherwise.
     */
    public boolean isAnyFullScreenInsertShowing() {
        return mIsFullScreenInsertShowing.getValue();
    }

    public void setIsFullScreenInsertShowing(boolean isFullScreenInsertShowing) {
        mIsFullScreenInsertShowing.onNext(isFullScreenInsertShowing);
    }

    public boolean isInsertShowing(String requiredInsertId) {
        List<VisualInsertBase> showingInserts = getShowingInserts();
        for (VisualInsertBase showingInsert : showingInserts) {
            if (showingInsert.isShowing() && showingInsert.getGuideId().equals(requiredInsertId)) {
                return true;
            }
        }
        return false;
    }
}
