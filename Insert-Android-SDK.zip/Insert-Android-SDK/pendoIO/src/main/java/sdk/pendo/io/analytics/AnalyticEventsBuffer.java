package sdk.pendo.io.analytics;

import android.os.Handler;

import org.jetbrains.annotations.NotNull;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.FileUtils;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * This class purpose is represent disk buffer storage for
 * storing analytic events tracked by SDK and expose methods to handle operations
 * such write, read, remove, with specific to it logic. Also it handle storage triggers to notify
 * outside via its ITrigger interface to take appropriate further actions with analytic events
 * <p>
 * Created by DavidG on 16/12/19.
 */
class AnalyticEventsBuffer {
    static final int UNLIMITED_STORAGE = -1;
    private static final int FROM_START = 0;
    private static final String READ_ONLY_MODE = "r";
    private static final String WRITE_MODE = "rwd";
    /**
     * Buffer file
     */
    private File mBufferFile;
    /**
     * Buffer triggers
     */
    private int mBufferTimeoutInSecondsTrigger; // timer based trigger
    private int mBufferQueueSizeTrigger; // Number of stored events when to be triggered
    /**
     * Internal counters
     */
    private int mWrittenAnalyticEventsCounter; // Count of all current stored analytic events
    private int mHandledAnalyticEventsCounter; // Count of events that is in process of either be removed to another storage or to be send to backend
    /**
     * Buffer max storage params
     */
    private float mMaxStorageSizeBytes; // Limit size of storage
    private float mOverflowCorrectionFactor; // Factor used when calculating space to free up while there is events over size limit
    /**
     * Buffer file pointer
     */
    private long mBufferFileReadPointer; // Pointer within file to track current read amount of bytes

    private Handler mBufferTimeoutHandler = new Handler();
    private Runnable mBufferTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (mWrittenAnalyticEventsCounter > 0) {
                mTriggerCallback.trigger();
            } else {
                startTimeoutTrigger();
            }
        }
    };
    private ITrigger mTriggerCallback;

    /**
     * Construct instance of AnalyticEventsBuffer, initialize fields and opens appropriate file - {@param fileName}
     *
     * @param fileName                 of buffer stored on disk
     * @param timeoutTrigger           to notify, to handle already stored events if need
     * @param queueSizeTrigger         to notify, to handle already stored events if need
     * @param maxStorageSize           defines disk volume limit in bytes or no limit at all
     * @param overflowCorrectionFactor factor to correct buffer overflow cases by free up specific amount of space
     * @param callback                 to notify outside when buffer is triggered by timeout or queue size
     */
    AnalyticEventsBuffer(@NotNull String fileName, int timeoutTrigger, int queueSizeTrigger, float maxStorageSize,
                         float overflowCorrectionFactor, ITrigger callback) {
        mBufferTimeoutInSecondsTrigger = timeoutTrigger;
        mBufferQueueSizeTrigger = queueSizeTrigger;
        mTriggerCallback = callback;
        mMaxStorageSizeBytes = maxStorageSize;
        mOverflowCorrectionFactor = overflowCorrectionFactor;
        try {
            mBufferFile = FileUtils.createCacheFile(Pendo.getApplicationContext(), fileName);
            // If there is content within file we need to retrieve number of events
            // stored there to further process
            if (mBufferFile.length() > 0) {
                mWrittenAnalyticEventsCounter = calculateNumOfStoredAnalyticEvents();
            }
            startTimeoutTrigger();
        } catch (IOException e) {
            InsertLogger.e(e, e.getMessage());
            mBufferFile = null;
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    private void startTimeoutTrigger() {
        mBufferTimeoutHandler.postDelayed(mBufferTimeoutRunnable, mBufferTimeoutInSecondsTrigger * 1000);
    }

    void stopTimeoutTrigger() {
        mBufferTimeoutHandler.removeCallbacks(mBufferTimeoutRunnable);
    }

    /**
     * This method store analytic events to disk file {@code mFileName} storage
     * and fires trigger depend on {@code mBufferQueueSizeTrigger}
     *
     * @param events
     * @param counter
     */
    void storeAnalyticEvents(String events, int counter) {
        byte[] eventBytes = events.getBytes(Charset.forName(ENCODING_UTF_8));
        boolean succeededWriting = writeToFile(eventBytes);
        // We either succeed writing or we don't.
        if (!succeededWriting) {
            counter = 0;
        }
        mWrittenAnalyticEventsCounter += counter;
        if (mWrittenAnalyticEventsCounter >= mBufferQueueSizeTrigger && mHandledAnalyticEventsCounter == 0) {
            mBufferTimeoutHandler.removeCallbacks(mBufferTimeoutRunnable);
            mBufferTimeoutRunnable.run();
        }
    }

    /**
     * This method retrieves stored analytic events from file {@code mFileName}
     *
     * @return
     */
    String getStoredAnalyticEvents() {
        String events = readFromFile(FROM_START);
        mHandledAnalyticEventsCounter = mWrittenAnalyticEventsCounter;
        return events;
    }

    int getHandledAnalyticEventsCount() {
        return mHandledAnalyticEventsCounter;
    }

    int getWriteAnalyticEventsCounter() {
        return mWrittenAnalyticEventsCounter;
    }

    /**
     * This method remove analytic events that was already handled
     * and either delete file, if all events in it was handled, or rewrites it, if there is still events that not
     * been handled yet
     */
    synchronized void removeHandledAnalyticEvents() {
        try {
            if (mBufferFile != null
                    && mBufferFileReadPointer == mBufferFile.length()
                    && mBufferFile.length() != 0) {
                // If read pointer same as write, it means there is no new events appended to file,
                // since the last time we read events to handle them, so all events are handled
                clearFile();
            } else if (mBufferFileReadPointer > 0) {
                // There is new events appended to file, since the last time we read events to handle them,
                // so we need remove only events that been handled
                String content = readFromFile(mBufferFileReadPointer);
                clearFile();
                writeToFile(content.getBytes(Charset.forName(ENCODING_UTF_8)));
            }
            mWrittenAnalyticEventsCounter = mWrittenAnalyticEventsCounter - mHandledAnalyticEventsCounter;
            mBufferFileReadPointer = 0;
            mHandledAnalyticEventsCounter = 0;
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            startTimeoutTrigger();
        }
    }

    /**
     * This method handle storage overflow when storage is limited and overflowed by analytic events
     * Method removes redundant events and free up extra space in storage for minimum 20%
     */
    void handleStorageOverflowIfNeeded() {
        if ( mBufferFile != null
                && mMaxStorageSizeBytes != UNLIMITED_STORAGE
                && mBufferFile.length() > mMaxStorageSizeBytes) {
            StringBuilder eventsStringBuilder = new StringBuilder();
            float calculatedSpaceToFreeInBytes = mBufferFile.length() - mMaxStorageSizeBytes * mOverflowCorrectionFactor;
            float actualSpaceToFreeInBytes = 0;
            int redundantEventsCounter = 0;
            // We go over each event and summarize it size until we reach size need be to free up
            // All remaining events are rewrite to head of file
            for (String event : getAllStoredAnalyticEventsAsArray()) {
                if (actualSpaceToFreeInBytes < calculatedSpaceToFreeInBytes) {
                    actualSpaceToFreeInBytes = actualSpaceToFreeInBytes + event.getBytes(Charset.forName(ENCODING_UTF_8)).length + AnalyticEventsManager.ANALYTIC_EVENTS_DELIMITER.length();
                    redundantEventsCounter++;
                } else {
                    eventsStringBuilder.append(AnalyticEventsManager.ANALYTIC_EVENTS_DELIMITER).append(event);
                }
            }
            // We set count of remaining events to events that are actually exist in file - mWrittenAnalyticEventsCounter
            // And we correct mBufferFileReadPointer in case there is handled events and part of them or all of them are removed
            // while free up space
            mWrittenAnalyticEventsCounter = mWrittenAnalyticEventsCounter - redundantEventsCounter + 1;
            if (mBufferFileReadPointer > actualSpaceToFreeInBytes) {
                mBufferFileReadPointer = (long) (mBufferFileReadPointer - actualSpaceToFreeInBytes + AnalyticEventsManager.ANALYTIC_EVENTS_DELIMITER.length());
            } else {
                mBufferFileReadPointer = 0;
            }
            clearFile();
            writeToFile(eventsStringBuilder.toString().getBytes(Charset.forName(ENCODING_UTF_8)));
        }
    }

    /**
     * This method sets buffer trigger and capacity parameters
     *
     * @param bufferTimeoutInSeconds
     * @param bufferQueueSize
     * @param maxStorageSizeBytes
     */
    void setBufferParameters(int bufferTimeoutInSeconds, int bufferQueueSize, float maxStorageSizeBytes) {
        mBufferTimeoutInSecondsTrigger = bufferTimeoutInSeconds;
        mBufferQueueSizeTrigger = bufferQueueSize;
        mMaxStorageSizeBytes = maxStorageSizeBytes;
    }

    /**
     * This method calculates number of events stored into specific file
     */
    private int calculateNumOfStoredAnalyticEvents() {
        return getAllStoredAnalyticEventsAsArray().length - 1;
    }

    /**
     * This method retrieves all stored analytic events as array
     *
     * @return
     */
    private String[] getAllStoredAnalyticEventsAsArray() {
        String analyticEvents = readFromFile(FROM_START);
        return analyticEvents.split(AnalyticEventsManager.ANALYTIC_EVENTS_DELIMITER_REGEX);
    }

    /**
     * This method write to the end of file - {@code mFileName} content of bytes
     *
     * @param content
     * @return whether we succeeded to write or not
     */
    private boolean writeToFile(byte[] content) {
        FileOutputStream fileOutputStream = null;
        try {
            if (mBufferFile != null) {
                fileOutputStream = new FileOutputStream(mBufferFile.getPath(), true);
                fileOutputStream.write(content);
                return true;
            } else {
                InsertLogger.d("Could not write to file because of an IOException causing buffer file to be null.");
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            closeFile(fileOutputStream);
        }
        return false;
    }

    /**
     * This method read from file - {@code mFileName} starting from specified {@param start} position
     *
     * @param start position
     * @return file content as string
     */
    private String readFromFile(long start) {
        String result = "";
        RandomAccessFile randomAccessFile = null;
        try {
            randomAccessFile = openFile(READ_ONLY_MODE);
            if (randomAccessFile != null && start >= 0) {
                randomAccessFile.seek(start);
                result = randomAccessFile.readLine();
                if (start == FROM_START) {
                    mBufferFileReadPointer = randomAccessFile.getFilePointer();
                }
            } else {
                InsertLogger.d("Could not read from file because buffer file is null due to an IOException.");
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            closeFile(randomAccessFile);
        }
        return result;
    }

    /**
     * This method clear content of the file by truncating it to start of the file
     */
    private void clearFile() {
        RandomAccessFile randomAccessFile = null;
        try {
            randomAccessFile = openFile(WRITE_MODE);
            if (randomAccessFile != null) {
                randomAccessFile.setLength(0);
            } else {
                InsertLogger.d("Could not clear buffer file due to an IOException and it being null.");
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            closeFile(randomAccessFile);
        }
    }

    private RandomAccessFile openFile(String mode) throws FileNotFoundException {
        if (mBufferFile != null) {
            return new RandomAccessFile(mBufferFile.getPath(), mode);
        } else {
            return null;
        }
    }

    /**
     * This method attempt to close file
     *
     * @param closeable
     */
    private void closeFile(Closeable closeable) {
        try {
            if (closeable != null) {
                closeable.close();
            }
        } catch (IOException e) {
        }
    }

    /**
     * AnalyticEventsBuffer interface to provide callback for holding buffer when
     * trigger was fired
     */
    interface ITrigger {
        void trigger();
    }
}


