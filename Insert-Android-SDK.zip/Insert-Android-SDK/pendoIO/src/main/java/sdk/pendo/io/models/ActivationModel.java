package sdk.pendo.io.models;

import android.os.Build;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;

/**
 * Activation model holds a few things:
 * 1) mobile selector - a JSON Logic JSON Path rule.
 * 2) activationID - the id of the activation. - might be shared between activation objects.
 * 3) event - can be one of the following: click, view or applaunch.
 */
public class ActivationModel {

    @SerializedName("pageSelector")
    private String mPageSelector;

    @SerializedName("featureSelector")
    private String mFeatureSelector;

    @SerializedName("pageActivationId")
    private long mPageActivationId;

    @SerializedName("featureActivationId")
    private long mFeatureActivationId;

    @SerializedName("event")
    private String mEvent;

    public String getFeatureSelector() {
        return mFeatureSelector;
    }

    public String getPageSelector() {
        return mPageSelector;
    }

    public void setPageSelector(String pageSelector) {
        this.mPageSelector = pageSelector;
    }

    public void setFeatureSelector(String featureSelector) {
        this.mFeatureSelector = featureSelector;
    }

    private long getFeatureActivationId() {
        return mFeatureActivationId;
    }

    private long getPageActivationId() {
        return mPageActivationId;
    }

    public void setPageActivationId(long pageActivationId) {
        this.mPageActivationId = pageActivationId;
    }

    public void setFeatureActivationId(long featureActivationId) {
        this.mFeatureActivationId = featureActivationId;
    }

    public String getEvent() {
        return mEvent;
    }

    public void setEvent(String event) {
        this.mEvent = event;
    }

    @Override
    public String toString() {
        String pageSelector = mPageSelector != null ? mPageSelector : "";
        String featureSelector = mFeatureSelector != null ? mFeatureSelector : "";
        String event = mEvent != null ? mEvent : "";

        return "Activation Model: " + "\n"
                + "pageSelector: " + pageSelector + "\n"
                + "featureSelector: " + featureSelector + "\n"
                + "featureActivationId: " + mFeatureActivationId + "\n"
                + "pageActivationId: " + mPageActivationId + "\n"
                + "event: " + event;
    }

    @Override
    public boolean equals(Object o) {
        boolean equal = true;
        if (this == o) {
            return true;
        }
        if (null == o) {
            return false;
        }
        if (getClass() != o.getClass()) {
            return false;
        }
        ActivationModel that = (ActivationModel) o;
        if (mPageSelector != null && !mPageSelector.equals(that.getPageSelector())) {
            if (that.getPageSelector() == null) {
                return false;
            } else {
                equal = mPageSelector.equals(that.getPageSelector());
            }
        }
        if (mFeatureSelector != null && !mFeatureSelector.equals(that.getFeatureSelector())) {
            if (that.getFeatureSelector() == null) {
                return false;
            } else {
                equal = equal && mFeatureSelector.equals(that.getFeatureSelector());
            }
        }
        if (mPageActivationId != that.getPageActivationId()) {
            equal = equal && mPageActivationId == that.getPageActivationId();
        }
        if (mFeatureActivationId != that.getFeatureActivationId()) {
            equal = equal && mFeatureActivationId == that.getFeatureActivationId();
        }
        if (mEvent != null && !mEvent.equals(that.getEvent())) {
            if (that.getEvent() == null) {
                return false;
            } else {
                equal = equal && mEvent.equals(that.getEvent());
            }
        }
        return equal;
    }

    @Override
    public int hashCode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            return Objects.hash(mPageSelector, mFeatureSelector, mFeatureActivationId, mPageActivationId, mEvent);
        } else {
            int pageSelectorHash = mPageSelector == null ? 0 : mPageSelector.hashCode();
            int featureSelectorHash = mFeatureSelector == null ? 0 : mFeatureSelector.hashCode();
            int eventHash = mEvent == null ? 0 : mEvent.hashCode();
            return 31 * (31 * ((31 * pageSelectorHash) + eventHash) + featureSelectorHash);
        }
    }
}
