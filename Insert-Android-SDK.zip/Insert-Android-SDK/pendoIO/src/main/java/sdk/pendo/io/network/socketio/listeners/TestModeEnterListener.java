package sdk.pendo.io.network.socketio.listeners;

import org.json.JSONObject;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Listen on {@link SocketEvents#EVENT_TEST_MODE_ENTER}.
 */
public final class TestModeEnterListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got testModeEnter");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_TEST_MODE_ENTER, args);
        if (SocketEventFSM.getInstance().isTestMode()) {
            sendTestModeEnteredEvent();
        }
    }

    private void sendTestModeEnteredEvent() {
        JSONObject jsonObject = new JSONObject();
        SocketIOUtils.addSuccesfulToResponse(jsonObject, true);
        SocketIOUtils.emitToSocket(SocketEvents.EVENT_TEST_MODE_ENTERED.getCommand(), jsonObject);
    }

}
