package sdk.pendo.io.network.socketio.listeners;

import org.jose4j.jwt.consumer.InvalidJwtException;
import org.json.JSONObject;
import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Listen on {@link SocketEvents#EVENT_IDENTIFY_MODE_ENTER}.
 */
public class IdentifyModeEnterListener  implements  Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got identifyModeEnter");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_IDENTIFY_MODE_ENTER, args);
        if (SocketEventFSM.getInstance().isIdentifyMode()) {
            Object oldScreenJson = null;
            try {
                oldScreenJson = SocketEventFSM.getValidatedJWTData((JSONObject) args[0]);
            } catch (InvalidJwtException e) {
                InsertLogger.e(e, e.getMessage());
            }
            if (oldScreenJson != null) {
                String oldScreenJsonString = oldScreenJson.toString();
                SocketEventFSM
                        .getInstance()
                        .setIdentifyScreenData(SocketIOUtils.fetchOldScreenDetails(oldScreenJsonString));
                sendIdentifyModeEnteredEvent();
            }
        }
    }

    private void sendIdentifyModeEnteredEvent() {
        JSONObject jsonObject = new JSONObject();
        SocketIOUtils.addSuccesfulToResponse(jsonObject, true);
        SocketIOUtils.emitToSocket(SocketEvents.EVENT_IDENTIFY_MODE_ENTERED.getCommand(), jsonObject);
    }
}
