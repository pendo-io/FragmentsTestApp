package sdk.pendo.io.utilities;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Pair;
import android.view.View;
import android.view.ViewParent;
import android.widget.TextView;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import sdk.pendo.io.events.ConditionData;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.views.watcher.InsertTextWatcher;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;
import static sdk.pendo.io.intelligence.ViewIntel.getViewIntelId;

/**
 * Utility class for our predicate.
 * <p/>
 * Created by assaf on 12/8/15.
 */
public final class PredicateUtils {

    public static final int BASE64_FLAGS = Base64.URL_SAFE | Base64.NO_WRAP;
    private static final String TEXT_HISTORY_DELIMITER = "|";
    public static final String TEXT_PREFIX = "[text=\"";
    public static final String TEXT_SUFFIX = "\"]";
    private static final String OPENING_BRACKET = "[";
    private static final String CLOSING_BRACKET = "]";

    /**
     * This class represents the predicate, this class is for our convenience so we can request
     * the predicate feature with greater ease.
     */
    private static final class Predicate {

        private final ArrayList<String> mPredicateStrSplit;
        private final Iterator<String> mIterator;
        private final boolean mIsAny;
        private boolean mIsList = false;

        Predicate(String predicateStr) {

            final String indices = indexExtractor(predicateStr);
            if (indices != null) {
                setIsList(true);
                final String[] predIndices = getIndices(indices);
                mIsAny = "*".equals(predIndices[0]) && "*".equals(predIndices[1]);
            } else {
                mIsAny = false;
            }

            mPredicateStrSplit = new ArrayList<>(Arrays.asList(predicateStr.split("/")));
            Collections.reverse(mPredicateStrSplit);
            mIterator = mPredicateStrSplit.iterator();
        }

        boolean isAny() {
            return mIsAny;
        }

        int size() {
            return mPredicateStrSplit.size();
        }

        @Nullable
        String next() {
            if (mIterator != null && mIterator.hasNext()) {
                return mIterator.next();
            }

            return null;
        }

        void setIsList(boolean isList) {
            mIsList = isList;
        }

        public boolean isList() {
            return mIsList;
        }
    }

    private PredicateUtils() {
    }

    public static boolean isPredicateAny(String pred) {

        if (TextUtils.isEmpty(pred) || !isValidPredicate(pred)) {
            InsertLogger.d("Invalid predicate.");
            return false;
        }
        return new Predicate(pred).isAny();
    }

    @SuppressWarnings("unused")
    public static boolean compareIdentificationDetailsWithView(IdentificationData lIdentificationData, View view, @Nullable ConditionData condition) {
        // Old code, not collecting texts and accessibility
        return compareIdentificationDetailsWithView(lIdentificationData, getViewIntelId(view, false, false), condition);
    }

    public static boolean compareIdentificationDetailsWithView(IdentificationData lIdentificationData, IdentificationData viewIdentificationData,
                                                               @Nullable ConditionData condition) {

        String lPred = lIdentificationData.getRAPredicate();
        String viewPred = viewIdentificationData.getRAPredicate();

        if (viewPred != null && viewPred.equals(lPred) &&
                !TriggerUtils.isConditionRelevantForComparingViews(condition)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns whether the contained text strings inside the required view are matched to the provided view
     * @param viewIdentificationData The view's identification data
     * @param lIdentificationData The required view's identification data
     * @param isShowingDrawerValue
     * @return null if the contained text shouldn't be considered
     * (it is considered only in special scenarios such as drawer opened),
     * true if the contained text match, false otherwise
     */
    public static Boolean containedStringsMatch(IdentificationData viewIdentificationData, IdentificationData lIdentificationData, Boolean isShowingDrawerValue) {
        Boolean containedStringsMatch = null;
        if (isShowingDrawerValue) {
            containedStringsMatch = true;
            String viewTextStrings = viewIdentificationData.getText();
            String lTextStrings = lIdentificationData.getText();
            if ((viewTextStrings != null || lTextStrings != null) && (viewTextStrings == null || !viewTextStrings.equals(lTextStrings))) {
                containedStringsMatch = false;
            }
        }
        return containedStringsMatch;
    }

    private static boolean rComparePredicate(Predicate lPred, Predicate viewPred,
                                             boolean viewManipulation,
                                             @Nullable ConditionData condition, Boolean containedStringsMatch) {

        final String lPredExp = lPred.next();
        final String viewPredExp = viewPred.next();

        if (TextUtils.isEmpty(lPredExp)) {
            if (TextUtils.isEmpty(viewPredExp)) {
                return true;
            } else {
                InsertLogger.d("Predicate in different length?");
                return false;
            }
        } else if (TextUtils.isEmpty(viewPredExp)) {
            InsertLogger.d("Predicate in different length?");
            return viewManipulation && lPred.isList();
        }

        if (!lPredExp.equals(viewPredExp) ||
                TriggerUtils.isConditionRelevantForComparingViews(condition)) {

            if (!isClassMatch(lPredExp, viewPredExp)) {

                // We ignore these 2 classes. This happens when the TextWatcher matches TextViews
                // with views that might need text modification.
                if (!"com.android.internal.policy.impl.PhoneWindow$DecorView".equals(viewPredExp)
                        || !"android.view.ViewRootImpl".equals(lPredExp)) {
                    return false;
                }
            }

            if (!isIndexMatch(lPredExp, viewPredExp)) {
                return false;
            }


            if (!lPred.isAny() && !isTextMatch(textExtractor(lPredExp),
                    textExtractor(viewPredExp),
                    condition,
                    containedStringsMatch)) {
                return false;
            }
        }

        return rComparePredicate(lPred, viewPred, viewManipulation, condition, containedStringsMatch);
    }

    /**
     * Generates a Retroactive Analytics predicate.
     * Example:
     * For a view C, with a path as so:
     * R
     * |
     * |
     * +A
     *  |
     *  |
     *  +B
     *   |
     *   |
     *   +C
     * The Predicate will be: [R][A][B][C]
     * @param view - The view to generate the predicate for.
     * @return A retroactive analytics predicate for the view.
     */
    public synchronized static String generateRetroPredicateForView(@NonNull final View view) {

        ViewParent parent = view.getParent();
        ArrayList<Pair<String, Object>> classes = new ArrayList<>();
        classes.add(new Pair<>(view.getClass().getName(), (Object) view));
        while (parent != null) {
            classes.add(new Pair<>(parent.getClass().getName(), (Object) parent));
            parent = parent.getParent();
        }

        StringBuilder raPredicate = new StringBuilder();
        Collections.reverse(classes);
        for (Pair<String, Object> viewClass : classes) {
            raPredicate.append(OPENING_BRACKET).append(viewClass.first).append(CLOSING_BRACKET);
            if (viewClass.second instanceof View) {
                addList((View) viewClass.second, raPredicate);
            }
        }
        return raPredicate.toString();
    }

    public static String generatePredicateForView(View view) {
        return rGeneratePredicateForView(view);
    }

    private static String rGeneratePredicateForView(View view) {

        final ViewParent parent = view.getParent();
        if (parent == null) {
            return "/" + generatePredicateExpressionForView(view);
        }

        if (parent instanceof View) {
            final View parentView = (View) parent;
            final String predicateForParentView = rGeneratePredicateForView(parentView);

            return predicateForParentView + "/" + generatePredicateExpressionForView(view);
        } else {
            return "/" + parent.getClass().getName();
        }
    }

    private static String generatePredicateExpressionForView(View view) {

        StringBuilder predicateBuilder = new StringBuilder();

        predicateBuilder.append(view.getClass().getName());

        addList(view, predicateBuilder);
        addText(view, predicateBuilder);

        return predicateBuilder.toString();
    }

    private static void addList(View view, StringBuilder predicateBuilder) {

        if (ViewUtils.isViewAKnownList(view)) {
            return;
        }

        ViewParent parent = view.getParent();
        if (parent instanceof View && ViewUtils.isViewAKnownList((View) parent)) {
            final Integer positionInList = ViewUtils.getPositionInList((View) parent, view);

            if (positionInList != null && positionInList != RecyclerView.NO_POSITION) {
                predicateBuilder
                        .append(OPENING_BRACKET)
                        .append("indexPath=(0,")
                        .append(positionInList)
                        .append(")")
                        .append(CLOSING_BRACKET);
            }
        }
    }

    private static void addText(View view, StringBuilder predicateBuilder) {
        if (view instanceof TextView) {
            // Creates a predicate for the text view with the text history
            // of the form: "[text=base64text1|base64text2|base64text3...]"
            CharSequence text = ((TextView) view).getText();
            if (!TextUtils.isEmpty(text)) {

                // Shorten the text if it's too long.
                text = Utils.truncateStringToLength(text);

                predicateBuilder.append(TEXT_PREFIX);
                predicateBuilder
                        .append(Base64.encodeToString(text.toString().getBytes(Charset.forName(ENCODING_UTF_8)), BASE64_FLAGS));
                List<String> historyForPredicate = InsertTextWatcher.getTextHistoryForTextView(
                        (TextView) view);
                if (historyForPredicate != null) {
                    for (String historyText : historyForPredicate) {
                        if (historyText != null) {
                            if (!historyText.equals(text.toString())) {
                                predicateBuilder.append(TEXT_HISTORY_DELIMITER).append(
                                        Base64.encodeToString(historyText.getBytes(Charset.forName(ENCODING_UTF_8)), BASE64_FLAGS));
                            }
                        }
                    }
                }
                predicateBuilder.append("\"]");
            }
        }
    }

    private static final String BASE64_REGEX =
            "(([A-Za-z0-9\\-_]{4})*([A-Za-z0-9\\-_]{2}==|[A-Za-z0-9\\-_]{3}=)?|\\|)";
    private static final String INDEX_PATH_REGEX = "indexPath=\\([0-9\\*]+,[0-9\\*]+\\)";
    private static final String TEXT_REGEX = "text=\".*\"";
    private static final String PREDICATE_REGEX =
            "^/(/?[\\$a-zA-Z0-9_\\.]+(\\[" + INDEX_PATH_REGEX + "\\]|\\[" + TEXT_REGEX + "\\])*)+";
    private static final String PREDICATE_BEGIN_AND_END_REGEX =
            "/[\\$a-zA-Z0-9\\.]+[a-zA-Z0-9]+(\\[" + INDEX_PATH_REGEX + "\\])?" +
                    "(\\[" + TEXT_REGEX + "\\])?$";
    private static final Pattern PREDICATE_REGEX_PTRN = Pattern.compile(PREDICATE_REGEX);
    private static final Pattern PREDICATE_BEGIN_AND_END_REGEX_PTRN =
            Pattern.compile(PREDICATE_BEGIN_AND_END_REGEX);

    public static boolean isValidPredicate(String predicate) {
        if (predicate == null) {
            return false;
        } else {
            final Matcher predicateRegexMatcher = PREDICATE_REGEX_PTRN.matcher(predicate);
            return predicateRegexMatcher.find()
                    && predicateRegexMatcher.hitEnd()
                    && PREDICATE_BEGIN_AND_END_REGEX_PTRN.matcher(predicate).find();
        }
    }

    @VisibleForTesting
    private static boolean isClassMatch(String lPred, String viewPred) {

        final String lPredExpClass = classNameExtractor(lPred);
        final String viewPredExpClass = classNameExtractor(viewPred);

        return lPredExpClass != null
                && viewPredExpClass != null
                && lPredExpClass.equals(viewPredExpClass);
    }

    @VisibleForTesting
    static boolean isTextMatch(@Nullable String lPredExpText, @Nullable String viewPredExpText, @Nullable ConditionData condition, Boolean isContainedTextMatch) {

        if (isContainedTextMatch != null) {
            return isTextMatchDrawerScenario(lPredExpText, viewPredExpText, condition, isContainedTextMatch);
        }

        if (lPredExpText == null && viewPredExpText == null) {
            return true;
        }

        if (lPredExpText == null || viewPredExpText == null) {
            return false;
        }
        String[] splitViewPred = viewPredExpText.split("\\|");
        String decodedLPred = new String(Base64.decode(lPredExpText, BASE64_FLAGS), Charset.forName(ENCODING_UTF_8));
        for (String splitViewPredEncoded: splitViewPred) {
            String decodedViewPredText = new String(Base64.decode(splitViewPredEncoded, BASE64_FLAGS), Charset.forName(ENCODING_UTF_8));
            if (decodedViewPredText.equals(decodedLPred)) {
                if (!TriggerUtils.isConditionRelevantForComparingViews(condition)) {
                    return true;
                }
            }
        }

        if (!TriggerUtils.isConditionRelevantForComparingViews(condition)) {
            return lPredExpText.equals(viewPredExpText);
        }

        // In case the contained text is null, we should compare the actual text rather than the contained texts
        //We need to check if the predicate text satisfies the condition (e.g is it greater than 3).
        String decodedText = new String(Base64.decode(viewPredExpText, BASE64_FLAGS), Charset.forName(ENCODING_UTF_8));
        return TriggerUtils.satisfiesFieldValueCondition(condition, decodedText);

    }

    private static boolean isTextMatchDrawerScenario(String lPredExpText, String viewPredExpText, ConditionData condition, Boolean isContainedTextMatch) {
        if ((lPredExpText == null && viewPredExpText == null)) {
            return isContainedTextMatch;
        }
        if (lPredExpText == null || viewPredExpText == null) {
            return false;
        }
        if (!lPredExpText.equals(viewPredExpText)) {
            return false;
        }
        return true;
    }

    @SuppressWarnings("RedundantIfStatement")
    @VisibleForTesting
    private static boolean isIndexMatch(String lPred, String viewPred) {
        final String lPredExpList = indexExtractor(lPred);
        final String viewPredExpList = indexExtractor(viewPred);

        final boolean hasLPredIndices = !TextUtils.isEmpty(lPredExpList);
        final boolean hasViewPredIndices = !TextUtils.isEmpty(viewPredExpList);

        if (!hasLPredIndices && !hasViewPredIndices) {
            return true;
        }

        String[] viewIndices = null;
        String[] lPredIndices = null;

        if (hasLPredIndices) {
            lPredIndices = getIndices(lPredExpList);
        }

        if (hasViewPredIndices) {
            viewIndices = getIndices(viewPredExpList);
        }

        if (hasLPredIndices && !hasViewPredIndices) {
            return lPredIndices[0].equals("*") && lPredIndices[1].equals("*");
        } else if (!hasLPredIndices) {
            return false;
        }

        // Check the indices.
        if (!lPredIndices[0].equals("*") && !viewIndices[0].equals(lPredIndices[0])) {
            return false;
        }

        if (!lPredIndices[1].equals("*") && !viewIndices[1].equals(lPredIndices[1])) {
            return false;
        }

        return true;
    }

    private static String[] getIndices(String predExpList) {
        return predExpList.replaceAll(".*\\(", "").replaceAll("\\)", "").split(",");
    }

    private static final String PREDICATE_CLASSNAME_EXT_REGEX =
            "([a-zA-Z0-9\\.]+[a-zA-Z0-9\\.])[\\[.*\\]]?";
    private static final Pattern PREDICATE_CLASSNAME_EXT_PTRN =
            Pattern.compile(PREDICATE_CLASSNAME_EXT_REGEX);

    @VisibleForTesting
    @Nullable
    private static String classNameExtractor(String predicate) {
        try {
            final Matcher matcher = PREDICATE_CLASSNAME_EXT_PTRN.matcher(predicate);
            if (matcher.find()) {
                return matcher.group(1);
            }
            return null;
        } catch (Exception e) {
            InsertLogger.d("Predicate class didn't match: '" + predicate + "'.");
            return null;
        }
    }

    private static final String PREDICATE_INDEX_REGEX =
            "(indexPath=\\(.+,.+\\))";
    private static final String PREDICATE_TEXT_REGEX =
            "(text=\\\"?([a-zA-Z=0-9\\|\\-\\_]*)\\\"?)";

    private static final String PREDICATE_INDEX_EXTRACTOR_REGEX =
            ".*" + PREDICATE_INDEX_REGEX + ".*";
    private static final Pattern PREDICATE_INDEX_EXTRACTOR_PTRN =
            Pattern.compile(PREDICATE_INDEX_EXTRACTOR_REGEX);

    @VisibleForTesting
    @Nullable
    private static String indexExtractor(String predicate) {
        try {
            final Matcher matcher = PREDICATE_INDEX_EXTRACTOR_PTRN.matcher(predicate);
            if (matcher.find()) {
                return matcher.group(1);
            }
            return null;
        } catch (Exception e) {
            InsertLogger.d("Predicate index didn't match: '" + predicate + "'.");
            return null;
        }
    }

    private static final String PREDICATE_TEXT_EXTRACTOR_REGEX =
            ".*" + PREDICATE_TEXT_REGEX + ".*";
    private static final Pattern PREDICATE_TEXT_EXTRACTOR_PTRN =
            Pattern.compile(PREDICATE_TEXT_EXTRACTOR_REGEX);

    @VisibleForTesting
    @Nullable
    public static String textExtractor(String predicate) {
        try {
            final Matcher matcher = PREDICATE_TEXT_EXTRACTOR_PTRN.matcher(predicate);
            if (matcher.find()) {
                return matcher.group(2);
            }
            return null;
        } catch (Exception e) {
            InsertLogger.d("Predicate text didn't match: '" + predicate + "'.");
            return null;
        }
    }
}
