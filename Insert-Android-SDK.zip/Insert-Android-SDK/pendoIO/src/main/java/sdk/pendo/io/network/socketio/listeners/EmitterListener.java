package sdk.pendo.io.network.socketio.listeners;

import external.sdk.pendo.io.socket.emitter.Emitter;

/**
 * Wrapper abstract class for the {@link external.sdk.pendo.io.socket.emitter.Emitter.Listener}.
 *
 * Created by assaf on 4/20/15.
 */
public abstract class EmitterListener implements Emitter.Listener {


}
