package sdk.pendo.io.events;

import android.support.annotation.Nullable;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by nirsegev on 8/12/15.
 */
public class TriggerPreference {

    public enum EventPreferenceValueType {
        STRING("string"),
        NUMBER("number"),
        BOOLEAN("boolean"),
        DATE("date");

        private static final Map<String, EventPreferenceValueType> lookupByEvent = new HashMap<>();

        static {
            for (EventPreferenceValueType s : EnumSet.allOf(EventPreferenceValueType.class)) {
                lookupByEvent.put(s.type, s);
            }
        }

        private String type;

        EventPreferenceValueType(String type) {
            this.type = type;
        }

        public static EventPreferenceValueType getTypeForString(String typeString) {
            return lookupByEvent.get(typeString);
        }

        public String getType() {
            return type;
        }

        public boolean equals(String type) {
            return this.type.equals(type);
        }
    }

    public enum EventPreferenceType {
        USER("user");

        private static final Map<String, EventPreferenceType> lookupByEvent = new HashMap<>();

        static {
            for (EventPreferenceType s : EnumSet.allOf(EventPreferenceType.class)) {
                lookupByEvent.put(s.type, s);
            }
        }

        private String type;

        EventPreferenceType(String type) {

            this.type = type;
        }

        public String getType() {
            return type;
        }

        public boolean equals(String type) {
            return this.type.equals(type);
        }

        public static EventPreferenceType getTypeForString(String typeString) {
            return lookupByEvent.get(typeString);
        }
    }

    public enum EventPreferenceOperator {
        EQUAL("eq") {
            public <T> boolean compare(@Nullable T lco, @Nullable T rco) {
                if (lco == null && rco == null) {
                    return true;
                } else if (lco != null) {
                    return lco.equals(rco);
                }

                return false;
            }
        },

        NOT_EQUAL("notEq") {
            public <T> boolean compare(@Nullable T lco, @Nullable T rco) {

                return !EQUAL.compare(lco, rco);
            }
        };

        private static final Map<String, EventPreferenceOperator> lookupByEvent = new HashMap<>();

        static {
            for (EventPreferenceOperator s : EnumSet.allOf(EventPreferenceOperator.class)) {
                lookupByEvent.put(s.type, s);
            }
        }

        private String type;

        EventPreferenceOperator(String type) {

            this.type = type;
        }

        public static EventPreferenceOperator getTypeByString(String operator) {
            return lookupByEvent.get(operator);
        }

        public String getType() {
            return type;
        }

        public boolean equals(String type) {
            return this.type.equals(type);
        }

        public <T> boolean compare(@Nullable T lco, @Nullable T rco) {
            throw new AbstractMethodError();
        }
    }

    @Nullable
    String type;
    @Nullable
    String name;
    @Nullable
    String value;
    @Nullable
    String valueType;
    @Nullable
    String operator;
    @Nullable
    String defaultValue;

    @Nullable
    public String getType() {
        return type;
    }

    @Nullable
    public String getName() {
        return name;
    }

    @Nullable
    public String getValue() {
        return value;
    }

    @Nullable
    public String getValueType() {
        return valueType;
    }

    @Nullable
    public String getOperator() {
        return operator;
    }

    @Nullable
    public String defaultValue() {
        return defaultValue;
    }
}
