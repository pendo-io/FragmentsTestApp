package sdk.pendo.io.network.interfaces;

import external.sdk.pendo.io.okhttp3.RequestBody;
import external.sdk.pendo.io.okhttp3.ResponseBody;
import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.http.Body;
import external.sdk.pendo.io.retrofit2.http.POST;
import io.reactivex.Observable;

/**
 * REST API for the analytics data.
 *
 * Created by assaf on 6/18/15.
 */
public interface ErrorData {

    @POST("v" + RestAPI.REST_API_VERSION + "/devices/errorData")
    Observable<Response<ResponseBody>> send(@Body RequestBody json);
}
