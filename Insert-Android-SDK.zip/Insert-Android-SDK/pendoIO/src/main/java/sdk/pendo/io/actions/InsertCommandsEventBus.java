package sdk.pendo.io.actions;

import android.support.annotation.CheckResult;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import java.util.LinkedList;
import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.FlowableTransformer;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.processors.PublishProcessor;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.reactive.observers.InsertObserver;

/**
 * Pendo's {@link InsertCommand} event bus. // TODO: 3/20/16 Add doc.
 *
 * Created by assaf on 3/14/16.
 */
public final class InsertCommandsEventBus {
    private static volatile InsertCommandsEventBus INSTANCE;

    private final PublishProcessor<InsertCommand> mCommandEventBus = PublishProcessor.create();

    private InsertCommandsEventBus() {
    }

    public static synchronized InsertCommandsEventBus getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InsertCommandsEventBus();
        }

        return INSTANCE;
    }

    public Flowable<InsertCommand> getCommandEventBus() {
        return mCommandEventBus.onBackpressureBuffer();
    }

    /** package */ void send(InsertCommand command) {
        mCommandEventBus.onNext(command);
    }

    /** package */ void send(List<InsertCommand> commands) {

        Observable.fromIterable(commands)
                .subscribe(InsertObserver.create(new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.i("Sending: " + insertCommand.toString());
                        mCommandEventBus.onNext(insertCommand);
                    }
                }));
    }

    public Disposable subscribe(@Nullable Predicate<InsertCommand> filter,
                                @NonNull Consumer<InsertCommand> observer) {

        return subscribe(null, null, filter, observer);
    }

    public Disposable subscribe(@Nullable Flowable<?> takeUntil,
                                  @Nullable Predicate<InsertCommand> filter,
                                  @NonNull Consumer<InsertCommand> observer) {
        return subscribe(null, takeUntil, filter, observer);
    }

    public Disposable subscribe(
            @Nullable FlowableTransformer<InsertCommand, InsertCommand> transformer,
            @Nullable Predicate<InsertCommand> filter,
            @NonNull Consumer<InsertCommand> observer) {
        return subscribe(transformer, null, filter, observer);
    }

    public Disposable subscribe(
            @Nullable FlowableTransformer<InsertCommand, InsertCommand> transformer,
            @Nullable Flowable<?> takeUntil,
            @Nullable Predicate<InsertCommand> filter,
            @NonNull Consumer<InsertCommand> observer) {

        if (transformer == null && takeUntil == null && filter == null) {
            return mCommandEventBus.subscribe(observer, new InsertOnErrorHandler());
        }

        Flowable<InsertCommand> insertCommandObservable = null;
        if (transformer != null) {
            insertCommandObservable = mCommandEventBus
                    .compose(transformer);
        }

        if (takeUntil != null) {
            insertCommandObservable = mCommandEventBus
                    .takeUntil(takeUntil);
        }

        if (filter != null) {
            if (insertCommandObservable != null) {
                insertCommandObservable = insertCommandObservable.filter(filter);
            } else {
                insertCommandObservable = mCommandEventBus.filter(filter);
            }
        }

        return insertCommandObservable.subscribe(observer, new InsertOnErrorHandler());
    }

    @SuppressWarnings({"CheckStyle", "unused"})
    public static final class Parameter {

        /** Constants for the JSON parsing. **/
        public static final String INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_NAME = "name";
        public static final String INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_TYPE = "type";
        public static final String INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_VALUE = "value";

        @NonNull
        @SerializedName(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_NAME)
        final String parameterName;

        @NonNull
        @SerializedName(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_TYPE)
        final String valueType;

        @NonNull
        @SerializedName(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_VALUE)
        final String parameterValue;

        /**
         * Creates a parameter to use with {@link InsertCommand}.
         *
         * @param parameterName the parameter's name.
         * @param valueType the parameter's value type.
         * @param parameterValue the parameter's value.
         */
        public Parameter(@NonNull String parameterName,
                         @NonNull String valueType,
                         @NonNull String parameterValue) {

            this.parameterName = parameterName;
            this.valueType = valueType;
            this.parameterValue = parameterValue;
        }

        @Override
        public String toString() {
            return "{ "
                    + "name: '" + getParameterName() + "' "
                    + "type: '" + getValueType() + "' "
                    + "value: '" + getParameterValue() + "' "
                    + "}";
        }

        @NonNull
        public String getParameterName() {
            return parameterName;
        }

        @NonNull
        public String getValueType() {
            return valueType;
        }

        @NonNull
        public String getParameterValue() {
            return parameterValue;
        }

        @SuppressWarnings("RedundantIfStatement")
        static boolean isValidInsertCommandParameterJSON(
                JsonObject insertCommandParameterJSON) {

            if (!insertCommandParameterJSON.has(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_NAME)) {
                return false;
            }

            if (!insertCommandParameterJSON.has(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_TYPE)) {
                return false;
            }

            if (!insertCommandParameterJSON.has(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_VALUE)) {
                return false;
            }

            return true;
        }

        @NonNull
        public static List<Parameter> createParameters(@NonNull JsonArray parametersJsonArray) {

            LinkedList<Parameter> retList = new LinkedList<>();
            if (parametersJsonArray != null) {
                for (JsonElement paramterJsonElement : parametersJsonArray) {
                    final JsonObject parameterJsonObject = paramterJsonElement.getAsJsonObject();
                    String parameterName = parameterJsonObject.get(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_NAME).getAsString();
                    String parameterType = parameterJsonObject.get(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_TYPE).getAsString();
                    String parameterValue = parameterJsonObject.get(INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_VALUE).getAsString();
                    retList.add(
                            new Parameter(
                                    parameterName,
                                    parameterType,
                                    parameterValue));
                }
            }

            return retList;
        }

        /**
         * Iterates over the given {@link Parameter}s looking for the parameter
         * with the given {@code name} and of the given {@code type} and returns it's value.
         *
         * @param parameters the parameters to look within.
         * @param name the name of the parameter.
         * @param type the type of the parameter's value.
         *
         * @return the value of the parameter with the given {@code name} and {@code type}.
         *
         * @throws NoSuchFieldException if no parameter was found with the given name and type.
         */
        @CheckResult
        public static <T> T getParameterValue(@NonNull List<Parameter> parameters,
                                              @NonNull String name,
                                              @NonNull Class<T> type) throws NoSuchFieldException {

            // TODO: 7/6/17 THIS MUST BE REFACTORED TO KOTLIN!
            for (Parameter parameter : parameters) {

                try {
                    if (name.equals(parameter.getParameterName())) {
                        final String value = parameter.getParameterValue();

                        if (String.class.equals(type) || String.class.isInstance(type)) {
                            return type.cast(value);
                        } else if (Integer.class.isInstance(type)) {
                            return type.cast(Integer.parseInt(value));
                        } else if (Float.class.isInstance(type)) {
                            return type.cast(Float.parseFloat(value));
                        } else if (Long.class.isInstance(type)) {
                            return type.cast(Long.parseLong(value));
                        } else if (Double.class.isInstance(type)) {
                            return type.cast(Double.parseDouble(value));
                        } else if (Boolean.class.isInstance(type)) {
                            return type.cast(Boolean.parseBoolean(value));
                        }
                    }
                } catch (Exception ignore) {
                }
            }

            throw new NoSuchFieldException("'" + name + "' of type: '" + type + "' wasn't found.");
        }
    }
}
