package sdk.pendo.io.utilities

import android.net.Uri
import android.text.TextUtils

import sdk.pendo.io.Pendo

object InsertEndpointUtil {

	private const val DEVICE_ENDPOINT_KEY = "device"
	private const val DATA_ENDPOINT_KEY = "data"
	private const val WEBSOCKET_ENDPOINT_KEY = "websocket"

	private val endpoints: Map<String, String>?
		get() {
			return when (Pendo.getDataCenter()) {
				"eu" -> mapOf(
					DEVICE_ENDPOINT_KEY to "https://eu.device2.mobile.pendo.io",
					DATA_ENDPOINT_KEY to "https://eu.data2.mobile.pendo.io",
					WEBSOCKET_ENDPOINT_KEY to "https://app.eu.pendo.io"
				)
				"us" -> mapOf(
					DEVICE_ENDPOINT_KEY to "https://us.device2.mobile.pendo.io",
					DATA_ENDPOINT_KEY to "https://us.data2.mobile.pendo.io",
					WEBSOCKET_ENDPOINT_KEY to "https://app.pendo.io"
				)
				else -> null
			}
		}

	private val productionApiUri: Uri?
		get() {
			val uriString = endpoints?.get(DEVICE_ENDPOINT_KEY)
			return if (TextUtils.isEmpty(uriString)) {
				null
			} else Uri.parse(uriString)
		}

	private val productionAnalyticsUri: Uri?
		get() {
			val uriString = endpoints?.get(DATA_ENDPOINT_KEY)
			return if (TextUtils.isEmpty(uriString)) {
				null
			} else Uri.parse(uriString)
		}

	val productionSocketUri: Uri?
		get() {
			val uriString = endpoints?.get(WEBSOCKET_ENDPOINT_KEY)
			return if (TextUtils.isEmpty(uriString)) {
				null
			} else Uri.parse(uriString)
		}

	private val customAnalyticsUri: Uri?
		get() {
			return validateUrl(SettingsUtils.getCustomInsertAnalyticsUrl(Pendo.getApplicationContext()))
		}

	private val customApiUri: Uri?
		get() {
			return validateUrl(SettingsUtils.getCustomInsertUrl(Pendo.getApplicationContext()))
		}


	val customSocketUri: Uri?
		get() {
			return validateUrl(SettingsUtils.getCustomSocketUrl(Pendo.getApplicationContext()))
		}

	/**
	 * Calculates the api endpoint with the cname and custom url if needed.
	 *
	 * @return
	 */
	fun calculateApiEndpoint(): Uri? {
		val customInsertUrl = SettingsUtils.getCustomInsertUrl(Pendo.getApplicationContext())
		return if (!TextUtils.isEmpty(customInsertUrl)) {
			InsertEndpointUtil.customApiUri
		} else {
			InsertEndpointUtil.productionApiUri
		}
	}

	/**
	 * Calculates the api endpoint with the cname and custom url if needed.
	 *
	 * @return
	 */
	fun calculateAnalyticsEndpoint(): Uri? {
		val customInsertUrl = SettingsUtils.getCustomInsertAnalyticsUrl(Pendo.getApplicationContext())
		return if (!TextUtils.isEmpty(customInsertUrl)) {
			InsertEndpointUtil.customAnalyticsUri
		} else {
			InsertEndpointUtil.productionAnalyticsUri
		}
	}

	/**
	 * Validating the url is ok and injecting a prefix with the company name if set by the host app
	 *
	 * @param customSocketUrl
	 * @return
	 */
	private fun validateUrl(customSocketUrl: String?): Uri? {
		return if (TextUtils.isEmpty(customSocketUrl)) {
			null
		} else Uri.parse(customSocketUrl)
	}

}
