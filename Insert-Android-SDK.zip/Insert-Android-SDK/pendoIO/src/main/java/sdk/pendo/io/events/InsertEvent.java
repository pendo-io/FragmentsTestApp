package sdk.pendo.io.events;

import android.support.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.network.responses.TriggerModel;

/**
 * Pendo's event class.
 * <p/>
 * Created by assaf on 4/28/15.
 */
public final class InsertEvent {

    @SerializedName("triggers")
    private List<TriggerModel> triggers;
    private int id;
    @SerializedName("configuration")
    private EventConfiguration mConfiguration;

    public enum EventActions {
        CLICK("click"),
        SCREEN_VIEW("screenView"),
        SCREEN_LEFT("screenLeft"),
        ELEMENT_VIEW("elementView"), // Banner & Tooltip
        ELEMENT_VIEW_INTERNAL("elementViewInternal"), // Change/Highlight Text, Modify/Embedded Image
        APP_LAUNCHED("appLaunched"),
        DIRECT_LINK("directLink"),
        PREVIEW("preview"),
        CUSTOM_EVENT("customEvent");

        private static final Map<String, EventActions> LOOKUP_BY_EVENT = new HashMap<>();

        static {
            for (EventActions s : EnumSet.allOf(EventActions.class)) {
                LOOKUP_BY_EVENT.put(s.action, s);
            }
        }

        public final String action;

        EventActions(String action) {
            this.action = action;
        }

        @Nullable
        public static EventActions get(String action) {
            return LOOKUP_BY_EVENT.get(action);
        }

        public boolean equals(String action) {
            return this.action.equals(action);
        }
    }

    public enum EventTypes {
        TEXT_TWEAK("textTweak"),
        IMAGE_TWEAK("imageTweak"),
        EMBEDDED_LIST_CELL_TWEAK("embeddedListCellTweak");

        private static final Map<String, EventTypes> LOOKUP_BY_EVENT = new HashMap<>();

        static {
            for (EventTypes s : EnumSet.allOf(EventTypes.class)) {
                LOOKUP_BY_EVENT.put(s.type, s);
            }
        }

        public final String type;

        EventTypes(String type) {
            this.type = type;
        }

        @Nullable
        public static EventTypes get(String type) {
            return LOOKUP_BY_EVENT.get(type);
        }

        public boolean equals(String type) {
            return this.type.equals(type);
        }
    }

    @Override
    public String toString() {
        return Pendo.GSON.toJson(this);
    }

    public EventConfiguration getConfiguration() {
        return mConfiguration;
    }

    public void setConfiguration(EventConfiguration configuration) {
        mConfiguration = configuration;
    }

    public int getId() {
        return id;
    }

    public List<TriggerModel> getTriggers() {
        return triggers;
    }
}
