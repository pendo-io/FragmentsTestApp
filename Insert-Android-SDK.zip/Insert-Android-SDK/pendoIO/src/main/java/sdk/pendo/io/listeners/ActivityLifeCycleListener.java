package sdk.pendo.io.listeners;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

import com.trello.rxlifecycle3.android.ActivityEvent;

import sdk.pendo.io.activities.PendoGateActivity;
import sdk.pendo.io.events.DirectLinkEventManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.utilities.ConnectivityUtils;

/**
 * A listener for all the main activity life cycle.
 * <p>
 * Created by assaf on 4/8/15.
 */
public final class ActivityLifeCycleListener implements Application.ActivityLifecycleCallbacks {

    private static volatile ActivityLifeCycleListener INSTANCE;

    private ActivityLifeCycleListener() { }
    public static synchronized ActivityLifeCycleListener getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ActivityLifeCycleListener();
        }

        return INSTANCE;
    }

    @Override
    public void onActivityCreated(final Activity activity, Bundle savedInstanceState) {
        InsertLogger.i(activity.getLocalClassName());

        DirectLinkEventManager.getInstance().updateDirectLinkIfNeeded(activity);
        if (activity.getLocalClassName().contains(PendoGateActivity.PENDO_GATE_ACTIVITY)) {
            SocketIOUtils.setEnteredFromGateActivity(true);
        }
        ApplicationObservers.getInstance().updateLifecycleEvent(ActivityEvent.CREATE);
        ActivityLifecycleEventsObserver.getInstance().notifyListeners(activity, ActivityEvent.CREATE);
    }

    @Override
    public void onActivityStarted(final Activity activity) {
        InsertLogger.i(activity.getLocalClassName());

//        ApplicationFlowManager.getInstance().incrementStartStopCounter();
        ApplicationFlowManager.getInstance().appInForeground();
        ApplicationObservers.getInstance().updateLifecycleEvent(ActivityEvent.START);
        ActivityLifecycleEventsObserver.getInstance().notifyListeners(activity, ActivityEvent.START);
    }

    @Override
    public void onActivityResumed(final Activity activity) {
        InsertLogger.i(activity.getLocalClassName());

        DirectLinkEventManager.getInstance().updateDirectLinkIfNeeded(activity);
        ApplicationObservers.getInstance().addVisibleActivity(activity);
        ApplicationObservers.getInstance().updateLifecycleEvent(ActivityEvent.RESUME);
        ApplicationObservers.getInstance().activityInsideApp(true);
        ActivityLifecycleEventsObserver.getInstance().notifyListeners(activity, ActivityEvent.RESUME);
        ConnectivityUtils.registerConnectivityActionReceiver(activity.getApplicationContext());
    }

    @Override
    public void onActivityPaused(Activity activity) {
        InsertLogger.i(activity.getLocalClassName());
        ApplicationObservers.getInstance().removeVisibleActivity(activity);
        ApplicationFlowManager.getInstance().setPreviousActivity(activity.getClass().getName());
        ApplicationObservers.getInstance().updateLifecycleEvent(ActivityEvent.PAUSE);
        ActivityLifecycleEventsObserver.getInstance().notifyListeners(activity, ActivityEvent.PAUSE);
        ConnectivityUtils.unregisterConnectivityActionReceiver(activity.getApplicationContext());
    }

    @Override
    public void onActivityStopped(Activity activity) {
        InsertLogger.i(activity.getLocalClassName());
//        ApplicationFlowManager.getInstance().decrementStartStopCounter();
        ApplicationObservers.getInstance().updateLifecycleEvent(ActivityEvent.STOP);
        ActivityLifecycleEventsObserver.getInstance().notifyListeners(activity, ActivityEvent.STOP);
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        InsertLogger.i(activity.getLocalClassName());
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        InsertLogger.i(activity.getLocalClassName());
        ApplicationObservers.getInstance().removeLastVisibleActivityNotDestroyed(activity.getLocalClassName());
        ApplicationObservers.getInstance().updateLifecycleEvent(ActivityEvent.DESTROY);
        ActivityLifecycleEventsObserver.getInstance().notifyListeners(activity, ActivityEvent.DESTROY);
    }

}
