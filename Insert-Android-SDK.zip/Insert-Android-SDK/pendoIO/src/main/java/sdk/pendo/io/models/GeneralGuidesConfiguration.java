package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.actions.configurations.GuideCapping;

public class GeneralGuidesConfiguration {

    @SerializedName("capping")
    private GuideCapping mCapping;

    public GuideCapping getCapping() {
        return mCapping;
    }
}
