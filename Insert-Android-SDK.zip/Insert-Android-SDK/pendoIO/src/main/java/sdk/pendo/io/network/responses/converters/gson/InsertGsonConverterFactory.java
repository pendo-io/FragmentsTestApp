package sdk.pendo.io.network.responses.converters.gson;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import external.sdk.pendo.io.okhttp3.RequestBody;
import external.sdk.pendo.io.okhttp3.ResponseBody;
import external.sdk.pendo.io.retrofit2.Converter;
import external.sdk.pendo.io.retrofit2.Retrofit;
import sdk.pendo.io.Pendo;

/**
 * A {@linkplain Converter.Factory converter} which uses Gson for JSON.
 * <p>
 * Because Gson is so flexible in the types it supports, this converter assumes that it can handle
 * all types. If you are mixing JSON serialization with something else (such as protocol buffers),
 * you must {@linkplain Retrofit.Builder#addConverterFactory(Converter.Factory) add this instance}
 * last to allow the other converters a chance to see their types.
 */
public final class InsertGsonConverterFactory extends Converter.Factory {
    /**
     * Create an instance using a default {@link Gson} instance for conversion. Encoding to JSON and
     * decoding from JSON (when no charset is specified by a header) will use UTF-8.
     */
    public static InsertGsonConverterFactory create() {
        return create(Pendo.GSON);
    }

    /**
     * Create an instance using {@code gson} for conversion. Encoding to JSON and
     * decoding from JSON (when no charset is specified by a header) will use UTF-8.
     */
    public static InsertGsonConverterFactory create(Gson gson) {
        return new InsertGsonConverterFactory(gson);
    }

    private final Gson mGson;

    private InsertGsonConverterFactory(Gson gson) {
        if (gson == null) throw new NullPointerException("gson == null");
        mGson = gson;
    }

    @Override
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations,
                                                            Retrofit retrofit) {
        TypeAdapter<?> adapter = mGson.getAdapter(TypeToken.get(type));
        return new InsertGsonResponseBodyConverter<>(adapter, type);
    }

    @Override
    public Converter<?, RequestBody> requestBodyConverter(Type type,
                                                          Annotation[] parameterAnnotations, Annotation[] methodAnnotations, Retrofit retrofit) {
        TypeAdapter<?> adapter = mGson.getAdapter(TypeToken.get(type));
        return new InsertGsonRequestBodyConverter<>(mGson, adapter);
    }
}
