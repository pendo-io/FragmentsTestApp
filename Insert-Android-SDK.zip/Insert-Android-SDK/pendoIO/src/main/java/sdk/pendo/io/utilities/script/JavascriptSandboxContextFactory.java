package sdk.pendo.io.utilities.script;

import external.sdk.pendo.io.mozilla.javascript.Callable;
import external.sdk.pendo.io.mozilla.javascript.ClassShutter;
import external.sdk.pendo.io.mozilla.javascript.Context;
import external.sdk.pendo.io.mozilla.javascript.ContextAction;
import external.sdk.pendo.io.mozilla.javascript.ContextFactory;
import external.sdk.pendo.io.mozilla.javascript.Scriptable;

import java.util.HashMap;
import java.util.Map;

/**
 * Factory class that Rhino runtime uses to create new {@link Context}
 * instances. A <code>ContextFactory</code> can also notify listeners
 * about context creation and release.
 * <p>
 * When the Rhino runtime needs to create new {@link Context} instance during
 * execution of {@link Context#enter()} or {@link Context}, it will call
 * {@link #makeContext()} of the current global ContextFactory.
 * See {@link #getGlobal()} and {@link #initGlobal(ContextFactory)}.
 * <p>
 * It is also possible to use explicit ContextFactory instances for Context
 * creation. This is useful to have a set of independent Rhino runtime
 * instances under single JVM. See {@link #call(ContextAction)}.
 *
 * Created by assaf on 11/6/16.
 */
class JavascriptSandboxContextFactory extends ContextFactory {
    private static final int INSTRUCTION_OBSERVER_THRESHOLD = 10000;

    private final ScriptSandbox mShutter;

    JavascriptSandboxContextFactory(ScriptSandbox shutter) {
        mShutter = shutter;
    }

    @Override
    protected final Context makeContext() {

        // Create our context.
        InsertIoJSContext cx = new InsertIoJSContext(this);

        // Set the wrapping factory to our.
        cx.setWrapFactory(new JavascriptSandboxWrapFactory(mShutter));

        // Set the basic class shutter implementation.
        cx.setClassShutter(new ClassShutter() {

            // Saves the results for faster execution.
            private final Map<String, Boolean> mNameToAccepted = new HashMap<>();

            @Override
            public boolean visibleToScripts(String className) {
                Boolean granted = mNameToAccepted.get(className);

                if (granted != null) {
                    return granted;
                }

                Class<?> staticType;
                try {

                    // Try to create a class from the given className,
                    // if exception was raised it means the class either does not exists
                    // or we cannot access it.
                    staticType = Class.forName(className);
                } catch (Exception exc) {
                    mNameToAccepted.put(className, Boolean.FALSE);
                    return false;
                }

                // If we managed to create a class for that className,
                // check if the class is allowed.
                boolean grant = mShutter.allowClassAccess(staticType);

                mNameToAccepted.put(className, grant);
                return grant;
            }
        });

        // Set the maximum instruction counter so scripts will not run forever or too long.
        cx.setInstructionObserverThreshold(INSTRUCTION_OBSERVER_THRESHOLD);
        return cx;
    }

    @Override
    protected final void observeInstructionCount(Context cx, int instructionCount) {
        InsertIoJSContext icx = (InsertIoJSContext) cx;
        long currentTime = System.currentTimeMillis();
        if (currentTime - icx.getStartTime() > INSTRUCTION_OBSERVER_THRESHOLD) {
            // More then 10 seconds from Context creation time:
            // it is time to stop the script.
            // Throw Error instance to ensure that script will never
            // get control back through catch or finally.
            throw new Error();
        }
    }

    /**
     * Execute top call to script or function.
     * When the runtime is about to execute a script or function that will create the
     * first stack frame with scriptable code, it calls this method to perform the real call.
     * In this way execution of any script happens inside this function.
     */
    @Override
    protected Object doTopCall(Callable callable,
                               Context cx, Scriptable scope,
                               Scriptable thisObj, Object[] args) {
        InsertIoJSContext icx = (InsertIoJSContext) cx;
        icx.setStartTime(System.currentTimeMillis());

        return super.doTopCall(callable, cx, scope, thisObj, args);
    }

    /**
     * This class represents the runtime context of an executing script.
     *
     * Before executing a script, an instance of Context must be created
     * and associated with the thread that will be executing the script.
     * The Context will be used to store information about the executing
     * of the script such as the call stack. Contexts are associated with
     * the current thread  using the {@link #call(ContextAction)}
     * or {@link #enter()} methods.<p>
     *
     * Different forms of script execution are supported. Scripts may be
     * evaluated from the source directly, or first compiled and then later
     * executed. Interactive execution is also supported.<p>
     *
     * Some aspects of script execution, such as type conversions and
     * object creation, may be accessed directly through methods of
     * Context.
     *
     * @see Scriptable
     */
    static class InsertIoJSContext extends Context {
        private long mStartTime;

        InsertIoJSContext(ContextFactory factory) {
            super(factory);
        }

        /**
         * @return the time of when the script started to run in milliseconds.
         */
        long getStartTime() {
            return mStartTime;
        }

        /**
         * @param startTime the time of when the script started to run in milliseconds.
         */
        void setStartTime(long startTime) {
            mStartTime = startTime;
        }
    }
}
