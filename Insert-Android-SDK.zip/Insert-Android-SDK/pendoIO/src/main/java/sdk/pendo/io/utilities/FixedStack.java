package sdk.pendo.io.utilities;

import java.util.Stack;

/**
 * Stack data structure which holds up to defined size.
 * @param <T>
 */
public class FixedStack<T> extends Stack<T> {
    private static final int MAX_STACK_SIZE = 128;
    private int mMaxSize = 0;

    public FixedStack(int size) {
        super();
        mMaxSize = size;
    }

    public FixedStack() {
        super();
        mMaxSize = MAX_STACK_SIZE;
    }

    @Override
    public final Object push(Object object) {
        //If the stack is too big, remove elements until it's the right size.
        while (this.size() >= mMaxSize) {
            this.remove(0);
        }
        return super.push((T) object);
    }
}
