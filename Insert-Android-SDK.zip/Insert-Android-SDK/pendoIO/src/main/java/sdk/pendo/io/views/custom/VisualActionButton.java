package sdk.pendo.io.views.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;

import org.apache.commons.lang3.tuple.Pair;

import java.util.List;

import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType.UserEventType;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.views.custom.ActionableBlock.OnSubmitAction.CHANGE_SCREEN;
import static sdk.pendo.io.views.custom.ActionableBlock.OnSubmitAction.CLOSE;

/**
 *
 * Created by nirsegev on 8/3/15.
 */
public final class VisualActionButton extends Button implements ActionableBlock, InsertCustomView {

    public static final int NUMBER_OF_STATES = 3;
    public static final int NORMAL_STATE_POSITION = 2;
    public static final int DISABLED_STATE_POSITION = 1;
    public static final int PRESSED_STATE_POSITION = 0;

    private String mActionParam;
    private String mOnSubmit;

    private float[] mCornerRadii;
    private int mStrokeWidth, mStrokeColor;

    int[] mButtonTextColors;
    boolean setPressedTextColor, setDisabledTextColor;
    int[][] mStates = new int[][]{
            new int[]{android.R.attr.state_pressed},  // pressed
            new int[]{-android.R.attr.state_enabled}, // disabled
            new int[]{}, // normal
    };

    private GradientDrawable mNormalBackgroundDrawable, mPressedBackgroundDrawable, mDisabledBackgroundDrawable;
    private StateListDrawable mStateListDrawable;

    public VisualActionButton(Context context) {
        this(context, null);
    }

    public VisualActionButton(Context context, AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public VisualActionButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        setOnClickListener(this);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public VisualActionButton(Context context, AttributeSet attrs, int defStyleAttr,
                              int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);

        setOnClickListener(this);
    }

    @Override
    public String getActionParam() {
        return mActionParam;
    }

    @Override
    public void setActionParam(String actionParam) {

        mActionParam = actionParam;
    }

    @NonNull
    @Override
    public CharSequence getElementId() {
        return getContentDescription();
    }

    @Override
    public void setStrokeWidth(int strokeWidth) {
        mStrokeWidth = strokeWidth;

    }

    @Override
    public void setStrokeColor(int strokeColor) {
        mStrokeColor = strokeColor;
    }

    @Override
    public void setCornerRadius(float cornerRadius) {
        mCornerRadii = new float[] {cornerRadius, cornerRadius, cornerRadius,
                cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius};
    }

    @Override
    public void setCornerRadii(float[] cornerRadii) {
        mCornerRadii = cornerRadii;
    }

    public void setNormalBackgroundColor(int normalBackgroundColor) {
        if (mNormalBackgroundDrawable == null) {
            mNormalBackgroundDrawable = new GradientDrawable();
        }
        ((GradientDrawable) mNormalBackgroundDrawable.mutate()).setColor(normalBackgroundColor);
    }

    public void setPressedBackgroundColor(int pressedBackgroundColor) {
        if (mPressedBackgroundDrawable == null) {
            mPressedBackgroundDrawable = new GradientDrawable();
        }
        ((GradientDrawable) mPressedBackgroundDrawable.mutate()).setColor(pressedBackgroundColor);
    }

    public void setDisabledBackgroundColor(int disabledBackgroundColor) {
        if (mDisabledBackgroundDrawable == null) {
            mDisabledBackgroundDrawable = new GradientDrawable();
        }
        ((GradientDrawable) mDisabledBackgroundDrawable.mutate()).setColor(disabledBackgroundColor);
    }

    public void setNormalTextColor(int normalTextColor) {
        if (mButtonTextColors == null) {
            mButtonTextColors = new int[NUMBER_OF_STATES];
        }
        mButtonTextColors[NORMAL_STATE_POSITION] = normalTextColor;
    }

    public void setPressedTextColor(int pressedTextColor) {
        if (mButtonTextColors == null) {
            mButtonTextColors = new int[NUMBER_OF_STATES];
        }
        mButtonTextColors[PRESSED_STATE_POSITION] = pressedTextColor;
        setPressedTextColor = true;
    }

    public void setDisabledTextColor(int disabledTextColor) {
        if (mButtonTextColors == null) {
            mButtonTextColors = new int[NUMBER_OF_STATES];
        }
        mButtonTextColors[DISABLED_STATE_POSITION] = disabledTextColor;
        setDisabledTextColor = true;
    }

    @Override
    public Pair<OnSubmitAction, String> getOnSubmit() {

        if (mOnSubmit != null) {
            if (mOnSubmit.equals(CLOSE.getOnSubmitActionName())) {
                return Pair.of(CLOSE, null);
            }

            if (mOnSubmit.startsWith(CHANGE_SCREEN.getOnSubmitActionName())) {

                try {
                    final String screenId = OnSubmitAction.getChangeScreenId(mOnSubmit);
                    return Pair.of(CHANGE_SCREEN, screenId);
                } catch (IllegalStateException e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }

        // Default is close.
        return Pair.of(CLOSE, null);
    }

    @Override
    public void setOnSubmit(String onSubmit) {
        mOnSubmit = onSubmit;
    }

    private List<InsertCommand> mCommands = null;
    @Override
    public void setActions(List<InsertCommand> commands) {

        if (commands == null || commands.isEmpty()) {
            InsertLogger.d("No commands.");
            return;
        }

        mCommands = commands;
    }

    @Override
    public void onClick(View v) {

        if (mCommands == null || mCommands.isEmpty()) {
            InsertLogger.d("No commands.");
            return;
        }
        JavascriptRunner.InsertContext.addBasicParamsToInsertCommands(mCommands);
        InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, UserEventType.TAP_ON, true);
    }

    @Override
    public void renderView() {
        if (setColorsIfNeeded()) {
            setTextColor(new ColorStateList(mStates, mButtonTextColors));
        }

        if (shouldChangeDefaultBackground()) {
            generateStateListDrawableBackground();
        }

        invalidate();
    }

    /**
     * We check if array of text colors has been instantiated. If true, we assume that normal
     * state color has been given, and we make sure that if 'pressed' or 'disabled' were not
     * given, we set each one of them to be the same as the 'normal' state color.
     * @return true if array of text colors has been instantiated. False otherwise.
     */
    private boolean setColorsIfNeeded() {
        if (mButtonTextColors != null) {
            if (!setPressedTextColor) {
                mButtonTextColors[PRESSED_STATE_POSITION] = mButtonTextColors[NORMAL_STATE_POSITION];
            }
            if (!setDisabledTextColor) {
                mButtonTextColors[DISABLED_STATE_POSITION] = mButtonTextColors[NORMAL_STATE_POSITION];
            }
            return true;
        }

        else {
            return false;
        }
    }

    /**
     * Generates the background for the Button. Consists of 3 different drawables, one for each state,
     * so we have maximum abilities and control over each state's look and feel.
     */
    private void generateStateListDrawableBackground() {
        mStateListDrawable = new StateListDrawable();

        if (mPressedBackgroundDrawable != null) {
            ((GradientDrawable) mPressedBackgroundDrawable.mutate()).setCornerRadii(mCornerRadii);
            ((GradientDrawable) mPressedBackgroundDrawable.mutate()).setStroke(mStrokeWidth, mStrokeColor);
            mStateListDrawable.addState(new int[]{android.R.attr.state_pressed}, mPressedBackgroundDrawable);
        }

        if (mDisabledBackgroundDrawable != null) {
            ((GradientDrawable) mDisabledBackgroundDrawable.mutate()).setCornerRadii(mCornerRadii);
            ((GradientDrawable) mDisabledBackgroundDrawable.mutate()).setStroke(mStrokeWidth, mStrokeColor);
            mStateListDrawable.addState(new int[]{-android.R.attr.state_enabled}, mDisabledBackgroundDrawable);
        }

        if (mNormalBackgroundDrawable != null) {
            ((GradientDrawable) mNormalBackgroundDrawable.mutate()).setCornerRadii(mCornerRadii);
            ((GradientDrawable) mNormalBackgroundDrawable.mutate()).setStroke(mStrokeWidth, mStrokeColor);
            mStateListDrawable.addState(new int[]{}, mNormalBackgroundDrawable);
        }

        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN) {
            //noinspection deprecation
            setBackgroundDrawable(mStateListDrawable);
        } else {
            setBackground(mStateListDrawable);
        }
    }

    private boolean shouldChangeDefaultBackground() {
        return mNormalBackgroundDrawable != null
                || mPressedBackgroundDrawable != null
                || mDisabledBackgroundDrawable != null;
    }
}
