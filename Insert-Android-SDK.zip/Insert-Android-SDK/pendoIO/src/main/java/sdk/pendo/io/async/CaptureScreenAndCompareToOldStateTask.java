package sdk.pendo.io.async;

import android.app.Activity;
import android.graphics.Bitmap;
import android.view.View;
import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import sdk.pendo.io.events.ConditionData;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.network.responses.ScreenIdentificationData;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.utilities.ViewHierarchyUtility;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Captures app screen and compares the screen views to the old screen views given.
 * This class is used as part of the upgrade app version feature
 * that is done by the marketer during pairing
 */

public class CaptureScreenAndCompareToOldStateTask extends CaptureScreenTask {

    private static final String OLD_CONDITION_INDEX = "conditionIndex";
    private static final String NEW_ELEMENT_INFO = "elementInfo";
    private List<ConditionData> mOldConditions;
    private ScreenIdentificationData mOldScreenIdentificationData;
    private String mNewScreenIdActivityName;
    private List<Pair<Integer, IdentificationData>> mOldStateViewNewElementInfoMap = new ArrayList<>();

    public CaptureScreenAndCompareToOldStateTask(Activity activity,
                                                 List<ConditionData> oldConditions,
                                                 ScreenIdentificationData oldScreenIdentificationData,
                                                 CaptureScreenListener listener) {
        super(activity, listener);
        mOldConditions = oldConditions;
        mOldScreenIdentificationData = oldScreenIdentificationData;
        mNewScreenIdActivityName = activity.getLocalClassName();
    }

    /**
     * Generates the view tree and screen state as a preperation for sending it to the socket
     * @param view
     * @return
     */
    @Override
    protected Pair<JSONArray, JSONArray> generateViewTreeAndScreenState(View view) {
        return ViewHierarchyUtility.INSTANCE
                .getViewTreeAndScreenStateComparedToOldState(view,
                        mOldConditions,
                        mOldStateViewNewElementInfoMap);
    }

    @Override
    protected ScreenIdentificationData generateScreenId(Activity activity) {
        ScreenIdentificationData screenIdentificationData = super.generateScreenId(activity);
        mNewScreenIdActivityName = screenIdentificationData.getActivityName();
        return  screenIdentificationData;
    }

    /**
     * Prepares the screen data and send it via the socket to the backend
     * @param bitmap the screen capture bitmap
     * @throws JSONException
     */
    @Override
    protected void prepareScreenData(Bitmap bitmap) throws JSONException {
        // First make sure the old screen identification is similar to the new one.
        boolean newScreenIdEqualToOld = mNewScreenIdActivityName.equals(mOldScreenIdentificationData.getActivityName());

        // Then capture the screen
        SocketIOUtils.sendCapturedScreen(SocketEvents.EVENT_IDENTIFY_SCREEN_IDENTIFIED,
                getViewTree(),
                bitmap,
                newScreenIdEqualToOld ? generateObjectFromCompareMap(mOldStateViewNewElementInfoMap) : new JSONArray());
    }

    /**
     * Generates a json array map from the list of pair of old state identification id and new one
     * @param oldStateViewNewStateViewMap
     * @return json array representing the old vs new state view state
     */
    private JSONArray generateObjectFromCompareMap(List<Pair<Integer, IdentificationData>> oldStateViewNewStateViewMap) {
        JSONArray array = new JSONArray();
        for (Pair<Integer, IdentificationData> oldNewpair : oldStateViewNewStateViewMap) {
            JSONObject pair = new JSONObject();
            try {
                pair.put(OLD_CONDITION_INDEX, oldNewpair.getLeft());
                pair.put(NEW_ELEMENT_INFO, oldNewpair.getRight());
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            array.put(pair);
        }
        return array;
    }
}