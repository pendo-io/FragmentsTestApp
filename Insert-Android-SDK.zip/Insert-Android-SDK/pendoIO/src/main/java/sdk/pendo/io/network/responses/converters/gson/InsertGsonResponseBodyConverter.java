package sdk.pendo.io.network.responses.converters.gson;

import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;

import org.jose4j.jwt.consumer.InvalidJwtException;

import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.Scanner;

import external.sdk.pendo.io.okhttp3.ResponseBody;
import external.sdk.pendo.io.retrofit2.Converter;
import sdk.pendo.io.cache.GuideCacheManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.InitModel;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.utilities.AnalyticsUtils;

final class InsertGsonResponseBodyConverter<T> implements Converter<ResponseBody, T> {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private final TypeAdapter<T> mAdapter;
    private final Type mType;

    InsertGsonResponseBodyConverter(TypeAdapter<T> adapter, Type type) {
        mAdapter = adapter;
        mType = type;
    }

    @Override
    public T convert(ResponseBody value) throws IOException {

        InputStreamReader isr = null;
        try {
            isr = new InputStreamReader(value.byteStream(), UTF8);
            Scanner s = new Scanner(isr).useDelimiter("\\A");
            final String json = s.hasNext() ? s.next() : "";

            boolean isInitRequest = false;
            if (mType != null) {
                TypeToken typeToken = TypeToken.get(mType);
                isInitRequest = typeToken.getRawType().equals(InitModel.class);
            }

            try {
                String validated = JsonWebTokenValidator.INSTANCE.validate(json);

                // If this is the init request, store the signed json in the cache.
                if (isInitRequest) {
                    GuideCacheManager.getInstance().storeCachedInsertAndEvents(json, GuideCacheManager.CACHE_FILE_NAME);
                }

                return mAdapter.fromJson(validated);
            } catch (InvalidJwtException e) {
                InsertLogger.d(e, e.getMessage());
                if (isInitRequest) {
                    AnalyticsUtils.sendJwtSecurityException(json, "init", e.getMessage());
                }

                return null;
            }
        } finally {
            if (isr != null) {
                try {
                    isr.close();
                } catch (IOException ignored) {
                }
            }
            value.close();
        }
    }
}
