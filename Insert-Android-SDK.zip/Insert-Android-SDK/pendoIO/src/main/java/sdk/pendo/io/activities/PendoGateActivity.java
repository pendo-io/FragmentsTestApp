package sdk.pendo.io.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.jose4j.jwt.consumer.InvalidJwtException;

import io.reactivex.functions.Consumer;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.R;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.InsertPushData;
import sdk.pendo.io.models.ShowInsertData;
import sdk.pendo.io.models.ShowInsertLinkData;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.network.socketio.SocketIOManager;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.Utils;

public final class PendoGateActivity extends Activity {

    private static final String MODE_PAIRING = "pairing";
    private static final String MODE_DIRECT_LINK = "showInsert";
    private static final String DIRECT_LINK_DATA_KEY = "data";
    private static final String INSERT_VIEWER_PACKAGE_NAME = "com.insertViewer";
    public static final String INSERT_PUSH_DATA_KEY = "insertData";
    public static final String SHOW_INSERT_LINK_KEY = "showInsertLink";
    public static final String TRIGGER_ID_KEY = "triggerId";
    public static final String INSERT_ID_KEY = "insertId";
    public static final String PENDO_GATE_ACTIVITY = "PendoGateActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent origIntent = getIntent();
        Bundle extrasForNewIntent = new Bundle();

        final Uri data = origIntent.getData();
        if (data != null) {
            if (getPackageName().equals(INSERT_VIEWER_PACKAGE_NAME)) {
                handleInsertViewer();
            }

            if (MODE_PAIRING.equals(data.getHost())) {
                startPairingProcess();

            } else if (MODE_DIRECT_LINK.equals(data.getHost())) {
                final Pair<Integer, String> pair =
                        extractDirectLinkData(data.getQueryParameter(DIRECT_LINK_DATA_KEY));
                if (pair != null) {
                    extrasForNewIntent.putInt(TRIGGER_ID_KEY, pair.getLeft());
                    extrasForNewIntent.putString(INSERT_ID_KEY, pair.getRight());
                }
            }
        }

        handlePushClickedAnalyticsIfNeeded(origIntent.getStringExtra(INSERT_PUSH_DATA_KEY));

//        // Handle opening URL, if needed
//        if (origIntent.getStringExtra(NOTIFICATION_URL_KEY) != null) {
//            Intent urlIntent = new Intent(Intent.ACTION_VIEW,
//                    Uri.parse(origIntent.getStringExtra(NOTIFICATION_URL_KEY)));
//            startActivity(urlIntent);
//
//        } else {

            // Handle Direct Link on the intent, if exists.
            String signedLink = origIntent.getStringExtra(SHOW_INSERT_LINK_KEY);
            if (signedLink != null) {
                String signedData = extractSignedDataFromLink(signedLink);
                final Pair<Integer, String> pair = extractDirectLinkData(signedData);
                if (pair != null) {
                    extrasForNewIntent.putInt(TRIGGER_ID_KEY, pair.getLeft());
                    extrasForNewIntent.putString(INSERT_ID_KEY, pair.getRight());
                }
            }

            extrasForNewIntent.putString(getString(R.string.insert_calling_activity_intent_param),
                    this.getClass().getSimpleName()); // For InsertViewer use.

            // We handle the edge case where the app is currently alive in the background in an activity
            // that has a singleInstance/singleTask launch mode, that prevents the onCreate() method
            // from being called and we end up losing our intent which holds our data. To solve this we
            // add our data on the existing activity's intent.
            boolean isCurrentlyAlive = handleSingleInstanceActivity(extrasForNewIntent);
            if (!isCurrentlyAlive) {
                launchRelevantActivity(extrasForNewIntent);
            }
//        }

        finish();
    }

    /**
     * We handle the case where we came from InsertViewer's pincode/splash
     * activity, we only caught its onStop() but not its onStart(), and
     * therefore our sdk thinks the app is in the background. To solve this
     * we update the counter accordingly to be in the foreground.
     */
    private void handleInsertViewer() {
//        if (ApplicationFlowManager.getInstance().isInBackground()) {
//            ApplicationFlowManager.getInstance().incrementStartStopCounter();
//        }
    }

    private void startPairingProcess() {
        RestAPI.getAccessTokenObservable().firstElement().subscribe(InsertMaybeObserver.create(
                new Consumer<String>() {
                    @Override
                    public void accept(String s) {
                        if (!TextUtils.isEmpty(s)) {
                            SocketIOUtils.setSessionDetails(getIntent().getDataString());
                            InsertLogger.d("trying to connect to socket...");
                            SocketIOManager.getInstance().connect();
                        }
                    }
                }
        ));
    }

    /**
     * This method is responsible for taking signed insert data, validating it using jwt,
     * and returning the Trigger ID and Pendo ID that was inside the data.
     *
     * @param showInsertDataSigned - The signed insert data.
     *
     * @return the Trigger ID from inside the data.
     */
    private Pair<Integer, String> extractDirectLinkData(String showInsertDataSigned) {
        try {
            Utils.requireNonNull(showInsertDataSigned, "Pendo data is null!");
            String showInsertDataJson = JsonWebTokenValidator.INSTANCE.validate(showInsertDataSigned);
            ShowInsertData showInsertData =
                    Pendo.GSON.fromJson(showInsertDataJson, ShowInsertData.class);
            return Pair.of(showInsertData.getTriggerId(), showInsertData.getInsertId());

        } catch (Exception e) {

            if (e instanceof InvalidJwtException) {
                InsertLogger.e(e, "Gate cannot validate direct link data: '"
                        + showInsertDataSigned + "'.");
            } else {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return null;
    }

    /**
     * This method is responsible for taking signed link data that comes on a push,
     * validating it using jwt and returning the insert data that was inside the link url.
     * @param showInsertLinkDataSigned - The signed link data the came on the push.
     * @return - signed insert data.
     */
    private String extractSignedDataFromLink(String showInsertLinkDataSigned) {
        if (showInsertLinkDataSigned != null) {
            try {
                Utils.requireNonNull(showInsertLinkDataSigned, "Data from link is null!");
                String showInsertLinkDataJson =
                        JsonWebTokenValidator.INSTANCE.validate(showInsertLinkDataSigned);
                ShowInsertLinkData showInsertLinkData =
                        Pendo.GSON.fromJson(showInsertLinkDataJson, ShowInsertLinkData.class);
                return Uri.parse(showInsertLinkData.getLink())
                        .getQueryParameter(DIRECT_LINK_DATA_KEY);

            } catch (Exception e) {
                if (e instanceof InvalidJwtException) {
                    InsertLogger.e(e, "Gate cannot validate data from link: '"
                            + showInsertLinkDataSigned + "'.");
                } else {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }
        return null;
    }

    /**
     * This method is responsible for taking the signed data that comes on a push,
     * validate it using jwt and sending appropriate analytics to our backend using
     * the decoded data.
     * @param stringPushDataSigned - The signed data that came on the push.
     */
    private void handlePushClickedAnalyticsIfNeeded(String stringPushDataSigned) {
        if (stringPushDataSigned != null) {
            try {
                Utils.requireNonNull(stringPushDataSigned, "Push click analytics is null!");
                String insertDataJson = JsonWebTokenValidator.INSTANCE.validate(stringPushDataSigned);
                InsertPushData insertPushData =
                        Pendo.GSON.fromJson(insertDataJson, InsertPushData.class);
                AnalyticsUtils
                        .sendPushAnalytics(insertPushData, AnalyticsEvent.GUIDE_DISPLAYED);
                AnalyticsUtils
                        .sendPushAnalytics(insertPushData, AnalyticsEvent.INSERT_ELEMENT_CLICKED);
            } catch (Exception e) {
                if (e instanceof InvalidJwtException) {
                    InsertLogger.e(e, "Gate cannot send push analytics: '"
                            + stringPushDataSigned + "'.");
                } else {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }
    }

    private void launchRelevantActivity(Bundle extras) {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        Bundle originalExtras = null;
        if (launchIntent != null) {
            originalExtras = launchIntent.getExtras();
        }
        if (Pendo.getApplicationContext() != null) {
            Class<?> activity;
            try {
                String lastActivityName = ApplicationFlowManager.getInstance().getLastActivity();
                if (!TextUtils.isEmpty(lastActivityName)) {
                    activity = Class.forName(lastActivityName);
                    launchIntent = new Intent(getApplicationContext(), activity);
                }
            } catch (Exception e) {
            }
        }
        if (launchIntent != null) {
            if (extras != null && !extras.isEmpty()) {
                if (originalExtras != null) {
                    originalExtras.putAll(extras);
                    launchIntent.putExtras(originalExtras);
                } else {
                    launchIntent.putExtras(extras);
                }
            } else {
                if (originalExtras != null) {
                    launchIntent.putExtras(originalExtras);
                }
            }
            startActivity(launchIntent);
        }
    }

    /**
     * This methods adds new Extras on the current live activity's intent (if such exists).
     * @param newExtras - The new extras to be added to the intent.
     */
    private boolean handleSingleInstanceActivity(Bundle newExtras) {
        Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();

        if (activity == null) {
            activity = ApplicationObservers.getInstance().getLastVisibleActivityNotDestroyed();
        }

        boolean isCurrentlyAlive = false;
        if (activity != null) {
            isCurrentlyAlive = true;
            Intent intent = activity.getIntent();
            if (intent != null) {
                Bundle extras = intent.getExtras();
                if (extras != null) {
                    extras.putAll(newExtras);
                    intent.putExtras(extras);
                } else {
                    intent.putExtras(newExtras);
                }
            } else {
                intent = new Intent();
                intent.putExtras(newExtras);
            }
            startActivity(intent);
        }
        return isCurrentlyAlive;
    }
}
