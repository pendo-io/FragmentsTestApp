package sdk.pendo.io.network.interfaces;

import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.http.GET;
import io.reactivex.Observable;

/**
 * Pendo REST API for GetAuthToken.
 *
 * Created by nir on 15/4/16. 
 */
public interface GetAuthToken {

    class GetAuthTokenResponse {
        public String accessToken;
    }

    @GET("v" + RestAPI.REST_API_VERSION + "/devices/getAccessTokenSigned")
    Observable<Response<GetAuthTokenResponse>> getAccessTokenSigned();
}
