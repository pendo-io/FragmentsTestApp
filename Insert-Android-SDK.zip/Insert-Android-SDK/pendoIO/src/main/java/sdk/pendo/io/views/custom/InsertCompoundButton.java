package sdk.pendo.io.views.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.util.AttributeSet;
import android.widget.CompoundButton;

/**
 * Pendo's CompoundButton
 *
 * Created by assaf on 8/26/15.
 */
public abstract class InsertCompoundButton extends CompoundButton {

    @ColorInt private int mCheckedTextColor;
    @ColorInt private int mCheckedBackgroundColor;
    @ColorInt private int mTextColor;
    @ColorInt private int mBackgroundColor;

    public InsertCompoundButton(Context context) {
        super(context);
    }

    public InsertCompoundButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public InsertCompoundButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public InsertCompoundButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public void setCheckedTextColor(@ColorInt int color) {
        mCheckedTextColor = color;
    }

    public void setCheckedBackgroundColor(@ColorInt int color) {
        mCheckedBackgroundColor = color;
    }

    public void setDefaultTextColor(@ColorInt int color) {
        mTextColor = color;
    }

    public void setDefaultBackgroundColor(@ColorInt int color) {
        mBackgroundColor = color;
    }

    @Override
    public void setChecked(boolean checked) {

        if (checked) {
            setBackgroundColor(mCheckedBackgroundColor);
            setTextColor(mCheckedTextColor);
        } else {
            setBackgroundColor(mBackgroundColor);
            setTextColor(mTextColor);
        }

        super.setChecked(checked);
    }
}
