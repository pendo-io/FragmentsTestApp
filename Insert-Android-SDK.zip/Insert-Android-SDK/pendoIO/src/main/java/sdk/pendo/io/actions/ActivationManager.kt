package sdk.pendo.io.actions

import android.view.View
import io.reactivex.subjects.BehaviorSubject
import sdk.pendo.io.Pendo
import sdk.pendo.io.events.IdentificationData
import sdk.pendo.io.events.InsertEvent
import androidx.annotation.VisibleForTesting
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.jayway.jsonpath.JsonPath
import io.reactivex.disposables.Disposable
import net.minidev.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.sdk.manager.ScreenManager
import java.lang.ref.WeakReference
import kotlin.collections.HashMap
import kotlin.collections.HashSet
import sdk.pendo.io.intelligence.IntelManager
import sdk.pendo.io.listeners.ApplicationObservers
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.models.*
import sdk.pendo.io.utilities.ViewHierarchyUtility


/**
 * Responsible for activating the following triggers: click, appLaunch & screenView.
 * Also stores activation to guideId map.
 * The mapping is used for showing purposes, as the GuideManager holds a mapping from guideId to the
 * guide that need to be shown.
 * https://pendo-io.atlassian.net/wiki/spaces/ENG/pages/373293493/New+Guide+Activation+Model+Retroactive+SDK
 */
object ActivationManager {

    private class Trigger(val activation: ActivationModel, val location: StepLocationModel?) {

        val guideIds = mutableSetOf<String>()

        fun addGuideId(guideId: String) {
            guideIds.add(guideId)
        }
    }

    /**
     * An enum containing the possible activation events.
     */
    enum class ActivationEvents(val activationEvent: String) {
        APP_LAUNCH("appLaunch"),
        VIEW("view"),
        CLICK("click"),
        PREVIEW("preview"),
        ANY("any");

        companion object {
            val map = HashMap<String, ActivationEvents>()

            init {
                for (i in values()) {
                    map[i.activationEvent] = i
                }
            }

            fun fromString(type: String?): ActivationEvents? {
                if (type != null) {
                    return map[type]
                }
                return null
            }
        }
    }

    private const val ELEMENT_INFO_KEY = "retroElementInfo"
    private const val SCREEN_DATA_KEY = "retroactiveScreenData"
    private const val FULLSCREEN_WIDGET_TYPE_NAME = "FullScreen"

    // Contains a mapping of ActivationModel to a List of connected Guide Ids.
    private val triggers = mutableListOf<Trigger>()
    private val screenChangedSubscription: Disposable
    private val inScreenChangedSubscription: Disposable

    init {
        // This will notify on *future* screen changes only!
        screenChangedSubscription = ScreenManager.screenChangedSubject.subscribe {
            handleScreenView()
        }

        inScreenChangedSubscription = ScreenManager.inScreenChangedSubject.subscribe {
            handleScreenView()
        }
    }

    // ************************************************************************************************
    // These isInited() left-overs are from the old EventManager class and should be removed someday.
    // Keeping them here just so the current flow wont break, but since there's no
    // concept of "init" to this class, it is always "inited" (returning true).
    // ************************************************************************************************
    private val sIsInitedObservable = BehaviorSubject.createDefault(false)

    @Synchronized
    fun isInitedObservable(): BehaviorSubject<Boolean> {
        return sIsInitedObservable
    }

    @Synchronized
    fun isInited(): Boolean {
        return sIsInitedObservable.value!!
    }
    // ************************************************************************************************

    fun start() {}

    /**
     * Restart the manager with an array of guides.
     * Will organize the guides based on activation to optimize lookup.
     * This will also trigger relevant guides if needed (app launch and screen view for current screen).
     *
     * @param guides array of GuideModel
     */
    @Synchronized
    fun restartWithGuides(guides: List<GuideModel>) {
        try {
            triggers.clear()
            for (guide in guides) {
                val guideSteps = guide.steps
                val guideStepsArray = Pendo.GSON.fromJson(guideSteps, JsonArray::class.java)
                // We care about the first step for activation.
                val currentGuideStep = guideStepsArray.get(0) as JsonObject
                val currentStepModel = Pendo.GSON.fromJson(currentGuideStep, StepModel::class.java)
                for (activation in currentStepModel.stepActivations) {
                    val activationModel = Pendo.GSON.fromJson(activation.toString(), ActivationModel::class.java)
                    val stepLocationModel = currentStepModel.stepLocationModel
                    addGuideIdForActivationAndLocation(guide.guideId, activationModel, stepLocationModel)
                }
            }
            handleRestart()
        } catch (e: Exception) {
            InsertLogger.e(e, e.message)
        }
    }

    /**
     * Clear the current guides (will not cancel pending activations).
     * (For future proof, kill switch and testing.)
     */
    @Synchronized
    fun clear() {
        // Remove all triggers
        triggers.clear()
    }

    private fun addGuideIdForActivationAndLocation(guideId: String, activation: ActivationModel, location: StepLocationModel?) {
        // Search for existing trigger
        for (trigger in triggers) {
            if (trigger.activation == activation && trigger.location == location) {
                // Found the trigger, add the guide id.
                trigger.addGuideId(guideId)
                return
            }
        }

        // Did not find an existing trigger, add a new one.
        val trigger = Trigger(activation, location)
        trigger.addGuideId(guideId)
        triggers.add(trigger)
    }

    private fun getTriggersForStep(): MutableList<Trigger> {
        val relevantTriggers = mutableListOf<Trigger>()
        if (StepSeenManager.getInstance().currentStepSeen != null) {
            val currentStepGuideId = StepSeenManager.getInstance().currentStepGuideId
            val currentStepStepId = StepSeenManager.getInstance().currentStepId
            if (currentStepGuideId != null && currentStepStepId != null) {
                val guideModel: GuideModel? = GuideManager.getGuide(StepSeenManager.getInstance().currentStepGuideId)
                val currentStepModel: StepModel? = guideModel?.getGuideStepModel(currentStepStepId)
                if (currentStepModel != null) {
                    for (activation in currentStepModel.stepActivations) {
                        val activationModel = Pendo.GSON.fromJson(activation.toString(), ActivationModel::class.java)
                        val stepLocationModel = currentStepModel.stepLocationModel
                        val trigger = Trigger(activationModel, stepLocationModel)
                        trigger.addGuideId(currentStepGuideId)
                        relevantTriggers.add(trigger)
                    }
                }
            }
        }
        return relevantTriggers
    }

    private fun getGuideIdStepIndexActivationEventViewQuadruple(objectData: JSONObject?, event: ActivationEvents): Set<Quadruple<String, Int, ActivationEvents, WeakReference<View>?>> {
        val guideIds = mutableSetOf<Quadruple<String, Int, ActivationEvents, WeakReference<View>?>>()

        // Check which triggers we should operate on.
        val stepTriggers = getTriggersForStep()
        val relevantTriggers = if (stepTriggers.isNotEmpty()) {
            stepTriggers
        } else {
            triggers
        }

        val reducedToRelevantByEventTriggers = relevantTriggers.filter { it.activation.event!!.contentEquals(event.activationEvent) || it.activation.event!!.contentEquals(ActivationEvents.ANY.activationEvent) }
        for (trigger in reducedToRelevantByEventTriggers) {
            if (isMatch(trigger.activation, trigger.location, objectData, trigger.activation.event)) {
                for (guideId in trigger.guideIds) {
                    if (ActivationEvents.fromString(trigger.activation.event) != null) {
                        val currentGuideModel: GuideModel? = GuideManager.getGuide(guideId)
                        var widgetName = FULLSCREEN_WIDGET_TYPE_NAME
                        val currentStepIndex = StepSeenManager.getInstance().currentStepIndex
                        if (currentGuideModel != null) {
                            widgetName = currentGuideModel.getStepVisualInsertType(currentStepIndex).widgetName
                        }
                        if (widgetName == GuideModel.VisualGuideType.TOOLTIP.widgetName) {
                            var foundView: WeakReference<View>? = null
                            if (trigger.location != null && trigger.location.featureSelector != null && trigger.location.featureSelector.isNotEmpty()) {
                                foundView = getView(trigger.location.featureSelector, objectData)
                            }
                            if (foundView?.get() != null) {
                                guideIds.add(Quadruple(guideId, currentStepIndex, ActivationManager.ActivationEvents.fromString(trigger.activation.event)!!, foundView))
                            }
                        } else {
                            guideIds.add(Quadruple(guideId, currentStepIndex, ActivationManager.ActivationEvents.fromString(trigger.activation.event)!!, null))
                        }
                    }
                }
            }
        }
        return guideIds
    }

    // TODO: move to ActivationModel?
    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    fun isMatch(activation: ActivationModel, location: StepLocationModel?, objectData: JSONObject?, event: String): Boolean {
        // basic null checks + equal event:
        if (activation.event.isEmpty() || event.isEmpty() || activation.event != event) {
            return false
        }

        // if app launch event (already checked equal) - no need to parse the rule (which should be empty anyway)
        if (event == ActivationEvents.APP_LAUNCH.activationEvent || event == ActivationEvents.ANY.activationEvent) {
            return true
        }

        // verify we have a rule and data to match it on:
        if (objectData == null || activation.pageSelector == null) {
            return false
        }
        var locationExists = false
        var isLocationMatch = false
        val isActivationMatch = isFeaturePageSelectorsMatch(activation.pageSelector, activation.featureSelector, objectData)
        if (location != null) {
            isLocationMatch = isFeaturePageSelectorsMatch(location.pageSelector, location.featureSelector, objectData)
            locationExists = true
        }

        return if (locationExists) {
            isActivationMatch && isLocationMatch
        } else {
            isActivationMatch
        }
    }

    private fun isFeaturePageSelectorsMatch(pageSelector: String?, featureSelector: String?, objectData: JSONObject?): Boolean {
        var isPageSelectorExist = false
        var isFeatureSelectorExist = false
        val isPageMatch = if (pageSelector != null && pageSelector.isNotEmpty()) {
            val pageSelectorResult = JsonPath.read<JSONArray>(objectData.toString(), pageSelector)
            isPageSelectorExist = true
            pageSelectorResult != null && pageSelectorResult.isNotEmpty()
        } else {
            false
        }
        val isFeatureMatch = if (featureSelector != null && featureSelector.isNotEmpty()) {
            val featurSelectorResult = JsonPath.read<JSONArray>(objectData.toString(), featureSelector)
            isFeatureSelectorExist = true
            featurSelectorResult != null && featurSelectorResult.isNotEmpty()
        } else {
            false
        }
        if (isPageSelectorExist && isFeatureSelectorExist) {
            return isFeatureMatch && isPageSelectorExist
        }
        if (isPageSelectorExist) {
            return isPageMatch
        }
        if (isFeatureSelectorExist) {
            return isFeatureMatch
        }
        return false
    }

    /**
     * We find if there are any paths in the screen data matching the selector. If such a path
     * is found (we take the first) we call IntelManager.findViewInHierarchy using the currently
     * visible activity and the generated IdentificationData object created by using the found path.
     * @param activation - guide activation
     * @param objectData - the screen data
     * @return a WeakReference to the matching view.
     */
    private fun getView(featureSelector: String, objectData: JSONObject?): WeakReference<View>? {
        if  (objectData == null) {
            return null
        }
        val result = JsonPath.read<JSONArray>(objectData.toString(), featureSelector)
        if (result != null && result.size > 0) {
            val identificationData = IdentificationData.makeFromJson(result.toJSONString())
            val currentVisibleActivity = ApplicationObservers.getInstance().currentVisibleActivity

            if (currentVisibleActivity != null) {
                val view = IntelManager.findViewInHierarchy(
                        currentVisibleActivity.window.decorView,
                        identificationData,
                        true,
                        null)
                if (view != null) {
                    return WeakReference(view)
                }
                return null
            }
        }
        return null
    }

    /**
     * method produces a a set of the guide id, step index, activation event and the relevant view
     * when the view is present on the currently visible screen. The set returned is a list of
     * potential specific view related guides to the current screen
     */
    private fun getGuidesWithMatchingViewsCurrentlyOnScreen(): LinkedHashSet<Quadruple<String, Int, ActivationEvents, WeakReference<View>?>> {
        val objectData = JSONObject()
        objectData.put(SCREEN_DATA_KEY, ScreenManager.currentScreenData!!)
        val guideIds = LinkedHashSet<Quadruple<String, Int, ActivationEvents, WeakReference<View>?>>()
        getRetroElementInfoMatchingSelector()?.forEach { retroElement ->
            objectData.put(ELEMENT_INFO_KEY, retroElement)
            guideIds.addAll(getGuideIdStepIndexActivationEventViewQuadruple(objectData, ActivationEvents.VIEW))
        }
        return guideIds
    }

    /**
     * Method goes through the relevant triggers - ones with event type VIEW.
     * For each of the object in the view hierarchy of the currently visible activity
     * it checks to see that a JsonPath matches his selector.
     * return: JSONArray containing the retro elements json representations.
     */
    private fun getRetroElementInfoMatchingSelector(): JSONArray? {
        val stepTriggers = getTriggersForStep()
        var relevantTriggers = if (stepTriggers.isNotEmpty()) {
            stepTriggers
        } else {
            triggers
        }
        val relevantTriggersReducedByViewEvent = relevantTriggers.filter { ActivationEvents.VIEW.activationEvent.contentEquals(it.activation.event) }
        if (relevantTriggersReducedByViewEvent.isEmpty()) {
            return null
        }
        val path = JSONObject()

        path.put(SCREEN_DATA_KEY, ScreenManager.currentScreenData!!)
        //TODO: MS check for better solution
        val pageFilteredTriggers = relevantTriggersReducedByViewEvent.filter { JsonPath.read<JSONArray>(path.toString(), it.activation.pageSelector) != null }
        if (pageFilteredTriggers.isEmpty()) {
            return null
        }
        ApplicationObservers.getInstance().currentVisibleActivity ?: return null
        val currentVisibleActivityViewHierarchy = ViewHierarchyUtility.getViewTreeAndScreenState(ApplicationObservers.getInstance().currentVisibleActivity.window.decorView)
                ?: return null
        val tree = currentVisibleActivityViewHierarchy.left ?: return null

        val retroElements = JSONArray()

        for (trigger in pageFilteredTriggers) {
            for (i in 0 until tree.length()) {
                try {
                    val retroElement = tree.getJSONObject(i).getJSONObject(ELEMENT_INFO_KEY)
                    path.put(ELEMENT_INFO_KEY, retroElement)
                    if (trigger.location != null && trigger.location.featureSelector != null) {
                        val result = JsonPath.read<JSONArray>(path.toString(), trigger.location.featureSelector)
                        if (result != null && result.size > 0) {
                            retroElements.add(retroElement)
                        }
                    }
                } catch (e: Exception) {
                    continue
                }
            }
        }
        return retroElements
    }


    fun hasViewManipulationsForActivity(className: String?): Boolean {
        return false
    }

    fun getTextModificationStrings(localClassName: String?): HashSet<String> {
        return HashSet()
    }

    fun getViewManipulationElement(localClassName: String?, viewIntelId: IdentificationData?): List<InsertEvent>? {
        return null
    }

    private fun handleRestart() {
        // TODO: Re-enable kill switch after it's calculated just once and cached.
        //if (KillSwitchManager.isKillSwitchOn()) { return }

        // TODO: call async?
        // Get all relevant guides at once so we wont effect their priorities.
        val guideIndexStepIdActivationEventTriplets = mutableSetOf<Quadruple<String, Int, ActivationEvents, WeakReference<View>?>>()

        // Check AppLaunch
        guideIndexStepIdActivationEventTriplets.addAll(getGuideIdStepIndexActivationEventViewQuadruple(null, ActivationEvents.APP_LAUNCH))

        // Check screen view if there's screen data
        if (ScreenManager.currentScreenData != null) {
            val objectData = JSONObject()
            objectData.put(SCREEN_DATA_KEY, ScreenManager.currentScreenData!!)
            guideIndexStepIdActivationEventTriplets.addAll(getGuideIdStepIndexActivationEventViewQuadruple(objectData, ActivationEvents.VIEW))
        }

        if (guideIndexStepIdActivationEventTriplets.isNotEmpty()) {
            GuideManager.show(guideIndexStepIdActivationEventTriplets.toList())
        }
    }

    fun handleClick(viewElementInfo: JSONObject): String {

        // TODO: Re-enable kill switch after it's calculated just once and cached.
        //if (KillSwitchManager.isKillSwitchOn()) { return }
        if (ScreenManager.currentScreenData == null || viewElementInfo == null) {
            return InsertAction.NO_ID
        }
        val objectData = JSONObject()
        objectData.put(SCREEN_DATA_KEY, ScreenManager.currentScreenData!!)
        objectData.put(ELEMENT_INFO_KEY, viewElementInfo)

        // TODO: call async?
        val guideIdStepIndexActivationEventTriplets = getGuideIdStepIndexActivationEventViewQuadruple(objectData, ActivationEvents.CLICK)

        if (guideIdStepIndexActivationEventTriplets.isNotEmpty()) {
            return GuideManager.show(guideIdStepIndexActivationEventTriplets.toList())
        }
        return InsertAction.NO_ID
    }

    @Synchronized private fun handleScreenView() {
        // TODO: Re-enable kill switch after it's calculated just once and cached.
        //if (KillSwitchManager.isKillSwitchOn()) { return }
        if (VisualInsertManager.getInstance().isAnyFullScreenInsertShowing()){
            return
        }
        if (ScreenManager.currentScreenData == null) {
            return
        }

        val objectData = JSONObject()
        objectData.put(SCREEN_DATA_KEY, ScreenManager.currentScreenData!!)

        //We add to a single joined set, both the screenview guides and the guides that tooltips, so
        //they can be properly sorted later
        val guideIdStepIndexActivationEventTriplets = getGuideIdStepIndexActivationEventViewQuadruple(objectData, ActivationEvents.VIEW) + getGuidesWithMatchingViewsCurrentlyOnScreen()

        if (guideIdStepIndexActivationEventTriplets.isNotEmpty()) {
            GuideManager.show(guideIdStepIndexActivationEventTriplets.toList())
        }
    }
}
