package sdk.pendo.io.listeners.views;

import android.view.View;
import android.view.ViewGroup;

import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by assaf on 4/8/15.
 */
public class InsertOnHierarchyChangeListener implements ViewGroup.OnHierarchyChangeListener {

    private volatile static InsertOnHierarchyChangeListener INSTANCE;

    public static synchronized InsertOnHierarchyChangeListener getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InsertOnHierarchyChangeListener();
        }

        return INSTANCE;
    }

    @Override
    public void onChildViewAdded(View parent, View child) {
        InsertLogger.i("parent = " + parent.toString() + " child = " + child.toString());
    }

    @Override
    public void onChildViewRemoved(View parent, View child) {
        InsertLogger.i("parent = " + parent.toString() + " child = " + child.toString());
    }
}
