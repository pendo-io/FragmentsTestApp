package sdk.pendo.io.utilities;

import external.sdk.pendo.io.yoyo.Techniques;

import sdk.pendo.io.actions.configurations.InsertTransition;

/**
 * Created by tomerlevinson on 3/16/16.
 */
@SuppressWarnings("CheckStyle")
public final class AnimationUtils {
    /*
     * Choose technique for the animation.
     */
    public static Techniques chooseTechnique(InsertTransition transition) {
        switch(transition.getEffect()) {
            case POP:
                switch(transition.getType()){
                    case IN:
                        return Techniques.BounceIn;
                    case OUT:
                        return Techniques.ZoomOut;
                }
                break;
            case FADE:
                switch(transition.getType()){
                    case IN:
                        return Techniques.FadeIn;
                    case OUT:
                        return Techniques.FadeOut;
                }
                break;
            case SLIDE:
                switch(transition.getDirection()) {
                    case TOP:
                        if (transition.getType().equals(InsertTransition.InsertTransitionType.IN)){
                            return Techniques.SlideInDown;
                        }
                        else {
                            return Techniques.SlideOutUp;
                        }
                    case BOTTOM:
                        if (transition.getType().equals(InsertTransition.InsertTransitionType.IN)){
                            return Techniques.SlideInUp;
                        }
                        else {
                            return Techniques.SlideOutDown;
                        }
                    case RIGHT:
                        if (transition.getType().equals(InsertTransition.InsertTransitionType.IN)){
                            return Techniques.SlideInLeft;
                        }
                        else {
                            return Techniques.SlideOutLeft;
                        }
                    case LEFT:
                        if (transition.getType().equals(InsertTransition.InsertTransitionType.IN)){
                            return Techniques.SlideInRight;
                        }
                        else {
                            return Techniques.SlideOutRight;
                        }
                }
                break;
            case LAND:
                switch(transition.getType()) {
                    case IN:
                        return Techniques.Landing;
                    case OUT:
                        return Techniques.TakingOff;
                }
                break;
            default:
                return Techniques.FadeIn;
        }
        return null;
    }

}
