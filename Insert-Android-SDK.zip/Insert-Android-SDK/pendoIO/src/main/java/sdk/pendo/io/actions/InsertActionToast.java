package sdk.pendo.io.actions;

import android.content.Context;
import android.support.annotation.NonNull;
import android.widget.Toast;

import sdk.pendo.io.network.responses.InsertModel;

/**
 * Pendo's Toast action class.
 *
 * Created by assaf on 4/30/15.
 */
public class InsertActionToast extends InsertAction {

    public enum ToastLength {
        SHORT(Toast.LENGTH_SHORT),
        LONG(Toast.LENGTH_LONG);

        public final int length;

        ToastLength(int length) {
            this.length = length;
        }
    }

    private String mToastMsg;
    private ToastLength mLength;

    public InsertActionToast(@NonNull String toastMsg, @NonNull ToastLength length) {
        super(InsertActions.TOAST.type, (InsertModel) null);

        mToastMsg = toastMsg;
        mLength = length;
    }
}
