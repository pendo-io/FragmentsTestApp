package sdk.pendo.io.information.collectors.application

import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.AndroidUtils
import sdk.pendo.io.utilities.SettingsUtils
import sdk.pendo.io.utilities.ViewUtils
import sdk.pendo.io.utilities.add
import java.util.*

/**
 * Collect information about the application.

 * Created by assaf on 4/14/15.
 */
internal class ApplicationInfo : Collector() {

    override fun collectData(json: JSONObject) {

        // Add information about the application.
        addApplicationInfo(json)
    }

    private fun addApplicationInfo(info: JSONObject) {
        val applicationInfo = application!!.applicationInfo
        val applicationFlags = applicationInfo.flags

        info.add("device_time", Date().toString())
        info.add("app_name", AndroidUtils.getAppName(application))
        info.add("app_id", packageName)
        info.add("debuggable", SettingsUtils.isHostAppDebuggable())

        setIsGame(info, applicationFlags)

        // Get information about the package.
        try {
            val packageInfo = application!!.packageManager.getPackageInfo(packageName, 0)

            try {
                info.add("icon", ViewUtils.convertBitmapToBase64(Bitmap.CompressFormat.JPEG, 10, getApplicationIcon(application!!)))
            } catch (e: PackageManager.NameNotFoundException) {
                InsertLogger.e(e, "Failed to get application icon.")
            }

            info.add("version_name", packageInfo.versionName)
            info.add("version_code", packageInfo.versionCode)
            info.add("install_time", Date(packageInfo.firstInstallTime).toString())
            info.add("update_time", Date(packageInfo.lastUpdateTime).toString())

        } catch (e: PackageManager.NameNotFoundException) {
            InsertLogger.e(e, "Failed to get package info.")
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private fun setIsGame(info: JSONObject, applicationFlags: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            info.add("is_game", 0 != applicationFlags and android.content.pm.ApplicationInfo.FLAG_IS_GAME)
        }
    }

    @Throws(PackageManager.NameNotFoundException::class)
    private fun getApplicationIcon(ctx: Context): Bitmap {
        val icon = ctx.packageManager.getApplicationIcon(packageName)
        return ViewUtils.drawableToBitmap(icon)
    }
}
