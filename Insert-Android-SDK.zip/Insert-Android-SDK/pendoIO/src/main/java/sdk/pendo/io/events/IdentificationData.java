package sdk.pendo.io.events;

import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import org.apache.commons.lang3.builder.DiffBuilder;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.builder.Diffable;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.AccessibilityData;
import sdk.pendo.io.utilities.PredicateUtils;
import sdk.pendo.io.utilities.ResourceUtils;
import sdk.pendo.io.utilities.Utils;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Identification data.
 *
 * Created by assaf on 7/7/15.
 */
public final class IdentificationData implements Diffable<IdentificationData> {

    public static final String SERIALIZED_NAME = "elementInfo";
    public static final String RETROACTIVE_ELEMENT_INFO = "retroElementInfo";
    public static final String RETROACTIVE_ELEMENT_INFO_HASH = "retroElementInfoHash";

    public static final String FIELD_PARENT_ID = "parentId";
    public static final String FIELD_ID_OF_PARENTS = "idOfParents";
    public static final String FIELD_ID = "id";
    public static final String FIELD_TYPE = "type";
    public static final String FIELD_CHILD_COUNT = "childCount";
    public static final String FIELD_INDEX_IN_PARENT = "indexInParent";
    public static final String FIELD_TEXT = "text";
    private static final String FIELD_ACCESSIBILITY = "accessibility";
    private static final String FIELD_IS_LIST = "isList";
    private static final String FIELD_INSIDE_LIST = "insideList";
    private static final String FIELD_INSIDE_DRAWER = "insideDrawer";

    public static final String RA_PREDICATE = "RAPredicate";
    public static final String PREDICATE = "predicate";
    public static final String RA_TEXT = "text";

    private static final String EMPTY_STRING = "";
    private static final String OPENING_BRACKET = "[";
    private static final String CLOSING_BRACKET = "]";
    private static final String SPACE = " ";
    private static final String STRINGS_SEPARATOR = ",";

    // Members to exclude from hashCode and equals methods
    private static final String[] excludedFields = {"mMandatory", "mAccessibilityData"};

    @SerializedName("parentId")
    private String parentId;

    @SerializedName("idOfParents")
    private ArrayList<String> idOfParents;

    @SerializedName("id")
    private String id;

    @SerializedName("type")
    private String type;

    @SerializedName("RAPredicate")
    private String mRAPredicate;

    @SerializedName("text")
    private String text;

    @SerializedName("childCount")
    private int childCount = 0;

    @SerializedName("isList")
    private boolean mIsList = false;

    @SerializedName("insideList")
    private boolean mIsInsideList = false;

    @SerializedName(FIELD_INDEX_IN_PARENT)
    private Integer mIndexInParent = -1;

    @SerializedName("insideDrawer")
    private boolean mIsInsideDrawer = false;

    @SerializedName("accessibility")
    private AccessibilityData mAccessibilityData;

    public void setIsList(boolean isList) {
        mIsList = isList;
    }

    public boolean isList() {
        return mIsList;
    }

    public void setInsideList(boolean insideList) {
        mIsInsideList = insideList;
    }

    public void setIndexInParent(Integer index) {
        mIndexInParent = index;
    }

    public Integer getIndexInParent() {
        return mIndexInParent;
    }

    public boolean isInsideList() {
        return mIsInsideList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public ArrayList<String> getIdOfParents() {
        return idOfParents;
    }

    public void setIdOfParents(ArrayList<String> idOfParents) {
        this.idOfParents = idOfParents;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return The Base64 encoded truncated text if set, null otherwise.
     */
    @Nullable
    public String getText() {
        return text;
    }

    /**
     * Encodes the truncated text into Base64 and set it as text.
     * @param text - The text to set.
     */
    public void setText(String text) {
        if (!TextUtils.isEmpty(text)) {
            this.text = Base64.encodeToString(Utils.truncateStringToLength(text).toString().getBytes(Charset.forName(ENCODING_UTF_8)), PredicateUtils.BASE64_FLAGS);
        }
    }

    public int getChildCount() {
        return childCount;
    }

    public void setChildCount(int childCount) {
        this.childCount = childCount;
    }

    public void setPredicate(View view) {
        mRAPredicate = PredicateUtils.generateRetroPredicateForView(view);
    }

    @Nullable
    public String getRAPredicate() {
        return mRAPredicate;
    }


    public AccessibilityData getAccessibilityData() { return mAccessibilityData; }

    public void setAccessibilityData(AccessibilityData accessibilityData) {
        mAccessibilityData = accessibilityData;
    }

    public JSONObject toJSON() throws JSONException {

        JSONObject retJSON = new JSONObject();
        if (parentId != null) {
            retJSON.put(FIELD_PARENT_ID, parentId);
        }

        if (idOfParents != null) {
            retJSON.put(FIELD_ID_OF_PARENTS, idOfParents);
        }

        if (id != null) {
            retJSON.put(FIELD_ID, id);
        }

        if (type != null) {
            retJSON.put(FIELD_TYPE, type);
        }

        if (mRAPredicate != null) {
            retJSON.put(RA_PREDICATE, mRAPredicate);
        }

        if (text != null) {
            retJSON.put(RA_TEXT, text);
        }

        retJSON.put(FIELD_CHILD_COUNT, childCount);


        if (mAccessibilityData != null) {
            JSONObject accessibility = new JSONObject();
            accessibility.put(AccessibilityData.ACCESSIBILITY_CONTENT_DESCRIPTION,
                    mAccessibilityData.getContentDescription());
            retJSON.putOpt(FIELD_ACCESSIBILITY, accessibility);
        }
        retJSON.putOpt(FIELD_IS_LIST, mIsList);
        retJSON.putOpt(FIELD_INSIDE_LIST, mIsInsideList);
        retJSON.putOpt(FIELD_INDEX_IN_PARENT, mIndexInParent);
        retJSON.putOpt(FIELD_INSIDE_DRAWER, mIsInsideDrawer);
        return retJSON;
    }

    @Override
    public String toString() {
        try {
            return toJSON().toString();
        } catch (JSONException e) {
            InsertLogger.e(e);
            return null;
        }
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(17, 37, this, false,
                null, excludedFields);
    }

    @Override
    public boolean equals(Object o) {

        if (!(o instanceof IdentificationData)) {
            return false;
        } else if (o == this) {
            return true;
        }

        IdentificationData rhs = (IdentificationData) o;
        return EqualsBuilder.reflectionEquals(this, rhs, excludedFields);
    }

    @Override
    public DiffResult diff(IdentificationData obj) {

        // No need for null check, as NullPointerException correct if obj is null
        final DiffBuilder diffBuilder = new DiffBuilder(this, obj, ToStringStyle.SHORT_PREFIX_STYLE, true)
                .append(FIELD_TYPE, this.type, obj.type)
                .append(RA_TEXT, this.text, obj.text)
                .append(FIELD_INDEX_IN_PARENT, this.mIndexInParent, obj.mIndexInParent)
                .append(FIELD_CHILD_COUNT, this.childCount, obj.childCount)
                .append(RA_PREDICATE, this.mRAPredicate, obj.mRAPredicate);

        if (!ResourceUtils.isIdStringEquals(this.id, obj.id)) {
            diffBuilder.append(FIELD_ID, this.id, obj.id);
        }

        if (!ResourceUtils.isIdStringEquals(this.parentId, obj.parentId)) {
            diffBuilder.append(FIELD_PARENT_ID, this.parentId, obj.parentId);
        }

        //noinspection ConstantConditions
        if ((this.idOfParents == null && obj.idOfParents == null)
                || (this.idOfParents == null && obj.idOfParents != null)
                || (this.idOfParents != null && obj.idOfParents == null)
                || (this.idOfParents.size() != obj.idOfParents.size())) {
            diffBuilder.append(FIELD_ID_OF_PARENTS, this.idOfParents, obj.idOfParents);
        } else {
            for (int i = 0; i < this.idOfParents.size(); i++) {
                String thisParentId = this.idOfParents.get(i);
                String objParentId = obj.idOfParents.get(i);
                if (!ResourceUtils.isIdStringEquals(thisParentId, objParentId)) {
                    diffBuilder.append(FIELD_ID_OF_PARENTS, this.idOfParents, obj.idOfParents);
                    break;
                }
            }
        }
        return diffBuilder.build();
    }

    public static IdentificationData copyIdentificationData(IdentificationData identificationData) {
        return Pendo.GSON.fromJson(identificationData.toString(), IdentificationData.class);
    }

    /**
     * Set whether the view is located inside a drawer
     * @param insideDrawer true in case the view is located inside a drawer,
     *                     false otherwise
     */
    public void setInsideDrawer(boolean insideDrawer) {
        mIsInsideDrawer = insideDrawer;
    }

    /**
     * Retrieves whether the view is located inside drawer.
     * @return true if the view is located inside drawer.
     */
    public boolean isInsideDrawer() {
        return mIsInsideDrawer;
    }

    /**
     * Using the content of the json representation of the retroElementInfo, we build a new matching POJO.
     * @param jsonArray
     * @return an Identification object based on the json array content.
     */
    @Nullable
    public static IdentificationData makeFromJson(String jsonArray) {
        try {
            JSONArray jsonElements = new JSONArray(jsonArray);
            if (jsonElements.length() > 0) {
                JSONObject jsonObject = ((JSONObject) jsonElements.get(0)).getJSONObject(RETROACTIVE_ELEMENT_INFO);
                IdentificationData identificationData = new IdentificationData();
                identificationData.mRAPredicate = jsonObject.getString(PREDICATE);
                if (jsonObject.has(FIELD_ID)) {
                    identificationData.id = jsonObject.getString(FIELD_ID);
                }
                if (jsonObject.has(FIELD_INDEX_IN_PARENT)) {
                    identificationData.mIndexInParent = jsonObject.getInt(FIELD_INDEX_IN_PARENT);
                }
                if (jsonObject.has(FIELD_TEXT)) {
                    identificationData.text = jsonObject.getString(FIELD_TEXT);
                }
                identificationData.type = jsonObject.getString(FIELD_TYPE);
                identificationData.childCount = jsonObject.getInt(FIELD_CHILD_COUNT);
                identificationData.mIsList = jsonObject.getBoolean(FIELD_IS_LIST);
                identificationData.mIsInsideList = jsonObject.getBoolean(FIELD_INSIDE_LIST);
                identificationData.mIsInsideDrawer = jsonObject.getBoolean(FIELD_INSIDE_DRAWER);
                identificationData.idOfParents = new ArrayList<>(Arrays.asList(jsonObject.getString(FIELD_ID_OF_PARENTS)
                        .replace(SPACE, EMPTY_STRING)
                        .replace(OPENING_BRACKET, EMPTY_STRING)
                        .replace(CLOSING_BRACKET, EMPTY_STRING)
                        .split(STRINGS_SEPARATOR)));
                return identificationData;
            }
        } catch (Exception e) {
            InsertLogger.e(e);
        }

        return null;
    }

}
