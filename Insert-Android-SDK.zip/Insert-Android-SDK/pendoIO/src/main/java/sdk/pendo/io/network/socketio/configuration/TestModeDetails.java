package sdk.pendo.io.network.socketio.configuration;

import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.models.GuideModel;

/**
 * Created by tomerlevinson on 11/17/15.
 *
 * This class is used for data extraction from server request,
 * once entering test mode.
 */
public class TestModeDetails {

    @SerializedName("sid")
    public String sessionId;

    @SerializedName("from")
    public String from;

    @SerializedName("to")
    public String to;

    @SerializedName("timestamp")
    public long timestamp;

    @SerializedName("data")
    public GuideModel data;

}
