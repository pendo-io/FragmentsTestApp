package sdk.pendo.io.actions.configurations;

import android.support.annotation.Nullable;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by tomerlevinson on 3/6/16.
 */
public final class InsertTransition {
    private InsertTransitionDirection mDirection;
    private InsertTransitionEffect mEffect;
    private InsertTransitionType mType;
    private int mDuration;
    private String mBackgroundId;

    public static final String INSERT_TRANSITION_TYPE_FIELD = "type";
    public static final String INSERT_TRANSITION_DIRECTION_FIELD = "direction";
    public static final String INSERT_NO_DIRECTION_FIELD_VALUE = "noDirection";
    public static final String INSERT_TRANSITION_EFFECT_FIELD = "effect";
    public static final String INSERT_TRANSITION_DURATION_FIELD = "duration";
    public static final String INSERT_TRANSITION_BACKGROUND_ID = "backgroundId";

    public enum InsertTransitionType {
        IN("in"),
        OUT("out");

        private final String mType;

        private static final Map<String, InsertTransitionType> LOOKUP_TABLE = new HashMap<>();

        static {
            for (InsertTransitionType s : EnumSet.allOf(InsertTransitionType.class)) {
                LOOKUP_TABLE.put(s.mType, s);
            }
        }

        InsertTransitionType(String type) {
            this.mType = type;
        }

        public boolean equals(InsertTransitionType insertType) {
            return this.mType.equals(insertType.mType);
        }

        public String getType(){
            return mType;
        }

        @Nullable
        public static InsertTransitionType get(String type) {
            return LOOKUP_TABLE.get(type);
        }
    }

    public enum InsertTransitionEffect {
        POP("pop"),
        FADE("fade"),
        SLIDE("slide"),
        LAND("land");

        private final String mEffect;

        private static final Map<String, InsertTransitionEffect> LOOKUP_TABLE = new HashMap<>();

        static {
            for (InsertTransitionEffect s : EnumSet.allOf(InsertTransitionEffect.class)) {
                LOOKUP_TABLE.put(s.mEffect, s);
            }
        }

        InsertTransitionEffect(String type) {
            this.mEffect = type;
        }

        public boolean equals(InsertTransitionEffect insertEffect) {
            return this.mEffect.equals(insertEffect.mEffect);
        }

        public String getEffect(){
            return mEffect;
        }

        @Nullable
        public static InsertTransitionEffect get(String effect) {
            return LOOKUP_TABLE.get(effect);
        }
    }

    public enum InsertTransitionDirection {
        LEFT("left"),
        RIGHT("right"),
        TOP("top"),
        BOTTOM("bottom");

        private final String mDirection;

        private static final Map<String, InsertTransitionDirection> LOOKUP_TABLE = new HashMap<>();

        static {
            for (InsertTransitionDirection s : EnumSet.allOf(InsertTransitionDirection.class)) {
                LOOKUP_TABLE.put(s.mDirection, s);
            }
        }

        InsertTransitionDirection(String direction) {
            this.mDirection = direction;
        }

        public String getDirection(){
            return mDirection;
        }

        public boolean equals(InsertTransitionDirection insertDirection) {
            return this.mDirection.equals(insertDirection.mDirection);
        }

        @Nullable
        public static InsertTransitionDirection get(String direction) {
            return LOOKUP_TABLE.get(direction);
        }
    }

    public InsertTransitionEffect getEffect() {
        return mEffect;
    }

    public InsertTransitionType getType() {
        return mType;
    }

    public int getDuration() {
        return mDuration;
    }

    public String getBackgroundId() {
        return mBackgroundId;
    }

    public InsertTransitionDirection getDirection(){
        return mDirection;
    }

    public InsertTransition(String direction, String effect, String type,
                            int duration, String backgroundId) {
        if (direction.equals(INSERT_NO_DIRECTION_FIELD_VALUE)){
            mDirection = null;
        } else {
            mDirection = InsertTransitionDirection.get(direction);
        }
        mEffect = InsertTransitionEffect.get(effect);
        mType = InsertTransitionType.get(type);
        mDuration = duration;
        mBackgroundId = backgroundId;
    }

    @Nullable
    public static InsertTransition getInsertTransition(JsonObject transition) {

        if (!isValidTransition(transition)) {
            return null;
        }

        String transitionDirection;
        if (transition.has(
                InsertTransition.INSERT_TRANSITION_DIRECTION_FIELD) &&
                !transition.get(InsertTransition.INSERT_TRANSITION_DIRECTION_FIELD).isJsonNull()) {
                transitionDirection = transition.get(
                        InsertTransition.INSERT_TRANSITION_DIRECTION_FIELD)
                        .getAsString();
        } else {
            // In case we have no direction.
            transitionDirection =
                    InsertTransition.INSERT_NO_DIRECTION_FIELD_VALUE;
        }

        String transitionEffect = transition.get(
                InsertTransition.INSERT_TRANSITION_EFFECT_FIELD)
                .getAsString();
        String transitionType = transition.get(
                InsertTransition.INSERT_TRANSITION_TYPE_FIELD)
                .getAsString();
        int transitionDuration = transition.get(
                InsertTransition.INSERT_TRANSITION_DURATION_FIELD)
                .getAsInt();
        JsonElement backgroundIdElement = transition
                .get(InsertTransition.INSERT_TRANSITION_BACKGROUND_ID);

        String backgroundId = null;
        // Banner inserts don't have background id
        if (backgroundIdElement != null) {
            backgroundId = backgroundIdElement.getAsString();
        }

        return new InsertTransition(transitionDirection,
                                    transitionEffect,
                                    transitionType,
                                    transitionDuration,
                                    backgroundId);
    }

    @SuppressWarnings("RedundantIfStatement")
    public static boolean isValidTransition(JsonObject transition) {

        if (!transition.has(
                InsertTransition.INSERT_TRANSITION_EFFECT_FIELD)) {
            return false;
        }

        if (!transition.has(
                InsertTransition.INSERT_TRANSITION_TYPE_FIELD)) {
            return false;
        }

        if (!transition.has(
                InsertTransition.INSERT_TRANSITION_DURATION_FIELD)) {
            return false;
        }

        return true;
    }
}
