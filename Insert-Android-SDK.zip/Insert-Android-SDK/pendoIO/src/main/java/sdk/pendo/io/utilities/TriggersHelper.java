package sdk.pendo.io.utilities;

import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;

import sdk.pendo.io.events.DirectLinkEventManager;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.events.InsertEvent.EventActions;
import sdk.pendo.io.network.responses.TriggerModel;

/**
 * Created by nirsegev on 10/1/15.
 */
public final class TriggersHelper {
    private TriggersHelper() {
    }

    public static List<Pair<List<String>, TriggerModel>> chooseTrigger(InsertEvent insertEvent) {
        List<Pair<List<String>, TriggerModel>> triggerList = new ArrayList<>();
        boolean isDirectLinkEvent = insertEvent.getConfiguration().getAction().
                equals(EventActions.DIRECT_LINK.action);
        Pair<Integer, String> directLinkTriggerAndInsert = DirectLinkEventManager.getInstance().getDirectLinkData();

        for (TriggerModel trigger : insertEvent.getTriggers()) {
            if (isDirectLinkEvent &&  directLinkTriggerAndInsert != null) {
                if (trigger.getId() == directLinkTriggerAndInsert.getLeft()) {
                    List<String> insertIds = new ArrayList<>();
                    insertIds.add(directLinkTriggerAndInsert.getRight());
                    triggerList.add(Pair.of(insertIds, trigger));
                    break;
                }
            }

            else if (PreferencesUtils
                    .isConditionalPreferencesValid(trigger.getConfiguration().getPreferences())) {
                triggerList.add(Pair.of(trigger.getInsertIds(), trigger));
            }
        }
        return triggerList;
    }
}
