package sdk.pendo.io.logging;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import javax.net.ssl.SSLPeerUnverifiedException;

import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.utilities.AnalyticsUtils;

import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONFIGURATION;

/**
 * Debug logging tree.
 * <p/>
 * Created by assaf on 4/8/15.
 */
public class InsertReleaseTree extends InsertLogger.Tree {

    public InsertReleaseTree() { }

    @Override
    /** Log a verbose message with optional format args. */
    public void v(String message, Object... args) {
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.VERBOSE);
    }

    @Override
    /** Log a verbose exception and a message with optional format args. */
    public void v(Throwable t, String message, Object... args) {
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.VERBOSE,
                                                                       t.toString());
    }

    @Override
    /** Log a debug message with optional format args. */
    public void d(String message, Object... args) {
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.DEBUG);
    }

    @Override
    /** Log a debug exception and a message with optional format args. */
    public void d(Throwable t, String message, Object... args) {
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.DEBUG,
                                                                       t.toString());
    }

    @Override
    /** Log an info message with optional format args. */
    public void i(String message, Object... args) {
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.INFO);
    }

    @Override
    /** Log an info exception and a message with optional format args. */
    public void i(Throwable t, String message, Object... args) {
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.INFO,
                                                                       t.toString());
    }

    @Override
    /** Log a warning message with optional format args. */
    public void w(String message, Object... args) {
        super.w(null, message, args);
        sendErrorReport(message);
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.WARNING);
    }

    @Override
    /** Log a warning exception and a message with optional format args. */
    public void w(Throwable t, String message, Object... args) {
        super.w(t, message, args);
        sendExceptionReport(t, message);
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.WARNING,
                                                                       t.toString());
    }


    @Override
    /** Log an error message with optional format args. */
    public void e(String message, Object... args) {
        super.e(null, message, args);
        sendErrorReport(message);
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.ERROR);
    }


    @Override
    /** Log an error exception and a message with optional format args. */
    public void e(Throwable t, String message, Object... args) {
        super.e(t, message, args);
        sendExceptionReport(t, message);
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.ERROR,
                                                                       t.toString());
    }

    @Override
    protected final void log(int priority, String tag, String message, Throwable t) {
        tag = "Pendo";
        if (message.length() < InsertLogger.MAX_LOG_LENGTH) {
            if (priority == Log.ASSERT) {
                Log.wtf(tag, message);
            } else {
                Log.println(priority, tag, message);
            }
            return;
        }

        // Split by line, then ensure each line can fit into Log's maximum length.
        for (int i = 0, length = message.length(); i < length; i++) {
            int newline = message.indexOf('\n', i);
            newline = newline != -1 ? newline : length;
            do {
                int end = Math.min(newline, i + InsertLogger.MAX_LOG_LENGTH);
                String part = message.substring(i, end);
                if (priority == Log.ASSERT) {
                    Log.wtf(tag, part);
                } else {
                    Log.println(priority, tag, part);
                }
                i = end;
            } while (i < newline);
        }
    }

    private void sendErrorReport(String message) {
        if (BackendApiManager.getInstance().isAuthenticated()) {
            AnalyticsUtils.sendErrorReport(ERROR_REASON_CONFIGURATION, message);
        }
    }

    private void sendExceptionReport(@NonNull Throwable t, @Nullable String message) {

        if (t instanceof SSLPeerUnverifiedException) {
            // TODO: 9/19/16 Talk to Udi about how can we send this to the server.
            InsertLogger.d("Cannot send SSLPeerUnverifiedException to server yet.");
            return;
        }

        if (BackendApiManager.getInstance().isAuthenticated()) {
            AnalyticsUtils.sendExceptionReport(t, message);
        }
    }
}
