package sdk.pendo.io.models;
import com.google.gson.annotations.SerializedName;

/**
 * Depicts the new app key format.
 */
public class AppKeyData {
    @SerializedName("datacenter")
    private String mDataCenter;

    @SerializedName("key")
    private String mKey;

    public String getDataCenter() {
        return mDataCenter;
    }

    public String getKey() {
        return mKey;
    }
}
