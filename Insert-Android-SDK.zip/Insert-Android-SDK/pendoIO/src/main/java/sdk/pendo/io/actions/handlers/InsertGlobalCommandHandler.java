package sdk.pendo.io.actions.handlers;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.actions.VisualInsertBase;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.ActivityUtils;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.ResourceUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.SendInsertGenericAnalyticsConsts.ANALYTICS_TYPE;
import static sdk.pendo.io.analytics.AnalyticsProperties.GUIDE_ID;
import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;

/**
 * {@link InsertCommand} handler for {@link InsertCommandGlobalAction} actions.
 * <p>
 * Created by assaf on 3/29/16.
 */
public final class InsertGlobalCommandHandler {
    private static final String NUMBER_PARAMETER_TYPE = "number";
    public static final String INSERT_GLOBAL_COMMAND_DEST = "Global";
    private static final String PROPS_PREFIX = "props.";
    private static final String PROPS_JSON_KEY = "props";

    private static final Predicate<InsertCommand> OPEN_URL_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.OPEN_URL,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> SHOW_ALERT_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SHOW_ALERT,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> CHANGE_SCREEN_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.CHANGE_SCREEN,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    public static final Predicate<InsertCommand> DISMISS_INSERT_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.DISMISS_INSERT,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    public static final Predicate<InsertCommand> GUIDE_ADVANCE_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.ADVANCE_GUIDE,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> SEND_APP_GENERIC_ANALYTICS_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SEND_APP_GENERIC_ANALYTICS,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> SEND_APP_SPECIFIC_ANALYTICS_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SEND_APP_SPECIFIC_ANALYTICS,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> INSERT_ANALYTICS_EVENT_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SEND_ANALYTICS,
                    InsertCommandEventType.INSERT_ANALYTICS_EVENT,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> SEND_GUIDE_GENERIC_ANALYTICS_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SEND_GUIDE_GENERIC_ANALYTICS,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    public static final Predicate<InsertCommand> SEND_GUIDE_PARAMETRIZED_GENERIC_ANALYTICS_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SEND_GUIDE_PARAMETERIZED_GENERIC_ANALYTICS,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    public static final Predicate<InsertCommand> SEND_CUSTOM_ANALYTICS_FILTER =
            InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_GLOBAL_COMMAND_DEST,
                    InsertCommandGlobalAction.SEND_CUSTOM_ANALYTICS,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private static final Predicate<InsertCommand> RUN_SCRIPT_FILTER =
            InsertCommand.createFilter(
                    InsertCommand.COMMAND_STRING_ANY,
                    JavascriptRunner.JAVA_SCRIPT_RUNNER_DESTINATION,
                    InsertCommandAction.InsertCommandRunnableAction.RUN_JAVA_SCRIPT,
                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

    private Consumer<InsertCommand> sendParameterizedAnalyticsAction = new Consumer<InsertCommand>() {
        @Override
        public void accept(InsertCommand insertCommand) {
            final List<InsertCommandsEventBus.Parameter> parameters =
                    insertCommand.getParameters();

            if (parameters == null) {
                InsertLogger.d("Got " + insertCommand.getAction()
                        + " and " + insertCommand.getEventType()
                        + " without parameters! Doing nothing.");

                return;
            }

            JSONObject analyticsData = new JSONObject();
            JSONObject analyticsProps = new JSONObject();
            String insertEvent = null;
            for (InsertCommandsEventBus.Parameter parameter : parameters) {
                String parameterName = parameter.getParameterName();
                String parameterValue = parameter.getParameterValue();
                String parameterType = parameter.getValueType();

                if (parameterName.startsWith(GUIDE_ID)) {
                    continue;
                }
                if (parameterName.startsWith(PROPS_PREFIX)) {
                    parameterName = parameterName.replace(PROPS_PREFIX, "");
                    addParameterToJSON(analyticsProps, parameter, parameterName, parameterValue, parameterType);
                } else {
                    addParameterToJSON(analyticsData, parameter, parameterName, parameterValue, parameterType);
                }

                if (AnalyticsProperties.TYPE.equals(parameterName)) {
                    insertEvent = parameter.getParameterValue();
                }
            }

            if (analyticsProps.length() > 0) {
                try {
                    analyticsData.put(PROPS_JSON_KEY, analyticsProps);
                } catch (JSONException e) {
                    InsertLogger.e(e.getMessage(), e);
                }
            }
            Tracker tracker = InsertAnalytics.newTracker(analyticsData);
            AnalyticsUtils.sendGenericAnalytics(tracker,
                    AnalyticsEvent.findEvent(insertEvent),
                    insertCommand.getParamValueFromCommand(InsertInfoConsts.EXTERNAL_ENDPOINT_URL));
        }
    };

    private void addParameterToJSON(JSONObject jsonObject,
                                    InsertCommandsEventBus.Parameter parameter,
                                    String parameterName,
                                    String parameterValue,
                                    String parameterType) {
        try {
            if (parameterType.equals(NUMBER_PARAMETER_TYPE)) {
                if (Utils.isLong(parameterValue)) {
                    jsonObject.put(parameterName, Long.parseLong(parameterValue));
                } else if (Utils.isInteger(parameterValue)) {
                    jsonObject.put(parameterName, Integer.parseInt(parameterValue));
                }
            } else if (Utils.isJSONObjectValid(parameterValue)) {
                jsonObject.put(parameterName, new JSONObject(parameterValue));
            } else if (Utils.isJSONArrayValid(parameterValue)) {
                jsonObject.put(parameterName, new JSONArray(parameterValue));
            } else {
                jsonObject.put(parameterName, parameter.getParameterValue());
            }
        } catch (JSONException ignore) {
        }
    }

    public static final int SHORT_DURATION_TOAST = 2;
    public static final int DEFAULT_EVENT_ID = -1;

    private static volatile InsertGlobalCommandHandler INSTANCE;

    private InsertGlobalCommandHandler() {
        openUrlHandler();
        showAlertHandler();
        dismissInsertHandler();
        guideAdvanceHandler();
        sendAppGenericAnalyticsHandler();
        sendInsertAppSpecificAnalyticsHandler();
        sendInsertGenericAnalyticsHandler();
        sendParameterizedInsertGenericAnalyticsHandler();
        sendCustomAnalyticsHandler();
        insertAnalyticsEventHandler();
        insertRunnableActionsHandler();
    }

    private void insertRunnableActionsHandler() {
        InsertCommandsEventBus.getInstance().subscribe(
                RUN_SCRIPT_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        final List<InsertCommandsEventBus.Parameter> parameters =
                                insertCommand.getParameters();

                        if (parameters == null) {
                            InsertLogger.d("Got " + insertCommand.getAction()
                                    + " and " + insertCommand.getEventType()
                                    + " without parameters! Doing nothing.");

                            return;
                        }

                        for (InsertCommandsEventBus.Parameter parameter : parameters) {
                            String parameterName = parameter.getParameterName();
                            if (JavascriptRunner.SCRIPT_NAME.equals(parameterName)) {
                                final String script = parameter.getParameterValue();
                                final String scriptLang = parameter.getValueType();

                                if (JavascriptRunner.JAVA_SCRIPT_TYPE.equals(scriptLang)) {
                                    JavascriptRunner.runCode(script,
                                            String.class,
                                            insertCommand.getContext());
                                }
                            }
                        }
                    }
                }
        );
    }

    private void sendInsertGenericAnalyticsHandler() {

        // FIXME: 4/10/16 Does not support multiple inserts simultaneously.
        InsertCommandsEventBus.getInstance().subscribe(SEND_GUIDE_GENERIC_ANALYTICS_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());

                        final List<InsertCommandsEventBus.Parameter> parameters =
                                insertCommand.getParameters();

                        if (parameters == null) {
                            InsertLogger.d("Got " + insertCommand.getAction()
                                    + " and " + insertCommand.getEventType()
                                    + " without parameters! Doing nothing.");

                            return;
                        }

                        String analyticsType = null;
                        String dismissedBy = null;
                        String insertIdString = null;
                        JSONObject analyticsData = new JSONObject();
                        for (InsertCommandsEventBus.Parameter parameter : parameters) {
                            final String parameterName = parameter.getParameterName();
                            final String parameterValue = parameter.getParameterValue();
                            final String parameterType = parameter.getValueType();

                            if (ANALYTICS_TYPE.equals(parameterName)
                                    || AnalyticsProperties.TYPE.equals(parameterName)) {
                                analyticsType = parameterValue;
                            } else if (InsertCommandGlobalAction.SendInsertGenericAnalyticsConsts.DISMISSED_BY
                                    .equals(parameterName)) {
                                dismissedBy = parameterValue;
                            } else if(InsertCommandGlobalAction.SendInsertGenericAnalyticsConsts.DISMISSED_REASON
                                    .equals(parameterName)) {
                                dismissedBy = parameterValue;
                            } else if (InsertInfoConsts.GUIDE_ID.equals(parameterName)) {
                                insertIdString = parameterValue;
                            }

                            try {
                                if (parameterType.equals(NUMBER_PARAMETER_TYPE)) {
                                    if (Utils.isLong(parameterValue)) {
                                        analyticsData.put(parameterName, Long.parseLong(parameterValue));
                                    } else if (Utils.isInteger(parameterValue)) {
                                        analyticsData.put(parameterName, Integer.parseInt(parameterValue));
                                    }
                                } else if (Utils.isJSONObjectValid(parameterValue)) {
                                    analyticsData.put(parameterName, new JSONObject(parameterValue));
                                } else {
                                    analyticsData.put(parameterName, parameter.getParameterValue());
                                }
                            } catch (JSONException ignore) {
                            }
                        }

                        final VisualInsertBase visualInsert = VisualInsertManager
                                .getInstance()
                                .getVisualInsert(insertIdString);

                        if (visualInsert == null) {
                            InsertLogger.w("Visual insert already null.");
                            return;
                        }

                        final Tracker tracker = visualInsert.getTracker();

                        if (tracker == null) {
                            InsertLogger.w("Tracker for insert is null. Not sending analytics.");
                            return;
                        }

                        tracker.setAnalyticsData(analyticsData);

                        if (analyticsType == null) {
                            InsertLogger.w("analyticsType is null, doing nothing.");
                            return;
                        }

                        if (InsertCommandGlobalAction.SendInsertGenericAnalyticsConsts.GUIDE_DISMISSED
                                .equalsIgnoreCase(analyticsType)) {
                            if (dismissedBy == null) {
                                InsertLogger.w("DismissBy is null, doing nothing.");
                                return;
                            }

                            AnalyticsUtils.sendInsertDismissedAnalytics(tracker,
                                    visualInsert.getDuration(),
                                    dismissedBy,
                                    insertCommand.getParamValueFromCommand(InsertInfoConsts.EXTERNAL_ENDPOINT_URL),
                                    null);
                        }
                    }
                });
    }

    private void sendParameterizedInsertGenericAnalyticsHandler() {
        InsertCommandsEventBus.getInstance().subscribe(
                SEND_GUIDE_PARAMETRIZED_GENERIC_ANALYTICS_FILTER,
                sendParameterizedAnalyticsAction
        );
    }

    private void sendAppGenericAnalyticsHandler() {
        InsertCommandsEventBus.getInstance().subscribe(
                SEND_APP_GENERIC_ANALYTICS_FILTER,
                sendParameterizedAnalyticsAction
        );
    }

    private void sendCustomAnalyticsHandler() {
        InsertCommandsEventBus.getInstance().subscribe(
                SEND_CUSTOM_ANALYTICS_FILTER,
                sendParameterizedAnalyticsAction
        );
    }


    private void insertAnalyticsEventHandler() {
        InsertCommandsEventBus.getInstance().subscribe(
                INSERT_ANALYTICS_EVENT_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        List<InsertCommandsEventBus.Parameter> parameterList = insertCommand.getParameters();
                        InsertAction insertAction = null;
                        InsertCommandEventType analyticsActionEventType = null;
                        String analyticsEvent = null;
                        for (InsertCommandsEventBus.Parameter param : parameterList) {
                            String parameterName = param.getParameterName();
                            if (parameterName.equals(GUIDE_ID)) {
                                insertAction = InsertsManager.getInsert(
                                        param.getParameterValue());
                            } else if (parameterName.equals(ANALYTICS_TYPE)) {
                                analyticsActionEventType = InsertCommandEventType.getEventType(
                                        param.getParameterValue());
                            } else if (parameterName.equals(AnalyticsProperties.TYPE)) {
                                analyticsEvent = param.getParameterValue();
                            }
                        }
                        try {
                            //Check analytics type here.
                            if (analyticsActionEventType == null) {
                                InsertLogger.e("Cannot get event type.");
                                return;
                            }

                            if (GuideManager.INSTANCE.getGuideActions() == null) {
                                InsertLogger.e("Cannot get actions.");
                                return;
                            }
                            // Pass on the Event parameter.
                            List<InsertCommand> insertSpecificActions = GuideManager.INSTANCE.getGuideActions();
                            //Add event to actions.
                            for (InsertCommand insertSpecificAction : insertSpecificActions) {
                                List<InsertCommandsEventBus.Parameter> insertSpecificActionParameters = insertSpecificAction.getParameters();
                                InsertCommandsEventBus.Parameter existantParam  = null;
                                if (insertSpecificActionParameters != null) {
                                    for (InsertCommandsEventBus.Parameter parameter : insertSpecificActionParameters) {
                                        if (parameter.getParameterName().equals(AnalyticsProperties.TYPE)) {
                                            existantParam = parameter;
                                        }
                                    }
                                    if (existantParam != null) {
                                        insertSpecificActionParameters.remove(existantParam);
                                    }

                                    if (analyticsEvent != null) {
                                        insertSpecificActionParameters.add(
                                                new InsertCommandsEventBus.Parameter(
                                                        AnalyticsProperties.EVENT,
                                                        TYPE_STRING,
                                                        analyticsEvent));
                                    }
                                }
                            }
                            //Dispatch the commands for the specific event.
                            InsertCommandDispatcher.getInstance().dispatchCommands(
                                    insertSpecificActions,
                                    analyticsActionEventType,
                                    false
                            );
                        } catch (Exception e) {
                            InsertLogger.e(e, e.getMessage());
                        }
                    }
                }
        );
    }

    private void sendInsertAppSpecificAnalyticsHandler() {
        InsertCommandsEventBus
                .getInstance()
                .subscribe(
                        SEND_APP_SPECIFIC_ANALYTICS_FILTER,
                        new Consumer<InsertCommand>() {
                            @Override
                            public void accept(InsertCommand insertCommand) {
                                InsertLogger.d(insertCommand.toString());

                                final List<InsertCommandsEventBus.Parameter> parameters =
                                        insertCommand.getParameters();

                                if (parameters == null) {
                                    InsertLogger.d("Parameters are null, doing nothing.");
                                    return;
                                }
                                String event = insertCommand.getEventType().eventType;
                                JSONObject analytics = new JSONObject();
                                JSONObject customEventData = null;
                                Integer eventId = DEFAULT_EVENT_ID;
                                Boolean customEventParamsExist = false;
                                String customEventParamsName = "";
                                try {
                                    for (InsertCommandsEventBus.Parameter para : parameters) {
                                        final String name = para.getParameterName();
                                        final String parameterValue = para.getParameterValue();
                                        if (AnalyticsProperties.TYPE.equals(name)) {
                                            event = parameterValue;
                                        } else if (AnalyticsProperties.ORIENTATION.equals(name)) {
                                            int orientation = ResourceUtils.getResources().getConfiguration().orientation;
                                            analytics.put(AnalyticsProperties.ORIENTATION,
                                                    ResourceUtils.orientationToString(orientation));
                                        } else if (AnalyticsProperties.CUSTOM_EVENT_ID.equals(name)) {
                                            eventId = Integer.parseInt(parameterValue);
                                        } else if (AnalyticsProperties.CUSTOM_EVENT_DATA.equals(name)) {
                                            customEventParamsExist = true;
                                            customEventParamsName = name;
                                            String paramValue = para.getParameterValue();
                                            if (Utils.isJSONObjectValid(paramValue)) {
                                                customEventData = new JSONObject(paramValue);
                                            }
                                        } else {

                                            if (Utils.isNumber(parameterValue)) {
                                                if (Utils.isLong(parameterValue)) {
                                                    analytics.put(name, Long.parseLong(parameterValue));
                                                } else if (Utils.isInteger(parameterValue)) {
                                                    analytics.put(name, Integer.parseInt(parameterValue));
                                                }
                                            } else if (Utils.isJSONObjectValid(parameterValue)) {
                                                analytics.put(name, new JSONObject(parameterValue));
                                            } else if (Utils.isJSONArrayValid(parameterValue)) {
                                                analytics.put(name, new JSONArray(parameterValue));
                                            } else {
                                                analytics.put(name, parameterValue);
                                            }
                                        }
                                    }
                                    if (eventId != DEFAULT_EVENT_ID) {
                                        analytics.put(AnalyticsProperties.CUSTOM_EVENT_ID, String.valueOf(eventId.intValue()));
                                    }
                                    //Add supported params in case needed.
//                                    JsonArray supportedParams;
                                    if (customEventParamsExist && (eventId != DEFAULT_EVENT_ID)) {
                                        if (customEventData != null) {
                                            analytics.put(customEventParamsName, customEventData);
                                        }
//                                        InsertEvent eventOccurredEvent = EventsManager.getInstance().getCustomEventOccuredEvent(
//                                                eventId);
//                                        if (eventOccurredEvent != null && eventOccurredEvent.getConfiguration() != null) {
//                                            supportedParams = eventOccurredEvent.getConfiguration().getSupportedParams();
//                                            if (supportedParams != null) {
//                                                analytics.put(customEventParamsName, new JSONArray(supportedParams.toString()));
//                                            }
//                                        }
                                    }
                                } catch (Exception e) {
                                    InsertLogger.e(e, e.getMessage());
                                }

                                InsertAnalytics.newTracker().send(event, analytics,
                                        insertCommand.getParamValueFromCommand(InsertInfoConsts.EXTERNAL_ENDPOINT_URL));
                            }
                        });
    }



    private void showAlertHandler() {
        InsertCommandsEventBus.getInstance().subscribe(SHOW_ALERT_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());
                        final List<InsertCommandsEventBus.Parameter> parameters =
                                insertCommand.getParameters();

                        if (parameters == null) {
                            InsertLogger.d("Got " + insertCommand.getAction()
                                    + " and " + insertCommand.getEventType()
                                    + " without parameters! Doing nothing.");

                            return;
                        }

                        String title = null;
                        String message = null;
                        Long duration = null;
                        for (InsertCommandsEventBus.Parameter parameter : parameters) {
                            final String parameterName = parameter.getParameterName();
                            if ("title".equals(parameterName)) {
                                title = parameter.getParameterValue();
                            } else if ("message".equals(parameterName)) {
                                message = parameter.getParameterValue();
                            } else if ("duration".equals(parameterName)
                                    && "long".equals(parameter.getValueType())) {

                                try {
                                    duration = Long.valueOf(parameter.getParameterValue());
                                } catch (Exception notMajor) {
                                    InsertLogger.w(notMajor, notMajor.getMessage());
                                }
                            }
                        }

                        if (message == null || duration == null) {
                            InsertLogger.w("message = '" + message + "'"
                                    + " duration = '" + duration + "'"
                                    + " doing nothing.");
                            return;
                        }

                        int toastDuration = Toast.LENGTH_SHORT;
                        if (TimeUnit.MILLISECONDS.toSeconds(duration) > SHORT_DURATION_TOAST) {
                            toastDuration = Toast.LENGTH_LONG;
                        }

                        Toast.makeText(Pendo.getApplicationContext(), message, toastDuration)
                                .show();
                    }
                });
    }

    private void openUrlHandler() {
        InsertCommandsEventBus.getInstance().subscribe(OPEN_URL_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());
                        final List<InsertCommandsEventBus.Parameter> parameters =
                                insertCommand.getParameters();

                        if (parameters == null) {
                            InsertLogger.d("Got " + insertCommand.getAction()
                                    + " and " + insertCommand.getEventType()
                                    + " without parameters! Doing nothing.");

                            return;
                        }

                        String url = null;
                        String type = null;
                        for (InsertCommandsEventBus.Parameter parameter : parameters) {
                            final String parameterName = parameter.getParameterName();
                            if ("url".equals(parameterName)) {
                                url = parameter.getParameterValue();
                            } else if ("type".equals(parameterName)) {
                                type = parameter.getParameterValue();
                            }
                        }

                        if (url == null || type == null || url.isEmpty()) {
                            InsertLogger.w("URL = '" + url
                                    + "' type = '" + type + "', doing nothing.");
                            return;
                        }

                        Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse(url));

                        if (!"deeplink".equalsIgnoreCase(type)) {
                            ApplicationObservers.getInstance().activityInsideApp(false);
                        }

                        ActivityUtils.startActivityImmediate(browserIntent);
                    }
                });
    }


    private void guideAdvanceHandler() {
        InsertCommandsEventBus.getInstance().subscribe(GUIDE_ADVANCE_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());

                        InsertCommand command =
                                new InsertCommand.Builder(insertCommand.getAction(),
                                        insertCommand.getEventType())
                                        .setSourceId(insertCommand.getSourceId())
                                        .setDestinationId(
                                                VisualInsert.INSERT_COMMAND_VISUAL_INSERT_DEST)
                                        .setScope(insertCommand.getScope())
                                        .build();
                        List<InsertCommandsEventBus.Parameter> parameters = insertCommand.getParameters();
                        if (parameters != null && parameters.size() > 0) {
                            command.setParameters(parameters);
                        }

                        InsertCommandDispatcher.getInstance().dispatchCommand(command, false);
                    }
                });
    }

    private void dismissInsertHandler() {
        InsertCommandsEventBus.getInstance().subscribe(DISMISS_INSERT_FILTER,
                new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());

                        InsertCommand command =
                                new InsertCommand.Builder(insertCommand.getAction(),
                                        insertCommand.getEventType())
                                        .setSourceId(insertCommand.getSourceId())
                                        .setDestinationId(
                                                VisualInsert.INSERT_COMMAND_VISUAL_INSERT_DEST)
                                        .setScope(insertCommand.getScope())
                                        .build();
                        List<InsertCommandsEventBus.Parameter> parameters = insertCommand.getParameters();
                        if (parameters != null && parameters.size() > 0) {
                            command.setParameters(parameters);
                        }

                        InsertCommandDispatcher.getInstance().dispatchCommand(command, false);
                    }
                });
    }

    public static synchronized InsertGlobalCommandHandler getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InsertGlobalCommandHandler();
        }

        return INSTANCE;
    }
}
