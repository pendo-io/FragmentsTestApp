package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Pair;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.script.JavascriptRunner;

/**
 * Class represents an Pendo command to be sent on {@link InsertCommandsEventBus}.
 * <p>
 * Created by assaf on 3/28/16.
 */
@SuppressWarnings({"CheckStyle", "unused"})
public final class InsertCommand {

    public static final String COMMAND_STRING_ANY = "any";
    /**
     * Constants for the JSON parsing.
     **/
    public static final String INSERT_COMMANDS_SERIALIZED_NAME = "actions";
    private static final String INSERT_COMMAND_SERIALIZED_NAME_ID = "id";
    private static final String INSERT_COMMAND_SERIALIZED_NAME_SOURCE = "source";
    private static final String INSERT_COMMAND_SERIALIZED_NAME_DESTINATION = "destination";
    private static final String INSERT_COMMAND_SERIALIZED_NAME_ACTION = "action";
    public static final String INSERT_COMMAND_SERIALIZED_NAME_EVENT_TYPE = "eventType";
    private static final String INSERT_COMMAND_SERIALIZED_NAME_SCOPE = "scope";
    private static final String INSERT_COMMAND_SERIALIZED_NAME_PARAMETERS = "parameters";

    @Nullable
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_ID)
    final String commandId;

    @Nullable
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_SOURCE)
    final String sourceId;

    @Nullable
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_DESTINATION)
    final String destinationId;

    @NonNull
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_ACTION)
    final InsertCommandAction action;

    @NonNull
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_EVENT_TYPE)
    final InsertCommandEventType eventType;

    @NonNull
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_SCOPE)
    final InsertCommandScope scope;

    @Nullable
    @SerializedName(INSERT_COMMAND_SERIALIZED_NAME_PARAMETERS)
    List<InsertCommandsEventBus.Parameter> parameters;

    @Nullable
    JavascriptRunner.InsertContext context;

    /**
     * @param commandId     the {@link InsertCommand} id (if null, a random UUID will be
     *                      generated).
     * @param sourceId      of an action (for analytics purposes perhaps).
     * @param destinationId of the action. This is the entity that performs the behavior
     *                      encoded
     * @param action        of the behavior that is encoded to the destination component. into this
     *                      action.
     * @param eventType     the specific event that should occur.
     * @param scope         the scope that this action should occur in.
     * @param parameters    some {@link InsertCommandsEventBus.Parameter}s that the action or listener needs.
     */
    public InsertCommand(@Nullable String commandId,
                         @Nullable String sourceId,
                         @Nullable String destinationId,
                         @NonNull InsertCommandAction action,
                         @NonNull InsertCommandEventType eventType,
                         @NonNull InsertCommandScope scope,
                         @Nullable List<InsertCommandsEventBus.Parameter> parameters) {

        if (commandId != null) {
            this.commandId = commandId;
        } else {
            this.commandId = UUID.randomUUID().toString();
        }

        this.sourceId = sourceId;
        this.destinationId = destinationId;
        this.action = action;
        this.eventType = eventType;
        this.scope = scope;
        this.parameters = parameters;
    }

    /**
     * @param commandId     the {@link InsertCommand} id (if null, a random UUID will be
     *                      generated).
     * @param sourceId      of an action (for analytics purposes perhaps).
     * @param destinationId of the action. This is the entity that performs the behavior
     *                      encoded
     * @param action        of the behavior that is encoded to the destination component. into this
     *                      action.
     * @param eventType     the specific event that should occur.
     * @param parameters    some {@link InsertCommandsEventBus.Parameter}s that the action or listener needs.
     */
    public InsertCommand(@Nullable String commandId,
                         @Nullable String sourceId,
                         @Nullable String destinationId,
                         @NonNull InsertCommandAction action,
                         @NonNull InsertCommandEventType eventType,
                         @NonNull InsertCommandScope scope,
                         @Nullable InsertCommandsEventBus.Parameter... parameters) {

        if (commandId != null) {
            this.commandId = commandId;
        } else {
            this.commandId = UUID.randomUUID().toString();
        }

        this.sourceId = sourceId;
        this.destinationId = destinationId;
        this.action = action;
        this.eventType = eventType;
        this.scope = scope;
        if (parameters != null) {
            this.parameters = Arrays.asList(parameters);
        }
    }

    @Override
    public String toString() {
        return "Action:{ source: " + getSourceId() + " -> destination: " + getDestinationId()
                + " action: " + getAction() + " event: " + getEventType()
                + " parameter: "
                + (parameters != null ? Arrays.toString(parameters.toArray()) : "null") + " }";
    }

    @Nullable
    public String getSourceId() {
        return sourceId;
    }

    @NonNull
    public InsertCommandAction getAction() {
        return action;
    }

    @Nullable
    public String getDestinationId() {
        return destinationId;
    }

    @NonNull
    public InsertCommandEventType getEventType() {
        return eventType;
    }

    @NonNull
    public InsertCommandScope getScope() {
        return scope;
    }

    @Nullable
    public List<InsertCommandsEventBus.Parameter> getParameters() {
        return parameters;
    }

    @Nullable
    public JavascriptRunner.InsertContext getContext() {
        return context;
    }

    public void setContext(@Nullable JavascriptRunner.InsertContext context) {
        this.context = context;
    }

    public void setParameters(
            @Nullable List<InsertCommandsEventBus.Parameter> parameters) {
        this.parameters = parameters;
    }

    public void addParameter(@NonNull InsertCommandsEventBus.Parameter parameter) {
        if (this.parameters == null) {
            this.parameters = new ArrayList<>();
        }

        this.parameters.add(parameter);
    }

    public boolean removeParameter(@NonNull InsertCommandsEventBus.Parameter parameter) {
        if (this.parameters == null) {
            return false;
        }

        return this.parameters.remove(parameter);
    }

    public Predicate<InsertCommand> getFilter() {
        return new Predicate<InsertCommand>() {
            @Override
            public boolean test(InsertCommand insertCommand) {
                return InsertCommand.this.equals(true, insertCommand);
            }
        };
    }

    private Function<InsertCommand, Boolean> getFilter(final Pair<String, String>... parameters) {
        return new Function<InsertCommand, Boolean>() {
            @Override
            public Boolean apply(InsertCommand insertCommand) {
                return InsertCommand.this.equals(true, insertCommand)
                        && insertCommand.hasParameters(parameters);
            }
        };
    }

    /**
     * Checks whether the insert command has the specific commands and their values.
     *
     * @param parameters
     * @return
     */
    public boolean hasParameters(Pair<String, String>... parameters) {
        boolean paramsValid = true;
        List<InsertCommandsEventBus.Parameter> commandParameters = getParameters();
        if (Utils.isEmpty(commandParameters) && (parameters != null && parameters.length > 0)) {
            return false;
        }
        if (!Utils.isEmpty(commandParameters) && parameters == null) {
            return false;
        }
        for (Pair<String, String> paramToValidate : parameters) {
            String keyToValidate = paramToValidate.first;
            String valueToValidate = paramToValidate.second;

            for (InsertCommandsEventBus.Parameter commandParameter : commandParameters) {
                // Param is not valid only if the key is identical but the value is not
                if (commandParameter.getParameterName().equals(keyToValidate)) {
                    if (!commandParameter.getParameterValue().equals(valueToValidate)) {
                        paramsValid = false;
                    }
                }
            }
        }
        return paramsValid;
    }

    @SuppressWarnings("RedundantIfStatement")
    public boolean equals(boolean allowAny, InsertCommand command) {

        if (!compareField(allowAny, action, command.action)) {
            return false;
        }

        if (!compareField(allowAny, eventType, command.eventType)) {
            return false;
        }

        if (!compareField(allowAny, sourceId, command.sourceId)) {
            return false;
        }

        if (!compareField(allowAny, destinationId, command.destinationId)) {
            return false;
        }

        if (!compareField(allowAny, scope, command.scope)) {
            return false;
        }

        return true;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof InsertCommand)) {
            return false;
        } else if (o == this) {
            return true;
        }

        return equals(false, (InsertCommand) o);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(17, 37, this, false, null);
    }

    public static Predicate<InsertCommand> createFilter(@Nullable final String source,
                                                        @Nullable final String destination,
                                                        @NonNull final List<InsertCommandAction> actions,
                                                        @NonNull final InsertCommandEventType eventType) {
        return createFilter(source, destination, actions, Collections.singletonList(eventType));
    }

    public static Predicate<InsertCommand> createFilter(@Nullable final String source,
                                                        @Nullable final String destination,
                                                        @NonNull final InsertCommandAction action,
                                                        @NonNull final List<InsertCommandEventType> eventTypes) {
        return createFilter(source, destination, Collections.singletonList(action), eventTypes);
    }

    public static Predicate<InsertCommand> createFilter(@Nullable final String source,
                                                        @Nullable final String destination,
                                                        @NonNull final List<InsertCommandAction> actions,
                                                        @NonNull final List<InsertCommandEventType> eventTypes) {
        return createFilter(source, destination, actions, eventTypes, InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);
    }

    public static Predicate<InsertCommand> createFilter(@Nullable final String source,
                                                        @Nullable final String destination,
                                                        @NonNull final List<InsertCommandAction> actions,
                                                        @NonNull final List<InsertCommandEventType> eventTypes,
                                                        @NonNull final InsertCommandScope scope) {

        return new Predicate<InsertCommand>() {
            @SuppressWarnings("SimplifiableIfStatement")
            @Override
            public boolean test(InsertCommand insertCommand) {

                boolean match = false;
                for (InsertCommandAction action : actions) {
                    if (insertCommand.compareField(true, insertCommand.action, action)) {
                        match = true;
                        break;
                    }
                }

                for (InsertCommandEventType eventType : eventTypes) {
                    if (insertCommand.compareField(true, insertCommand.eventType, eventType)) {
                        match &= true;
                        break;
                    }
                }

                if (!insertCommand.compareField(true, insertCommand.sourceId, source)) {
                    return false;
                }

                if (!insertCommand.compareField(true, insertCommand.destinationId, destination)) {
                    return false;
                }

                if (!insertCommand.compareField(true, scope, insertCommand.scope)) {
                    return false;
                }

                return match;
            }
        };
    }

    public static Predicate<InsertCommand> createFilter(@Nullable String source,
                                                        @Nullable String destination,
                                                        @NonNull InsertCommandAction action,
                                                        @NonNull InsertCommandEventType eventType,
                                                        @NonNull InsertCommandScope scope) {

        return new InsertCommand(null, source, destination, action, eventType, scope)
                .getFilter();
    }

    public static Function<InsertCommand, Boolean> createFilter(
            @Nullable String source,
            @Nullable String destination,
            @NonNull InsertCommandAction action,
            @NonNull InsertCommandEventType eventType,
            @NonNull InsertCommandScope scope,
            @NonNull Pair<String, String> stringStringPair) {

        return new InsertCommand(null, source, destination, action, eventType, scope)
                .getFilter(stringStringPair);
    }

    public static List<InsertCommand> getInsertCommands(JsonArray actions) {
        LinkedList<InsertCommand> commands = new LinkedList<>();

        if (actions == null) {
            return commands;
        }

        for (int i = 0; i < actions.size(); i++) {
            final JsonObject command = JsonUtils.optJsonObject(actions, i);
            final List<InsertCommand> insertCommands = InsertCommand.commandFactory(command);

            if (!insertCommands.isEmpty()) {
                commands.addAll(insertCommands);
            } else {
                InsertLogger.d("Cannot create command from: " + command.toString());
            }
        }

        return commands;
    }

    /**
     * Returns InsertCommands contained with specific parameters
     *
     * @param actionsJson          the json array that contains the commands
     * @param insertMetadataParams the parameters to add for each command
     * @return
     */
    public static List<InsertCommand> getInsertCommandsWithParameters(
            JsonArray actionsJson,
            List<InsertCommandsEventBus.Parameter> insertMetadataParams) {

        return getInsertCommandsWithParameters(actionsJson, insertMetadataParams, null);
    }

    /**
     * Returns InsertCommands contained with specific parameters
     *
     * @param actionsJson          the json array that contains the commands
     * @param insertMetadataParams the parameters to add for each command
     * @return
     */
    public static List<InsertCommand> getInsertCommandsWithParameters(
            JsonArray actionsJson,
            List<InsertCommandsEventBus.Parameter> insertMetadataParams,
            @Nullable JavascriptRunner.InsertContext insertContext) {

        List<InsertCommand> insertCommands = getInsertCommands(actionsJson);
        return getInsertCommandsWithParameters(insertCommands, insertMetadataParams, insertContext);
    }

    /**
     * Returns InsertCommands contained with specific parameters
     *
     * @param insertCommands       the commands.
     * @param insertMetadataParams the parameters to add for each command
     * @return
     */
    public static List<InsertCommand> getInsertCommandsWithParameters(
            List<InsertCommand> insertCommands,
            List<InsertCommandsEventBus.Parameter> insertMetadataParams,
            @Nullable JavascriptRunner.InsertContext insertContext) {
        if (insertCommands != null) {
            for (InsertCommand command : insertCommands) {
                command.addParameters(insertMetadataParams);
                command.setContext(insertContext);
            }
            return insertCommands;
        }
        return new LinkedList<>();
    }

    /**
     * Retrieves a parameter value from the current command
     *
     * @param requiredParamName the required parameter name
     * @return the required parameter value
     */
    @Nullable
    public String getParamValueFromCommand(String requiredParamName) {
        String requiredParamValue = null;
        List<InsertCommandsEventBus.Parameter> parameters = getParameters();
        if (parameters == null) {
            return null;
        }
        for (InsertCommandsEventBus.Parameter parameter : parameters) {
            final String parameterName = parameter.getParameterName();
            if (requiredParamName.equals(parameterName)) {
                return parameter.getParameterValue();
            }
        }
        return requiredParamValue;
    }

    private void addParameters(List<InsertCommandsEventBus.Parameter> parameters) {
        for (InsertCommandsEventBus.Parameter parameter : parameters) {
            addParameter(parameter);
        }
    }

    private boolean compareField(boolean allowAny, Object f1, Object f2) {
        // Check if the compared field are fits any.
        if (allowAny) {
            if (f1 instanceof InsertCommandAction && f2 instanceof InsertCommandAction) {
                if (InsertCommandAction.INSERT_COMMAND_ACTION_ANY.equals(f1)
                        || InsertCommandAction.INSERT_COMMAND_ACTION_ANY.equals(f2)) {
                    return true;
                }
            }

            if (f1 instanceof InsertCommandEventType && f2 instanceof InsertCommandEventType) {
                if (InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY.equals(f1)
                        || InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY.equals(f2)) {
                    return true;
                }
            }

            if (f1 instanceof InsertCommandScope && f2 instanceof InsertCommandScope) {
                if (InsertCommandScope.INSERT_COMMAND_SCOPE_ANY.equals(f1)
                        || InsertCommandScope.INSERT_COMMAND_SCOPE_ANY.equals(f2)) {
                    return true;
                }
            }

            if (COMMAND_STRING_ANY.equals(f1) || COMMAND_STRING_ANY.equals(f2)) {
                return true;
            }
        }

        if (f1 != null) {
            if (f2 == null) {
                return false;
            } else return f1.equals(f2);
        } else return f2 == null;

    }

    @NonNull
    public static List<InsertCommand> commandFactory(@NonNull JsonObject insertCommand) {

        LinkedList<InsertCommand> retList = new LinkedList<>();
        if (!isValidInsertCommandJSON(insertCommand)) {
            InsertLogger.e("Pendo command is not a valid JSON: "
                    + insertCommand.toString());
            return retList;
        }

        InsertCommand.Builder builder = new Builder();

        try {
            builder.setCommandId(
                    insertCommand.get(INSERT_COMMAND_SERIALIZED_NAME_ID).getAsString());
        } catch (Exception ignore) {
        }

        builder.setAction(InsertCommandAction.getAction(
                insertCommand.get(INSERT_COMMAND_SERIALIZED_NAME_ACTION).getAsString()));

        try {
            builder.setDestinationId(
                    insertCommand.get(INSERT_COMMAND_SERIALIZED_NAME_DESTINATION).getAsString());
        } catch (Exception ignore) {
        }
        try {
            builder.setSourceId(
                    insertCommand.get(INSERT_COMMAND_SERIALIZED_NAME_SOURCE).getAsString());
        } catch (Exception ignore) {
        }
        try {
            builder.setScope(InsertCommandScope.getScope(
                    insertCommand.get(INSERT_COMMAND_SERIALIZED_NAME_SCOPE).getAsString()));
        } catch (Exception ignore) {
        }

        try {
            if (insertCommand.has(INSERT_COMMAND_SERIALIZED_NAME_PARAMETERS)) {
                final JsonArray parametersJsonArray = insertCommand
                        .get(INSERT_COMMAND_SERIALIZED_NAME_PARAMETERS)
                        .getAsJsonArray();

                final List<InsertCommandsEventBus.Parameter> parameters =
                        InsertCommandsEventBus.Parameter.createParameters(parametersJsonArray);

                builder.setParameters(parameters);
            }
        } catch (Exception ignore) {
        }

        final String eventType = insertCommand
                .get(INSERT_COMMAND_SERIALIZED_NAME_EVENT_TYPE).getAsString();

        /**
         * Events can now be piped (e.g. "onLastPage|onFirstPage"). Doing so will generate a copy
         * of the action with each of the events. This means that the actions will be the same in
         * everything but the events.
         */
        if (eventType.contains("|")) {
            final String[] eventTypes = eventType.split("\\|");

            for (String type : eventTypes) {
                final InsertCommandEventType commandEventType =
                        InsertCommandEventType.getEventType(type.trim());

                if (commandEventType != null) {
                    builder.setEventType(commandEventType);
                    retList.add(builder.build());
                }
            }
        } else {
            builder.setEventType(InsertCommandEventType.getEventType(eventType));
            retList.add(builder.build());
        }

        return retList;
    }

    private static boolean isValidInsertCommandJSON(JsonObject insertCommandJSON) {
        if (insertCommandJSON == null) {
            return false;
        }
        if (!insertCommandJSON.has(INSERT_COMMAND_SERIALIZED_NAME_ID)) {
            return false;
        }

        if (!insertCommandJSON.has(INSERT_COMMAND_SERIALIZED_NAME_DESTINATION)) {
            return false;
        }

        if (!insertCommandJSON.has(INSERT_COMMAND_SERIALIZED_NAME_ACTION)) {
            return false;
        }

        if (!insertCommandJSON.has(INSERT_COMMAND_SERIALIZED_NAME_EVENT_TYPE)) {
            return false;
        }

        if (insertCommandJSON.has(INSERT_COMMAND_SERIALIZED_NAME_PARAMETERS)) {

            try {
                final JsonArray jsonArray = insertCommandJSON
                        .getAsJsonArray(INSERT_COMMAND_SERIALIZED_NAME_PARAMETERS);

                if (jsonArray != null) {
                    for (int i = 0; i < jsonArray.size(); i++) {
                        final JsonObject parameterJSON = jsonArray.get(i).getAsJsonObject();
                        if (!InsertCommandsEventBus.Parameter
                                .isValidInsertCommandParameterJSON(parameterJSON)) {
                            return false;
                        }
                    }
                }
            } catch (Exception e) {
                InsertLogger.w(e, "Cannot get parameters JSON.");
                return false;
            }
        }

        return true;
    }

    public static class Builder {
        @Nullable
        private String mCommandId = null;

        @Nullable
        private String mSourceId = null;

        @Nullable
        private String mDestinationId = null;

        @NonNull
        private InsertCommandAction mAction;

        @NonNull
        private InsertCommandEventType mEventType;

        @NonNull
        private InsertCommandScope mScope = InsertCommandScope.INSERT_COMMAND_SCOPE_ANY;

        @Nullable
        private List<InsertCommandsEventBus.Parameter> mParameters = null;

        Builder() {
        }

        public Builder(@NonNull InsertCommandAction action,
                       @NonNull InsertCommandEventType eventType) {
            mAction = action;
            mEventType = eventType;
        }

        Builder setAction(@NonNull InsertCommandAction action) {
            mAction = action;
            return this;
        }

        Builder setEventType(@NonNull InsertCommandEventType eventType) {
            mEventType = eventType;
            return this;
        }

        Builder setCommandId(@Nullable String commandId) {
            mCommandId = commandId;
            return this;
        }

        public Builder setSourceId(@Nullable String sourceId) {
            mSourceId = sourceId;
            return this;
        }

        public Builder setDestinationId(@Nullable String destinationId) {
            mDestinationId = destinationId;
            return this;
        }

        public Builder setScope(@NonNull InsertCommandScope scope) {
            mScope = scope;
            return this;
        }

        public Builder setParameters(@Nullable List<InsertCommandsEventBus.Parameter> parameters) {
            mParameters = parameters;
            return this;
        }

        public Builder addParameter(@Nullable InsertCommandsEventBus.Parameter parameter) {

            if (mParameters == null) {
                mParameters = new LinkedList<>();
            }

            mParameters.add(parameter);
            return this;
        }

        public InsertCommand build() {

            return new InsertCommand(mCommandId, mSourceId,
                    mDestinationId, mAction,
                    mEventType, mScope, mParameters);
        }
    }

    public enum InsertCommandScope {

        ONCE_PER_SESSION("session"),
        ALWAYS("always"),
        INSERT_COMMAND_SCOPE_ANY("any");

        private final String mScope;

        private static final Map<String, InsertCommandScope> LOOKUP_TABLE = new HashMap<>();

        static {
            for (InsertCommandScope s : EnumSet.allOf(InsertCommandScope.class)) {
                LOOKUP_TABLE.put(s.mScope, s);
            }
        }

        InsertCommandScope(String type) {
            this.mScope = type;
        }

        public boolean equals(InsertCommandScope operator) {
            return this.mScope.equals(operator.mScope);
        }

        @Nullable
        public static InsertCommandScope getScope(String scope) {
            return LOOKUP_TABLE.get(scope);
        }
    }
}
