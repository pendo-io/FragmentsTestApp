package sdk.pendo.io.network.responses;

import com.google.gson.annotations.SerializedName;

/**
 * Pendo's SDK authorization error model.
 *
 * Created by assaf on 5/13/15.
 */
public final class AuthTokenErrorResponse {
    public static final String AUTHTOKEN_ERROR_ID = "errorId";
    public static final String AUTHTOKEN_ERROR_MESSAGE = "errorMessage";

    @SerializedName(AUTHTOKEN_ERROR_ID)
    private String mErrorId;

    @SerializedName(AUTHTOKEN_ERROR_MESSAGE)
    private String mMessage;

    @SerializedName("kill")
    private KillSwitchModel mKillSwitchModel;

    public String getErrorId() {
        return mErrorId;
    }

    public String getErrorMessage() {
        return mMessage;
    }

    public KillSwitchModel getKillSwitchModel() {
        return mKillSwitchModel;
    }
}
