package sdk.pendo.io.network.interfaces;

import external.sdk.pendo.io.okhttp3.RequestBody;
import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.http.Body;
import external.sdk.pendo.io.retrofit2.http.POST;
import io.reactivex.Observable;

/**
 * REST protocol for registering the device with the backend.
 *
 * Created by assaf on 4/28/15.
 */
public interface RegisterDevice {

    class RegisterDeviceResponse {

        public int id;
        public int errorId;
        public String errorMessage;
    }

    @POST("v" + RestAPI.REST_API_VERSION + "/devices/register")
    Observable<Response<RegisterDeviceResponse>> registerDevice(@Body RequestBody json);
}
