package sdk.pendo.io.events;


import android.util.SparseArray;

import io.reactivex.functions.Consumer;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.utilities.PersistenceUtils;

import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_BACKGROUND;
import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_FOREGROUND;

/**
 * Manages and keeps the duration each screen is displayed so we
 * can send it to the backend every time a user leaves a screen.
 * <p>
 * Created by itayvallach on 16/01/2017.
 */

public class ScreenDisplayDurationManager {

    private static volatile ScreenDisplayDurationManager INSTANCE;

    private SparseArray<ScreenDurationStats> currentScreens = new SparseArray<>();

    private Consumer<ApplicationFlowManager.AppFlowState> mAppFlowListener =
            new Consumer<ApplicationFlowManager.AppFlowState>() {

                @Override
                public void accept(ApplicationFlowManager.AppFlowState appFlowState) {
                    for (int i = 0; i < currentScreens.size(); i++) {
                        int currentScreenId = currentScreens.keyAt(i);

                        if (currentScreenId != 0 && isScreenCurrentlyShowing(currentScreenId)) {

                            if (IN_BACKGROUND.equals(appFlowState)) {
                                currentScreens.valueAt(i).handleAppInBackground(currentScreenId);

                            } else if (IN_FOREGROUND.equals(appFlowState)) {
                                currentScreens.valueAt(i).handleAppInForeground();
                            }
                        }
                    }
                }
            };

    private ScreenDisplayDurationManager() {
        ApplicationFlowManager.getInstance().getAppFlowChanges(true).subscribe(mAppFlowListener, new InsertOnErrorHandler());
    }

    public static synchronized ScreenDisplayDurationManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ScreenDisplayDurationManager();
        }

        return INSTANCE;
    }

    public SparseArray<ScreenDurationStats> getCurrentScreens() {
        return currentScreens;
    }

    public long getScreenDisplayStartTime(int screenId) {
        return currentScreens.get(screenId).mStartTime;
    }

    public void setScreenDisplayStartTime(int screenId, long time) {
        currentScreens.get(screenId).setStartTime(time);
    }

    public long getScreenDisplayDuration(int screenId) {
        return currentScreens.get(screenId).mDuration;
    }

    public void setScreenFinalDisplayDuration(int screenId) {
        currentScreens.get(screenId).setFinalDuration(screenId);
    }

    public boolean isScreenCurrentlyShowing(int screenId) {
        ScreenDurationStats screen = currentScreens.get(screenId);
        if (screen == null) {
            currentScreens.append(screenId, new ScreenDurationStats());
            PersistenceUtils.removeScreenLeftIntervalledAnalytics(screenId);
            return false;
        } else {
            return screen.mStartTime > 0;
        }
    }

    private class ScreenDurationStats {
        private long mStartTime;
        private long mDuration;
        private long mAccumulativeTime;

        private void handleAppInBackground(int screenId) {
            long interval = System.currentTimeMillis() - mStartTime;
            PersistenceUtils.persistScreenLeftIntervalledAnalytics(mStartTime, interval,
                    screenId);
            mAccumulativeTime = interval + mAccumulativeTime;
        }

        private void handleAppInForeground() {
            setStartTime(System.currentTimeMillis());
        }

        private void setFinalDuration(int screenId) {
            long interval = System.currentTimeMillis() - mStartTime;
            PersistenceUtils.persistScreenLeftIntervalledAnalytics(mStartTime, interval,
                    screenId);
            mDuration = System.currentTimeMillis() - mStartTime + mAccumulativeTime;

            // Screen is not displayed anymore, let's reset times.
            mStartTime = 0;
            mAccumulativeTime = 0;
        }

        private void setStartTime(long startTime) {
            mStartTime = startTime;
        }
    }
}
