package sdk.pendo.io.network.responses;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.actions.configurations.InsertGroup;

/**
 * Created by assaf on 5/13/15.
 */
public class InsertModel {

    public static final String INSERT_ACTIONS = "actions";

    public String id;
    @SerializedName("configuration")
    public InsertActionConfiguration configuration;

    @SerializedName("capping")
    public GuideCapping capping;

    @SerializedName("group")
    public InsertGroup mGroup;

    @SerializedName("name")
    public String name;

    @SerializedName(INSERT_ACTIONS)
    public JsonArray actions;
}
