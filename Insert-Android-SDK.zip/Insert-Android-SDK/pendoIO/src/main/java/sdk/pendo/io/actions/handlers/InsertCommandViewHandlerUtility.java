package sdk.pendo.io.actions.handlers;

import android.graphics.Color;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.trello.rxlifecycle3.android.RxLifecycleAndroid;

import java.util.List;

import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.views.custom.InsertEditText;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPageAction.VALIDATE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandTextAction.SET_TEXT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.ENABLE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.SET_BACKGROUND_COLOR;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.SET_VISIBILITY;

/**
 * This class is a {@link InsertCommand} handler for {@link InsertCommandViewGeneralAction}
 * actions.
 * <p/>
 * Created by assaf on 4/3/16.
 */
public final class InsertCommandViewHandlerUtility {

    private InsertCommandViewHandlerUtility() {
    }

    public static void handleInsertCommandsForView(final View view, final String viewId) {

        // Filter for actions targeting this view.
        Predicate<InsertCommand> viewFilter = InsertCommand.createFilter(
                InsertCommand.COMMAND_STRING_ANY,
                viewId,
                InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

        setupViewGeneralHandler(view, viewFilter);

        if (view instanceof RadioGroup) {
            setupRadioGroupHandler(view, viewFilter);
        }

        if (view instanceof TextView) {
            setupTextViewHandler(view, viewFilter);
        }
    }

    private static void setupViewGeneralHandler(final View view,
                                                Predicate<InsertCommand> viewFilter) {
        final Consumer<InsertCommand> generalViewHandler = new Consumer<InsertCommand>() {
            @Override
            public void accept(InsertCommand insertCommand) {
                InsertLogger.d(insertCommand.toString());

                final InsertCommandAction action = insertCommand.getAction();

                final List<InsertCommandsEventBus.Parameter> parameters =
                        insertCommand.getParameters();

                if (parameters == null) {
                    InsertLogger.w("Got " + insertCommand.getAction()
                                     + " and " + insertCommand.getEventType()
                                     + " without parameters! Doing nothing.");

                    return;
                }

                String visibility = null;
                String color = null;
                Boolean enable = null;
                for (InsertCommandsEventBus.Parameter parameter : parameters) {
                    final String parameterName = parameter.getParameterName();
                    if ("visibility".equals(parameterName)) {
                        visibility = parameter.getParameterValue();
                    } else if ("color".equals(parameterName)) {
                        color = parameter.getParameterValue();
                    } else if ("enabled".equals(parameterName)
                            && "boolean".equalsIgnoreCase(parameter.getValueType())) {
                        try {
                            enable = Boolean.valueOf(parameter.getParameterValue());
                        } catch (Exception e) {
                            InsertLogger.w(e, e.getMessage());
                        }
                    }
                }

                if (ENABLE.equals(action)) {

                    if (enable == null) {
                        InsertLogger.w("enable is null doing nothing.");
                        return;
                    }

                    view.setEnabled(enable);
                } else if (SET_BACKGROUND_COLOR.equals(action)) {

                    if (color == null) {
                        InsertLogger.w("color is null doing nothing.");
                        return;
                    }

                    try {
                        view.setBackgroundColor(Color.parseColor(color));
                    } catch (Exception e) {
                        InsertLogger.w(e, "Got color: " + color);
                    }
                } else if (SET_VISIBILITY.equals(action)) {

                    if (visibility == null) {
                        InsertLogger.w("visibility is null doing nothing.");
                        return;
                    }

                    switch (visibility) {
                        case "visible":
                            view.setVisibility(View.VISIBLE);
                            break;
                        case "hidden":
                            view.setVisibility(View.INVISIBLE);
                            break;
                        case "removed":
                            view.setVisibility(View.GONE);
                            break;
                        default:
                            InsertLogger.w("Got unsupported visibility: " + visibility);
                            break;
                    }
                }
            }
        };

        // Compose with RxLifecycle of the given view.
        InsertCommandsEventBus.getInstance().subscribe(
                RxLifecycleAndroid.<InsertCommand>bindView(view), viewFilter, generalViewHandler);
    }

    private static void setupTextViewHandler(final View view,
                                             Predicate<InsertCommand> viewFilter) {
        InsertCommandsEventBus.getInstance().subscribe(
                RxLifecycleAndroid.<InsertCommand>bindView(view),
                viewFilter, new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());
                        final InsertCommandAction action = insertCommand.getAction();

                        final List<InsertCommandsEventBus.Parameter> parameters =
                                insertCommand.getParameters();

                        if (parameters == null) {
                            InsertLogger.w("Got " + insertCommand.getAction()
                                             + " and " + insertCommand.getEventType()
                                             + " without parameters! Doing nothing.");

                            return;
                        }

                        String text = null;
                        for (InsertCommandsEventBus.Parameter parameter : parameters) {
                            final String parameterName = parameter.getParameterName();
                            if ("text".equals(parameterName)) {
                                text = parameter.getParameterValue();
                            }
                        }

                        if (SET_TEXT.equals(action)) {

                            if (text != null) {
                                ((TextView) view).setText(text);
                                InsertContentDescriptionManager.getInstance().setContentDescription(
                                        view, text, null);
                            }
                        }

                        if (VALIDATE.equals(action)) {
                            if (view instanceof InsertEditText) {
                                ((InsertEditText) view).validate();
                            }
                        }
                    }
                });
    }

    private static void setupRadioGroupHandler(final View view,
                                               Predicate<InsertCommand> viewFilter) {
//        InsertCommandsEventBus.getInstance().subscribe(
//                RxLifecycle.<InsertCommand>bindView(view),
//                viewFilter, new Action1<InsertCommand>() {
//
//                    @Override
//                    public void call(InsertCommand insertCommand) {
//                        InsertLogger.d(insertCommand.toString());
//                        final InsertCommandAction action = insertCommand.getAction();
//
//                        if (!SELECT_RADIO_BUTTON.equals(action)) {
//                            return;
//                        }
//
//                        String source = insertCommand.getSourceId();
//
//                        if (TextUtils.isEmpty(source)) {
//                            InsertLogger.w("No source given!");
//                            return;
//                        }
//
//                        ArrayList<View> outViews = new ArrayList<>();
//                        view.findViewsWithText(outViews, source,
//                                               View.FIND_VIEWS_WITH_CONTENT_DESCRIPTION);
//
//                        if (outViews.isEmpty()) {
//                            InsertLogger.w("Didn't find RadioButton for id: " + source);
//                        } else if (outViews.size() > 1) {
//                            InsertLogger.w("Found '" + outViews.size() + "' RadioButtons for id: "
//                                             + source);
//                        } else {
//                            ((RadioGroup) view).check(outViews.get(0).getId());
//                        }
//                    }
//                });
    }
}
