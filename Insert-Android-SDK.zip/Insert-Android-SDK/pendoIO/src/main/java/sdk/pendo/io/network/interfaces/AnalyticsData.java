package sdk.pendo.io.network.interfaces;

import external.sdk.pendo.io.okhttp3.RequestBody;
import external.sdk.pendo.io.okhttp3.ResponseBody;
import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.http.Body;
import external.sdk.pendo.io.retrofit2.http.POST;
import external.sdk.pendo.io.retrofit2.http.Url;
import io.reactivex.Observable;

/**
 * REST API for the analytics data.
 *
 * Created by assaf on 6/18/15.
 */
public interface AnalyticsData {

    @POST
    Observable<Response<ResponseBody>> send(@Url String endpointUrl, @Body RequestBody json);

}
