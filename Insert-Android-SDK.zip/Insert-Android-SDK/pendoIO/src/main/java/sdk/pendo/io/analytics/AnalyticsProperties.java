package sdk.pendo.io.analytics;

/**
 * Analytics constants.
 *
 * Created by nirsegev on 7/13/15.
 */
public final class AnalyticsProperties {

    public static final String RETROACTIVE_EVENT_ID = "id";
    public static final String RETROACTIVE_EVENT_DATA = "data";
    public static final String RETROACTIVE_EVENT_ACTIVITIES = "activities";
    public static final String RETROACTIVE_EVENT_FRAGMENTS = "fragments";
    public static final String RETROACTIVE_EVENT_TEXTS_ENCODED = "texts";
    public static final String RETROACTIVE_EVENT_TEXTS_ORIGINAL = "textsOriginal";
    public static final String RETROACTIVE_EVENT_TEXTS_BASE_64 = "textsBase64";
    public static final String RETROACTIVE_TEXTS_ELEMENT_INFOS = "texts";
    public static final String RETROACTIVE_EVENT_APP_VERSION = "appVersion";
	public static final String ACTION_TYPE = "actionType";
    public static final String DISMISSED_BY = "dismissBy";
    public static final String APP_STATE_DURATION = "duration";
    public static final String APP_SESSION_DURATION = "duration";
    public static final String INTERVAL_DURATION = "duration";
    public static final String BUFFER_DURATION_MILLIS = "bufferDurationMillis";
    public static final String DISPLAY_DURATION_MILLIS = "displayDurationInMillis";
    public static final String DISPLAY_DURATION = "displayDuration";
    public static final String STEP_DISPLAY_DURATION = "stepDisplayDuration";
    public static final String SCREEN_DISPLAY_DURATION = "screenDisplayDuration";
    public static final String VIDEO_ID_ACTION_IDENTIFIER = "actionIdentifier";
    public static final String VIDEO_LENGTH_MILLIS = "videoLengthMillis";
    public static final String STATE = "state";
    public static final String PLAY_DURATION_MILLIS = "playDurationMillis";
    public static final String SEND_MODE = "sendMode";
    public static final String SEND_MODE_BUFFER = "buffer";
    public static final String SEND_MODE_IMMEDIATE = "immediate";
    public static final String CUSTOM_EVENT_ID = "customEventId";
    public static final String CUSTOM_EVENT_DATA = "customEventData";
    public static final String CUSTOM_EVENT_PARAMS = "customEventParams";
    public static final String CUSTOM_EVENT_NAME = "customEventName";
    public static final String TRACK_EVENT_TYPE = "track";
    public static final String TYPE = "type";
    public static final String CUSTOM_EVENT_PROPERTIES = "properties";
    public static final String LANGUAGE = "language";
    public static final String EVENT = "event";
    public static final String SCREEN_ID = "screenId";
    public static final String GUIDE_ID = "guideId";
    public static final String GUIDE_STEP_ID = "guideStepId";
    public static final String ELEMENT_ID = "elementId";
    public static final String VISITOR_ID_CAMELCASE = "visitorId";
    public static final String VISITOR_ID_UNDERSCORE = "visitor_id";
    public static final String ACCOUNT_ID_CAMELCASE = "accountId";
    public static final String ACCOUNT_ID_UNDERSCORE = "account_id";

    public static final String ELEMENT_TYPE = "elementType";
    public static final String IMAGE_URL = "imageUrl";
	public static final String ORIENTATION = "orientation";
    public static final String REASON = "reason";
    public static final String SEEN_REASON = "seenReason";
    public static final String DISMISS_REASON = "dismiss_reason";
    public static final String PROPS_JSON_KEY = "props";
    public static final String VERSION = "version";
    public static final String NOT_DISPLAYED_REASON = "notDisplayedReason";
    public static final String SEEK_BAR_TIME = "seekBarTime";
    public static final String STACK_TRACE = "stackTrace";
    public static final String TRIGGER = "trigger";
    public static final String TIMESTAMP = "device_time";
    public static final String RETROACTIVE_SCREEN_ID = "retroactiveScreenId";
    public static final String RETROACTIVE_SCREEN_DATA = "retroactiveScreenData";
    public static final String TRIGGERED_BY = "triggeredBy";
    public static final String ACTIVE_TIME = "activeTime";
    public static final String TIME = "time";

    // Application List Item Clicked Message.
    public static final String ITEM_ID = "itemId";
    public static final String ITEM_INDEX = "itemIndex";
    public static final String ITEM_TEXT = "itemText";

    public static final String ERROR_INFO = "errorInfo";
    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String EXCEPTION_TYPE = "exceptionType";
    public static final String DEVICE_INFO = "device_info";

    // Pendo groups type.
    public static final String CONTROL_GROUP = "group";
    public static final String CONTROL_GROUP_TYPE = "type";
    public static final String CONTROL_GROUP_GID = "groupId";
    public static final String CONTROL_GROUP_GID_SEND = "id";

    // Security exception analytics.
    public static final String SIGNED_DATA = "signedData";
    public static final String SOURCE = "source";
    public static final String EXCEPTION_MESSAGE = "exceptionMessage";
}
