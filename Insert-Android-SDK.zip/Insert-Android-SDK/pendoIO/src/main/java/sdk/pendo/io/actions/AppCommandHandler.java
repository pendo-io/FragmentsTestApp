package sdk.pendo.io.actions;

import android.support.annotation.NonNull;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.SetupManager;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.utilities.PersistenceUtils;
import sdk.pendo.io.utilities.ReactiveUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.actions.InsertCommandEventType.AppEventType.APP_IN_BACKGROUND;
import static sdk.pendo.io.actions.InsertCommandEventType.AppEventType.APP_IN_FOREGROUND;
import static sdk.pendo.io.actions.InsertCommandEventType.AppEventType.APP_SESSION_START;
import static sdk.pendo.io.actions.InsertCommandEventType.AppEventType.APP_SESSION_END;

/**
 * Created by itayvallach on 03/09/2017.
 * <p>
 * Responsible of handling Application-level commands. Such commands come on the init json
 * from the backend and are being saved here on initialization. Then the sdk can dispatch
 * them back to the backend whenever necessary.
 */

public final class AppCommandHandler {

    private List<InsertCommand> mCommands = new LinkedList<>();
    private BehaviorSubject<Boolean> mIsAppCommandsSet = BehaviorSubject.createDefault(false);

    private static volatile AppCommandHandler INSTANCE;

    private AppCommandHandler() {
    }

    public void reset() {
        mIsAppCommandsSet.onNext(false);
        mCommands = null;
    }

    public static synchronized AppCommandHandler getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new AppCommandHandler();
        }
        return INSTANCE;
    }

    public void setApplicationCommands(final JsonArray commands) {
        if (commands == null) {
            mIsAppCommandsSet.onNext(true);
        } else {
            ReactiveUtils.schedule(new ApiAction() {
                @Override
                protected void execute() {
                    mCommands = InsertCommand.getInsertCommands(commands);
                    mIsAppCommandsSet.onNext(true);
                }
            });
        }
    }

    public BehaviorSubject<Boolean> getIsAppCommandsSetSubject() {
        return mIsAppCommandsSet;
    }

    public void addParamsAndDispatch(@NonNull InsertCommandEventType.AppEventType eventType,
                                     List<InsertCommandsEventBus.Parameter> additionalParams, String visitorId, String accountId) {
        ArrayList<InsertCommand> chosenCommandsByEventType = new ArrayList<>();
        if (eventType.eventType.equals(APP_SESSION_END.eventType)) {
            handleAppStaticAnalytics(chosenCommandsByEventType, ConstantActions.APP_SESSION_END, true);
        } else if (eventType.eventType.equals(APP_SESSION_START.eventType)) {
            handleAppStaticAnalytics(chosenCommandsByEventType, ConstantActions.APP_SESSION_START, false);
        } else if (eventType.eventType.equals(APP_IN_BACKGROUND.eventType)) {
            handleAppStaticAnalytics(chosenCommandsByEventType, ConstantActions.APP_IN_BACKGROUND, false);
        } else if (eventType.eventType.equals(APP_IN_FOREGROUND.eventType)) {
            handleAppStaticAnalytics(chosenCommandsByEventType, ConstantActions.APP_IN_FOREGROUND, false);
        }

        // Check which commands are suitable for the specific event type we received.
        for (InsertCommand command : mCommands) {
            if (command.getEventType() == eventType) {
                chosenCommandsByEventType.add(command);
            }
        }

        // Add additional params if needed.
        for (InsertCommand command : chosenCommandsByEventType) {
            if (additionalParams != null) {
                JavascriptRunner.InsertContext commandContext = new JavascriptRunner.InsertContext();
                if (visitorId != null) {
                    commandContext.set(AnalyticsProperties.VISITOR_ID_CAMELCASE, visitorId);
                } else {
                    String persistedVisitorId = PersistenceUtils.getPersistedVisitorId();
                    if (persistedVisitorId != null) {
                        commandContext.set(AnalyticsProperties.VISITOR_ID_CAMELCASE, persistedVisitorId);
                    }
                }
                if (accountId != null) {
                    commandContext.set(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, accountId);
                } else {
                    String persistedAccountId = PersistenceUtils.getPersistedAccountId();
                    if (persistedAccountId != null) {
                        commandContext.set(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, persistedAccountId);
                    }
                }
                for (InsertCommandsEventBus.Parameter param : additionalParams) {
                    commandContext.set(param.getParameterName(), param.getParameterValue());
                }
                command.setContext(commandContext);
            }
        }
        InsertCommandDispatcher.getInstance().dispatchCommands(chosenCommandsByEventType,
                eventType, false);

    }

    /**
     * Receives a list of commands and populates it with the contents of the staticCommand JSON,
     * adding the JSON extra data such as visitor and account.
     *
     * @param commands        - List of commands to be populated.
     * @param staticCommand   - The string of the command which we want to add metadata to and insert into commands.
     * @param isAppSessionEnd - A flag saying whether we're in appSessionEnd or not, depending on that, we notify SetupManager of persistence send.
     */
    private void handleAppStaticAnalytics(final ArrayList<InsertCommand> commands, String staticCommand, boolean isAppSessionEnd) {
        JsonParser parser = new JsonParser();
        JsonObject appStaticJSON = null;
        try {
            appStaticJSON = parser.parse(staticCommand).getAsJsonObject();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
            if (isAppSessionEnd) {
                SetupManager.getInstance().setIsFinishedSendingPersistedAnalytics(true);
            }
        }
        if (appStaticJSON != null) {
            commands.addAll(InsertCommand.commandFactory(appStaticJSON));
        }
    }
}
