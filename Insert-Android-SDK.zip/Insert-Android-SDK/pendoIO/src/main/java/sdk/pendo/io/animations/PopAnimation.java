package sdk.pendo.io.animations;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for the pop animation.
 *
 * Created by assaf on 5/6/15.
 */
public final class PopAnimation {

    public static final int DEFAULT_ENTER_DURATION = 600;
    public static final int DEFAULT_EXIT_DURATION = 400;

    private PopAnimation() {}

//    public static AnimatorSet getEnterAnimatorSet(View view, long duration) {
//        return getEnterAnimatorSet(view, -1, duration);
//    }

    public static AnimatorSet getEnterAnimatorSet(View view, int innerViewId) {
        return getEnterAnimatorSet(view, innerViewId, DEFAULT_ENTER_DURATION);
    }

    public static AnimatorSet getEnterAnimatorSet(View view, int innerViewId, long duration) {

        View scaleView = view;
        if (innerViewId != -1) {
            scaleView = view.findViewById(innerViewId);
        }

        scaleView.setScaleX(0f);
        scaleView.setScaleY(0f);
        scaleView.setVisibility(View.VISIBLE);

        AnimatorSet scaleSet = new AnimatorSet();
        List<Animator> collection = new ArrayList<>();
        collection.add(ObjectAnimator.ofFloat(scaleView, View.SCALE_X, 1f));
        collection.add(ObjectAnimator.ofFloat(scaleView, View.SCALE_Y, 1f));

        // Add fade.
        view.setAlpha(0f);
        collection.add(ObjectAnimator.ofFloat(view, View.ALPHA, 1f));

        scaleSet.playTogether(collection);
        scaleSet.setInterpolator(new OvershootInterpolator());
        scaleSet.setDuration(duration);

        return scaleSet;
    }

//    public static AnimatorSet getExitAnimatorSet(View view, long duration) {
//        return getExitAnimatorSet(view, -1, duration);
//    }

    public static AnimatorSet getExitAnimatorSet(View view, int innerViewId) {
        return getExitAnimatorSet(view, innerViewId, DEFAULT_EXIT_DURATION);
    }

    public static AnimatorSet getExitAnimatorSet(View view, int innerViewId, long duration) {

        View scaleView = view;
        if (innerViewId != -1) {
            scaleView = view.findViewById(innerViewId);
        }

        scaleView.setScaleX(1f);
        scaleView.setScaleY(1f);

        AnimatorSet scaleSet = new AnimatorSet();
        List<Animator> collection = new ArrayList<>();
        collection.add(ObjectAnimator.ofFloat(scaleView, View.SCALE_X, 0f));
        collection.add(ObjectAnimator.ofFloat(scaleView, View.SCALE_Y, 0f));

        // Add fade.
        view.setAlpha(1f);
        collection.add(ObjectAnimator.ofFloat(view, View.ALPHA, 0f));

        scaleSet.playTogether(collection);
        scaleSet.setInterpolator(new AnticipateInterpolator());
        scaleSet.setDuration(duration);

        return scaleSet;
    }
}
