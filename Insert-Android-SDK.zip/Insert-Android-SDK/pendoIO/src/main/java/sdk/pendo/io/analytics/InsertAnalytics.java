package sdk.pendo.io.analytics;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableTransformer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState;
import sdk.pendo.io.utilities.PersistenceUtils;

import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_BACKGROUND;
import static sdk.pendo.io.sdk.manager.AnalyticsManager.SCREEN_LEFT;

/**
 * Pendo's analytics and data collection framework.
 * <p>
 * Created by assaf on 6/16/15.
 */
public final class InsertAnalytics {
    private static volatile InsertAnalytics INSTANCE;
    private static final int PUBLISHER_BUFFER_DURATION_SECONDS = 1;
    private static final int PUBLISHER_BUFFER_QUEUE_SIZE = 3;
    private static final int INVALID_ID = -1;
    private static final String INVALID_GUIDE_ID = "";
    private static final Object LOCK = new Object();
    private static boolean sIsAppInBackgroundTriggered = false;

    private final Consumer<List<JSONObject>> mAnalyticEventsConsumer = new Consumer<List<JSONObject>>() {
        @Override
        public void accept(List<JSONObject> jsonObjects) {
            try {
                AnalyticEventsManager.getInstance().handleTrackedAnalyticEvents(jsonObjects, sIsAppInBackgroundTriggered);
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    };
    // Create a REST adapter which points the Pendo API.
    private volatile PublishSubject<JSONObject> mAnalyticsPublisher = PublishSubject.create();

    private PublishSubject<Boolean> mForceFlushObservable = PublishSubject.create();
    private Disposable mSubscription = null;

    private static final BehaviorSubject<Boolean> mBufferIsSetObservable = BehaviorSubject.createDefault(false);

    private volatile boolean mIsQueueSizeCounterNeedBeDropped = false;
    private volatile boolean mIsTimeIntervalCounterNeedBeDropped = false;

    public static BehaviorSubject<Boolean> getBufferIsSetObservable() {
        return mBufferIsSetObservable;
    }

    private InsertAnalytics() {
        synchronized (LOCK) {
            subscribeToPublisher();
        }
    }

    public static synchronized InsertAnalytics getInstance() {
        if (INSTANCE == null) {
            synchronized (LOCK) {
                if (INSTANCE == null) {
                    INSTANCE = new InsertAnalytics();
                }
            }
        }
        return INSTANCE;
    }

    public static Tracker newTracker(GenericInsertAnalyticsData insertGenericAnalytics) {
        return new Tracker(insertGenericAnalytics);
    }

    public static Tracker newTracker(JSONObject analyticsData) {
        return new Tracker(analyticsData);
    }

    public static Tracker newTracker() {
        return new Tracker();
    }

    public synchronized PublishSubject<JSONObject> getAnalyticsPublisher() {
        return mAnalyticsPublisher;
    }

    public void flushCurrentBuffer() {
        mForceFlushObservable.onNext(true);
    }

    /**
     * Receives a json, checks if it's relevant to insert dismissed, if it is,
     * we remove the dismissed interval analytics.
     *
     * @param jsonObject
     */
    private void removeDismissedIntervalAnalyticsIfNeeded(JSONObject jsonObject) {
        if (jsonObject != null
                && jsonObject.has(AnalyticsProperties.TYPE)
                && jsonObject.has(AnalyticsProperties.GUIDE_ID)) {
            String jsonEvent = null;
            String guideId = INVALID_GUIDE_ID;
            try {
                jsonEvent = jsonObject.getString(AnalyticsProperties.TYPE);
                guideId = jsonObject.getString(AnalyticsProperties.GUIDE_ID);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            if (jsonEvent != null
                    && jsonEvent.equals(
                    AnalyticsEvent.GUIDE_DISMISSED.getValue())
                    && !guideId.equals(INVALID_GUIDE_ID)) {
                PersistenceUtils.removeInsertDismissedIntervalledAnalytics(
                        guideId);
            }
        }
    }

    /**
     * Receives a json object, checks if it's relevant to screen left,
     * if it is, we remove the interval screen left analytics.
     *
     * @param jsonObject
     */
    private void removeScreenLeftIntervalAnalyticsIfNeeded(JSONObject jsonObject) {
        String jsonEvent = null;
        if (jsonObject != null
                && jsonObject.has(AnalyticsProperties.EVENT)
                && (jsonObject.has(AnalyticsProperties.SCREEN_ID) || jsonObject.has(AnalyticsProperties.RETROACTIVE_SCREEN_ID))) {
            jsonEvent = null;
            int screenId = INVALID_ID;
            boolean isRetroactiveScreenId = false;
            if (jsonObject.has(AnalyticsProperties.RETROACTIVE_SCREEN_ID)) {
                isRetroactiveScreenId = true;
            }
            try {
                jsonEvent = jsonObject.getString(AnalyticsProperties.EVENT);
                if (!isRetroactiveScreenId) {
                    screenId = jsonObject.getInt(AnalyticsProperties.SCREEN_ID);
                } else {
                    if (jsonEvent.equals(SCREEN_LEFT)) {
                        // Get screen id hashed, as we stored it, in order to remove properly from persistence.
                        screenId = jsonObject.getString(AnalyticsProperties.RETROACTIVE_SCREEN_ID).hashCode();
                    }
                }
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            if (jsonEvent != null
                    && jsonEvent.equals(
                    AnalyticsEvent.APP_SCREEN_LEFT.getValue())
                    && screenId != INVALID_ID) {
                PersistenceUtils.removeScreenLeftIntervalledAnalytics(
                        screenId);
            }
        }
    }


    public void removeAppSessionEndIntervalAnalyticsIfNeeded(JSONObject jsonObject) {
        if (jsonObject != null
                && jsonObject.has(AnalyticsProperties.EVENT)) {
            String jsonEvent = null;
            try {
                jsonEvent = jsonObject.getString(AnalyticsProperties.EVENT);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            if (jsonEvent != null
                    && jsonEvent.equals(
                    AnalyticsEvent.APP_SESSION_END.getValue())) {
                PersistenceUtils.removeAppInBackgroundIntervalledAnalytics();
            }
        }
    }

    Function<JSONObject, JSONObject> visitorAccountIdMap() {
        return new Function<JSONObject, JSONObject>() {
            @Override
            public JSONObject apply(JSONObject receivedJSON) {
                try {
                    String persistedVisitorId = PersistenceUtils.getPersistedVisitorId();
                    String persistedAccountId = PersistenceUtils.getPersistedAccountId();
                    String initParamsVisitorId = Pendo.getVisitorId();
                    String initParamsAccountId = Pendo.getAccountId();
                    /**
                     * Check whether we have the visitor_id or account_id keys in the received analytics.
                     * We have it in case it has been previously added via the Javascript resolved action.
                     * If it hasn't been added before, then we should add a visitor id and account id.
                     * The visitor and account ids that we should add in that case should be of the following format:
                     * visitorId, accountId
                     */
                    if (!(receivedJSON.has(AnalyticsProperties.VISITOR_ID_CAMELCASE)
                            || receivedJSON.has(AnalyticsProperties.VISITOR_ID_UNDERSCORE))) {
                        if (initParamsVisitorId != null) {
                            receivedJSON.put(AnalyticsProperties.VISITOR_ID_CAMELCASE, initParamsVisitorId);
                        } else if (persistedVisitorId != null) {
                            receivedJSON.put(AnalyticsProperties.VISITOR_ID_CAMELCASE, persistedVisitorId);
                        }
                    }
                    if (!(receivedJSON.has(AnalyticsProperties.ACCOUNT_ID_CAMELCASE)
                            || receivedJSON.has(AnalyticsProperties.ACCOUNT_ID_UNDERSCORE))) {
                        if (initParamsAccountId != null) {
                            receivedJSON.put(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, initParamsAccountId);
                        } else if (persistedAccountId != null) {
                            receivedJSON.put(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, persistedAccountId);
                        }
                    }
                } catch (JSONException e) {
                    InsertLogger.e(e, e.getMessage());
                }
                return receivedJSON;

            }
        };
    }

    private void subscribeToPublisher() {
        synchronized (LOCK) {
            mSubscription = mAnalyticsPublisher
                    // Used in order to remove used analytics.
                    .filter(new Predicate<JSONObject>() {
                        @Override
                        public boolean test(JSONObject jsonObject) {
                            removeDismissedIntervalAnalyticsIfNeeded(jsonObject);
                            removeScreenLeftIntervalAnalyticsIfNeeded(jsonObject);
                            removeAppSessionEndIntervalAnalyticsIfNeeded(jsonObject);
                            return true;
                        }
                    })
                    .map(visitorAccountIdMap())
                    /**
                     * Change observable stream to emit a list of JSONObjects according
                     * to the buffer strategy.
                     */
                    .compose(this.<JSONObject>getAnalyticsBuffer())
                    .filter(new Predicate<List<JSONObject>>() {
                        @Override
                        public boolean test(List<JSONObject> typedJSONStrings) {
                            return !typedJSONStrings.isEmpty();
                        }
                    })
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(mAnalyticEventsConsumer, new InsertOnErrorHandler());
        }
    }

    // Interval timer, fires at 1s intervals but filters based on sBufferDurationInSeconds
    private Observable timeIntervalReachedObservable() {
        return Observable.interval(1, TimeUnit.SECONDS).filter(new Predicate<Long>() {

            private int mCounter = 0; // Seconds

            @Override
            public boolean test(Long time) {
                if (mIsTimeIntervalCounterNeedBeDropped) {
                    mCounter = 0;
                    mIsTimeIntervalCounterNeedBeDropped = false;
                }
                mCounter++;
                synchronized (LOCK) {
                    if (mCounter == PUBLISHER_BUFFER_DURATION_SECONDS) {
                        mCounter = 0;
                        mIsQueueSizeCounterNeedBeDropped = true;
                        return true;
                    }
                }
                return false;
            }
        });
    }

    private <T> Observable<T> queueSizeReachedObservable(Observable<T> source) {
        return source.filter(new Predicate<T>() {

            private int mCounter = 0;

            @Override
            public boolean test(T jsonObject) {
                if (mIsQueueSizeCounterNeedBeDropped) {
                    mCounter = 0;
                    mIsQueueSizeCounterNeedBeDropped = false;
                }
                mCounter++;
                synchronized (LOCK) {
                    if (mCounter == PUBLISHER_BUFFER_QUEUE_SIZE) {
                        mCounter = 0;
                        mIsTimeIntervalCounterNeedBeDropped = true;
                        return true;
                    }
                }
                return false;
            }
        });
    }

    private Observable applicationInBackgroundObservable() {
        return ApplicationFlowManager.getInstance().getAppFlowChanges()
                .filter(new Predicate<AppFlowState>() {
                    @Override
                    public boolean test(
                            AppFlowState appFlowState) {
                        sIsAppInBackgroundTriggered = appFlowState.equals(IN_BACKGROUND);
                        return sIsAppInBackgroundTriggered;
                    }
                });
    }

    private <T> ObservableTransformer<T, List<T>> getAnalyticsBuffer() {
        return new ObservableTransformer<T, List<T>>() {
            @Override
            public Observable<List<T>> apply(Observable<T> source) {

                /*
                 * Combine 2 states:
                 * 1. Waiting for init (buffer is set)
                 * 2. Buffer is set
                 */

                Observable<Boolean> buffIsSetObservable = InsertAnalytics.getBufferIsSetObservable()
                        .filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean isSet) {
                                return isSet;
                            }
                        });

                /*
                 * Once the SDK is inited (buffer is set), we should:
                 * 1) buffer according to time. Once reached we should flush.
                 * 2) buffer according to  queue size. Once reached we should flush.
                 * 3) Flush when the app goes to background.
                 * 4) Flush when flushCurrentBuffer() is called to immediately force a flush.
                 */

                Observable<?> bufferStrategyObservable =

                        Observable.merge(
                                /**
                                 * Emits every sBufferDurationInSeconds seconds.
                                 */
                                timeIntervalReachedObservable(),
                                /**
                                 * Emits true once queue size reached (when enough jsons have been stored)
                                 */
                                queueSizeReachedObservable(source),

                                /**
                                 * Emits true when app is in background
                                 */
                                applicationInBackgroundObservable(),

                                /**
                                 * Emits true when flushCurrentBuffer() is called to immediately flush current pending analytics.
                                 */
                                mForceFlushObservable
                        );

                return source.buffer(Observable.combineLatest(
                        buffIsSetObservable, bufferStrategyObservable,
                        new BiFunction<Boolean, Object, Boolean>() {
                            @Override
                            // Wait for BufferIsSet
                            public Boolean apply(Boolean bufferIsSet, Object object) {
                                return bufferIsSet;
                            }
                        }));
            }
        };
    }

    public GenericInsertAnalyticsData newInsertGenericAnalytics(InsertAction insertAction) {
        return new GenericInsertAnalyticsData(insertAction);
    }

    public GenericInsertAnalyticsData newGuideGenericAnalytics(GuideModel guideModel) {
        return new GenericInsertAnalyticsData(guideModel);
    }

    /**
     * Create observable from InsertAnalyticsData and subscribe to it further handling.
     *
     * @param analyticsData - the InsertAnalyticsData (may be plural).
     */
    public void setupAndSubscribe(InsertAnalyticsData... analyticsData) {
        Observable.fromArray(analyticsData)
                .subscribe(InsertObserver.create(new Consumer<InsertAnalyticsData>() {
                    public void accept(InsertAnalyticsData insertAnalyticsData) {
                        JSONObject jsonObject = insertAnalyticsData.convertToJSONObject();
                        if (jsonObject != null) {
                            InsertLogger.d("Analytics: " + jsonObject.toString());
                            mAnalyticsPublisher.onNext(jsonObject);
                        }
                    }
                }));
    }
}
