package sdk.pendo.io.network.responses.validators

import org.jose4j.base64url.Base64
import org.jose4j.jwa.AlgorithmConstraints
import org.jose4j.jwk.RsaJsonWebKey
import org.jose4j.jwt.consumer.InvalidJwtException
import org.jose4j.jwt.consumer.JwtConsumer
import org.jose4j.jwt.consumer.JwtConsumerBuilder

import java.security.KeyFactory
import java.security.NoSuchAlgorithmException
import java.security.interfaces.RSAPublicKey
import java.security.spec.InvalidKeySpecException
import java.security.spec.X509EncodedKeySpec

import sdk.pendo.io.logging.InsertLogger

/**
 * [JWT](http://jwt.io) validator.
 *
 *
 * JSON Web Tokens are an open, industry standard RFC 7519 method for representing
 * claims securely between two parties.
 *
 *
 *
 * JWT.IO allows you to decode, verify and generate JWT.
 *
 * Created by assaf on 1/12/16.
 */
object JsonWebTokenValidator {

    private var ENV = Environment.PRODUCTION
    private var RSA_JSON_WEB_KEY = generatePublicKey()
    private var JWT_CONSUMER = generateJWT()

    // TODO: move this to a more generic class?
    private enum class Environment {
        PRODUCTION,
        STAGING,
        DEV
    }

    @Synchronized
    fun setEnvironment(environment: String) {
        try {
            ENV = Environment.valueOf(environment.toUpperCase())
        } catch (e: Exception) {
            InsertLogger.w("Invalid environment: [$environment], will use current values")
            return
        }

        RSA_JSON_WEB_KEY = generatePublicKey()
        JWT_CONSUMER = generateJWT()
    }

    @Synchronized
    private fun generateJWT(): JwtConsumer? {
        if (RSA_JSON_WEB_KEY == null) {
            return null
        }

        return JwtConsumerBuilder()
                .setRelaxVerificationKeyValidation()
                // Verify the signature with the public key.
                .setVerificationKey(RSA_JSON_WEB_KEY!!.key)
                .setJweAlgorithmConstraints(AlgorithmConstraints.DISALLOW_NONE)
                .build() // Create the JwtConsumer instance.
    }

    private fun getEnvironmentPublicKey(): String {
        return when (ENV) {
            JsonWebTokenValidator.Environment.STAGING -> "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCv8IqRRwpH8s7EnWhLwuFqnbTA\n" + "6iT8LqQ+nPL0WvwCtHPABV4hXd0+qj4TZo3nEew13M5uEFiD6cFlA1/l/dydjGjT\n" + "vknbo5+6pBVWVZpCg5Rtpii3JUKMxOmJrccBCo7ICIqPIj/L9Nc5zmWMH2igKHLq\n" + "x4N4CYzAsWwSc505vwIDAQAB"
            JsonWebTokenValidator.Environment.DEV -> "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCbelsiqvdpzGmRF3pex4Ar1HNI\n" + "McadFr9rwxGUMGOn8qIcjLE4vr9T1rxm6DekW9IBGNAwGOynuA+ebTfpfPMYY8nO\n" + "Z7gvgJ/czWhiH8IDnmHnxVeLd6O8Z+/4hl++9Yae1093QTb2k5FIekNae54Klg4N\n" + "T0Qiqky2MfXLee1lYwIDAQAB"
            //use PRODUCTION as default
            else -> "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1B6qsa2sbpc4CuFEjgRWez9nN\n" + "Mtburcr/RZ6n4iEIGcLZFfQ34whx3aGQ8ZuImAOOHnhjohaZzaW8bITEnZNa+v/h\n" + "0vFrDGYtyJQdh1H7ejasIvWYDt+S/Pd1b8b8/ZZ6czA8fNcDDGgXmcGOCi8tK2nJ\n" + "972K3gVzG7F581Tw6QIDAQAB"
        }
    }

    @Synchronized
    private fun generatePublicKey(): RsaJsonWebKey? {

        val publicKey = getEnvironmentPublicKey()
        val decoded = Base64.decode(publicKey)
        try {
            val kFactory = KeyFactory.getInstance("RSA")

            // Generate the public key.
            val spec = X509EncodedKeySpec(decoded)
            val publicKey = kFactory.generatePublic(spec) as RSAPublicKey
            return RsaJsonWebKey(publicKey)
        } catch (e: NoSuchAlgorithmException) {
            InsertLogger.d(e)
        } catch (e: InvalidKeySpecException) {
            InsertLogger.w(e)
        }

        InsertLogger.e("CANNOT GENERATE PUBLIC KEY!")
        return null
    }

    @Throws(IllegalStateException::class, InvalidJwtException::class)
    fun validate(json: String): String {

        if (RSA_JSON_WEB_KEY == null) {
            throw IllegalStateException("RSA key is null")
        }

        if (JWT_CONSUMER == null) {
            throw IllegalStateException("JWT consumer null")
        }

        //  Validate the JWT and process it to the Claims
        val jwtClaims = JWT_CONSUMER!!.processToClaims(json)
        return jwtClaims.toJson()
    }
}