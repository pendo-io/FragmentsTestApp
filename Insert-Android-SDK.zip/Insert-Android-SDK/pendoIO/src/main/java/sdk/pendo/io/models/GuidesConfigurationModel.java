package sdk.pendo.io.models;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

public class GuidesConfigurationModel {

    @SerializedName("throttling")
    private ThrottlingConfigurationModel mThrottlingConfigurationModel;

    @SerializedName("order")
    private JsonArray mOrder;

    @SerializedName("lastStepSeen")
    private LastStepSeenConfigurationModel mLastStepSeenConfigurationModel;

    public LastStepSeenConfigurationModel getLastStepSeenConfigurationModel() {
        return mLastStepSeenConfigurationModel;
    }

    public ThrottlingConfigurationModel getThrottlingConfigurationModel() {
        return mThrottlingConfigurationModel;
    }

}
