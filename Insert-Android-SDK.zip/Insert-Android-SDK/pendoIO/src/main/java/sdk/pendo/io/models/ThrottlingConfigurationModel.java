package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

public class ThrottlingConfigurationModel {
    @SerializedName("count")
    private int mCount;

    @SerializedName("enabled")
    private boolean mEnabled;

    @SerializedName("interval")
    private int mInterval;

    @SerializedName("unit")
    private String mUnit;


    public int getInterval() {
        return mInterval;
    }

    public String getUnit() {
        return mUnit;
    }

    public boolean isEnabled() {
        return mEnabled;
    }

}
