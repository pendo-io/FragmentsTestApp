package sdk.pendo.io.network.socketio.listeners;

import java.util.Arrays;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Listen on {@link external.sdk.pendo.io.socket.client.Socket#EVENT_CONNECT_TIMEOUT}.
 * Listen on {@link external.sdk.pendo.io.socket.client.Socket#EVENT_CONNECT_ERROR}.
 * Listen on {@link external.sdk.pendo.io.socket.client.Socket#EVENT_RECONNECT_FAILED}.
 */
public final class ConnectionErrorListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got connection error: "
                         + (args != null ? Arrays.toString(args) : ""));
        SocketIOUtils.handleUnauthorizedConnectionIfNeeded(args);
    }
}
