package sdk.pendo.io.cache;

import android.support.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

/**
 * The cache model.
 *
 * Created by assaf on 12/3/15.
 */
public final class CacheModel {

    private static final String CACHE_MODEL_SDK_VERSION = "sdkVersion";
    private static final String CACHE_MODEL_APP_VERSION = "appVersion";
    private static final String CACHE_MODEL_INIT_MODEL = "initModel";

    @NonNull
    @SerializedName(CACHE_MODEL_SDK_VERSION)
    private final String mSdkVersion;

    @NonNull
    @SerializedName(CACHE_MODEL_APP_VERSION)
    private final String mAppVersion;

    @NonNull
    @SerializedName(CACHE_MODEL_INIT_MODEL)
    private final String mInitModel;

    protected CacheModel(@NonNull String sdkVersion,
                         @NonNull String appVersion,
                         @NonNull String initModel) {
        mSdkVersion = sdkVersion;
        mAppVersion = appVersion;
        mInitModel = initModel;
    }

    @NonNull
    protected String getSdkVersion() {
        return mSdkVersion;
    }

    public String getAppVersion() {
        return mAppVersion;
    }

    @NonNull
    protected String getInitModel() {
        return mInitModel;
    }
}
