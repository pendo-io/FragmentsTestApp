package sdk.pendo.io.reactive.functions;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Function;

/**
 * Handles retrying the network observable in case of throwable was thrown.
 * This retry handler makes up to maxRetries retries
 * with a delay of retryDelayMillis between them.
 * Created by nirsegev on 24/07/2016.
 */

public class RetryWithDelay implements
        Function<Observable<? extends Throwable>, Observable<?>> {

    private final int mMaxRetries;
    private final int mRetryDelayMillis;
    private int mRetryCount;

    /**
     * CTOR This retry handler makes up to maxRetries retries
     * with a delay of retryDelayMillis between them.
     *
     * @param maxRetries       max retries number
     * @param retryDelayMillis the delay between retries
     */
    public RetryWithDelay(final int maxRetries, final int retryDelayMillis) {
        mMaxRetries = maxRetries;
        mRetryDelayMillis = retryDelayMillis;
        mRetryCount = 0;
    }

    @Override
    public Observable<?> apply(Observable<? extends Throwable> attempts) {
        return attempts
                .flatMap(new Function<Throwable, Observable<?>>() {
                    @Override
                    public Observable<?> apply(Throwable throwable) {
                        if (++mRetryCount < mMaxRetries) {
                            // When this Observable calls onNext, the original
                            // Observable will be retried (i.e. re-subscribed).
                            return Observable.timer(mRetryDelayMillis,
                                    TimeUnit.MILLISECONDS);
                        }
                        // Max retries hit. Just pass the error along.
                        return Observable.error(throwable);
                    }
                });
    }
}