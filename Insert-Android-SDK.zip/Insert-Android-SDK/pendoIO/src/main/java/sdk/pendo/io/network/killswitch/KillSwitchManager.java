package sdk.pendo.io.network.killswitch;

import android.text.TextUtils;

import org.jose4j.jwt.consumer.InvalidJwtException;

import java.nio.charset.Charset;
import java.util.List;

import external.sdk.pendo.io.okhttp3.ResponseBody;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.network.responses.AuthTokenErrorResponse;
import sdk.pendo.io.network.responses.KillSwitchModel;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.utilities.APIUtils;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.FileUtils;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.SettingsUtils;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * handles the kill switch operation . both loading validating and storing
 * Created by nirsegev on 4/14/16.
 */
public class KillSwitchManager {

    public static final String KILL_SWITCH_FILE_NAME = "pendo_killswitch";
    public static final String APP_VERSION_FILE_NAME = "host_app_version";
    private static volatile KillSwitchManager INSTANCE;

    private KillSwitchManager() {
    }

    public static synchronized KillSwitchManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new KillSwitchManager();
        }

        return INSTANCE;
    }

    private static synchronized void storeKillSwitch(String killSwitchResponse) {
        if (TextUtils.isEmpty(killSwitchResponse)) {
            return;
        }
        FileUtils.createFileFromByteArray(killSwitchResponse.getBytes(Charset.forName(ENCODING_UTF_8)), KILL_SWITCH_FILE_NAME);
    }

    /**
     * Handling the kill switch response
     *
     * @param error the retrofit error representing the kill switch
     * @return true if kill switch is ON. false if kill switch is OFF
     */
    public static boolean handleKillSwitchResponse(ResponseBody error) {
        try {
            String retrofitErrorResponseBody = APIUtils.INSTANCE.getResponseBodyAsString(error);
            String killSwitchJson = JsonWebTokenValidator.INSTANCE.validate(retrofitErrorResponseBody);
            AuthTokenErrorResponse authTokenErrorResponse =
                    Pendo.GSON.fromJson(killSwitchJson, AuthTokenErrorResponse.class);

            storeKillSwitch(retrofitErrorResponseBody);

            return logAndCheckKillSwitch(authTokenErrorResponse);
        } catch (Exception ignore) {
            InsertLogger.d("Problem with kill switch handling" + ignore.getMessage());
        }
        return false;
    }

    /**
     * Check if kill switch is on.
     * @return true if kill switch is on. False otherwise.
     */
    public static synchronized boolean isKillSwitchOn() {
        if (isApplicationVersionChanged()) {
            return false;
        }
        return isCachedKillSwitchOn();
    }

    /**
     * Load the persisted application version, check for changes and update it.
     * If the application version changed, delete the persisted kill switch file.
     * @return true if the application version changed. False if it persisted or didn't exists.
     */
    private static boolean isApplicationVersionChanged() {
        String persistedHostAppVersion = FileUtils.getStoredFileAsString(APP_VERSION_FILE_NAME);
        String currentHostAppVersion = AndroidUtils.getAppVersionName();
        if (persistedHostAppVersion != null) {
            if (!persistedHostAppVersion.equals(currentHostAppVersion)) {
                // Delete the file and Store the new version and return true.
                FileUtils.deleteFile(APP_VERSION_FILE_NAME);
                FileUtils.deleteFile(KILL_SWITCH_FILE_NAME);
                FileUtils.createFileFromByteArray(currentHostAppVersion.getBytes(Charset.forName(ENCODING_UTF_8)), APP_VERSION_FILE_NAME);
                return true;
            }
        } else {
            // Store the new version.
            FileUtils.createFileFromByteArray(currentHostAppVersion.getBytes(Charset.forName(ENCODING_UTF_8)), APP_VERSION_FILE_NAME);
        }
        // App version didn't change.
        return false;
    }

    private static boolean logAndCheckKillSwitch(AuthTokenErrorResponse authTokenErrorResponse) {
        logKillSwitchResponse(authTokenErrorResponse);
        return isSDKVersionEffectedByKillSwitchModel(authTokenErrorResponse.getKillSwitchModel(), SettingsUtils.getSDKVersion());
    }

    private static void logKillSwitchResponse(AuthTokenErrorResponse response) {
        if (response.getKillSwitchModel() == null) {
            return;
        }
        Long expiration = response.getKillSwitchModel().getExpiration();
        List<String> affectedVersions = response.getKillSwitchModel().getAffectedVersions();
        InsertLogger.d("Got kill switch response:  " +
                " errorId: " + response.getErrorId() +
                " errorMessage: '" + response.getErrorMessage() +
                " kill expiration: " + (expiration == null ? "never" : String.valueOf(expiration.longValue())));
        if (affectedVersions != null) {
            for (String version : affectedVersions) {
                InsertLogger.d(" kill version: " + version);
            }
        }
    }

    /**
     * Loads the kill switch stored response
     *
     * @return true if killswitch is ON, false if kill switch is OFF
     */
    private static boolean isCachedKillSwitchOn() {
        String killswitchString = FileUtils.getStoredFileAsString(KILL_SWITCH_FILE_NAME);
        String validatedKillswitchString = null;
        try {
            if (!TextUtils.isEmpty(killswitchString)) {
                try {
                    validatedKillswitchString = JsonWebTokenValidator.INSTANCE.validate(killswitchString);
                } catch (InvalidJwtException ignore) {
                }
                AuthTokenErrorResponse authTokenErrorResponse = Pendo.GSON.fromJson(validatedKillswitchString, AuthTokenErrorResponse.class);
                if (logAndCheckKillSwitch(authTokenErrorResponse)) {
                    return true;
                } else {
                    // kill switch is off, let's delete the kill switch file
                    FileUtils.deleteFile(KILL_SWITCH_FILE_NAME);
                }
            }
            return false;
        } catch (Exception ignore) {

        }
        return false;
    }

    private static boolean isSDKVersionEffectedByKillSwitchModel(KillSwitchModel killSwitchModel, String currentSDKVersion) {
        if (!(killSwitchModel.isExpired())
                && (killSwitchModel.isCurrentSDKVersionAffected(currentSDKVersion))) {
            InsertLogger.d("Kill Switch is ON");
            return true;
        }
        return false;
    }
}
