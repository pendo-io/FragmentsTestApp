package sdk.pendo.io.events;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

/**
 * Created by nirsegev on 9/1/15.
 */
public final class EventConfiguration {

    @SerializedName("action")
    private String mAction;

    @SerializedName("type")
    private String mType;

    @SerializedName("eventName")
    private String mEventName;

    @SerializedName("isStateSensitive")
    private boolean mIsStateSensitive;

    @SerializedName("supportedParams")
    private JsonArray mSupportedParams;

    @SerializedName("screenId")
    private int mScreenId;

    public String getAction() {
        return mAction;
    }

    public String getType() {
        return mType;
    }

    public JsonArray getSupportedParams() {
        return mSupportedParams;
    }

    public void setAction(InsertEvent.EventActions eventAction) {
        mAction = eventAction.action;
    }

    public boolean isStateSensitive() {
        return mIsStateSensitive;
    }

    public String getEventName() {
        return mEventName;
    }

    public int getScreenId() {return mScreenId;}

    public void setScreenId(int screenId) {
        mScreenId = screenId;
    }
}

