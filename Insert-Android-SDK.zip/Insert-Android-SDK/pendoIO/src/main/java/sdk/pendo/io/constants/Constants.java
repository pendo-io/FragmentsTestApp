package sdk.pendo.io.constants;

import sdk.pendo.io.events.IdentificationData;

/**
 * Constants.
 * Created by assaf on 8/13/15.
 */
public final class Constants {

    private Constants() {
    }

    public static final class GeneralConsts {
        public static final String RTL = "rtl";
        public static final String TYPE_STRING = "string";
        public static final Object IRRELEVANT = new Object();
    }

    public static final class EncodingConsts {
        public static final String ENCODING_UTF_8 = "UTF-8";
    }

    public static final class ScreenCaptureConsts {
        public static final String ACTIVITY_NAME = "activityName";
        public static final String FRAGMENT_NAME = "fragmentName";
    }

    public static final class ViewCaptureConsts {
        public static final String DESCRIPTIVE_TEXT = "descriptiveText";
        public static final String TEXT = "text";
        public static final String TEXT_TRUNCATED = "textTruncated";
    }

    public static final class SpecialViewAttrTypeConsts {
        public static final String JSON = "json";
    }

    public static final class DynamicViewsConsts {
        public static final String NAME = "name";
        public static final String TYPE = "type";
        public static final String VALUE = "value";
    }

    public static final class SpecialViewAttrsConsts {
        public static final String ELEMENT = "element";
        public static final String IDENTIFICATION_DATA = IdentificationData.SERIALIZED_NAME;
    }

    public static final class ViewAttrsConsts {
        public static final String TEXT_DIRECTION = "textDirection";
        public static final String TEXT_SIZE = "textSize";
        public static final String PADDING = "padding";
        public static final String POSITION = "position";
        public static final String ID = "id";
        public static final String BACKGROUND = "background";
        public static final String STROKE = "stroke";
        public static final String STROKE_WIDTH = "strokeWidth";
        public static final String FONT_FAMILY = "fontFamily";
        public static final String TEXT_COLOR = "textColor";
        public static final String TEXT = "text";
        public static final String TEXT_STYLE = "textStyle";
        public static final String GRAVITY = "gravity";
        public static final String ANIMATION = "animation";
        public static final String DURATION = "animationDuration";
        public static final String FRAME_COLOR = "frameColor";
        public static final String FRAME_WIDTH = "frameWidth";

        public static final String CLICK_ACTION_PROPERTY = "click_action";

        public static final String ON_SUBMIT_CHANGE_SCREEN = "changeScreen";
        public static final String ON_SUBMIT_CLOSE = "close";
        public static final String FRAME_RADIUS = "frameRadius";
    }
}
