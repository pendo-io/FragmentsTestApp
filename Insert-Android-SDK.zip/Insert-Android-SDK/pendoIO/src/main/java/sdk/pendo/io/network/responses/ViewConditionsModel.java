package sdk.pendo.io.network.responses;

import com.google.gson.annotations.SerializedName;

/**
 * Created by assaf on 1/6/16.
 */
public final class ViewConditionsModel {

    @SerializedName("predicate")
    private String mPredicate;

    public String getPredicate() {
        return mPredicate;
    }
}
