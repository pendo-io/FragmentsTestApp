package sdk.pendo.io.network.interfaces;

import com.google.gson.JsonObject;
import external.sdk.pendo.io.okhttp3.RequestBody;
import external.sdk.pendo.io.okhttp3.ResponseBody;
import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.http.Body;
import external.sdk.pendo.io.retrofit2.http.GET;
import external.sdk.pendo.io.retrofit2.http.POST;
import io.reactivex.Observable;


/**
 * Created by tomerlevinson on 4/12/16.
 */
public interface SetupProcess {
    @POST("v" + RestAPI.REST_API_VERSION + "/devices/setup")
    Observable<Response<ResponseBody>> send(@Body RequestBody json);

    @GET("v" + RestAPI.REST_API_VERSION + "/devices/setup")
    Observable<Response<JsonObject>> getSetup();

    @POST("v" + RestAPI.REST_API_VERSION + "/devices/debugData")
    Observable<Response<ResponseBody>> sendDebugData(@Body RequestBody json);
}
