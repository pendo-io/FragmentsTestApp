package sdk.pendo.io.utilities

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import sdk.pendo.io.logging.InsertLogger

/**
 * Kotlin utils.
 *
 * Created by assaf on 6/14/17.
 */
object KotlinUtils {
    fun <T> ifAtLeastApi(api: Int, f: () -> T, g: () -> T) {
        if (api <= android.os.Build.VERSION.SDK_INT) {
            f()
        } else {
            g()
        }
    }
}

internal fun JSONObject.add(name: String, value: Any): JSONObject {
    try {
        when (value) {
            is Boolean -> this.put(name, value)
            is Double -> this.put(name, value)
            is Int -> this.put(name, value)
            is Long -> this.put(name, value)
            is Any -> this.put(name, value)
        }
    } catch (e: JSONException) {
        InsertLogger.e(e)
    }
    return this
}

internal fun JSONArray.add(value: Any): JSONArray {
    try {
        when (value) {
            is Boolean -> this.put(value)
            is Double -> this.put(value)
            is Int -> this.put(value)
            is Long -> this.put(value)
            is Any -> this.put(value)
        }
    } catch (e: JSONException) {
        InsertLogger.e(e)
    }
    return this
}