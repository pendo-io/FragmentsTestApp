package sdk.pendo.io.actions.configurations;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * Pendo's cache policy.
 *
 * Created by assaf on 11/29/15.
 */
public final class CachingPolicy {

    public static final String CACHING_POLICY_ENABLED = "enabled";
    public static final String CACHING_POLICY_EXPIRATION = "expiration";
    public static final String CACHING_POLICY_VERIFY_ON_SERVER = "verifyOnServer";
    public static final int CACHING_POLICY_NEVER_EXPIRE = -1;

    @SerializedName(CACHING_POLICY_ENABLED)
    private final boolean mEnabled; // fallback to false (default == false)

    @SerializedName(CACHING_POLICY_EXPIRATION)
    private final long mExpiration; // e.g.: UNIX time format (epoc). -1 == never expires.
    private Date mExpirationDate;

    @SerializedName(CACHING_POLICY_VERIFY_ON_SERVER)
    private final boolean mVerifyOnServer; // e.g.: false, Verify with Pendo before display.

    public CachingPolicy(boolean enabled, long expiration, boolean verifyOnServer) {
        mEnabled = enabled;
        mExpiration = expiration;
        mVerifyOnServer = verifyOnServer;
    }

    public boolean isEnabled() {
        return mEnabled;
    }

    public boolean isVerifyOnServer() {
        return mVerifyOnServer;
    }

    public synchronized boolean isExpired() {


        if (mExpiration == CACHING_POLICY_NEVER_EXPIRE) {
            return false;
        }

        Date now = new Date();
        return now.after(getExpirationDate());
    }

    private Date getExpirationDate() {
        if (mExpirationDate == null) {
            mExpirationDate = new Date(mExpiration);
        }
        return mExpirationDate;
    }

    @Override
    public String toString() {

        return "{"
                + CACHING_POLICY_ENABLED + " = " + mEnabled + ", "
                + CACHING_POLICY_EXPIRATION + " = " + mExpiration
                + ((mExpiration == CACHING_POLICY_NEVER_EXPIRE) ? ", "
                : "(" + getExpirationDate() + "), ")
                + CACHING_POLICY_VERIFY_ON_SERVER + " = " + mVerifyOnServer
                + "}";
    }
}
