package sdk.pendo.io.animations;

import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.graphics.Color;
import android.os.Build;
import android.view.Window;

/**
 * Animates the statusbar color from one value to another.
 *
 * Created by assaf on 9/3/15.
 */
@TargetApi(Build.VERSION_CODES.LOLLIPOP)
public final class StatusBarColorAnimation {

    private final Window mWindow;
    private final int mFromColor;
    private final int mToColor;

    @SuppressWarnings("CheckStyle")
    public StatusBarColorAnimation(Window from, int to, boolean toDarken) {
        mWindow = from;

        int color = to;
        if (toDarken) {
            float[] hsv = new float[3];
            Color.colorToHSV(color, hsv);
            hsv[2] = hsv[2] * 0.75f;
            color = Color.HSVToColor(hsv);
        }

        mFromColor = from.getStatusBarColor();
        mToColor = color;
    }

    public void statusBarColorAnimate() {
        ValueAnimator colorAnim = ValueAnimator.ofArgb(mFromColor, mToColor);
        colorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                mWindow.setStatusBarColor((Integer) animation.getAnimatedValue());
            }
        });
        colorAnim.start();
    }

    public void reverseStatusBarColorAnimate() {
        ValueAnimator colorAnim = ValueAnimator.ofArgb(mToColor, mFromColor);
        colorAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                mWindow.setStatusBarColor((Integer) animation.getAnimatedValue());
            }
        });
        colorAnim.start();
    }
}
