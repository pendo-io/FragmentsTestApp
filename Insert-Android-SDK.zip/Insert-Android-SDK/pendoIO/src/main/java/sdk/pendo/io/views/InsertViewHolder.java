package sdk.pendo.io.views;

import android.view.View;

import external.sdk.pendo.io.dynamicview.DynamicViewId;

/**
 * Holder class that keep UI Component from the Dynamic View.
 */
@SuppressWarnings("CheckStyle")
public class InsertViewHolder {

    @DynamicViewId(id = "insert_visual_close_button")
    public View closeButton;

    @DynamicViewId(id = "insert_visual_image")
    public View imageView;

    @DynamicViewId(id = "insert_visual_video")
    public View videoView;

    @DynamicViewId(id = "insert_visual_action_button")
    public View actionButton;

    @DynamicViewId(id = "insert_visual_main_layout")
    public View mainLayout;

    @DynamicViewId(id = "insert_visual_floating_layout")
    public View floatingLayout;

    public InsertViewHolder() {
    }
}
