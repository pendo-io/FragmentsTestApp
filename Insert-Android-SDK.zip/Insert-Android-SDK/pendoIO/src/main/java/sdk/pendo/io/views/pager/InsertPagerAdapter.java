package sdk.pendo.io.views.pager;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentStatePagerAdapter;
import android.view.ViewGroup;

import com.google.gson.JsonArray;

import sdk.pendo.io.views.InsertFragment;

/**
 * Pendo's {@link InsertPager} {@link FragmentStatePagerAdapter}.
 *
 * Created by assaf on 3/6/16.
 */
public final class InsertPagerAdapter extends FragmentStatePagerAdapter {

    private final int mPageCount;
    private final JsonArray mPages;
    private String mInsertId;
    private boolean mIsRTL;

    public InsertPagerAdapter(FragmentManager fm, JsonArray pages, String insertId, boolean isRTL) {
        super(fm);
        mInsertId = insertId;
        mIsRTL = isRTL;
        mPageCount = pages.size();
        mPages = pages;
    }

    @Override
    public Fragment getItem(int position) {
        try {
            // If it's RTL pager we take the position from the last item going backwards.
            if (mPages != null) {
                return InsertFragment.newInstance(mPages.get(
                        mIsRTL ? mPages.size() - 1 - position : position).getAsJsonObject(),
                        mInsertId);
            }
        } catch (Exception e) {
            return null; // TODO: 3/7/16 What to do here?
        }
        return null;
    }

    @Override
    public int getCount() {
        return mPageCount;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        return super.instantiateItem(container, position);
    }
}
