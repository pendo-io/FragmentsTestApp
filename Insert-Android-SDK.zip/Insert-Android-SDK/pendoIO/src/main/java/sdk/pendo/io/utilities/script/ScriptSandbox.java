package sdk.pendo.io.utilities.script;

import sdk.pendo.io.Pendo;

/**
 * Interface for script sandboxing.
 *
 * Created by assaf on 11/6/16.
 */
interface ScriptSandbox {

    /**
     * Sets the sandbox strict mode and the class whitelisting
     * using the {@link Pendo.PendoOptions} class.
     *
     * @param options the options to set.
     *
     * @return true if the sandbox mode was set.
     */
    boolean setSandboxModeAndWhitelist(Pendo.PendoOptions options);

    /**
     * Checks if the given class can be accessed or not.
     *
     * @param type the class to check.
     *
     * @return true if the class can be access, false otherwise.
     */
    boolean allowClassAccess(Class<?> type);

    /**
     * Checks if the given class's field can be accessed or not.
     *
     * @param type the class to check.
     * @param instance the class instance to check.
     * @param fieldName the class field name to check.
     *
     * @return true if the class's field can be access, false otherwise.
     */
    boolean allowFieldAccess(Class<?> type, Object instance, String fieldName);

    /**
     * Checks if the given class's method can be accessed or not.
     *
     * @param type the class to check.
     * @param instance the class instance to check.
     * @param methodName the class method name to check.
     *
     * @return true if the class's method can be access, false otherwise.
     */
    boolean allowMethodAccess(Class<?> type, Object instance, String methodName);

    /**
     * Checks if the given class's static field can be accessed or not.
     *
     * @param type the class to check.
     * @param fieldName the class static field name to check.
     *
     * @return true if the class's static field can be access, false otherwise.
     */
    boolean allowStaticFieldAccess(Class<?> type, String fieldName);

    /**
     * Checks if the given class's static method can be accessed or not.
     *
     * @param type the class to check.
     * @param methodName the class static method name to check.
     *
     * @return true if the class's static method can be access, false otherwise.
     */
    boolean allowStaticMethodAccess(Class<?> type, String methodName);
}
