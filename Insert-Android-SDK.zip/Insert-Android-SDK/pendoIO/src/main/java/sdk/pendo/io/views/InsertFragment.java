package sdk.pendo.io.views;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.exceptions.DynamicViewException;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.reactive.RxFragment;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;
import sdk.pendo.io.views.custom.InsertIoRatingBar;
import sdk.pendo.io.views.inserts.VisualInsertLayout;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandFormAction.UPDATE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPageAction.VALIDATE;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_INVALID;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_VALID;
import static sdk.pendo.io.actions.InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerPageEventType.ON_APPEAR;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerPageEventType.ON_DISAPPEAR;
import static sdk.pendo.io.constants.Constants.DynamicViewsConsts.NAME;
import static sdk.pendo.io.constants.Constants.DynamicViewsConsts.VALUE;
import static sdk.pendo.io.constants.Constants.ViewAttrsConsts.ID;

/**
 * Fragment that holds the Pendo view.
 * <p/>
 * Created by assaf on 3/7/16.
 */
public final class InsertFragment extends RxFragment {

    private static final String SCREEN_KEY = "SCREEN";
    private static final String SCREEN_TAG_KEY = "SCREEN_TAG";
    private static final String RETAIN_VIEWS_KEY = "retain_views";
    private static final String MANDATORY_FIELDS_KEY = "mandatory_fields";
    private static final String VALID_MANDATORY_FIELDS_KEY = "VALID_MANDATORY_FIELDS";
    private static final String INSERT_ID_KEY = "INSERT_ID";

    private HashSet<String> mValidMandatoryFields = new HashSet<>();
    private Disposable mSubscription;

    public static InsertFragment newInstance(JsonObject screenContent, String insertId) {

        InsertFragment fragment = new InsertFragment();

        JsonArray jArray = screenContent
                .getAsJsonArray(InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);

        Bundle args = new Bundle();
        args.putString(INSERT_ID_KEY, insertId);

        final JsonArray actions = JsonUtils.optJsonArray(
                screenContent, InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);

        if (actions != null) {
            args.putString(InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME, Pendo.GSON.toJson(actions));
        }

        if (jArray != null) {
            for (int i = 0; i < jArray.size(); i++) {

                final JsonObject jsonObject = jArray.get(i).getAsJsonObject();

                if (ID.equals(JsonUtils.optString(jsonObject, NAME))) {
                    final String screenTag = JsonUtils.optString(jsonObject, VALUE);
                    args.putString(SCREEN_TAG_KEY, screenTag);

                } else if (RETAIN_VIEWS_KEY.equals(JsonUtils.optString(jsonObject, NAME))) {
                    // Save the ids of all the views we need to retain.
                    final String retainViews = JsonUtils.optString(jsonObject, VALUE);
                    try {
                        JSONArray retainList = new JSONArray(retainViews);
                        ArrayList<String> retain = new ArrayList<>();

                        for (int r = 0; r < retainList.length(); r++) {
                            try {
                                retain.add(retainList.getString(r));
                            } catch (JSONException e) {
                                InsertLogger.w(e, e.getMessage());
                            }
                        }
                        args.putStringArrayList(RETAIN_VIEWS_KEY, retain);
                    } catch (JSONException e) {
                        InsertLogger.d(e.getMessage());
                    }
                } else if (MANDATORY_FIELDS_KEY.equals(JsonUtils.optString(jsonObject, NAME))) {
                    // Save the ids of all the mandatory views.
                    final String mandatoryFields = JsonUtils.optString(jsonObject, VALUE);
                    try {
                        JSONArray mandatoryFieldList = new JSONArray(mandatoryFields);
                        ArrayList<String> mandatory = new ArrayList<>();

                        for (int r = 0; r < mandatoryFieldList.length(); r++) {
                            try {
                                mandatory.add(mandatoryFieldList.getString(r));
                            } catch (JSONException e) {
                                InsertLogger.w(e, e.getMessage());
                            }
                        }
                        args.putStringArrayList(MANDATORY_FIELDS_KEY, mandatory);
                    } catch (JSONException e) {
                        InsertLogger.d(e.getMessage());
                    }
                }
            }
        }
        args.putString(SCREEN_KEY, screenContent.toString());
        fragment.setArguments(args);

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        final VisualInsertLayout visualInsertLayout = new VisualInsertLayout(getActivity(), true);

        final Bundle arguments = getArguments();

        if (arguments != null) {
            final JSONObject screenContent = getScreenContent();

            if (screenContent == null) {
                InsertLogger.e("Screen content is null!");
                return null;
            }

            final JsonElement screen = new JsonParser().parse(screenContent.toString());
            try {

                subscribeToInsertCommands();

                visualInsertLayout.inflateView(
                        screen.getAsJsonObject(),
                        (ViewGroup) ApplicationObservers.getInstance().getCurrentActivityRootView(),
                        getInsertId(),
                        getInsertId(),
                        VisualInsert.VisualInsertType.FULL_SCREEN);
            } catch (DynamicViewException e) {
                InsertLogger.e(e, "Pendo id: '" + getInsertId() + "'.");
            }
        }

        return visualInsertLayout;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (savedInstanceState != null) {
            final ArrayList<String> validMandatoryFields = savedInstanceState
                    .getStringArrayList(VALID_MANDATORY_FIELDS_KEY);

            if (validMandatoryFields != null) {
                mValidMandatoryFields.clear();
                mValidMandatoryFields.addAll(validMandatoryFields);
                InsertLogger.d("Valid fields restored (size = " + mValidMandatoryFields.size() + ").");
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mSubscription == null || mSubscription.isDisposed()) {
            subscribeToInsertCommands();
        }
    }

    private synchronized void subscribeToInsertCommands() {

        if (mSubscription != null && !mSubscription.isDisposed()) {
            return;
        }

        LinkedList<InsertCommandAction> actions = new LinkedList<>();
        actions.add(VALIDATE);
        actions.add(UPDATE);

        LinkedList<InsertCommandEventType> events = new LinkedList<>();
        events.add(INSERT_COMMAND_EVENT_TYPE_ANY);

        mSubscription = InsertCommandsEventBus.getInstance()
                .subscribe(
                        this.<InsertCommand>bindToLifecycle(),
                        InsertCommand.createFilter(InsertCommand.COMMAND_STRING_ANY,
                                                   getFragmentId(),
                                                   actions,
                                                   events),
                        new Consumer<InsertCommand>() {
                            @Override
                            public void accept(InsertCommand insertCommand) {
                                InsertLogger.d(insertCommand.toString());

                                boolean validate = VALIDATE.equals(insertCommand.getAction());
                                if (UPDATE.equals(insertCommand.getAction())) {
                                    String elementId = insertCommand.getSourceId();
                                    boolean valid = false;

                                    final List<InsertCommandsEventBus.Parameter> parameters =
                                            insertCommand.getParameters();

                                    if (parameters != null) {
                                        try {
                                            valid = InsertCommandsEventBus.Parameter
                                                    .getParameterValue(
                                                            parameters,
                                                            "valid",
                                                            Boolean.TYPE);
                                        } catch (NoSuchFieldException e) {
                                            InsertLogger.d(e.getMessage());
                                            valid = insertCommand.getEventType() == ON_VALID;
                                        }
                                    }

                                    if (valid) {
                                        mValidMandatoryFields.add(elementId);
                                    } else {
                                        mValidMandatoryFields.remove(elementId);
                                    }

                                    validate = true;
                                }

                                if (validate) {
                                    final List<String> mandatory = getMandatoryViews();
                                    boolean valid = false;

                                    if ((mandatory == null)
                                            || mValidMandatoryFields.containsAll(mandatory)) {
                                        valid = true;
                                    }

                                    final List<InsertCommand> commands =
                                            getCommands(getArguments());

                                    if (commands != null) {
                                        InsertCommandDispatcher.getInstance()
                                                .dispatchCommands(
                                                        commands,
                                                        valid ? ON_VALID : ON_INVALID,
                                                        true);
                                    }
                                }
                            }
                        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        outState.putStringArrayList(VALID_MANDATORY_FIELDS_KEY,
                                    new ArrayList<>(mValidMandatoryFields));
        final List<String> retainViews = getRetainViews();
        saveViewState(outState, retainViews);
    }

    @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        restoreViewState(savedInstanceState);
        super.onViewStateRestored(savedInstanceState);
    }

    private void saveViewState(Bundle outState, List<String> retainViews) {

        if (retainViews == null || retainViews.isEmpty()) {
            InsertLogger.d("No views to retain.");
            return;
        }

        final View view = getView();

        if (view == null) {
            InsertLogger.d("Failed to save state, no view.");
            return;
        }

        for (String retainView : retainViews) {
            ArrayList<View> outViews = new ArrayList<>();
            view.findViewsWithText(outViews,
                                   retainView,
                                   View.FIND_VIEWS_WITH_CONTENT_DESCRIPTION);

            if (!outViews.isEmpty()) {
                final View outView = outViews.get(0);

                if (outView instanceof EditText) {
                    outState.putString(retainView, ((EditText) outView).getText().toString());

                } else if (outView instanceof RadioGroup) {
                    final RadioGroup radioGroup = (RadioGroup) outView;
                    final int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                    final View checkedRadioButton = radioGroup
                            .findViewById(checkedRadioButtonId);

                    if (checkedRadioButton == null) {
                        InsertLogger.d("Null RadioButton, id = '" + checkedRadioButtonId + "'.");
                        continue;
                    }

                    final CharSequence contentDescription =
                            checkedRadioButton.getContentDescription();
                    outState.putCharSequence(retainView, contentDescription);

                } else if (outView instanceof InsertIoRatingBar) {
                    final InsertIoRatingBar ratingBar = (InsertIoRatingBar) outView;
                    final int rating = ratingBar.getRating();

                    if (rating > 0) {
                        outState.putInt(retainView, rating);
                    }

                } else {
                    InsertLogger.d("Not saving, view is: '" + outView.getClass().getName() + "'.");
                }
            }
        }
    }

    private void restoreViewState(Bundle savedInstanceState) {

        if (savedInstanceState == null || savedInstanceState.isEmpty()) {
            return;
        }

        final View view = getView();

        if (view == null) {
            InsertLogger.d("Failed to restore state, view is null.");
            return;
        }

        for (String contentDesc : savedInstanceState.keySet()) {
            ArrayList<View> outViews = new ArrayList<>();
            view.findViewsWithText(outViews,
                                   contentDesc,
                                   View.FIND_VIEWS_WITH_CONTENT_DESCRIPTION);

            if (!outViews.isEmpty()) {
                final View outView = outViews.get(0);

                if (outView instanceof EditText) {
                    final EditText edittext = ((EditText) outView);
                    edittext.setText(savedInstanceState.getString(contentDesc));
                    InsertContentDescriptionManager.getInstance().setContentDescription(edittext,
                            savedInstanceState.getString(contentDesc), null);

                } else if (outView instanceof RadioGroup) {
                    final CharSequence radioButtonConDesc =
                            savedInstanceState.getCharSequence(contentDesc);

                    if (radioButtonConDesc == null) {
                        continue;
                    }

                    final RadioGroup radioGroup = (RadioGroup) outView;
                    for (int i = 0; i < radioGroup.getChildCount(); i++) {
                        final RadioButton radioButton =
                                (RadioButton) radioGroup.getChildAt(i);
                        if (radioButtonConDesc
                                .equals(radioButton.getContentDescription())) {
                            radioButton.toggle();
                            break;
                        }
                    }

                } else if (outView instanceof InsertIoRatingBar) {
                    final InsertIoRatingBar ratingBar = (InsertIoRatingBar) outView;

                    final int rating = savedInstanceState.getInt(contentDesc, -1);

                    if (rating > 0) {
                        ratingBar.setRating(rating);
                    }

                } else {
                    InsertLogger.d("Not restoring, view is: '" + outView.getClass().getName() + "'.");
                }
            }
        }
    }

    @Nullable
    public String getFragmentId() {
        return getArguments().getString(SCREEN_TAG_KEY);
    }

    @Nullable
    private JSONObject getScreenContent() {
        try {
            return new JSONObject(getArguments().getString(SCREEN_KEY));
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

        return null;
    }

    public void onAppear() {
        InsertLogger.d("Appearing.");
        final List<InsertCommand> commands = getCommands(getArguments());

        if (commands != null) {
            InsertCommandDispatcher.getInstance()
                    .dispatchCommands(commands, ON_APPEAR, true);
        }
    }

    public void onDisappear() {
        InsertLogger.d("Disappearing.");
        final List<InsertCommand> commands = getCommands(getArguments());

        if (commands != null) {
            InsertCommandDispatcher.getInstance()
                    .dispatchCommands(commands, ON_DISAPPEAR, true);
        }
    }

    @Nullable
    private List<InsertCommand> getCommands(Bundle arguments) {
        final String actions = arguments.getString(InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);

        if (actions == null) {
            return null;
        }

        try {
            JsonParser parser = new JsonParser();
            JsonArray actionsJson = parser.parse(actions).getAsJsonArray();
            final JavascriptRunner.InsertContext insertContext =
                    new JavascriptRunner.InsertContext(getInsertId());
            return InsertCommand.getInsertCommandsWithParameters(actionsJson,
                    InsertInfoConsts.createInsertMetadataParams(getInsertId()),
                                                                 insertContext);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    private List<String> getRetainViews() {
        return getArguments().getStringArrayList(RETAIN_VIEWS_KEY);
    }

    private List<String> getMandatoryViews() {
        return getArguments().getStringArrayList(MANDATORY_FIELDS_KEY);
    }

    private String getInsertId() {
        return getArguments().getString(INSERT_ID_KEY);
    }
}
