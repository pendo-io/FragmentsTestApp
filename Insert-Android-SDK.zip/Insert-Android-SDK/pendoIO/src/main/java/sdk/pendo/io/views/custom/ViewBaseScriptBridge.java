package sdk.pendo.io.views.custom;

import org.json.JSONObject;

/**
 * Pendo's base bridge for views that can be accessed from scripts.
 *
 * Created by assaf on 11/8/16.
 */
@SuppressWarnings({"UnnecessaryInterfaceModifier", "CheckStyle", "unused"})
public interface ViewBaseScriptBridge {

    public ViewBaseScriptBridge getViewScriptBridge();

    public String getType();

    public interface FormScriptBridge extends ViewBaseScriptBridge {
        public JSONObject getAnswers();
    }

    public interface PagerScriptBridge extends ViewBaseScriptBridge {
        public Integer getPageNumber();
    }

    public static class ViewBaseScriptBridgeUtils {
        public static String getType(ViewBaseScriptBridge viewBaseScriptBridge) {
            if (viewBaseScriptBridge instanceof FormScriptBridge) {
                return "Form";
            } else if (viewBaseScriptBridge instanceof PagerScriptBridge) {
                return "Pager";
            } else {
                return "UNKNOWN";
            }
        }
    }
}
