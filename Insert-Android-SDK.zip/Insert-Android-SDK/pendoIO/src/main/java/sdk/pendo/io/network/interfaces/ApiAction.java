package sdk.pendo.io.network.interfaces;

import io.reactivex.Scheduler;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Represents an API action against the backend. this action is executed in a
 * rx worker which is being unsubscribed after the action is finished
 * Created by nirsegev on 24/07/2016.
 */

public abstract class ApiAction implements Runnable {
    private Scheduler.Worker mWorker;

    /**
     * Set a scheduler worker to execute the API action
     * @param worker the rx worker which should execute the action
     */
    public void setWorker(Scheduler.Worker worker) {
        mWorker = worker;
    }

    @Override
    public void run() {
        try {
            execute();
        }
        catch (Exception e){
            InsertLogger.d(e, e.getMessage());
        }
        finally {
            if (mWorker != null && !mWorker.isDisposed()) {
                mWorker.dispose();
            }
        }
    }

    protected abstract void execute();

}
