package sdk.pendo.io.events;

import android.app.Activity;

import org.apache.commons.lang3.tuple.Pair;

import io.reactivex.Observable;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.utilities.Optional;

import static sdk.pendo.io.activities.PendoGateActivity.PENDO_GATE_ACTIVITY;
import static sdk.pendo.io.activities.PendoGateActivity.TRIGGER_ID_KEY;
import static sdk.pendo.io.activities.PendoGateActivity.INSERT_ID_KEY;

/**
 * This class manages direct link events. Direct link events are triggered by Trigger ID.
 * We keep an observable that keeps the current direct link Trigger ID and we update
 * this observable whenever necessary.
 *
 * Created by itayvallach on 14/07/2016.
 */
public class DirectLinkEventManager {

    private static volatile DirectLinkEventManager INSTANCE;
    private final BehaviorSubject<Optional<Pair<Integer, String>>> mDirectLinkDataObservable = BehaviorSubject.create();

    private DirectLinkEventManager() {}

    public static synchronized DirectLinkEventManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new DirectLinkEventManager();
        }

        return INSTANCE;
    }

    public void updateDirectLinkIfNeeded(Activity activity) {
        if (shouldUpdateDirectLinkData(activity)) {
            String insertIdKey = activity.getIntent().getStringExtra(INSERT_ID_KEY);
            if (insertIdKey == null) {
                insertIdKey = "";
            }
            updateDirectLinkData(Pair.of(
                    activity.getIntent().getIntExtra(TRIGGER_ID_KEY, 0),
                    insertIdKey));

            activity.getIntent().removeExtra(TRIGGER_ID_KEY);
            activity.getIntent().removeExtra(INSERT_ID_KEY);
        }
    }

    public boolean shouldUpdateDirectLinkData(Activity activity) {
        return (!mDirectLinkDataObservable.hasValue() ||
                mDirectLinkDataObservable.getValue().getValue() == null ||
                mDirectLinkDataObservable.getValue().getValue().getLeft() == 0)
                && !(activity.getClass().getSimpleName().equals(PENDO_GATE_ACTIVITY));
    }

    public void updateDirectLinkData(Pair<Integer,String> directLinkData) {
        mDirectLinkDataObservable.onNext(new Optional<Pair<Integer, String>>(directLinkData));
    }

    public void removeLastDirectLinkData() {
        mDirectLinkDataObservable.onNext(new Optional<Pair<Integer, String>>(null));
    }

    public Observable<Optional<Pair<Integer,String>>> getDirectLinkDataAsObservable() {
        return mDirectLinkDataObservable;
    }
    public Pair<Integer,String> getDirectLinkData() {
        return mDirectLinkDataObservable.hasValue() ?
                mDirectLinkDataObservable.getValue().getValue() : null;
    }



}
