package sdk.pendo.io.network.responses;

import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.events.IdentificationData;

/**
 * Created by assaf on 5/13/15.
 */
public final class ElementConfigurationModel {

    @SerializedName(IdentificationData.SERIALIZED_NAME)
    private IdentificationData mIdentificationData;

    public IdentificationData getIdentificationData() {
        return mIdentificationData;
    }

    /**
     * Copy constructor for this class to support cloning.
     *
     * @param elementConfigurationModel the {@link ElementConfigurationModel} to clone.
     *
     * @return a cloned copy of the given {@link ElementConfigurationModel}.
     */
    public static ElementConfigurationModel copyElementConfigurationModel(
            ElementConfigurationModel elementConfigurationModel) {
        ElementConfigurationModel copiedECM = new ElementConfigurationModel();

        copiedECM.mIdentificationData =
                IdentificationData.copyIdentificationData(
                        elementConfigurationModel.mIdentificationData);

        return copiedECM;
    }
}
