package sdk.pendo.io.network;

import android.support.annotation.Nullable;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by tomerlevinson on 4/11/16.
 */
public final class InsertRPC {

    public enum InsertRPCEnum {
        GET_PUSH_ID("getPushId"),
        GET_ADVERTISER_ID("getAdvertiserId"),
        EVALUATE("evaluate"),
        WAIT_FOR_KEY("waitForKey");

        private final String rpcFunction;

        private static final Map<String, InsertRPCEnum> LOOKUP_TABLE = new HashMap<>();

        static {
            for (InsertRPCEnum s : EnumSet.allOf(InsertRPCEnum.class)) {
                LOOKUP_TABLE.put(s.rpcFunction, s);
            }
        }

        InsertRPCEnum(String rpcFunction) {
            this.rpcFunction = rpcFunction;
        }

        public String getRpcFunction() {
            return rpcFunction;
        }

        public boolean equals(InsertRPCEnum rpcFunction) {
            return this.rpcFunction.equals(rpcFunction.rpcFunction);
        }

        @Nullable
        public static InsertRPCEnum get(String rpcFunction) {
            return LOOKUP_TABLE.get(rpcFunction);
        }
    }

    private InsertRPC() {
    }
}
