package sdk.pendo.io.sdk.manager

import io.reactivex.disposables.Disposable
import org.json.JSONObject
import sdk.pendo.io.analytics.AnalyticsProperties
import sdk.pendo.io.analytics.AnalyticsProperties.ACTIVE_TIME
import sdk.pendo.io.analytics.AnalyticsProperties.DISPLAY_DURATION
import sdk.pendo.io.analytics.InsertAnalytics
import sdk.pendo.io.events.IdentificationData
import sdk.pendo.io.events.RAScreenDisplayDurationManager
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.network.killswitch.KillSwitchManager
import sdk.pendo.io.utilities.*

/**
 * This Singleton manages the retroactive ScreenView, ScreenLeft, and Click events.
 * Every time an Activity starts or a button is clicked this class analyzes the
 * event and sends appropriate analytics.
 */

object AnalyticsManager {

    const val SCREEN_LEFT = "RAScreenLeft"
    const val SCREEN_VIEW = "RAScreenView"
    const val CLICK = "RAClick"

    private var currentScreenData: JSONObject? = null
    private var currentScreenId: String = ""
    private val screenChangedSubscription: Disposable

    init {

        // This will notify on *future* screen changes only!
        screenChangedSubscription = ScreenManager.screenChangedSubject.subscribe {
            handleScreenViewEvent(ScreenManager.currentScreenData, ScreenManager.currentScreenId)
        }

        // Handle initial state (current screen)
        if (ScreenManager.currentScreenId.isNotEmpty()) {
            handleScreenViewEvent(ScreenManager.currentScreenData, ScreenManager.currentScreenId)
        }
    }

    // TODO?
    fun start() {}

    /**
     * Generates and sends ScreenView event for the current screen.
     *
     * @param screenData the RA screen data of the new screen
     * @param screenId the RA screen ID of the new screen
     */
    @Synchronized
    private fun handleScreenViewEvent(screenData: JSONObject?, screenId: String) {

        if (KillSwitchManager.isKillSwitchOn()) { return }

        // Same screen?
        if (currentScreenId == screenId) { return }

        InsertLogger.d("New screen identified! ScreenId: '$screenId', Current (old) screenId: '$currentScreenId')")

        // Old screen? Send SCREEN_LEFT
        if (currentScreenData != null) {
            val event = generateAnalyticsEventJSON(currentScreenData!!, currentScreenId, SCREEN_LEFT)
            InsertAnalytics.getInstance().analyticsPublisher.onNext(event)
        }

        // Update current
        currentScreenData = screenData
        currentScreenId = screenId
        RAScreenDisplayDurationManager.beginCountingScreenDisplayDuration(screenId)

        // New screen? Send SCREEN_VIEW
        if (currentScreenData != null) {
            val event = generateAnalyticsEventJSON(currentScreenData!!, currentScreenId, SCREEN_VIEW)
            InsertAnalytics.getInstance().analyticsPublisher.onNext(event)
        }

    }

    /**
     * Generates and sends a Click event.
     *
     * @param viewElementInfo the RA element info of the view that was clicked.
     */
    @Synchronized
    fun handleClickEvent(viewElementInfo: JSONObject) {

        if (KillSwitchManager.isKillSwitchOn()) { return }

        if (currentScreenData == null) {
            //TODO: send error!
            return
        }

        val event = generateAnalyticsEventJSON(currentScreenData!!, currentScreenId, CLICK)
        // Get the RA data object and inject elementInfoRA into it:
        val retroEventData = event.getJSONObject(AnalyticsProperties.RETROACTIVE_EVENT_DATA)
        retroEventData.put(IdentificationData.RETROACTIVE_ELEMENT_INFO, viewElementInfo)
        // Put the updated RA data object back into the event object
        event.put(AnalyticsProperties.RETROACTIVE_EVENT_DATA, retroEventData)
        // Send event
        InsertAnalytics.getInstance().analyticsPublisher.onNext(event)
    }

    private fun populateJSONWithCommonData(json: JSONObject, event: String): JSONObject {
        json
                .put(AnalyticsProperties.EVENT, event)
                .put(AnalyticsProperties.ACTION_TYPE, event)
                .put(AnalyticsProperties.ORIENTATION, DeviceStateUtils.getDeviceOrientation())
                .put(AnalyticsProperties.TIMESTAMP, System.currentTimeMillis())
                .put(AnalyticsProperties.RETROACTIVE_EVENT_APP_VERSION, AndroidUtils.getAppVersionName())

        return json
    }

    /**
     * Takes an event type and its id, and generates a proper analytics json to send to the BE.
     *
     * @param event the event type (ScreenView, ScreenLeft, Click...).
     *
     * @return a JSON representing the analytic event.
     */
    @Synchronized
    private fun generateAnalyticsEventJSON(screenData: JSONObject, screenId: String, event: String): JSONObject {

        val dataJSON = JSONObject().put(AnalyticsProperties.RETROACTIVE_SCREEN_DATA, screenData)
        val json = populateJSONWithCommonData(JSONObject(), event)
                .put(AnalyticsProperties.RETROACTIVE_EVENT_ID, screenId)
                .put(AnalyticsProperties.RETROACTIVE_EVENT_DATA, dataJSON)

        if (event == SCREEN_LEFT) {
            json
                    .put(DISPLAY_DURATION, RAScreenDisplayDurationManager.getScreenDisplayDuration())
                    .put(ACTIVE_TIME, RAScreenDisplayDurationManager.getScreenActiveTime())
        }

        return json
    }





}
