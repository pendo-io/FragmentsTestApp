package sdk.pendo.io.reactive

import io.reactivex.functions.Consumer
import sdk.pendo.io.reactive.observers.InsertObserver.shouldReportException
import sdk.pendo.io.utilities.AnalyticsUtils


class InsertOnErrorHandler : Consumer<Throwable> {

    override fun accept(t: Throwable) {
        if (shouldReportException(t)) {
            AnalyticsUtils.sendExceptionReport(t)
        }
    }
}
