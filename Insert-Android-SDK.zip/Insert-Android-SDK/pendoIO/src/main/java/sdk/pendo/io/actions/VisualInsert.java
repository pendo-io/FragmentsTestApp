package sdk.pendo.io.actions;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.gson.JsonElement;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.StatsSnapshot;
import com.trello.rxlifecycle3.android.ActivityEvent;
import org.json.JSONObject;
import java.util.concurrent.TimeUnit;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.PublishSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertCommandEventType.SdkEventType;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.exceptions.DynamicViewException;
import sdk.pendo.io.listeners.ActivityLifecycleEventsObserver;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.listeners.ImageDownloadListener;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideConfigurationModel;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.PersistenceUtils;
import sdk.pendo.io.utilities.ViewHierarchyUtility;
import sdk.pendo.io.views.InsertViewHolder;
import sdk.pendo.io.views.inserts.VisualInsertLayout;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.DISMISS_INSERT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.constants.Constants.GeneralConsts.IRRELEVANT;
import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_BACKGROUND;
import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_FOREGROUND;

/**
 * Pendo's visual action class.
 * <p>
 * Created by assaf on 5/12/15.
 */
public class VisualInsert extends VisualInsertBase {

    private boolean mHasTimeout = false;
    private static final int DISPLY_DURATION_PERSISTENCE_INTERVAL_IN_MILLIS = 2000;

    private static ImageDownloadListener sPicassoListener = new ImageDownloadListener();
    private static Picasso sPicasso = new Picasso.Builder(Pendo.getApplicationContext())
            .listener(sPicassoListener)
            .loggingEnabled(true)
            .downloader(new OkHttp3Downloader(Pendo.getApplicationContext()))
            .build();

    private VisualInsertLayout mVisualView;

    private long mStartDurationInterval;
    private boolean mIsInsertActivity;

    private ViewGroup mRootView;
    private ViewGroup mContainer;
    private InsertViewHolder mInsertViewHolder;
    private Disposable mLifecycleResumeSubscription;
    private Disposable mInsertDismissedWithAppFlowChangesSubscription;

    // Manages the time the insert was displayed to the user.
    private Consumer<ApplicationFlowManager.AppFlowState> mAppFlowListener =
            new Consumer<ApplicationFlowManager.AppFlowState>() {

                @Override
                public void accept(ApplicationFlowManager.AppFlowState appFlowState) {

                    if (IN_BACKGROUND.equals(appFlowState)) {
                        mAccumulativeTime = getDuration();
                        if (mHasTimeout) {
                            cancelTimeout(false);

                            // Recalculate timeout.
                            mTimeCounter = Math.max(
                                    mOriginalTimeCounter - mAccumulativeTime,
                                    1);
                        }
                    } else if (IN_FOREGROUND.equals(appFlowState)) {
                        setStartDuration(System.currentTimeMillis());

                        if (mHasTimeout) {
                            startTimeout();
                        }
                    }
                }
            };

    private Disposable mAppFlowSubscription;
    private Disposable mDisplayDurationPersist;

    private final PublishSubject mStopTimeoutSubject = PublishSubject.create();

    private long mOriginalTimeCounter;
    private long mTimeCounter;

    public VisualInsert(StepGuideModel previewOnDeviceDetails, VisualInsertLifecycleListener listener) {
        super(previewOnDeviceDetails, listener);
        mListener = listener;
        mVisualInsertType = VisualInsertType.FULL_SCREEN;
    }

    public VisualInsert(GuideModel guideModel, VisualInsertLifecycleListener listener) {
        super(guideModel, listener);
        mListener = listener;
        mVisualInsertType = VisualInsertType.FULL_SCREEN;
    }


    @Override
    void insertTypeDependentCommandHandle(final InsertCommand insertCommand) {
        if (mActivity != null && !mActivity.isFinishing()) {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (DISMISS_VISIBLE_INSERTS.equals(insertCommand.getSourceId())) {
                        // In case it is a dismiss all action, we try to remove the
                        // visible inserts asap with no animation. fixes issue: IDEV-5116
                        hideWithNoAnimation();
                    } else {
                        hideWithAnimation();
                    }
                }
            });
        }
    }

    private Observable timedOut() {
        return mStopTimeoutSubject;
    }

    public static synchronized Picasso picasso() {
        return sPicasso;
    }

    public static StatsSnapshot getPicassoStats() {
        return sPicasso.getSnapshot();
    }

    @SuppressLint("RestrictedApi")
    public final void init(Activity activity,
                           GenericInsertAnalyticsData iga,
                           String activatedBy)
            throws DynamicViewException {
        super.init(activatedBy, iga);
        Integer currentStepIndex = StepSeenManager.getInstance().getCurrentStepIndex();
        mListener.onCreate(this);
        mActivatedBy = activatedBy;
        //FIXME: Support more than one step
        if (getSteps() == null || getSteps().get(currentStepIndex) == null || !getSteps().get(currentStepIndex).isJsonObject()) {
            InsertLogger.w("Cannot inflate the main screen.");
            return;
        }
        final JsonElement jsonScreen = getSteps().get(currentStepIndex);

        setTracker(InsertAnalytics.newTracker(iga));

        if (activity == null) {
            mActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
            mIsInsertActivity = false;
        } else {
            mActivity = activity;
            mIsInsertActivity = true;
        }

        View rootView = ViewHierarchyUtility.INSTANCE.getCurrentRootView(mActivity);

        // Set not important recursively for accessibility for non-activity visual inserts.
        if (!mIsInsertActivity) {
            InsertContentDescriptionManager.getInstance()
                    .setNotImportantForAccessibilityRecursively(rootView);
        }

        if (rootView == null || !(rootView instanceof ViewGroup)) {
            // TODO: 2/1/16 we can fallback to activity here.
            InsertLogger.w("Cannot show insert without ViewGroup. Pendo ID: " + getGuideId() +
                    "  rootView = " + (rootView == null ? "null" : rootView.getClass().getCanonicalName()));
            return;
        }

        if (VisualInsertType.BANNER.equals(mVisualInsertType)) {
            final View contentView = rootView.findViewById(android.R.id.content);

            if (contentView != null) {
                rootView = contentView;
            }
        }

        setRootView((ViewGroup) rootView);

        StepGuideModel stepGuideModel = getGuideStepModel(currentStepIndex);
        long guideTimeout = 0;
        if (stepGuideModel != null) {
            GuideConfigurationModel guideConfigurationModel = stepGuideModel.getConfiguration();
            if (guideConfigurationModel != null) {
                guideTimeout = guideConfigurationModel.getTimeoutMs();
            }
        }
        mOriginalTimeCounter = guideTimeout;
        mTimeCounter = mOriginalTimeCounter;
        mHasTimeout = mOriginalTimeCounter > 0;

        LayoutInflater inflater =
                LayoutInflater.from(mActivity);

        mContainer = (ViewGroup) inflater.inflate(
                mVisualInsertType.getLayoutId(),
                (ViewGroup) rootView,
                false);

        mVisualView = (VisualInsertLayout) mContainer
                .findViewById(R.id.insert_visual_container);

        final View view = mVisualView.inflateView(jsonScreen.getAsJsonObject(),
                (ViewGroup) rootView,
                getGuideId(),
                StepSeenManager.getInstance().getCurrentStepId(),
                mVisualInsertType);
        setViewHolder(view);

        String currentFragment = AndroidUtils.getCurrentVisibleFragmentName(mActivity);
        mLifecycleResumeSubscription = ActivityLifecycleEventsObserver.getInstance()
                .subscribeAnyButActivityLifeEventObserverOrFragmentChange(
                        mActivity,
                        ActivityEvent.RESUME,
                        currentFragment,
                        new Consumer<ActivityEvent>() {
                            @Override
                            public void accept(ActivityEvent lifecycleEvent) {
                                if (InsertsManager.getInstance().wasInsertFullyDisplayedAfterAnimation(getGuideId())) {
                                    InsertsManager.getInstance().removeInsertFullyDisplayedAfterAnimation(getGuideId());
                                }
                            }
                        });
    }

    @Override
    final void startTimeout() {
        if (mHasTimeout) {

            // Setting the insert timeout in milli.
            Observable
                    .timer(mTimeCounter, TimeUnit.MILLISECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .takeUntil(timedOut())
                    .filter(new Predicate<Long>() {
                        @Override
                        public boolean test(Long aLong) {
                            return isShowing();
                        }
                    })
                    .subscribe(InsertObserver.create(new Consumer<Long>() {
                        @Override
                        public void accept(Long aLong) {
                            InsertLogger.d("Times up! Time: "
                                    + TimeUnit.MILLISECONDS.toSeconds(mTimeCounter));
                            InsertCommandsEventBus.getInstance().send(
                                    new InsertCommand.Builder(DISMISS_INSERT, SdkEventType.TIME_OUT)
                                            .setDestinationId(INSERT_COMMAND_VISUAL_INSERT_DEST)
                                            .setParameters(InsertInfoConsts.createInsertMetadataParams(getGuideId()))
                                            .build());
                        }
                    }));

        }
    }

    @Override
    public final void cancelTimeout(boolean forceCancelTimeoutEntirely) {
        try {
            mStopTimeoutSubject.onNext(IRRELEVANT);
            if (forceCancelTimeoutEntirely) {
                // In case we would like to cancel the timeout entirely
                // we need to reset the has timeout flag so going to background and then to front
                // won't restart the timeout
                mHasTimeout = false;
            }
        } catch (Exception ignore) {
        }
    }

    @Override
    public final boolean show() {

        InsertLogger.d("Showing.");
        try {
            setStartDuration(System.currentTimeMillis());
            int currentStepIndex = StepSeenManager.getInstance().getCurrentStepIndex();
            StepGuideModel stepGuideModel = getGuideStepModel(currentStepIndex);
            if (stepGuideModel != null) {
                mVisualAnimationManager = new VisualAnimationManager(getGuideId(), stepGuideModel.getConfiguration());
                showWithAnimation();
                unsubscribeAppFlowListener();
                mAppFlowSubscription = ApplicationFlowManager
                        .getInstance().getAppFlowChanges().subscribe(mAppFlowListener);

                persistDisplayDurationByInterval(DISPLY_DURATION_PERSISTENCE_INTERVAL_IN_MILLIS);
                persistDisplayDurationByTimeIntervals();
            }
        } catch (Exception e) {
            InsertLogger.e("Tracker will be now set to null due to " + e.getMessage());
            onDestroy();
            InsertLogger.e(e, e.getMessage());
            return false;
        }
        return true;
    }

    private void persistDisplayDurationByInterval(int intervalInMillis) {
        mDisplayDurationPersist = Observable
                .interval(intervalInMillis, TimeUnit.MILLISECONDS)
                .subscribeWith(InsertObserver.create(new Consumer<Long>() {
                    @Override
                    public void accept(Long redundant) {
                        PersistenceUtils.persistInsertDisplayDuration(getGuideId(), getDuration());
                    }
                }));
    }

    /**
     * Get the last time interval in which the insert was shown.
     *
     * @return time interval.
     */
    private long getLastIntervalDuration() {
        return System.currentTimeMillis() - mStartDurationInterval;
    }

    /**
     * Persist the intervalled displayed duration by the new convention of:
     * {startTime, duration}
     */
    private void persistDisplayDurationByTimeIntervals() {
        mInsertDismissedWithAppFlowChangesSubscription = ApplicationFlowManager.getInstance().getAppFlowChanges()
                .subscribeWith(InsertObserver.create(new Consumer<ApplicationFlowManager.AppFlowState>() {
                    @Override
                    public void accept(
                            ApplicationFlowManager.AppFlowState appFlowState) {
                        if (appFlowState.equals(IN_BACKGROUND)) {
                            if (mStartDurationInterval > 0) {
                                PersistenceUtils.persistInsertDisplayedIntervalledAnalytics(
                                        mStartDurationInterval, getLastIntervalDuration(), getGuideId());
                            }
                        } else if (appFlowState.equals(IN_FOREGROUND)) {
                            mStartDurationInterval = System.currentTimeMillis();
                        }
                    }
                }));
    }

    private void showWithAnimation() {
        try {
            mVisualAnimationManager.performShow(mActivity,
                    mStatusBarColorAnimation
            );


        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    void hideWithAnimation() {
        ApplicationObservers.getInstance().getActivityInsideApp()
                .filter(new Predicate<Boolean>() {
                    @Override
                    public boolean test(Boolean isInsideApp) {
                        return isInsideApp;
                    }
                })
                .firstElement().subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
            @Override
            public void accept(Boolean aBoolean) {
                mVisualAnimationManager.performHide(mStatusBarColorAnimation, true);
            }
        }));
    }

    private void hideWithNoAnimation() {
        mVisualAnimationManager.performHide(mStatusBarColorAnimation, false);
    }

    private void setViewHolder(View view) {

        if (view == null || view.getTag() == null || !(view.getTag() instanceof InsertViewHolder)) {
            InsertLogger.d("Not setting view holder.");
            return;
        }

        InsertViewHolder insertViewHolder = (InsertViewHolder) view.getTag();

        if (insertViewHolder.mainLayout == null) {
            InsertLogger.d("No main layout, not updating the view holder.");
            return;
        }
        // Set the view as important for accessibility
        InsertContentDescriptionManager.getInstance().setImportantForAccessibility(view);
        mInsertViewHolder = insertViewHolder;
    }

    @Nullable
    protected final InsertViewHolder getViewHolder() {
        return mInsertViewHolder;
    }

    @Nullable
    @Override
    protected final ViewGroup getContainer() {
        return mContainer;
    }

    @Nullable
    @Override
    final ViewGroup getRootView() {
        return mRootView;
    }

    final void setRootView(ViewGroup rootView) {
        mRootView = rootView;
    }

    @Override
    final void onDestroy() {

        try {
            InsertLogger.d("Pendo destroying.");

            if (mLifecycleResumeSubscription != null) {
                mLifecycleResumeSubscription.dispose();
                mLifecycleResumeSubscription = null;
            }

            cancelDuration();

            if (mListener != null) {
                mListener.onDestroy(getGuideId());
            }


            // Set the showing state to false.
            mShowing.set(false);

            // Free all views.
            mVisualView = null;
            mContainer = null;
            mRootView = null;
            mStatusBarColorAnimation = null;
            mInsertViewHolder = null;

            // Free activity.
            mActivity = null;

            // Free analytics.
            mAdditionalInfo = new JSONObject();
            setTracker(null);

            unsubscribeAppFlowListener();
            unsubscribeDisplayDurationPersist();
            unsubscribeIntervalledDisplayDurationPersistence();
            unsubscribeDismissAndAdvance();

            InsertsManager.removeVisualInsertInitedObservable(getGuideId());
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    private void unsubscribeAppFlowListener() {
        if (mAppFlowSubscription != null) {
            mAppFlowSubscription.dispose();
        }
    }

    private void unsubscribeDisplayDurationPersist() {
        if (mDisplayDurationPersist != null) {
            mDisplayDurationPersist.dispose();
        }
    }

    /**
     * Unsubscribe the intervalled subscription that we have.
     * This case is needed because our subscription to the app flow changes,
     * doesn't take care of the last interval, nor if any time intervals exist at all.
     */
    private void unsubscribeIntervalledDisplayDurationPersistence() {
        if (mInsertDismissedWithAppFlowChangesSubscription != null) {
            mInsertDismissedWithAppFlowChangesSubscription.dispose();
        }
    }

    /**
     * Returns the visual animation manager of this visual insert
     *
     * @return VisualAnimationManager
     */
    public VisualAnimationManager getAnimationManager() {
        return mVisualAnimationManager;
    }

    /**
     * Returns the insert container view id
     *
     * @return int representing the container view id
     */
    int getContainerId() {

        return mVisualInsertType.getContainerId();
    }


}
