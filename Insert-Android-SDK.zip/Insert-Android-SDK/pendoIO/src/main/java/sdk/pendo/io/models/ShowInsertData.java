package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

/**
 * Created by itayvallach on 26/06/2016.
 *
 * This class represents the model of the data we get in order to show an
 * Pendo (currently comes on a direct link url)
 */
public class ShowInsertData {

    @SerializedName("triggerId")
    private int mTriggerId;

    @SerializedName("insertId")
    private String mInsertId;

    public int getTriggerId() {
        return mTriggerId;
    }

    public String getInsertId() {
        return mInsertId;
    }
}
