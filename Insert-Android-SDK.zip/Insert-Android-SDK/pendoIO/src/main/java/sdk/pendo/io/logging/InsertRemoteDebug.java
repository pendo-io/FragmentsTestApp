package sdk.pendo.io.logging;

import org.json.JSONArray;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by tomerlevinson on 7/27/16.
 * This class in used in responsible of logging and device info,
 * in case we received the "settings" json, in the setup action json,
 * and inside of it we received a wanted "refreshInterval"
 * in this case, this class is in charge of saving timber logs and
 * device info.
 */
public class InsertRemoteDebug {
    private static final int DEFAULT_INTERVAL_TIME = 60;
    private static volatile InsertRemoteDebug sInstance;
    private AtomicBoolean mIsRefreshIntervalSet;
    private LinkedList<LogEntry> mRemoteDebuggingInfoDebug;
    private static final Object LOCK = new Object();
    private int mRefreshInterval;

    public static InsertRemoteDebug getInstance() {
        InsertRemoteDebug result = sInstance;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = sInstance;
                if (result == null) { // 2nd check (w/ lock)
                    sInstance = result = new InsertRemoteDebug();
                }
            }
        }
        return result;
    }

    private InsertRemoteDebug() {
        mIsRefreshIntervalSet = new AtomicBoolean(false);
        mRemoteDebuggingInfoDebug = new LinkedList<>();
        setRefreshInterval(DEFAULT_INTERVAL_TIME);
    }

    public final void clearRemoteDebugInfo() {
        mRemoteDebuggingInfoDebug.clear();
    }

    public final JSONArray getRemoteDebuggingInfoAsJSONArray() {
        JSONArray remoteDebuggingArray = new JSONArray();
        ListIterator<LogEntry> listIterator = mRemoteDebuggingInfoDebug.listIterator();
        while (listIterator.hasNext()) {
            remoteDebuggingArray.put(listIterator.next().toString());
        }
        return remoteDebuggingArray;
    }

    public final void setIsRefreshIntervalSet(boolean isRefreshIntervalSet) {
        mIsRefreshIntervalSet.getAndSet(isRefreshIntervalSet);
    }

    public final boolean getIsRefreshIntervalSet() {
        return mIsRefreshIntervalSet.get();
    }

    public final void addLogIfRemoteDebugOn(String message, String loggingLevel) {
        if (getIsRefreshIntervalSet()) {
            mRemoteDebuggingInfoDebug.add(
                    new LogEntry(System.currentTimeMillis() / 1000,
                            message,
                            loggingLevel));
        }
    }

    public final void addExceptionLogIfRemoteDebugOn(String message,
                                                     String loggingLevel,
                                                     String exceptionMessage) {
        if (getIsRefreshIntervalSet()) {
            mRemoteDebuggingInfoDebug.add(
                    new LogEntry(System.currentTimeMillis() / 1000,
                            message,
                            exceptionMessage,
                            loggingLevel));
        }
    }

    public int getRefreshInterval() {
        return mRefreshInterval;
    }

    /**
     * Setter for the refresh interval.
     *
     * @param refreshInterval in seconds
     */
    public void setRefreshInterval(int refreshInterval) {
        mRefreshInterval = refreshInterval;
    }
}
