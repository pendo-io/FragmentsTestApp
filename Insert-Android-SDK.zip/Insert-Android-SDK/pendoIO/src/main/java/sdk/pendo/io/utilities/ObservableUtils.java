package sdk.pendo.io.utilities;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Predicate;

/**
 * Created by tomerlevinson on 05/09/2017.
 * This class is meant for storing recipes for RX.
 */
public final class ObservableUtils {
    private ObservableUtils() { }

    /**
     * Used to create a pausable interval observable.
     * Can be paused by setting the pause parameter to true.
     * Can be resumed by setting the pause parameter to false.
     * @param pause - used to pause and resume the observable emissions.
     * @param initialDelay - delay in ms for start of emission.
     * @param period - after each period we will emit.
     * @param unit - time unit.
     * @param scheduler
     * @return
     */
    public static Observable<Long> createPausableInterval(final AtomicBoolean pause, final long initialDelay,
                                                          final long period, TimeUnit unit, Scheduler scheduler) {
        return Observable.interval(initialDelay, period, unit, scheduler).filter(new Predicate<Long>() {

            @Override
            public boolean test(Long tick) {
                return !pause.get();
            }

        }).scan(new BiFunction<Long, Long, Long>() {

            @Override
            public Long apply(Long acc, Long tick) {
                return acc + 1;
            }

        });
    }

    /**
     * Used to create a pausable interval observable.
     * Can be paused by setting the pause parameter to true.
     * Can be resumed by setting the pause parameter to false.
     * @param pause - used to pause and resume the observable emissions.
     * @param period - after each period we will emit.
     * @param unit - time unit.
     * @return
     */
    public static Observable<Long> createPausableInterval(final AtomicBoolean pause,
                                                          final long period,
                                                          TimeUnit unit) {
        return Observable.interval(period, unit).filter(new Predicate<Long>() {

            @Override
            public boolean test(Long tick) {
                return !pause.get();
            }

        }).scan(new BiFunction<Long, Long, Long>() {

            @Override
            public Long apply(Long acc, Long tick) {
                return acc + 1;
            }

        });
    }
}
