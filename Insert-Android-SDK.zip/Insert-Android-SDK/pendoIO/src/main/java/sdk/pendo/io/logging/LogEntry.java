package sdk.pendo.io.logging;

/**
 * Created by tomerlevinson on 7/25/16.
 */
public class LogEntry {
    private long mTimestamp;
    private String mMessage;
    private String mException;
    private String mLoggingLevel;

    public LogEntry(long timestamp, String message, String loggingLevel) {
        this.mLoggingLevel = loggingLevel;
        this.mMessage = message;
        this.mTimestamp = timestamp;
    }

    public LogEntry(long timestamp, String message, String exception, String loggingLevel) {
        this.mLoggingLevel = loggingLevel;
        this.mMessage = message;
        this.mTimestamp = timestamp;
        this.mException = exception;
    }

    @Override
    public final String toString() {
        String exception = (mException != null) ? ("Exception: " + mException + ", ") : "";
        return "[" +
                "Timestamp: " + Long.toString(mTimestamp) + ", " +
                "Logging Level: " + mLoggingLevel + ", " +
                "Message: " + mMessage + ", " +
                exception +
                "]";
    }
}
