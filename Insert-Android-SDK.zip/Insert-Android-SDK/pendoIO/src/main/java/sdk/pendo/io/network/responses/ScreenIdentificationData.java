package sdk.pendo.io.network.responses;

import android.app.Activity;

import com.google.gson.annotations.SerializedName;

import org.json.JSONException;
import org.json.JSONObject;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.constants.Constants;
import sdk.pendo.io.utilities.AndroidUtils;

/**
 * Created by assaf on 12/28/15.
 */
public final class ScreenIdentificationData {

    @SerializedName(Constants.ScreenCaptureConsts.ACTIVITY_NAME)
    private String mActivityName;

    @SerializedName(Constants.ScreenCaptureConsts.FRAGMENT_NAME)
    private String mFragmentName;

    public ScreenIdentificationData(Activity activity) {
        mActivityName = activity.getLocalClassName();
        String currentFragmentName = AndroidUtils.getCurrentVisibleFragmentName(activity);
        if (currentFragmentName != null) {
            mFragmentName = currentFragmentName;
        } else {
            mFragmentName = mActivityName;
        }


    }

    public String getActivityName() {
        return mActivityName;
    }

    public String getFragmentName() {
        return mFragmentName;
    }

    public JSONObject toJSON() throws JSONException {
        return new JSONObject(toString());
    }

    @Override
    public String toString() {
        return Pendo.GSON.toJson(this);
    }
}
