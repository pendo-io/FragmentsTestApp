package sdk.pendo.io.actions;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * Event types to use with {@link InsertCommand}.
 * Created by assaf on 3/28/16.
 */
@SuppressWarnings({"unused", "CheckStyle"})
public class InsertCommandEventType {

    public static final InsertCommandEventType INSERT_COMMAND_EVENT_TYPE_ANY = new InsertCommandEventType("ANY");
    public static final InsertCommandEventType INSERT_ANALYTICS_EVENT = new InsertCommandEventType("insertAnalyticsEvent");

    public final String eventType;

    private InsertCommandEventType(String eventType) {
        this.eventType = eventType;
    }

    private static HashMap<String, InsertCommandEventType> sEventTypeMap = new HashMap<>();
    public static synchronized InsertCommandEventType getEventType(String eventType) {
        if (sEventTypeMap.isEmpty()) {
            generateEventTypeMap();
        }

        // FIXME: 10/5/16 Add comment to this workaround or remove it.
        return sEventTypeMap.get(eventType);
    }

    @Override
    public String toString() {
        return "Event type = {" + eventType + "}";
    }

    @Override
    public int hashCode() {
        return eventType.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof InsertCommandEventType)) {
            return false;
        } else if (o == this) {
            return true;
        }

        return eventType.equals(((InsertCommandEventType) o).eventType);
    }

    private static void generateEventTypeMap() {
        Class[] classes = {
                SdkEventType.class,
                InsertPreparationEventType.class,
                UserEventType.class,
                FormEventType.class,
                TextFieldEventType.class,
                PagerEventType.class,
                PagerPageEventType.class,
                VideoEventType.class,
                AnalyticsEventType.class,
                AppEventType.class
        };

        for (Class aClass : classes) {
            final Field[] fields = aClass.getDeclaredFields();

            for (Field field : fields) {
                final int modifiers = field.getModifiers();
                if (Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers)) {
                    try {
                        final InsertCommandEventType eventTypeField = (InsertCommandEventType) field.get(aClass);

                        sEventTypeMap.put(eventTypeField.eventType, eventTypeField);
                    } catch (Exception ignore) { }
                }
            }
        }
    }

    public static class InsertCommandEventTypeDeserializer implements JsonDeserializer<InsertCommandEventType> {
        @Override
        public InsertCommandEventType deserialize(JsonElement json, Type typeOfT,
                                                  JsonDeserializationContext context) throws
                JsonParseException {
            return getEventType(json.getAsString());
        }
    }

    public static final class AnalyticsEventType extends  InsertCommandEventType {
        private AnalyticsEventType(String eventType) { super(eventType); }
        public static final AnalyticsEventType GUIDE_DISPLAYED = new AnalyticsEventType("onGuideDisplayed");
        public static final AnalyticsEventType GUIDE_RECEIVED = new AnalyticsEventType("onGuideReceived");
        public static final AnalyticsEventType GUIDE_NOT_DISPLAYED_OUT_OF_CAPPING = new AnalyticsEventType("onGuideNotDisplayedCapping");
        public static final AnalyticsEventType GUIDE_NOT_DISPLAYED_NO_CONNECTIVITY = new AnalyticsEventType("onGuideNotDisplayedNoConnectivity");
        public static final AnalyticsEventType GUIDE_NOT_DISPLAYED_CONTROL_GROUP = new AnalyticsEventType("onGuideNotDisplayedControlGroup");
        public static final AnalyticsEventType GUIDE_NOT_DISPLAYED_ERROR = new AnalyticsEventType("guideNotDisplayedErrorEvent");
        public static final AnalyticsEventType GUIDE_DISMISSED_TIMEOUT = new AnalyticsEventType("onGuideDismissedTimeout");
        public static final AnalyticsEventType GUIDE_DISMISSED_STATE_CHANGED = new AnalyticsEventType("onGuideDismissedStateChanged");
        public static final AnalyticsEventType GUIDE_DISMISSED_BACK_BUTTON = new AnalyticsEventType("onGuideDismissedBackButton");
        public static final AnalyticsEventType GUIDE_DISMISSED_USER_ACTION = new AnalyticsEventType("onGuideDismissedUserAction");

        private static final LinkedList<InsertCommandEventType> ANALYTICS_EVENT_TYPES = new LinkedList<>();

        static {
            ANALYTICS_EVENT_TYPES.add(GUIDE_DISPLAYED);
            ANALYTICS_EVENT_TYPES.add(GUIDE_RECEIVED);
            ANALYTICS_EVENT_TYPES.add(GUIDE_NOT_DISPLAYED_OUT_OF_CAPPING);
            ANALYTICS_EVENT_TYPES.add(GUIDE_NOT_DISPLAYED_NO_CONNECTIVITY);
            ANALYTICS_EVENT_TYPES.add(GUIDE_NOT_DISPLAYED_ERROR);
            ANALYTICS_EVENT_TYPES.add(GUIDE_DISMISSED_TIMEOUT);
            ANALYTICS_EVENT_TYPES.add(GUIDE_DISMISSED_STATE_CHANGED);
            ANALYTICS_EVENT_TYPES.add(GUIDE_DISMISSED_BACK_BUTTON);
            ANALYTICS_EVENT_TYPES.add(GUIDE_DISMISSED_USER_ACTION);
        }

        public static List<InsertCommandEventType> getAnalyticsEventTypes() {
            return new LinkedList<>(ANALYTICS_EVENT_TYPES);
        }
    }

    public static final class SdkEventType extends InsertCommandEventType {
        private SdkEventType(String eventType) { super(eventType); }

        public static final SdkEventType GUIDE_DISMISSED = new SdkEventType("guideDismissed");
        public static final SdkEventType TIME_OUT = new SdkEventType("timeOut");
        public static final SdkEventType ANIMATION_DONE = new SdkEventType("animationDone");
        public static final SdkEventType HOST_APP_DEVELOPER_CALL = new SdkEventType("hostAppDeveloperCall");
        public static final SdkEventType TRIGGER_OCCURRED = new SdkEventType("triggerOccurred");
    }

    public static final class AppEventType extends InsertCommandEventType {
        private AppEventType(String eventType) { super(eventType); }

        public static final AppEventType APP_IN_BACKGROUND = new AppEventType("onAppInBackground");
        public static final AppEventType APP_IN_FOREGROUND = new AppEventType("onAppInForeground");
        public static final AppEventType APP_SESSION_START = new AppEventType("onAppSessionStart");
        public static final AppEventType APP_SESSION_END = new AppEventType("onAppSessionEnd");
    }

    public static final class InsertPreparationEventType extends InsertCommandEventType {
        private InsertPreparationEventType(String eventType) { super(eventType); }

        public static final InsertPreparationEventType PREFETCH_IMAGES_END = new InsertPreparationEventType("prefetchImagesEnd");
    }

    public static final class UserEventType extends InsertCommandEventType {
        private UserEventType(String eventType) { super(eventType); }

        public static final UserEventType TAP_ON = new UserEventType("click");
        public static final UserEventType SWIPE_LEFT = new UserEventType("swipeLeft");
        public static final UserEventType SWIPE_RIGHT = new UserEventType("swipeRight");
        public static final UserEventType PINCH_IN = new UserEventType("pinchIn");
        public static final UserEventType PINCH_OUT  = new UserEventType("pinchOut");
    }

    public static final class FormEventType extends InsertCommandEventType {
        private FormEventType(String eventType) { super(eventType); }

        public static final FormEventType ON_SUBMIT = new FormEventType("onSubmit");
        public static final FormEventType ON_VALID = new FormEventType("onValid");
        public static final FormEventType ON_INVALID = new FormEventType("onInvalid");

        public static final FormEventType ON_SELECTION_CHANGED = new FormEventType("onSelectionChanged");
    }

    public static final class TextFieldEventType extends InsertCommandEventType {
        private TextFieldEventType(String eventType) { super(eventType); }

        public static final TextFieldEventType ON_TEXT_CHANGED = new TextFieldEventType("onTextChanged");
    }

    public static final class PagerEventType extends InsertCommandEventType {
        private PagerEventType(String eventType) { super(eventType); }

        public static final PagerEventType ON_CHANGE_PAGE = new PagerEventType("onChangePage");
        public static final PagerEventType ON_FIRST_PAGE = new PagerEventType("onFirstPage");
        public static final PagerEventType ON_LAST_PAGE = new PagerEventType("onLastPage");
        public static final PagerEventType ON_INNER_PAGE = new PagerEventType("onInnerPage");
    }

    public static final class PagerPageEventType extends InsertCommandEventType {
        private PagerPageEventType(String eventType) { super(eventType); }

        public static final PagerPageEventType ON_APPEAR = new PagerPageEventType("onAppear");
        public static final PagerPageEventType ON_DISAPPEAR = new PagerPageEventType("onDisappear");
    }

    public static final class VideoEventType extends InsertCommandEventType {
        private VideoEventType(String eventType) { super(eventType); }

        public static final VideoEventType ON_START = new VideoEventType("onStart");
        public static final VideoEventType ON_STOP = new VideoEventType("onStop");
        public static final VideoEventType ON_COMPLETE = new VideoEventType("onComplete");
        public static final VideoEventType ON_PAUSE = new VideoEventType("onPause");
    }
}
