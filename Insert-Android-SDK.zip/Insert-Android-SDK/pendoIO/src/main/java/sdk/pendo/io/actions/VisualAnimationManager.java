
package sdk.pendo.io.actions;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.util.concurrent.TimeUnit;

import external.sdk.pendo.io.dynamicview.DynamicView;
import external.sdk.pendo.io.yoyo.Techniques;
import external.sdk.pendo.io.yoyo.YoYo;
import io.reactivex.Flowable;
import io.reactivex.FlowableTransformer;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.configurations.InsertTransition;
import sdk.pendo.io.activities.InsertVisualActivity;
import sdk.pendo.io.animations.PopAnimation;
import sdk.pendo.io.animations.StatusBarColorAnimation;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.logging.profiling.ProfilingManager;
import sdk.pendo.io.models.GuideConfigurationModel;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.utilities.AnimationUtils;

import static sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.NOTIFY_CLOSE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.OUT_ANIMATION_DONE;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.ANIMATION_DONE;
import static sdk.pendo.io.logging.profiling.ProfilingManager.ProfilerType.PERFORMANCE;


/**
 * Created by tomerlevinson on 3/16/16.
 */
public final class VisualAnimationManager {

    // Constants.
    private static final int DEFAULT_FADE_ENTER_DURATION = 50;
    private static final String IN_TYPE_TRANSITION = "in";
    private static final String OUT_TYPE_TRANSITION = "out";
    private static final int DEFAULT_FADE_COLOR = 0xCC000000;

    private String mInsertId;
    // Constructor params.
    private GuideConfigurationModel mGuideActionConfiguration;

    // Animation finished behavioural subject.
    private BehaviorSubject<Boolean> mFinishedAnimation = BehaviorSubject.createDefault(false);

    // Faded background linear layout below the inserts.
    private LinearLayout mFadedBackgroundLinearLayout;

    /*
     * Constructor
     */
    VisualAnimationManager(String insertId, GuideConfigurationModel configuration) {
        mInsertId = insertId;
        mGuideActionConfiguration = configuration;
    }

    /*
     * Set the on animation finish observable.
     */
    public void setOnFinishedAnimationObservable(Boolean animationFinished) {
        mFinishedAnimation.onNext(animationFinished);
    }

    /*
     * Get the on animation finish observable.
     */
    public Observable<Boolean> getFinishedAnimationObservable() {
        return mFinishedAnimation;
    }

    /*
     * Mark with the profiling manager.
     * Animate status bar.
     */
    private void markAndAnimateStatusBar(final StatusBarColorAnimation statusBarColorAnimation) {
        try {

            final VisualInsertBase visualInsert =
                    VisualInsertManager.getInstance().getVisualInsert(mInsertId);

            if (visualInsert == null) {
                InsertLogger.w("Visual insert is null!");
                return;
            }

            ProfilingManager.getInstance()
                    .mark(PERFORMANCE, "Pendo show started id " + visualInsert.getGuideId());

            if (statusBarColorAnimation != null) {
                statusBarColorAnimation.statusBarColorAnimate();

            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    /*
     * This method reverses the status bar animation.
     */
    void reverseStatusBarAnimation(StatusBarColorAnimation statusBarColorAnimation) {
        try {
            if (statusBarColorAnimation != null) {
                statusBarColorAnimation.reverseStatusBarColorAnimate();
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    /*
     * This method performs insert hiding including animation.
     */
    void performHide(final StatusBarColorAnimation statusBarColorAnimation, boolean animated) {
        try {
            final VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(mInsertId);

            if (visualInsert == null) {
                InsertLogger.w("Visual insert is null!");
                return;
            }

            InsertLogger.v("Calling! showing? " + visualInsert.isShowing());
            if (!visualInsert.getAndSetShowing(false)) {
                InsertLogger.d("Already dismissing!");
                return;
            }

            visualInsert.cancelDuration();

            ProfilingManager.getInstance().mark(PERFORMANCE,
                    "Pendo hide started id " + visualInsert.getGuideId());

            if (animated) {
                hideWithAnimation(statusBarColorAnimation);
            }
            else {
                removeViewsAndFinishUp();
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    /*
     * This method performs insert showing including animation.
     */
    void performShow(Activity activity,
                     final StatusBarColorAnimation statusBarColorAnimation) {
        try {
            final VisualInsertBase visualInsert =
                    VisualInsertManager.getInstance().getVisualInsert(mInsertId);

            if (visualInsert == null) {
                InsertLogger.w("Visual insert is null!");
                return;
            }

            setOnFinishedAnimationObservable(false);
            InsertLogger.v("Calling! showing? " + visualInsert.isShowing());
            if (visualInsert.isShowing()) {
                InsertLogger.d("Already showing!");
                return;
            }

            final Activity currentActivity =
                    ApplicationObservers.getInstance().getCurrentVisibleActivity();

            if (activity == null
                    || !(activity instanceof InsertVisualActivity)) {
                activity = currentActivity;
            }

            final boolean isBanner = VisualInsertBase.VisualInsertType.BANNER
                    .equals(visualInsert.getVisualInsertType());

            View rootView = null;
            if (!isBanner) {
                try {
                    rootView = activity.getWindow().getDecorView().getRootView();
                } catch (Exception e) {
                    InsertLogger.w(e, e.getMessage());
                }

                if (rootView == null || !(rootView instanceof ViewGroup)) {
                    // TODO: 2/1/16 we can fallback to activity here.
                    InsertLogger.w("Cannot show insert without ViewGroup. Pendo ID: " + visualInsert.getGuideId() +
                            "  rootView = " + (rootView == null? "null" : rootView.getClass().getCanonicalName()));
                    return;
                }
            }

            visualInsert.getAndSetShowing(true);

            if (!isBanner) {
                visualInsert.setRootView((ViewGroup) rootView);
            }
            startShowingAnimation(statusBarColorAnimation);
            visualInsert.startTimeout();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    /*
     * This method starts the animation.
     */
    void startShowingAnimation(final StatusBarColorAnimation statusBarColorAnimation) {

        final VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(mInsertId);

        if (visualInsert == null) {
            InsertLogger.w("Visual insert is null!");
            return;
        }

        final String insertId = visualInsert.getGuideId();
        // The root view of the insert (in case of insert visual activity will be the insert visual activity),
        // In case of view insert will be the activity holding it.
        final ViewGroup rootView = visualInsert.getRootView();
        //The insert view group container
        final ViewGroup container = visualInsert.getContainer();
        if (rootView == null || container == null) {
            InsertLogger.w("Cannot start animation to display Pendo. Visual rootView is null? '" +
                    (rootView == null) + "' container is null? '" + (container == null) +
                    " insertId = " + insertId + ".");
            return;
        }
        // Get the in transition from the configuration.
        final InsertTransition inTransition =
                mGuideActionConfiguration.getTransition(IN_TYPE_TRANSITION);

        View floatingLayoutView = null;

        // Adding faded background if not banner insert
        if (!VisualInsertBase.VisualInsertType.BANNER.equals(visualInsert.getVisualInsertType())) {
            floatingLayoutView = addFadedBackgroundLayout(rootView, container, inTransition, floatingLayoutView);
        }

        final View finalFloatingLayoutView = floatingLayoutView;
        final String guideStepId = StepSeenManager.getInstance().getCurrentStepId();
        if (InsertPreparationManager.getInstance().getHasImages(guideStepId) != null) {
            Observable.combineLatest(
                    InsertsManager.getVisualGuideStepInitedAsObservable(guideStepId)
                    .filter(
                            new Predicate<Boolean>() {
                                @Override
                                public boolean test(Boolean insertInited) {
                                    return insertInited;
                                }
                            }),
                    InsertPreparationManager.getInstance().getImagesSetAsObservable(guideStepId),
                    new BiFunction<Boolean, Boolean, Boolean>() {
                        @Override
                        public Boolean apply(Boolean insertInflated, Boolean imagesLoaded) {
                            return insertInflated && imagesLoaded;
                        }
                    })
                    .filter(new Predicate<Boolean>() {
                        @Override
                        public boolean test(Boolean imagesLoadedAndInsertInflated) {
                            return imagesLoadedAndInsertInflated;
                        }
                    })
                    .mergeWith(InsertTapOnManager.getTapOnTimeExpiredObservable())
                    .filter(new Predicate<Boolean>() {
                        @Override
                        public boolean test(Boolean hasImagesLoadedOrTimeoutExpired) {
                            // Will continue if one of the two happens,
                            // Either the images have loaded or the time expired for tap on.
                            return hasImagesLoadedOrTimeoutExpired;

                        }
                    })
                    .firstElement()
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                        @Override
                        public void accept(Boolean hasImagesLoadedOrTimeoutExpired) {
                            InsertsManager.removeVisualInsertInitedObservable(insertId);
                            // In case the timeout expired and we are in a tap on insert.
                            if (InsertTapOnManager.isTapOnTimeoutExpired()) {
                                InsertTapOnManager.resetTapOn();
                            } else {
                                // Otherwise, run the insert.
                                InsertTapOnManager.removeSpinnerFromLayout();
                                startYoYoAnimations(rootView, container,
                                        inTransition,
                                        finalFloatingLayoutView,
                                        statusBarColorAnimation,
                                        visualInsert.getContainerId(),
                                        visualInsert.getVisualInsertType());
                            }
                        }
                    }));
        } else {
            InsertTapOnManager.removeSpinnerFromLayout();
            startYoYoAnimations(rootView, container,
                    inTransition,
                    finalFloatingLayoutView,
                    statusBarColorAnimation,
                    visualInsert.getContainerId(),
                    visualInsert.getVisualInsertType());
        }
    }

    /**
     * Starting the YoYo library animation, identifying wheter to add a faded background layer according to the insert type
     * @param rootView the root view to contain the faded layout
     *
     * @param container the insert layout container
     *
     * @param inTransition the transition to be used when insert appears
     *
     * @param finalFloatingLayoutView the insert content
     *
     * @param statusBarColorAnimation the status bar color
     *
     * @param innerLayoutId the inner layout id
     *
     * @param visualInsertType the visual insert type
     */
    private void startYoYoAnimations(ViewGroup rootView, final ViewGroup container,
                                     final InsertTransition inTransition,
                                     final View finalFloatingLayoutView,
                                     final StatusBarColorAnimation statusBarColorAnimation,
                                     final int innerLayoutId,
                                     VisualInsertBase.VisualInsertType visualInsertType) {
        if (!VisualInsertBase.VisualInsertType.BANNER.equals(visualInsertType)) {
            playFadedBackgroundAnimation(rootView,
                    container,
                    inTransition,
                    finalFloatingLayoutView,
                    statusBarColorAnimation,
                    innerLayoutId,
                    visualInsertType);
        } else {
            playInsertAnimation(rootView,
                    container,
                    inTransition,
                    innerLayoutId,
                    finalFloatingLayoutView,
                    statusBarColorAnimation,
                    visualInsertType);
        }

    }

    /**
     * Adds a faded background layer "below" the full screen insert in case of floating insert
     * @param rootView the root view to contain the faded layout
     *
     * @param container the insert layout container
     *
     * @param inTransition the transition to be used when insert appears
     *
     * @param floatingLayoutView the insert content
     *
     * @return
     */
    @Nullable
    private View addFadedBackgroundLayout(ViewGroup rootView,
                                          ViewGroup container,
                                          InsertTransition inTransition,
                                          View floatingLayoutView) {
        if (inTransition != null) {
            String backgroundId = inTransition.getBackgroundId();
            if (DynamicView.getIdsMap().containsKey(backgroundId)) {
                int floatingLayoutViewId = DynamicView.getIdsMap().get(backgroundId);
                floatingLayoutView = container.findViewById(floatingLayoutViewId);
            }
        }

        // Construct the faded background in the back of the insert.
        mFadedBackgroundLinearLayout = new LinearLayout(Pendo.getApplicationContext());
        if (floatingLayoutView != null) {

            // If we have background color in the floating layout, take it from there!
            final Drawable background = floatingLayoutView.getBackground();

            if (background != null) {

                // Make the floating layout transparent to avoid duplicate backgrounds.
                setBackgroundTransparent(floatingLayoutView);

                if (background instanceof GradientDrawable) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        mFadedBackgroundLinearLayout.setBackground(background);
                    } else {
                        //noinspection deprecation
                        mFadedBackgroundLinearLayout.setBackgroundDrawable(background);
                    }
                } else {
                    mFadedBackgroundLinearLayout.setBackgroundColor(
                            ((ColorDrawable) background).getColor());
                }
            } else {

                // else take the default color.
                mFadedBackgroundLinearLayout.setBackgroundColor(DEFAULT_FADE_COLOR);
            }
        } else {

            // else take the default color.
            mFadedBackgroundLinearLayout.setBackgroundColor(DEFAULT_FADE_COLOR);
        }

        rootView.addView(mFadedBackgroundLinearLayout); // IllegalStateException
        mFadedBackgroundLinearLayout.setVisibility(View.GONE);
        container.setVisibility(View.GONE);
        rootView.addView(container);
        return floatingLayoutView;
    }

    /**
     * Plays the faded background that located "behind" the insert.
     * after playing it's animation plays the insert content animation
     * @param rootView the root view to contain the faded layout
     *
     * @param container the insert layout container
     *
     * @param inTransition the transition to be used when insert appears
     *
     * @param finalFloatingLayoutView the insert content
     *
     * @param statusBarColorAnimation the status bar color
     *
     * @param innerLayoutId the inner layout id
     *
     * @param visualInsertType the visual insert type
     */
    private void playFadedBackgroundAnimation(final ViewGroup rootView,
                                              final ViewGroup container,
                                              final InsertTransition inTransition,
                                              final View finalFloatingLayoutView,
                                              final StatusBarColorAnimation statusBarColorAnimation,
                                              final int innerLayoutId,
                                                final VisualInsertBase.VisualInsertType visualInsertType) {
        // Default play duration for the screen.
        int fadeInPlayDuration = 0;
        // In case we've come from tap on, don't set the faded background to visible.
        // Let the duration be the default duration.
        if (mFadedBackgroundLinearLayout != null && !InsertTapOnManager.isTapOnLayoutExist()) {
            mFadedBackgroundLinearLayout.setVisibility(View.VISIBLE);
            fadeInPlayDuration = DEFAULT_FADE_ENTER_DURATION;
        }
        YoYo.with(AnimationUtils.chooseTechnique(inTransition)).
                onEnd(new YoYo.AnimatorCallback() {
                    @Override
                    public void call(Animator animator) {
                        playInsertAnimation(rootView,
                                container,
                                inTransition,
                                innerLayoutId,
                                finalFloatingLayoutView,
                                statusBarColorAnimation,
                                visualInsertType);
                    }
                })
                .duration(fadeInPlayDuration)
                .pivotRelationToParent(true)
                .playOn(
                mFadedBackgroundLinearLayout != null ? mFadedBackgroundLinearLayout : container);
    }

    /**
     * Plays the insert content animation accoring  to the transition parameters
     * @param rootView
     * @param container
     * @param inTransition
     * @param innerLayoutId
     * @param finalFloatingLayoutView
     * @param statusBarColorAnimation
     * @param visualInsertType
     */
    private void playInsertAnimation(ViewGroup rootView, ViewGroup container,
                                     InsertTransition inTransition,
                                     int innerLayoutId,
                                     View finalFloatingLayoutView,
                                     final StatusBarColorAnimation statusBarColorAnimation,
                                     VisualInsertBase.VisualInsertType visualInsertType) {
        if (container == null) {
            return;
        }

        final VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(mInsertId);

        if (visualInsert == null) {
            return;
        }

        // In case the transition isn't null , we can use YoYo.
        try {
            if (inTransition != null) {
                // Add the insert container after we have finished fading in the background.
                container.setVisibility(View.VISIBLE);
                View insertContainer =
                        container.findViewById(
                               innerLayoutId);
                if (insertContainer != null) {
                    if (VisualInsertBase.VisualInsertType.BANNER.equals(visualInsertType)) {
                        rootView.addView(container);
                    } else {
                        insertContainer.setBackgroundColor(Color.TRANSPARENT);

                        if (finalFloatingLayoutView != null) {
                            finalFloatingLayoutView.setBackgroundColor(
                                    Color.TRANSPARENT);
                        }
                    }

                    int inTransitionDuration = inTransition.getDuration();

                    Techniques chosenTechnique = AnimationUtils.chooseTechnique(
                            inTransition);
                    YoYo.with(chosenTechnique)
                        .onStart(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(
                                    Animator animator) {
                                try {
                                    markAndAnimateStatusBar(
                                            statusBarColorAnimation);
                                } catch (Exception e) {

                                }
                            }

                        })
                            .onEnd(new YoYo.AnimatorCallback() {
                                @Override
                                public void call(Animator animator) {
                                    try {
                                        InsertsManager.getInstance().setInsertFullyDisplayedAfterAnimation(mInsertId);
                                        final Tracker tracker = visualInsert.getTracker();

                                        if (tracker == null) {
                                            InsertLogger.e("Tracker is null, not sending analytics; '"
                                                    + AnalyticsEvent.GUIDE_DISPLAYED + "'.");
                                            return;
                                        }

                                        if (tracker.getGenericAnalytics() != null) {
                                            InsertCommandParameterInjector.getInstance().handleInsertDisplayedAnalytics(
                                                    mInsertId, true, visualInsert.getActivatedBy());
                                        }
                                    } catch (IllegalStateException e) {
                                        InsertLogger.e(e, "Illegal state exception of InsertsManager: " + e.getMessage());
                                    } catch (Exception e) {
                                        InsertLogger.e(e, e.getMessage());
                                    }
                                }})
                        .duration(inTransitionDuration)
                        .pivotRelationToParent(true)
                        .playOn(insertContainer);
                }

            } else {
                // Else fallback to default animation.
                AnimatorSet enterPop =
                        PopAnimation.getEnterAnimatorSet(
                                container,
                                innerLayoutId);

                container.setVisibility(View.VISIBLE);
                if (VisualInsertBase.VisualInsertType.BANNER.equals(visualInsertType)) {
                    //Adding the container to the root view directly as we don't use the faded backgound flow for banner
                    rootView.addView(container);
                }
                enterPop.addListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        markAndAnimateStatusBar(statusBarColorAnimation);
                    }

                    @Override
                    public void onAnimationEnd(Animator animation) {
                        try {
                            InsertsManager.getInstance().setInsertFullyDisplayedAfterAnimation(mInsertId);
                        } catch (IllegalStateException e) {
                            InsertLogger.e(e, "Illegal state exception of InsertsManager: " + e.getMessage());
                        } catch (Exception e) {
                            InsertLogger.e(e, e.getMessage());
                        }
                    }

                    @Override
                    public void onAnimationCancel(Animator animation) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animation) {

                    }
                });
                enterPop.start();
            }
        } catch (Exception ignore) {
            InsertLogger.d(ignore, "animation exception " + ignore.getMessage());
        }
    }

    void hideWithAnimation(
            final StatusBarColorAnimation statusBarColorAnimation) {

        final VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(mInsertId);

        if (visualInsert == null) {
            InsertLogger.w("Visual insert is null!");
            return;
        }

        final ViewGroup container = visualInsert.getContainer();

        if (container == null) {
            InsertLogger.w("Error while trying to hide Pendo with animation, " +
                    "container is null. Pendo ID = " + visualInsert.getGuideId());
            return;
        }

        if (container.getParent() == null) {
            removeViewsAndFinishUp();
            return;
        }


        // Get the transition from the configuration.
        InsertTransition outTransition =
                mGuideActionConfiguration.getTransition(OUT_TYPE_TRANSITION);

        // In case we have a transition, continue with the YoYo animation library
        if (outTransition !=  null) {
            int outTransitionDuration = outTransition.getDuration();

            // Choose the transition according to the config.
            Techniques chosenTechnique = AnimationUtils.chooseTechnique(outTransition);

            // Start hiding.
            YoYo.with(chosenTechnique)
                    .onStart(
                            new YoYo.AnimatorCallback() {
                                @Override
                                public void call(Animator animator) {
                                    reverseStatusBarAnimation(statusBarColorAnimation);
                                }

                            })
                    .onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            removeViewsAndFinishUp();
                        }
                    })
                    .duration(outTransitionDuration)
                    .pivotRelationToParent(true)
                    .playOn(container);
        } else {
            // Otherwise fallback to default transition.
            AnimatorSet exitPop =
                    PopAnimation.getExitAnimatorSet(
                            container,
                           visualInsert.getContainerId());


            exitPop.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {
                    reverseStatusBarAnimation(statusBarColorAnimation);
                }

                @Override
                public void onAnimationEnd(Animator animation) {

                    removeViewsAndFinishUp();
                }

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });
            exitPop.start();
        }

    }

    /*
     * This method stops the animation.
     */
    void removeViewsAndFinishUp() {

        final VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(mInsertId);

        if (visualInsert == null) {
            InsertLogger.w("Visual insert is null!");
            return;
        }

        final ViewGroup rootView = visualInsert.getRootView();
        final ViewGroup container = visualInsert.getContainer();

        if (rootView == null || container == null) {
            InsertLogger.w("Error trying to stop the animation and hide the Pendo." +
                    "rootView is null? '" + (rootView == null) + "' container is null? '"
                    + (container == null) +  " Pendo ID = " + visualInsert.getGuideId() + "'.");
            return;
        }

        try {

            InsertContentDescriptionManager.getInstance().setImportantRecursively(rootView);
            // Remove the insert.
            rootView.removeView(container);

            // Remove the faded background.
            rootView.removeView(mFadedBackgroundLinearLayout);

            InsertTapOnManager.resetTapOn();

            GuideModel currentGuideModel = GuideManager.INSTANCE.getGuide(mInsertId);
            if (currentGuideModel != null) {
                InsertPreparationManager.getInstance().removeImageSetForInsertId(StepSeenManager.getInstance().getCurrentStepId());
            }

            // Set the finished observable on finished mode.
            setOnFinishedAnimationObservable(true);
            InsertCommandDispatcher.getInstance().dispatchCommand(
                    new InsertCommand.Builder(OUT_ANIMATION_DONE, ANIMATION_DONE)
                            .setSourceId(visualInsert.getGuideId())
                            .setDestinationId(InsertCommand.COMMAND_STRING_ANY)
                            .setParameters(InsertInfoConsts.createInsertMetadataParams(visualInsert.getGuideId()))
                            .build(), false
            );

        } catch (Exception e) {
            InsertLogger.w(e, e.getMessage());
        }

        // Not showing anymore.
        visualInsert.getAndSetShowing(false);

        // Destroy.
        visualInsert.onDestroy();
    }

    private static final int INSERT_DISMISSED_DELAY = 17;

    public static FlowableTransformer<InsertCommand, InsertCommand>
                waitForAnimationDoneAndNotifyClose(@NonNull final String insertId) {

        return new FlowableTransformer<InsertCommand, InsertCommand>() {

            @Override
            public Flowable<InsertCommand> apply(Flowable<InsertCommand> tObservable) {
                final Predicate<InsertCommand> insertDismissedFilter = InsertCommand
                        .createFilter(InsertCommand.COMMAND_STRING_ANY,
                                InsertCommand.COMMAND_STRING_ANY,
                                NOTIFY_CLOSE,
                                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

                final Predicate<InsertCommand> animationDoneFilter = InsertCommand
                        .createFilter(InsertCommand.COMMAND_STRING_ANY,
                                InsertCommand.COMMAND_STRING_ANY,
                                OUT_ANIMATION_DONE, ANIMATION_DONE,
                                InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

                // Delay the detach notification by 1 minute.
//                final Observable<Void> detaches = RxView
//                        .detaches(view)
//                        .delay(1, TimeUnit.MINUTES);

                final Flowable<InsertCommand> dismissed = InsertCommandsEventBus.getInstance()
                        .getCommandEventBus()
                        .filter(insertDismissedFilter)
                        // Perservence time for people watching videos.
                        // If a person watches a video more than 17 seconds we will not keep the insert.
                        .delay(INSERT_DISMISSED_DELAY, TimeUnit.SECONDS);

                return tObservable
                        // Take until the insert was dismissed.
                        .takeUntil(dismissed)
//                        .takeUntil(detaches)

                        // Make sure both the close notification and animation done happened.
                        .filter(new Predicate<InsertCommand>() {

                            private boolean mDismissed = false;
                            private boolean mAnimationDone = false;
                            private boolean mIsDeepLink = false;
                            private static final String DEEPLINK = "deeplink";

                            @Override
                            public boolean test(InsertCommand insertCommand) {
                                String insertIdString = insertCommand.getParamValueFromCommand(InsertInfoConsts.GUIDE_ID);
                                if (TextUtils.isEmpty(insertIdString)) {
                                    return false;
                                }
                                // In case this is not the right insert id , ignore.
                                if (!insertIdString.equals(insertId)) {
                                    return false;
                                }
                                if (insertCommand.getParameters() != null) {
                                    for (InsertCommandsEventBus.Parameter parameter: insertCommand.getParameters()) {
                                        if (parameter.getParameterName().equals(InsertCommandsEventBus.Parameter.INSERT_COMMAND_PARAMETER_SERIALIZED_NAME_TYPE)
                                                && parameter.getParameterValue().equals(DEEPLINK)) {
                                            mIsDeepLink = true;
                                        }
                                    }
                                }
                                try {
                                    if (insertDismissedFilter.test(insertCommand)) {
                                        mDismissed = true;
                                    } else if (animationDoneFilter.test(insertCommand)) {
                                        mAnimationDone = true;
                                    }
                                } catch (Exception e) {
                                    InsertLogger.e(e, e.getMessage());
                                }

                                if (mDismissed && mAnimationDone && mIsDeepLink) {
                                    mIsDeepLink = false;
                                    mDismissed = false;
                                    mAnimationDone = false;
                                    return false;
                                }

                                if (mDismissed && mAnimationDone && !mIsDeepLink) {
                                    mDismissed = false;
                                    mAnimationDone = false;
                                    return true;
                                }
                                return false;
                            }
                        });
            }
        };
    }

    private void setBackgroundTransparent(View view) {
        GradientDrawable gd = new GradientDrawable();
        ((GradientDrawable) gd.mutate()).setColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(gd);
        } else {
            //noinspection deprecation
            view.setBackgroundDrawable(gd);
        }
    }
}
