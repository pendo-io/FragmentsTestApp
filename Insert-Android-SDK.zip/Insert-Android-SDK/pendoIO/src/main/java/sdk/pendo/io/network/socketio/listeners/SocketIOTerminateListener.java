package sdk.pendo.io.network.socketio.listeners;

import java.util.Arrays;
import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.SocketIOManager;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.logging.InsertLogger;

 /**
 * Listen on {@link SocketEvents#EVENT_TERMINATE}
 */
public final class SocketIOTerminateListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got terminate: "  + (args != null ? Arrays.toString(args) : "args is null"));
        SocketIOManager.getInstance().terminateSession();
    }
}
