package sdk.pendo.io.utilities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings.Secure;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Base64;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Random;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Utility class for Android.
 * <p/>
 * Created by assaf on 5/11/15.
 */
public final class AndroidUtils {
    private static final Object LOCK = new Object();
    public static final int VERSION_CODE_UNDEFINED = -1;
    public static final String VERSION_NAME_UNKNOWN = "unknown";
    public static final String OS_NAME = "android";
    public static final String OS_VERSION = Build.VERSION.RELEASE;
    private static int sAppVersionCode = VERSION_CODE_UNDEFINED;
    private static String sAppVersionName = null;

    /**
     * Checks whether a specific permission is granted.
     *
     * @param permission The permission to check.
     *
     * @return True if the permission was granted to the application, false otherwise.
     */
    public static boolean isPermissionGranted(String permission) {
        Context ctx = Pendo.getApplicationContext();
        return ctx.checkCallingOrSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Returns the application name.
     *
     * @param app The application.
     *
     * @return The application name.
     */
    public static CharSequence getAppName(Context app) {
        ApplicationInfo applicationInfo = app.getApplicationInfo();
        return app.getPackageManager().getApplicationLabel(applicationInfo);
    }



    @Nullable
    public static String getDeviceId() {
        try {
            return DeviceIdHolder.getDeviceId();
        } catch (NoSuchAlgorithmException | IllegalStateException e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    public static boolean isInEmulator() {
        if (!Build.HARDWARE.equals("goldfish")) {
            return false;
        }

        if (!Build.BRAND.startsWith("generic")) {
            return false;
        }

        if (!Build.DEVICE.startsWith("generic")) {
            return false;
        }

        if (!Build.PRODUCT.contains("sdk")) {
            return false;
        }

        //noinspection RedundantIfStatement
        if (!Build.MODEL.toLowerCase(Locale.US).contains("sdk")) {
            return false;
        }

        return true;
    }

    /**
     * Returns the application version code
     * Holding it for the whole session to minimize calculations
     *
     * @return The application version code.
     */
    public static int getAppVersionCode() {
        int result = sAppVersionCode;
        if (result == -1) { // First check (no locking)
            synchronized (LOCK) {
                result = sAppVersionCode;
                if (result == -1) { // Second check (with locking)
                    //noinspection CheckStyle
                    sAppVersionCode = result = computeAppVersionCode();
                }
            }
        }
        return result;
    }

    private static int computeAppVersionCode() {
        try {
            Context ctx = Pendo.getApplicationContext();
            PackageInfo packageInfo = ctx.getPackageManager().getPackageInfo(
                    ctx.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }
        return -1;
    }

    /**
     * Returns the application version name
     * Holding it for the whole session to minimize calculations
     *
     * @return The application version name.
     */
    public static String getAppVersionName() {
        String result = sAppVersionName;
        if (result == null) { // First check (no locking)
            synchronized (LOCK) {
                result = sAppVersionName;
                if (result == null) { // Second check (with locking)
                    //noinspection CheckStyle
                    sAppVersionName = result = computeAppVersionName();
                }
            }
        }
        return result;
    }

    @SuppressLint("RestrictedApi")
    public static String getCurrentVisibleFragmentName(Activity activity) {
        String currentFragmentName = null;
        if (activity instanceof FragmentActivity) {
            for (Fragment fragment : ((FragmentActivity) activity).getSupportFragmentManager().getFragments()) {
                if (fragment != null && fragment.isVisible() && fragment.isMenuVisible()) {
                    currentFragmentName = fragment.getClass().getSimpleName();
                    break;
                }
            }
        }
        return currentFragmentName;
    }

    /**
     * Generate the application version name
     *
     * @return The application version.
     */
    private static String computeAppVersionName() {
        try {
            Context ctx = Pendo.getApplicationContext();
            PackageInfo packageInfo = ctx.getPackageManager().getPackageInfo(
                    ctx.getPackageName(), 0);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }
        return VERSION_NAME_UNKNOWN;
    }

    /**
     * Generate a BASE64 encoding of a string
     * @param string (non null)
     * @return it's BASE64 digest
     */
    public static String encodeToBase64(@NonNull final String string) {
        return Base64.encodeToString(string.getBytes(Charset.forName(ENCODING_UTF_8)), PredicateUtils.BASE64_FLAGS);
    }

    private static class DeviceIdHolder {

        private static final String HASH_ALGORITHM = "SHA-256";
        private static final Object LOCK = new Object();
        private static final int HASH_ITERATIONS = 1024;
        private static final String SALT_KEY = "dSalt";
        private static final int SALT_SIZE = 16;

        // Double-check idiom for lazy initialization of instance fields.
        private static volatile String sDeviceId;

        @WorkerThread
        static String getDeviceId() throws IllegalStateException, NoSuchAlgorithmException {

            String result = sDeviceId;
            if (result == null) { // First check (no locking)
                synchronized (LOCK) {
                    result = sDeviceId;
                    if (result == null) { // Second check (with locking)
                        //noinspection CheckStyle
                        sDeviceId = result = computeDeviceIdValue();
                    }
                }
            }
            return result;
        }

        /**
         * Computes the unique device ID based on the read device ID and the app package name. <p>
         * {@link #HASH_ALGORITHM}(DeviceID + PackageName) x {@link #HASH_ITERATIONS} times =>
         * Pendo's unique device id. </p>
         *
         * @return Hex representation of the device id.
         *
         * @throws IllegalStateException thrown if there is no context.
         * @throws NoSuchAlgorithmException thrown if {@link #HASH_ALGORITHM} specified algorithm is
         * not available
         */
        @SuppressWarnings("CheckStyle")
        private static synchronized String computeDeviceIdValue() throws IllegalStateException,
                NoSuchAlgorithmException {
            Context ctx = Pendo.getApplicationContext();
            final String appKey = Pendo.getAppKey();
            if (ctx == null) {
                throw new IllegalStateException(
                        "Cannot compute device id before initializing Pendo.");
            }

            if (appKey == null) {
                throw new IllegalStateException(
                        "Cannot compute device id without application key.");
            }

            String androidId;
            if (isInEmulator()) {
                androidId = "f4ce0deb1ce01d17";
            } else {
                androidId = Secure.getString(ctx.getContentResolver(), Secure.ANDROID_ID);
            }

            if (TextUtils.isEmpty(androidId)) {
                androidId = "fa177ed042d01d1d";
            }

            final long start = System.currentTimeMillis();
            byte[] id = androidId.getBytes(Charset.forName(ENCODING_UTF_8));
            byte[] appPackage = ctx.getApplicationInfo().packageName.getBytes(Charset.forName(ENCODING_UTF_8));
            byte[] salt = getSalt();
            byte[] bAppKey = appKey.getBytes(Charset.forName(ENCODING_UTF_8));
            byte[] toHash = new byte[id.length + appPackage.length + salt.length + bAppKey.length];

            System.arraycopy(id,         0, toHash, 0,                                           id.length);
            System.arraycopy(salt,       0, toHash, id.length,                                   salt.length);
            System.arraycopy(appPackage, 0, toHash, id.length + salt.length,                     appPackage.length);
            System.arraycopy(bAppKey,    0, toHash, id.length + salt.length + appPackage.length, bAppKey.length);

            MessageDigest md = MessageDigest.getInstance(HASH_ALGORITHM);
            md.update(toHash);

            for (int i = 0; i < HASH_ITERATIONS; i++) {
                byte[] result = md.digest();
                md.update(result);
            }
            // TODO: 11/17/15 Remove!
            InsertLogger.i("Device ID time: " + (System.currentTimeMillis() - start));

            return Utils.bytesToHex(md.digest());
        }

        private static synchronized byte[] getSalt() {

            final String salt = SettingsUtils.getSetting(SALT_KEY, "");

            if (TextUtils.isEmpty(salt)) {
                Random r = new SecureRandom();
                byte[] s = new byte[SALT_SIZE];
                r.nextBytes(s);

                String base64Salt = Base64.encodeToString(s, Base64.DEFAULT);
                SettingsUtils.storeSetting(SALT_KEY, base64Salt);
                return s;
            }

            return Base64.decode(salt, Base64.DEFAULT);
        }
    }
}
