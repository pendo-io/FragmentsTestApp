package sdk.pendo.io.actions;

import android.support.annotation.Nullable;
import android.view.View;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import sdk.pendo.io.analytics.GenericInsertAnalyticsData;

/**
 * Created by tomerlevinson on 12/14/15.
 */

public interface AppTweakInterface {
    enum TweakMode {
        CHANGE_TEXT("ChangeText"),
        HIGHLIGHTER("Highlighter"),
        CHANGE_IMAGE("ChangeImage");

        private final String mType;

        private static final Map<String, TweakMode> LOOKUP_TABLE = new HashMap<>();

        static {
            for (TweakMode s : EnumSet.allOf(TweakMode.class)) {
                LOOKUP_TABLE.put(s.mType, s);
            }
        }

        TweakMode(String type) {
            this.mType = type;
        }

        boolean equals(TweakMode tweakMode) {
            return this.mType.equals(tweakMode.mType);
        }

        @Nullable
        public static TweakMode get(String type) {
            return LOOKUP_TABLE.get(type);
        }
    }

    boolean runInsert(GenericInsertAnalyticsData iga, final View view);

    TweakMode getInsertType();
}
