package sdk.pendo.io.models;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.actions.AppCommandHandler;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.GuidesConfigurationManager;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandParameterInjector;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertPreparationManager;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.AnalyticEventsManager;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.events.PassiveTriggersListener;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.logging.InsertRemoteDebug;
import sdk.pendo.io.logging.profiling.ProfilingManager;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.DeviceStateUtils;

import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_RECEIVED;
import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;
import static sdk.pendo.io.logging.profiling.ProfilingManager.ProfilerType.PERFORMANCE;

public class InitModel {

    @SerializedName("guides")
    private JsonArray mGuides;

    @SerializedName("configuration")
    private InitConfiguration mInitConfiguration;

    @SerializedName("guideActions")
    private JsonArray mGuideActions;

    public static final Object CACHE_LOCK = new Object();
    private static final String REMOTE_DEBUG_MESSAGES_TAG = "messages";
    private static final String REMOTE_DEBUG_INFO_TAG = "info";

    public InitConfiguration getInitConfiguration() {
        return mInitConfiguration;
    }

    public List<GuideModel> getGuideList() {
        List<GuideModel> guideModelList = new ArrayList<>();
        JsonArray guidesArray = mGuides;
        if (guidesArray != null) {
            for (JsonElement guide : guidesArray) {
                try {
                    GuideModel guideModel = Pendo.GSON.fromJson(guide.toString(), GuideModel.class);
                    guideModelList.add(guideModel);
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }
        return guideModelList;
    }

    public InitModel() {
    }

    public InitModel(GuideModel guideModel) {
        try {
            JsonArray guideArray = new JsonArray();
            if (guideModel.getActivations() == null) {
                setGuides(guideArray);
            } else {
                JsonElement guideModelElement = Pendo.GSON.toJsonTree(guideModel, GuideModel.class);
                guideArray.add(guideModelElement);
                setGuides(guideArray);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    public void init() {
        init(false);
    }

    public void init(boolean fromUserCache) {
        synchronized (CACHE_LOCK) {
            AppCommandHandler.getInstance().setApplicationCommands(mGuideActions);
            if (mInitConfiguration != null) {
                ScreenManager.INSTANCE
                        .setPolicy(
                                mInitConfiguration.getInitAnalyticsModel().isIncludePageViewTexts(),
                                mInitConfiguration.getInitAnalyticsModel().isIncludeFeatureClickTexts(),
                                mInitConfiguration.getInitAnalyticsModel().isIncludePageViewAccessibility(),
                                mInitConfiguration.getInitAnalyticsModel().isIncludeFeatureClickAccessibility());
                checkIfDebugRemoteNeededAndInit();
                GuidesConfigurationModel guidesConfigurationModel = mInitConfiguration.getGuidesConfigurationModel();
                if (guidesConfigurationModel != null) {
                    if (guidesConfigurationModel.getThrottlingConfigurationModel() != null) {
                        GuidesConfigurationManager.INSTANCE.setThrottlingConfiguration(guidesConfigurationModel.getThrottlingConfigurationModel());
                    }
                    if (guidesConfigurationModel.getLastStepSeenConfigurationModel() != null) {
                        GuidesConfigurationManager.INSTANCE.setLastStepSeenConfigurationModel(guidesConfigurationModel.getLastStepSeenConfigurationModel());
                    }
                }

            }

            if (mGuideActions != null) {
                GuideManager.INSTANCE.setGuideActions(InsertCommand.getInsertCommands(mGuideActions));
            }
            if (!InsertsManager.isInited()) {
                InsertsManager.init(new HashMap<String, InsertAction>());
            }
            // In case we are currently showing an insert
            // dismiss it before emptying the data.
            if (VisualInsertManager.getInstance().isAnyInsertShowing()) {
                InsertsManager.getInstance().dismissVisibleGuides();
            }

            // Check if already inited and loading from cache, if so we can ignore.
            if (GuideManager.INSTANCE.isInited() && fromUserCache) {
                InsertLogger.d("Inserts initialized and trying to load from cache, ignoring.");
                return;
            }

            for (GuideModel guide : getGuideList()) {
                for (int stepIndex = 0; stepIndex < guide.getSteps().size(); stepIndex++) {
                    StepGuideModel stepGuideModel = guide.getGuideStepModel(stepIndex);
                    if (stepGuideModel != null) {
                        String guideStepId = guide.getGuideStepId(stepIndex);
                        if (!guideStepId.equals(GuideModel.DEFAULT_GUIDE_STEP_ID)) {
                            InsertPreparationManager.getInstance().prepareGuideImages(stepGuideModel.getViews(), guideStepId);
                            ArrayList<String> imagesToDownload = InsertPreparationManager.getInstance().getImages(
                                    stepGuideModel.getViews());
                            if (imagesToDownload != null) {
                                InsertPreparationManager.getInstance().fetchImages(guideStepId, imagesToDownload);
                            }
                        }
                    }
                }
                ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
                if (VisualInsertManager.getInstance().getVisualInsert(guide.getGuideId()) != null) {
                    specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.SEEN_REASON,
                            TYPE_STRING,
                            VisualInsertManager.getInstance().getVisualInsert(guide.getGuideId()).getActivatedBy()));
                }
                if (!fromUserCache) {
                    InsertCommandParameterInjector.getInstance().addGenericParamsInjectAndDispatch(guide,
                            GUIDE_RECEIVED.eventType,
                            specificParams);
                }

                ProfilingManager.getInstance()
                        .mark(PERFORMANCE, AnalyticsEvent.GUIDE_RECEIVED.getValue()
                                + " " + guide.getGuideId());
            }

            // Moved from EventManager, this is unrelated to ActivationManager
            ActivationManager.INSTANCE.isInitedObservable().onNext(true);

            List<GuideModel> guideModelList = getGuideList();
            if (GuideManager.INSTANCE.isInited()) {
                GuideManager.INSTANCE.repopulateGuidesMapping(guideModelList);
            } else {
                GuideManager.INSTANCE.init(guideModelList);
            }

            ActivationManager.INSTANCE.restartWithGuides(guideModelList);

            if (mInitConfiguration != null) {
                AnalyticEventsManager.getInstance().setMainBufferParameters(mInitConfiguration.getInitAnalyticsModel());
                InsertLogger.d("Buffer and storage size params updated: "
                        + " bufferQueueSize = '" + AnalyticEventsManager.getInstance().getBufferQueueSize() + "'"
                        + " bufferDuration = '" + AnalyticEventsManager.getInstance().getBufferDurationInSeconds() + "'"
                        + " maxStorageSizeMB = '" + AnalyticEventsManager.getInstance().getMaxStorageSizeMB() + "'.");
            } else  {
                InsertLogger.d("Using default buffer and default storage size: "
                        + " bufferQueueSize = '" + AnalyticEventsManager.getInstance().getBufferQueueSize() + "'"
                        + " bufferDuration = '" + AnalyticEventsManager.getInstance().getBufferDurationInSeconds() + "'"
                        + " maxStorageSizeMB = '" + AnalyticEventsManager.getInstance().getMaxStorageSizeMB() + "'.");
            }

            if (ApplicationObservers.getInstance().getCurrentVisibleActivity() != null) {
                PassiveTriggersListener.INSTANCE.activityStateChange();
            }
        }
    }

    public void setGuides(JsonArray guides) {
        this.mGuides = guides;
    }

    private void checkIfDebugRemoteNeededAndInit() {
        DebugConfigurationModel debugConfigurationModel = mInitConfiguration.getDebugConfigurationModel();
        if (debugConfigurationModel != null) {
            final InsertRemoteDebug insertRemoteDebug = InsertRemoteDebug.getInstance();
            insertRemoteDebug.setRefreshInterval(debugConfigurationModel.getRefreshIntervalMs());
            // Tell timber to start logging.
            insertRemoteDebug.clearRemoteDebugInfo();
            insertRemoteDebug.setIsRefreshIntervalSet(true);
            Observable.interval(insertRemoteDebug.getRefreshInterval(), TimeUnit.SECONDS, Schedulers.io())
                    .subscribe(InsertObserver.create(new Consumer<Long>() {
                        @Override
                        public void accept(Long aLong) {
                            try {
                                // Get insert logging info for the last "refreshInterval" milliseconds.
                                JSONObject jsonToSend = new JSONObject();
                                JSONArray loggingInfoArray = insertRemoteDebug.getRemoteDebuggingInfoAsJSONArray();
                                insertRemoteDebug.clearRemoteDebugInfo();
                                JSONObject deviceState = DeviceStateUtils.constructDeviceInfo();
                                jsonToSend.put(REMOTE_DEBUG_MESSAGES_TAG, loggingInfoArray);
                                jsonToSend.put(REMOTE_DEBUG_INFO_TAG, deviceState);
                                //Send here to server.
                                BackendApiManager.getInstance().sendDebugData(jsonToSend);
                            } catch (Exception e) {
                                InsertLogger.e(e, e.getMessage());
                            }
                        }
                    }));
        }
    }
}
