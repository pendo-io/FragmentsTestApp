package sdk.pendo.io.actions.configurations;

/**
 * Pendo's value and type class from JSON.
 *
 * Created by Nir on 6/14/15.
 */
public final class InsertTypeValue {

    public int value;
    public String type;
}
