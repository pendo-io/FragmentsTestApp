package sdk.pendo.io.reactive.filters;

import java.util.Set;

import io.reactivex.functions.Function;

/**
 * Filters redundant screens.
 *
 * Created by assaf on 10/11/15.
 */
public final class AppSpecificAnalyticsActivitiesDataFilter implements Function<String, Boolean> {

    private final Set<String> mActivityNames;

    public AppSpecificAnalyticsActivitiesDataFilter(Set<String> activityNames) {
        mActivityNames = activityNames;
    }

    @Override
    public Boolean apply(String activity) {
        return mActivityNames.contains(activity);
    }
}
