package sdk.pendo.io.information.collectors.device

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.support.annotation.RequiresPermission
import org.json.JSONObject
import sdk.pendo.io.Pendo
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.utilities.AndroidUtils
import sdk.pendo.io.utilities.MockUtils
import sdk.pendo.io.utilities.add

/**
 * Collect information about the networks.<br></br>
 * **Requires: ACCESS_NETWORK_STATE permission.**

 * Created by assaf on 4/14/15.
 */
internal class Network : Collector() {

    @SuppressLint("MissingPermission")
    override fun collectData(json: JSONObject) {

        // Add network information (if possible).
        addNetworksInfo(json)
    }

    /**
     * Adds JSON representing the device network info (if possible). <br></br>
     * This requires the ACCESS_NETWORK_STATE permission.
     * @param info The JSONObject to receive the device network info.
     */
    @RequiresPermission(value = Manifest.permission.ACCESS_NETWORK_STATE)
    @SuppressLint("MissingPermission")
    private fun addNetworksInfo(info: JSONObject) {

        val cm = application!!.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // Check that the connectivity manager is not null and that the application was granted
        // the ACCESS_NETWORK_STATE permission.
        if (AndroidUtils.isPermissionGranted(Manifest.permission.ACCESS_NETWORK_STATE)) {
            val netInfo = JSONObject()
            val activeNetworkInfo = cm.activeNetworkInfo
            netInfo.add(DeviceInfoConstants.Network.NET_ROAMING, activeNetworkInfo.isRoaming)
            netInfo.add(DeviceInfoConstants.Network.NET_TYPE, activeNetworkInfo.typeName)

            getWifiMacAddress(info, netInfo)
        }
    }

    @RequiresPermission(value = Manifest.permission.ACCESS_WIFI_STATE)
    @SuppressLint("MissingPermission")
    private fun getWifiMacAddress(info: JSONObject, netInfo: JSONObject) {
        if (AndroidUtils.isPermissionGranted(Manifest.permission.ACCESS_WIFI_STATE)) {
            val wifiMan = application!!.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiInf = wifiMan.connectionInfo
            val macAddr = wifiInf.macAddress

            // Mock WIFI MAC address for debug.
            if (Pendo.isDebugLogEnabled()) {
                netInfo.add(DeviceInfoConstants.Network.WIFI_MAC, MockUtils.getMockMACAddress())
            } else {
                netInfo.add(DeviceInfoConstants.Network.WIFI_MAC, macAddr)
            }
        }

        info.add(DeviceInfoConstants.Network.NETWORK, netInfo)
    }
}
