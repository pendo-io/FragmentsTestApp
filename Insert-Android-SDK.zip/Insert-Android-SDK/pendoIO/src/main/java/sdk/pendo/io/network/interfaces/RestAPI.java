package sdk.pendo.io.network.interfaces;

import android.net.Uri;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import external.sdk.pendo.io.okhttp3.Interceptor;
import external.sdk.pendo.io.okhttp3.OkHttpClient;
import external.sdk.pendo.io.okhttp3.Request;
import external.sdk.pendo.io.okhttp3.Response;
import external.sdk.pendo.io.retrofit2.Retrofit;
import external.sdk.pendo.io.rxjava2.RxJava2CallAdapterFactory;
import io.reactivex.Observable;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.CertificatePinningTrustManager;
import sdk.pendo.io.network.OkHttpClientRetryInterceptor;
import sdk.pendo.io.network.responses.converters.gson.InsertGsonConverterFactory;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.InsertEndpointUtil;
import sdk.pendo.io.utilities.SettingsUtils;


/**
 * Pendo REST API AnalyticsProperties.
 *
 * Created by assaf on 4/29/15.
 */
public final class RestAPI {

    public static final String REST_API_VERSION = "2";

    private static final Object LOCK = new Object();
    private static final Object LOCK_API_ENDPOINT = new Object();

    private static final String PENDO_AUTH_TOKEN_ID = "Authorization";
    private static final String PENDO_AUTH_BEARER = "Bearer ";

    private static final String PENDO_APP_KEY = "X-Pendo-App-Key";
    private static final String PENDO_APPLICATION_ID_HEADER_KEY = "X-Pendo-App-ID";
    private static final String PENDO_APPLICATION_VER_HEADER_KEY = "X-Pendo-App-Ver";
    private static final String PENDO_APPLICATION_VER_CODE_HEADER_KEY = "X-Pendo-App-Ver-Code";
    private static final String PENDO_DEVICE_TIME = "X-Pendo-Device-Time";
    private static final String PENDO_SDK_VER_HEADER_KEY = "X-Pendo-SDK-Ver";
    private static final String PENDO_DEVICE_ID_HEADER_KEY = "X-Pendo-Device-ID";
    private static final String PENDO_OS = "X-Pendo-OS";
    private static final String PENDO_OS_Version = "X-Pendo-OS-Version";
    /**
     *  New visitor ands account id's headers, replacing the now deprecated original non base64
     *  encoded headers
     *
     *    private static final String PENDO_VISITOR_ID_HEADER_KEY = "X-Pendo-Visitor-Id";
     *    private static final String PENDO_ACCOUNT_ID_HEADER_KEY = "X-Pendo-Account-Id";
     */
    private static final String PENDO_VISITOR_ID_ENCODED_HEADER_KEY = "X-Pendo-Encoded-Visitor-Id";
    private static final String PENDO_ACCOUNT_ID_ENCODED_HEADER_KEY = "X-Pendo-Encoded-Account-Id";


    /* Interceptor Constants.*/
    private static final long CONNECT_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(30);
    private static final long READ_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(30);
    public static final long INIT_TIMEOUT_MILLIS = TimeUnit.SECONDS.toMillis(40);

    /* We use char array here so we can wipe it from memory, and so it will not linger in memory. */
    private static volatile String sAccessToken;
    private static BehaviorSubject<String> sAccessTokenSubject = BehaviorSubject.create();
    private static BehaviorSubject<Boolean> sNetworkInited = BehaviorSubject.createDefault(false);
    private static Interceptor sInterceptor = new OkHttpClientRetryInterceptor();

    private static volatile Uri sApiEndpoint;
    private static volatile Uri sAnalyticsEndpoint;
    private static volatile Retrofit.Builder sAccessTokenRetrofitBuilder;
    private static volatile Retrofit.Builder sGeneralRetrofitBuilder;

    private RestAPI() { }

    public static Observable<String> getAccessTokenObservable() {
        return sAccessTokenSubject;
    }

    public static String getAccessToken() {
        return sAccessToken;
    }

    public static void setAccessToken(String accessToken) {
        sAccessToken = accessToken;
        sAccessTokenSubject.onNext(accessToken);
    }

    public static Observable<Boolean> getNetworkInitedObservable() {
        return sNetworkInited;
    }

    public static Boolean getNetworkInited() {
        return sNetworkInited.getValue();
    }

    public static void setNetworkInited(Boolean networkInited) {
        sNetworkInited.onNext(networkInited);
    }

    public static void addCommonHeadersToRequest(Request.Builder request) {

        addTestingIdIfNeeded(request);

        String visitorId = Pendo.getVisitorId();
        if (visitorId != null && !visitorId.isEmpty()) {
            request.addHeader(PENDO_VISITOR_ID_ENCODED_HEADER_KEY, AndroidUtils.encodeToBase64(visitorId));
        }

        String accountId = Pendo.getAccountId();
        if (accountId != null && !accountId.isEmpty()) {
            request.addHeader(PENDO_ACCOUNT_ID_ENCODED_HEADER_KEY, AndroidUtils.encodeToBase64(accountId));
        }

        // Add device time.
        String deviceTime = Long.toString(System.currentTimeMillis());
        request.addHeader(PENDO_DEVICE_TIME, deviceTime);
        request.addHeader(PENDO_OS, AndroidUtils.OS_NAME);

        String sdkVersion = SettingsUtils.getSDKVersion();
        if (sdkVersion != null) {
            request.addHeader(PENDO_SDK_VER_HEADER_KEY, sdkVersion);
        }

        String deviceId = AndroidUtils.getDeviceId();
        if (deviceId != null) {
            request.addHeader(PENDO_DEVICE_ID_HEADER_KEY, deviceId);
        } else {
            InsertLogger.w("device id is null!");
        }

        String appKey = Pendo.getAppKey();
        if (appKey != null) {
            request.addHeader(PENDO_APP_KEY, appKey);
        }

        String appVersionName = AndroidUtils.getAppVersionName();
        if (appVersionName != null) {
            request.addHeader(PENDO_APPLICATION_VER_HEADER_KEY, appVersionName);
        }

        String appVersionCode = String.valueOf(AndroidUtils.getAppVersionCode());
        if (appVersionCode != null) {
            request.addHeader(PENDO_APPLICATION_VER_CODE_HEADER_KEY, appVersionCode);
        }

        String osVersion = AndroidUtils.OS_VERSION;
        if (osVersion != null){
            request.addHeader(PENDO_OS_Version, osVersion);
        }
    }

    /**
     *  In case we are in a testing mode we are using the
     *  app id header to identify the app in the mock server
     * @param request the request which should be updated
     */
    private static void addTestingIdIfNeeded(Request.Builder request) {
        final String appIdForTesting = SettingsUtils.getAppIdForTesting(Pendo.getApplicationContext());
        if (!TextUtils.isEmpty(appIdForTesting)) {
            request.addHeader(PENDO_APPLICATION_ID_HEADER_KEY, appIdForTesting);
        }
    }


    public static final Interceptor INSERT_REQUEST_INTERCEPTOR = new Interceptor() {
        @Override
        public Response intercept(Chain chain) throws IOException {
            final Request.Builder requestBuilder = chain.request().newBuilder();
            addCommonHeadersToRequest(requestBuilder);

            String accessToken = getAccessToken();
            if (accessToken != null) {
                requestBuilder.addHeader(PENDO_AUTH_TOKEN_ID, PENDO_AUTH_BEARER + accessToken);
            }

            return chain.proceed(requestBuilder.build());
        }
    };

    public static final Interceptor INSERT_GET_ACCESS_TOKEN_REQUEST_INTERCEPTOR =
            new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    final Request.Builder requestBuilder = chain.request().newBuilder();
                    addCommonHeadersToRequest(requestBuilder);
                    return chain.proceed(requestBuilder.build());
                }
            };

    public static OkHttpClient getBaseOkHttpClient() {
        return getOkHttpClientBuilder().build();
    }

    private static Retrofit.Builder getRetrofitBuilder(boolean isGetAccessTokenRequest,
                                                          String endpointUrl) {
        return getRetrofitBuilder(isGetAccessTokenRequest, endpointUrl, false);
    }

    private static Retrofit.Builder getRetrofitBuilder(boolean isGetAccessTokenRequest,
                                                          String endpointUrl,
                                                          boolean forceNew) {
        synchronized (LOCK) {
            Retrofit.Builder retrofitBuilder = new Retrofit.Builder();
            OkHttpClient.Builder okHttpClientBuilder = getOkHttpClientBuilder();

            if (isGetAccessTokenRequest) {
                if (sAccessTokenRetrofitBuilder != null && !forceNew) {
                    return sAccessTokenRetrofitBuilder;
                }

                okHttpClientBuilder.addInterceptor(INSERT_GET_ACCESS_TOKEN_REQUEST_INTERCEPTOR);

            } else {
                if (sGeneralRetrofitBuilder != null && !forceNew) {
                    //We set the baseurl every time to avoid returning a cached instance with a wrong baseurl.
                    return sGeneralRetrofitBuilder.baseUrl(endpointUrl);
                }

                okHttpClientBuilder.addInterceptor(INSERT_REQUEST_INTERCEPTOR);
            }

            final HttpLoggingInterceptor.Level logLevel = getLogLevel();
            if (!logLevel.equals(HttpLoggingInterceptor.Level.NONE)) {
                HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
                loggingInterceptor.setLevel(logLevel);
                okHttpClientBuilder.addInterceptor(loggingInterceptor);
            }

            okHttpClientBuilder.connectTimeout(CONNECT_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS);
            okHttpClientBuilder.readTimeout(READ_TIMEOUT_MILLIS, TimeUnit.MILLISECONDS);
            okHttpClientBuilder.interceptors().add(sInterceptor);

            retrofitBuilder
                    .client(okHttpClientBuilder.build())
                    .addConverterFactory(InsertGsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .baseUrl(endpointUrl);

            setRetrofit(isGetAccessTokenRequest, retrofitBuilder);

            return retrofitBuilder;
        }
    }

    private static synchronized void setRetrofit(boolean isGetAccessTokenRequest,
                                                    Retrofit.Builder retrofitBuilder) {
        if (isGetAccessTokenRequest) {
            if (sAccessTokenRetrofitBuilder == null) {
                sAccessTokenRetrofitBuilder = retrofitBuilder;
            }
        } else {
            if (sGeneralRetrofitBuilder == null) {
                sGeneralRetrofitBuilder = retrofitBuilder;
            }
        }
    }

    private static OkHttpClient.Builder getOkHttpClientBuilder() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.certificatePinner(CertificatePinningTrustManager.getCertificatePinner());
        return builder;
    }


    private static HttpLoggingInterceptor.Level getLogLevel() {
        return Pendo.isDebugLogEnabled()
                ? HttpLoggingInterceptor.Level.BODY : HttpLoggingInterceptor.Level.NONE;
    }

    public static Retrofit getRetrofitRegister() {

        return getRetrofitWithGsonConverter(InsertGsonConverterFactory.create(
                new GsonBuilder().disableHtmlEscaping().create()), false);
    }

    public static Retrofit getRetrofitGetAccessToken() {
        Uri apiEndpoint = getApiEndpoint();
        if (apiEndpoint == null) { return null; }
        return getRetrofitBuilder(true,  apiEndpoint.toString()).build();
    }

    public static Retrofit getRetrofitGetInserts() {
        Uri apiEndpoint = getApiEndpoint();
        if (apiEndpoint == null) { return null; }
        return getRetrofitBuilder(false, apiEndpoint.toString()).build();
    }

    @Nullable
    public static Retrofit.Builder getAnalyticsRetrofitBuilder() {
        Uri analyticsEndpoint = getAnalyticsEndpoint();
        if (analyticsEndpoint == null) { return null; }
        return getRetrofitBuilder(false, analyticsEndpoint.toString());
    }

    @Nullable
    public static Retrofit getAnalyticsRetrofit() {
        Retrofit.Builder analyticsRetrofitBuilder = getAnalyticsRetrofitBuilder();
        if (analyticsRetrofitBuilder == null) { return null; }
        return analyticsRetrofitBuilder.build();
    }

    public static Retrofit.Builder getSetupActionRetrofitBuilder() {
        Uri apiEndpoint = getApiEndpoint();
        if (apiEndpoint == null) { return null; }
        return getRetrofitBuilder(false, apiEndpoint.toString());
    }

    public static Retrofit getRetrofitWithGsonConverter(InsertGsonConverterFactory gsonConverter,
                                                           boolean isGetAccessTokenRequest) {
        Uri apiEndpoint = getApiEndpoint();
        if (apiEndpoint == null) { return null; }
        return getRetrofitBuilder(false, getApiEndpoint().toString(), true)
                .addConverterFactory(gsonConverter).build();
    }

//    @Nullable
//    public static Retrofit getRetrofitWithGsonConverter(InsertGsonConverter gsonConverter, boolean isGetAccessTokenRequest) {
//
//        return getRetrofitBuilder(isGetAccessTokenRequest, getApiEndpoint().toString()).setConverter(gsonConverter).build();
//    }

    public static Uri getApiEndpoint() {

        Uri result = sApiEndpoint;

        if (result == null) { // 1st check (no lock)
            synchronized (LOCK_API_ENDPOINT) {
                result = sApiEndpoint;
                if (result == null) { // 2nd check (w/ lock)
                    sApiEndpoint = result = InsertEndpointUtil.INSTANCE.calculateApiEndpoint();
                }
                InsertLogger.d("API Endpoint: " + result.toString());
            }
        }

        return result;
    }

    private static Uri getAnalyticsEndpoint() {
        Uri result = sAnalyticsEndpoint;

        if (result == null) { // 1st check (no lock)
            synchronized (LOCK_API_ENDPOINT) {
                result = sAnalyticsEndpoint;
                if (result == null) { // 2nd check (w/ lock)
                    sAnalyticsEndpoint = result = InsertEndpointUtil.INSTANCE.calculateAnalyticsEndpoint();
                }
                InsertLogger.d("Analytics Endpoint: " + result.toString());
            }
        }
        return result;
    }
}
