package sdk.pendo.io.views.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;


import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jakewharton.rxbinding3.view.RxView;
import com.trello.rxlifecycle3.android.RxLifecycleAndroid;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandFormAction.SET_VALUE_FOR_KEY;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandFormAction.SUBMIT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandFormAction.UPDATE;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_INVALID;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_SUBMIT;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_VALID;
import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONFIGURATION;


/**
 * Pendo's form layout, extends LinearLayout.
 * <p/>
 * Created by assaf on 8/27/15.
 */// TODO: 8/30/15 Add support for non-LinearLayouts.
@SuppressWarnings("unused")
public final class InsertForm
        extends InsertLinearLayout
        implements ViewBaseScriptBridge.FormScriptBridge {

    public static final String ADDITIONAL_INFO_RADIO_BUTTON_INPUT = "radioButtonInput";
    public static final String ADDITIONAL_INFO_TEXT_FIELD_INPUT = "textFieldInput";
    public static final String ADDITIONAL_INFO_KEY_VALUES_INPUT = "keyValuesInput";
    public static final String ADDITIONAL_INFO_TEXT_FIELD_ID = "textFieldId";
    public static final String ADDITIONAL_INFO_TEXT_FIELD_VALUE = "value";
    public static final String ADDITIONAL_INFO_BUTTON_GROUP_ID = "buttonGroupId";
    public static final String ADDITIONAL_INFO_SELECTED_BUTTON_ID = "selectedButtonId";

    private String mInsertId;
    private Set<String> mMandatory = new HashSet<>();
    private HashMap<String, Pair<Class, String>> mUserInput = new HashMap<>();
    private Disposable mSubmitterSubscription;
    private Disposable mFormUpdatedSubscription;

    @Override
    public JSONObject getAnswers() {
        return getFormAdditionalInfo();
    }

    @Override
    public ViewBaseScriptBridge getViewScriptBridge() {
        return this;
    }

    @Override
    public String getType() {
        return ViewBaseScriptBridgeUtils.getType(this);
    }

    private Consumer<InsertCommand> mSubmitObserver = new Consumer<InsertCommand>() {
        @Override
        public void accept(InsertCommand insertCommand) {
            InsertLogger.d(insertCommand.toString());
            if (isValid()) {
                JavascriptRunner.InsertContext.addBasicParamsToInsertCommands(mCommands);
                InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, ON_SUBMIT, true);
            }
        }
    };

    private Consumer<InsertCommand> mFormUpdatedObserver = new Consumer<InsertCommand>() {
        @Override
        public void accept(InsertCommand insertCommand) {
            try {
                InsertLogger.d(insertCommand.toString());

                // User has interacted with the form, let's cancel the insert's timeout if it exists.
                if (!mInsertId.isEmpty()) {
                    VisualInsertManager.getInstance().getVisualInsert(mInsertId).cancelTimeout(true);
                }

                if (mCommands == null) {
                    InsertLogger.e("No commands for the form!");
                    return;
                }

                final List<InsertCommandsEventBus.Parameter> parameters =
                        insertCommand.getParameters();

                if (SET_VALUE_FOR_KEY.equals(insertCommand.getAction())) {

                    if (parameters == null) {
                        InsertLogger.e("Parameters are null for SET_VALUE_FOR_KEY.");
                        return;
                    }

                    try {
                        String key = InsertCommandsEventBus.Parameter
                                .getParameterValue(parameters, "key", String.class);

                        String value = InsertCommandsEventBus.Parameter
                                .getParameterValue(parameters, "value", String.class);

                        mUserInput.put(key, Pair.create((Class) Map.class, value));

                        isValid();

                    } catch (NoSuchFieldException e) {
                        InsertLogger.e(e, e.getMessage());
                    }
                } else { // Update.

                    final String sourceId = insertCommand.getSourceId();

                    if (sourceId == null) {
                        InsertLogger.w("Source id is null!");
                        return;
                    }

                    ArrayList<View> outViews = new ArrayList<>();
                    findViewsWithText(outViews, sourceId,
                            View.FIND_VIEWS_WITH_CONTENT_DESCRIPTION);

                    // Filter views that doesn't match this exact text.
                    Utils.filterList(outViews, new Utils.Predicate<View>() {
                        @Override
                        public boolean test(View view) {
                            return !sourceId.equals(view.getContentDescription().toString());
                        }
                    });

                    if (outViews.isEmpty()) {
                        InsertLogger.d("Didn't find source view for id: " + sourceId);
                    } else if (outViews.size() > 1) {
                        InsertLogger.w("Found '" + outViews.size() + "' source view for id: "
                                + sourceId);
                    } else {

                        View view = outViews.get(0);
                        String answerId = null;
                        Class klass = null;
                        if (view instanceof RadioGroup) {
                            try {
                                final RadioGroup radioGroup = (RadioGroup) view;
                                final int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();

                                if (checkedRadioButtonId == View.NO_ID) {
                                    InsertLogger.w("No selected radio button.");
                                    return;
                                }

                                final View checkedRadioButton =
                                        radioGroup.findViewById(checkedRadioButtonId);

                                if (checkedRadioButton == null) {
                                    InsertLogger
                                            .w("Could not find the selected radio button in the group!");
                                    return;
                                }

                                answerId = checkedRadioButton.getContentDescription().toString();
                                klass = RadioGroup.class;

                            } catch (Exception e) {
                                InsertLogger.e(e, e.getMessage());
                            }
                        } else if (view instanceof EditText) {
                            EditText editText = (EditText) view;
                            final Editable text = editText.getText();

                            if (!TextUtils.isEmpty(text)) {
                                answerId = text.toString();
                                klass = EditText.class;
                            } else {
                                mUserInput.remove(sourceId);
                            }
                        } else if (view instanceof InsertIoRatingBar) {
                            InsertIoRatingBar ratingControl = (InsertIoRatingBar) view;
                            final int rating = ratingControl.getAnalyticsRating();

                            if (rating != -1) {
                                answerId = Integer.toString(rating);
                                klass = InsertIoRatingBar.class;
                            } else {
                                mUserInput.remove(sourceId);
                            }
                        }

                        // Save the user's input.
                        if (!TextUtils.isEmpty(answerId)) {
                            mUserInput.put(sourceId, Pair.create(klass, answerId));
                        } else {
                            InsertLogger.d("Not saving answer."
                                    + " Answer is null: '" + TextUtils
                                    .isEmpty(answerId) + "'"
                                    + " Class is: '" + klass + "'"
                                    + " View is: '"
                                    + (view == null ? "null" : view.getClass()
                                    .getCanonicalName())
                                    + "'.");
                        }

                        isValid();
                    }
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

    };

    public boolean isValid() {

        if (mCommands == null) {
            return false;
        }

        // If there are no mandatory fields, the form is valid.
        if (mMandatory.isEmpty()) {
            InsertCommandDispatcher.getInstance()
                    .dispatchCommands(mCommands, ON_VALID, true);
            return true;
        }

        final Set<String> userInputIds = mUserInput.keySet();

        if (userInputIds.containsAll(mMandatory)) {
            InsertCommandDispatcher.getInstance()
                    .dispatchCommands(mCommands, ON_VALID, true);
            return true;

        } else {
            InsertCommandDispatcher.getInstance()
                    .dispatchCommands(mCommands, ON_INVALID, true);
            return false;
        }
    }

    private List<InsertCommand> mCommands;

    public InsertForm(Context context) {
        this(context, null);
    }

    public InsertForm(Context context, AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public InsertForm(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public InsertForm(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public void processForm(JsonObject form, List<InsertCommand> commands, String insertId) {
        mCommands = commands;
        mInsertId = insertId;
        processFormQuestions(form);
    }

    @Override
    protected void onAttachedToWindow() {

        final CharSequence contentDescription = getContentDescription();
        if (contentDescription != null) {
            subscribeOnSubmit(contentDescription.toString());
            subscribeFormUpdated(contentDescription.toString());

            RxView.globalLayouts(this)
                    .compose(RxLifecycleAndroid.bindView(this))
                    .subscribe(InsertObserver.create(
                            new Consumer<Object>() {
                        @Override
                        public void accept(Object aVoid) {
                            isValid();
                        }
                    }));
        }

        super.onAttachedToWindow();
    }

    private void subscribeOnSubmit(String destinationId) {

        unsubscribeSubmitter();

        final Predicate<InsertCommand> filter = InsertCommand.createFilter(
                InsertCommand.COMMAND_STRING_ANY,
                destinationId,
                SUBMIT,
                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

        mSubmitterSubscription = InsertCommandsEventBus.getInstance()
                .subscribe(RxLifecycleAndroid.<InsertCommand>bindView(this), filter, mSubmitObserver);
    }

    private void subscribeFormUpdated(String destinationId) {

        unsubscribeFormUpdated();

        LinkedList<InsertCommandAction> actions = new LinkedList<>();

        actions.add(UPDATE);
        actions.add(SET_VALUE_FOR_KEY);

        final Predicate<InsertCommand> filter = InsertCommand.createFilter(
                InsertCommand.COMMAND_STRING_ANY,
                destinationId,
                actions,
                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY);

        mFormUpdatedSubscription = InsertCommandsEventBus.getInstance()
                .subscribe(RxLifecycleAndroid.<InsertCommand>bindView(this), filter,
                           mFormUpdatedObserver);
    }

    public void setSubmitButton(VisualActionButton submitButton) {

    }

    private void unsubscribeSubmitter() {
        if (mSubmitterSubscription != null && !mSubmitterSubscription.isDisposed()) {
            mSubmitterSubscription.dispose();
        }
    }

    private void unsubscribeFormUpdated() {
        if (mFormUpdatedSubscription != null
                && !mFormUpdatedSubscription.isDisposed()) {
            mFormUpdatedSubscription.dispose();
        }
    }

    private void processFormQuestions(@NonNull JsonObject jsonObject) {

        final String widget = JsonUtils.optString(jsonObject, InsertActionConfiguration.GUIDE_SCREEN_WIDGET);
        final JsonArray properties = JsonUtils.optJsonArray(
                jsonObject, InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);

        if (widget == null || properties == null) {
            return;
        }

        JSONArray mandatory = null;
        for (int i = 0; i < properties.size(); i++) {
            final JsonObject prop = JsonUtils.optJsonObject(properties, i);

            if (prop != null && "mandatory_fields".equals(JsonUtils.optString(prop, "name"))) {
                try {
                    mandatory = new JSONArray(JsonUtils.optString(prop, "value"));
                } catch (JSONException e) {
                    InsertLogger.d(e.getMessage());
                }
            }

            if (mandatory != null) {
                break;
            }
        }

        if (mandatory != null) {
            for (int i = 0; i < mandatory.length(); i++) {
                try {
                    mMandatory.add(mandatory.getString(i));
                } catch (JSONException e) {
                    InsertLogger.w(e, e.getMessage());
                }
            }
        }
    }

    private JSONObject getFormAdditionalInfo() {

        JSONObject additionalInfo = new JSONObject();

        JSONArray rAnswers = new JSONArray();
        JSONArray eAnswers = new JSONArray();
        JSONArray mAnswers = new JSONArray();

        for (Map.Entry<String, Pair<Class, String>> entry : mUserInput.entrySet()) {
            JSONObject userInputs = new JSONObject();
            try {
                String elementIdOrKey = entry.getKey();
                final Pair<Class, String> inputPair = entry.getValue();

                final Class aClass = inputPair.first;
                final String answer = inputPair.second;
                if (RadioGroup.class.equals(aClass) || InsertIoRatingBar.class.equals(aClass)) {

                    userInputs.put(ADDITIONAL_INFO_BUTTON_GROUP_ID, elementIdOrKey);
                    userInputs.put(ADDITIONAL_INFO_SELECTED_BUTTON_ID, answer);
                    rAnswers.put(userInputs);
                } else if (EditText.class.equals(aClass)) {

                    userInputs.put(ADDITIONAL_INFO_TEXT_FIELD_ID, elementIdOrKey);
                    userInputs.put(ADDITIONAL_INFO_TEXT_FIELD_VALUE, answer);
                    eAnswers.put(userInputs);
                } else if (Map.class.equals(aClass)) {
                    userInputs.put(elementIdOrKey, answer);
                    mAnswers.put(userInputs);
                }
            } catch (Exception e) {
                InsertLogger.w(e, e.getMessage());
            }
        }

        try {
            if (rAnswers.length() > 0) {
                additionalInfo.put(ADDITIONAL_INFO_RADIO_BUTTON_INPUT, rAnswers);
            }

            if (eAnswers.length() > 0) {
                additionalInfo.put(ADDITIONAL_INFO_TEXT_FIELD_INPUT, eAnswers);
            }

            if (mAnswers.length() > 0) {
                additionalInfo.put(ADDITIONAL_INFO_KEY_VALUES_INPUT, mAnswers);
            }

            final CharSequence contentDescription = getContentDescription();
            if (TextUtils.isEmpty(contentDescription)) {
                AnalyticsUtils
                        .sendErrorReport(ERROR_REASON_CONFIGURATION,
                                         "No content description for element id.");
            } else {
                additionalInfo.put(AnalyticsProperties.ELEMENT_ID, contentDescription);
            }
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
        return additionalInfo;
    }
}
