package sdk.pendo.io.views.custom;

/**
 * Interface for views which require their background rendered
 * only after all of their child views have been created and this
 * view's final width and height have been measured (e.g to load
 * a background image with the correct and final dimensions).
 *
 * Created by itayvallach on 09/10/2016.
 */
public interface IBackgroundRenderView extends InsertCustomView {

    void setImageBackgroundURL(String url);

    void setImageFillType(String fillType);

    void renderBackground();
}
