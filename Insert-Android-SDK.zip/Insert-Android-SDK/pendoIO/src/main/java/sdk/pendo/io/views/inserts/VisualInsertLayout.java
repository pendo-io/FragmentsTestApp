package sdk.pendo.io.views.inserts;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.lang.ref.WeakReference;

import external.sdk.pendo.io.dynamicview.DynamicView;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.exceptions.DynamicViewException;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.ActivityUtils;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.utilities.ViewUtils;
import sdk.pendo.io.views.InsertViewHolder;
import sdk.pendo.io.views.custom.IBackgroundRenderView;

import static android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
import static android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.actions.InsertCommandDispatcher.PredefinedCommands.BACK_PRESSED;

/**
 * Visual Pendo.
 * <p/>
 * Created by assaf on 4/15/15.
 */
public class VisualInsertLayout extends FrameLayout {

    private WeakReference<Activity> mSavedActivity;
    private WeakReference<WindowManager.LayoutParams> mSavedWinParams;
    private String mGuideStepId;
    private String mGuideId;
    private VisualInsert.VisualInsertType mVisualInsertType;
    private boolean mForceNoPadding = false;

    public VisualInsertLayout(Context context, boolean forceNoPadding) {
        super(context);
        mForceNoPadding = forceNoPadding;
        avoidDrawBelowStatusBar();
    }

    public VisualInsertLayout(Context context) {
        this(context, null);
    }

    public VisualInsertLayout(Context context, AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public VisualInsertLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onFinishInflate() {
        try {
            super.onFinishInflate();
            if (!VisualInsert.VisualInsertType.BANNER.equals(mVisualInsertType)) {
                // Those operations are need so it will get the back key
                setFocusableInTouchMode(true);
                requestFocus();
                setClickable(true);
                setFocusable(true);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    @Nullable
    public View inflateView(JsonObject jsonScreen,
                            ViewGroup parent,
                            String guideId,
                            String stepId,
                            VisualInsert.VisualInsertType visualInsertType)
            throws DynamicViewException {
        mGuideId = guideId;
        mGuideStepId = stepId;
        mVisualInsertType = visualInsertType;

        avoidDrawBelowStatusBar();

        try {
            final JsonElement screenContents = InsertActionConfiguration
                    .getScreenContents(jsonScreen);
            if (screenContents == null || !screenContents.isJsonObject()) {
                InsertLogger.w("Cannot inflate the main screen, bad content.");
                return null;
            }

            View content = this;
            final Context context = content.getContext();
            View viewFromJson = DynamicView.createView(
                    context,
                    screenContents.getAsJsonObject(), parent,
                    InsertViewHolder.class, guideId, mGuideStepId);

            if (viewFromJson != null) {

                // Finished creating the whole Pendo view with all child views, now we have
                // every view's dimensions and we are ready to render the views' backgrounds.
                renderBackgroundIfNeeded(viewFromJson);
                addView(viewFromJson);
            } else {
                throw new DynamicViewException("Couldn't create a view out of JSON.");
            }

            return viewFromJson;

        } catch (Exception e) {
            if (e instanceof DynamicViewException) {
                throw e; // Rethrow.
            } else {
                InsertLogger.e(e, e.getMessage());
            }
        }

        return null;
    }

    /**
     * This method is called on the parent view of the insert once the whole insert view (including
     * all child views) has been created. Now that we have the final dimensions of each view, we can render
     * the backgrounds of views that need it.
     * @param parentView - the parent view of the Pendo.
     */
    public void renderBackgroundIfNeeded(View parentView) {
        if (parentView instanceof IBackgroundRenderView) {
            ((IBackgroundRenderView) parentView).renderBackground();
        }

        // Recursively traverse through the Pendo's view hierarchy.
        if (parentView instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) parentView).getChildCount(); ++i) {
                renderBackgroundIfNeeded(((ViewGroup) parentView).getChildAt(i));
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        setFocusableInTouchMode(false);

        if (mSavedActivity != null && mSavedWinParams != null) {
            final Activity activity = mSavedActivity.get();
            final WindowManager.LayoutParams layoutParams = mSavedWinParams.get();

            if (activity != null && layoutParams != null) {
                activity.getWindow().setAttributes(layoutParams);
            }

            mSavedActivity = null;
            mSavedWinParams = null;
        }

        super.onDetachedFromWindow();
    }

    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        if (VisualInsert.VisualInsertType.BANNER.equals(mVisualInsertType)) {
            return false;
        }
        return true;
    }

    private void avoidDrawBelowStatusBar() {

        // Ignore this if the insert is the banner.
        if (VisualInsert.VisualInsertType.BANNER.equals(mVisualInsertType)) {
            InsertLogger.d("Banner, ignoring statusbar padding.");
            return;
        }

        final Context context = getContext();
        Activity activity = ActivityUtils.getActivity(context);
        if (activity == null) {
            activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        }

        if (activity != null) {

            Window win = activity.getWindow();
            saveWindowAttributes(activity, win);
            WindowManager.LayoutParams winParams = win.getAttributes();

            winParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;

//            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//                final int systemUiVisibility = win.getDecorView().getSystemUiVisibility();
//                int drawBehindStatusBar = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
//
//                if ((systemUiVisibility & drawBehindStatusBar) == drawBehindStatusBar) {
//                    addTopPadding();
//                    return;
//                }
//            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                int behindStatusBar = WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
                        & FLAG_LAYOUT_IN_SCREEN;

                if (((winParams.flags & behindStatusBar) == behindStatusBar)) {
                    addCorrectionalPadding(
                            !GuideUtils.isInsertActivity(activity.getLocalClassName()));
                } else if ((winParams.flags & FLAG_TRANSLUCENT_STATUS) == FLAG_TRANSLUCENT_STATUS) {
                    addCorrectionalPadding(false);
                }

            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                if ((winParams.flags & FLAG_TRANSLUCENT_STATUS) == FLAG_TRANSLUCENT_STATUS
                    || (winParams.flags & FLAG_LAYOUT_IN_SCREEN) == FLAG_LAYOUT_IN_SCREEN) {
                    addCorrectionalPadding(false);
                }
            }
        }
    }

    private void saveWindowAttributes(Activity activity, Window win) {
        mSavedActivity = new WeakReference<>(activity);
        mSavedWinParams = new WeakReference<>(win.getAttributes());
    }

    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event) {
        if (!VisualInsert.VisualInsertType.BANNER.equals(mVisualInsertType)) {
            try {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    InsertCommand backPressedCommand = BACK_PRESSED;
                    backPressedCommand.setParameters(InsertInfoConsts.createInsertMetadataParams(mGuideId));
                    InsertCommandDispatcher.getInstance().dispatchCommand(backPressedCommand, true);
                    return true;
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return super.onKeyPreIme(keyCode, event);
    }

    /**
     * This method is called when the hosting activity set window flags that caused the activity to
     * draw views behind the status bar or navigation bar.
     *
     * @param navigationBarPadding set to true if adding padding for navigation bar is also needed.
     *        Targets the IDEV-4612 bug.
     */
    private void addCorrectionalPadding(boolean navigationBarPadding) {

        if (mForceNoPadding) {
            return;
        }

        int statusBarHeight = ViewUtils.getStatusBarHeight();
        int navigationBarHeight = 0;
        if (navigationBarPadding) {

            // Check to see if this device has a navigation bar.
            // TODO: 5/23/16 Should we store the value?
            boolean hasMenuKey = ViewConfiguration.get(getContext()).hasPermanentMenuKey();
            boolean hasBackKey = KeyCharacterMap.deviceHasKey(KeyEvent.KEYCODE_BACK);

            if (!hasMenuKey && !hasBackKey) {
                // This device has a navigation bar.
                navigationBarHeight = ViewUtils.getNavigationBarHeight();
            }
        }

        setPadding(0, statusBarHeight, 0, navigationBarHeight);
    }
}
