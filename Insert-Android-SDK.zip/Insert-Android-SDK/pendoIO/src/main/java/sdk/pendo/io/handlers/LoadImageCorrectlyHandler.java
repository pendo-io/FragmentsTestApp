package sdk.pendo.io.handlers;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.widget.ImageView;
import com.trello.rxlifecycle3.android.RxLifecycleAndroid;
import com.squareup.picasso.Transformation;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertPreparationManager;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.utilities.Optional;
import sdk.pendo.io.utilities.ViewUtils;

import static sdk.pendo.io.actions.InsertCommandAction.InsertInternalAction.IMAGES_SET;
import static sdk.pendo.io.actions.InsertCommandAction.InsertInternalAction.PREFETCH_IMAGES;
import static sdk.pendo.io.actions.InsertCommandEventType.InsertPreparationEventType.PREFETCH_IMAGES_END;

/**
 * Created by tomerlevinson on 6/6/16.
 *
 * This class is responsible for loading a given image via a url correctly to a supplied view.
 * This is done according to the following steps:
 *      o Get the image's sizes via an http url connection.
 *      o Find out the devices display metrics.
 *      o Load the image after being resized according to the metrics supplied.
 */
public final class LoadImageCorrectlyHandler {

    private String mInsertId;
    public static int mScreenWidth;
    public static int mScreenHeight;
    private static final String NO_INSERT_ID = "";
    private static final String IMAGE_FETCH_RESULT = "ImageFetchResult";
    private static final InsertCommandsEventBus.Parameter SUCCESS =
            new InsertCommandsEventBus.Parameter(IMAGE_FETCH_RESULT, "boolean", "true");
    private static final InsertCommandsEventBus.Parameter FAIL =
            new InsertCommandsEventBus.Parameter(IMAGE_FETCH_RESULT, "boolean", "false");

    /**
     *
     * @param currentCnxt The context we're running in
     * @param currentImageView the imageView we want to inject the bitmap into
     */
    public LoadImageCorrectlyHandler(Context currentCnxt,
                                     ImageView currentImageView, String url) {

        mInsertId = NO_INSERT_ID;
        startObserver((Activity) currentCnxt, currentImageView, url);
    }

    /**
     *
     * @param currentCnxt The context we're running in
     * @param currentImageView the imageView we want to inject the bitmap into
     * @param insertId the insert id.
     */
    public LoadImageCorrectlyHandler(Context currentCnxt, ImageView currentImageView,
                                     String url, String insertId) {
        mInsertId = insertId;
        startObserver((Activity) currentCnxt, currentImageView, url);
    }

    private void startObserver(final Activity currentCnxt, final ImageView currentImageView,
                               String url) {
        mScreenWidth = currentCnxt.getWindowManager().getDefaultDisplay().getWidth();
        mScreenHeight = currentCnxt.getWindowManager().getDefaultDisplay().getHeight();
        Observable.just(url)
                .subscribeOn(Schedulers.io())
                .map(new Function<String, Optional<Bitmap>>() {
                    @Override
                    public Optional<Bitmap> apply(String receivedUrl) {
                        try {
                            return new Optional<>(VisualInsert.picasso()
                                    .load(receivedUrl)
                                    .transform(getScreenDensityTransformation(currentImageView.getWidth(), currentImageView.getHeight()))
                                    .get());
                        } catch (Exception e) {
                            InsertLogger.e(e, e.getMessage());
                        }

                        return new Optional<>(null);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .compose(RxLifecycleAndroid.<Optional<Bitmap>>bindView(currentImageView))
                .filter(new Predicate<Optional<Bitmap>>() {
                    @Override
                    public boolean test(Optional<Bitmap> optionalBitmap) {

                        if (optionalBitmap.isEmpty()) {
                            if (!mInsertId.equals(NO_INSERT_ID)) {
                                InsertCommandDispatcher.getInstance().dispatchCommand(
                                        new InsertCommand.Builder(
                                                PREFETCH_IMAGES, PREFETCH_IMAGES_END)
                                                .setDestinationId(InsertPreparationManager.COMMAND_ACTION_DESTINATION)
                                                .setSourceId(mInsertId)
                                                .addParameter(FAIL)
                                                .build(), false
                                );
                            }
                            return false;
                        }
                        return true;
                    }
                })
                .firstElement()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(InsertMaybeObserver.create(
                        new Consumer<Optional<Bitmap>>() {
                    @Override
                    public void accept(Optional<Bitmap> optionalBitmap) {
                        currentImageView.setImageBitmap(optionalBitmap.getValue());
                        InsertContentDescriptionManager.getInstance().setContentDescription(
                                currentImageView, currentCnxt.getString(R.string.insert_image_accessibility_description),
                                null);
                        if (!mInsertId.equals(NO_INSERT_ID)) {
                            InsertCommandDispatcher.getInstance().dispatchCommand(
                                    new InsertCommand.Builder(
                                            IMAGES_SET, PREFETCH_IMAGES_END)
                                            .setDestinationId(InsertPreparationManager.COMMAND_ACTION_DESTINATION)
                                            .setSourceId(mInsertId)
                                            .addParameter(SUCCESS)
                                            .build(), false
                            );
                        }
                    }
                }));
    }


    private Transformation getScreenDensityTransformation(final int imageViewWidth, final int imageViewHeight) {
        return new Transformation() {

            @Override
            public Bitmap transform(Bitmap source) {
                int density = Math.round(ViewUtils.getDisplayMetrics().density);
                int scaledWidth = source.getWidth() * density;
                int scaledHeight = source.getHeight() * density;

                if (!(scaledWidth > mScreenWidth && scaledHeight > mScreenHeight)) {
                    Bitmap result = Bitmap.createScaledBitmap(source, scaledWidth, scaledHeight, false);
                    if (result != source) {
                        // Same bitmap is returned if sizes are the same
                        source.recycle();
                    }

                    return result;
                } else {
                    return source;
                }
            }

            @Override
            public String key() {
                return "screenDensityTransformation" + mInsertId + imageViewWidth + imageViewHeight;
            }
        };
    }

}
