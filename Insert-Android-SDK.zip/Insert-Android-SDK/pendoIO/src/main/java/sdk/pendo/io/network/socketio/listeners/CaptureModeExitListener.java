package sdk.pendo.io.network.socketio.listeners;

import org.json.JSONObject;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

 /**
 * Listen on {@link SocketEvents#EVENT_CAPTURE_MODE_EXIT}
 */
public final class CaptureModeExitListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got: captureModeExit");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_CAPTURE_MODE_EXIT);
        if (!SocketEventFSM.getInstance().isCaptureMode()) {
            sendCaptureModeExitedEvent();
        }
    }

    private void sendCaptureModeExitedEvent() {
        JSONObject jsonObject = new JSONObject();
        SocketIOUtils.addSuccesfulToResponse(jsonObject, true);
        SocketIOUtils.emitToSocket(SocketEvents.EVENT_CAPTURE_MODE_EXITED.getCommand(), jsonObject);
    }
}
