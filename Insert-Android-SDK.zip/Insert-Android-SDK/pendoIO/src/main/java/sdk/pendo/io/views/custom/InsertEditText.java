package sdk.pendo.io.views.custom;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.widget.EditText;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_INVALID;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_VALID;
import static sdk.pendo.io.actions.InsertCommandEventType.TextFieldEventType.ON_TEXT_CHANGED;

/**
 * Pendo's {@link EditText}.
 *
 * Created by assaf on 5/1/16.
 */
@SuppressWarnings("unused")
public final class InsertEditText extends EditText implements InsertCustomView {

    private final TextWatcher mTextWatcher;

    private Pattern mValidator;
    private List<InsertCommand> mCommands;

    private float[] mCornerRadii;
    private int mStrokeWidth, mStrokeColor;
    private int mBackgroundColor = Color.TRANSPARENT;
    private GradientDrawable mBackgroundDrawable = new GradientDrawable();

    public InsertEditText(Context context) {
        this(context, null);
    }

    public InsertEditText(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.editTextStyle);
    }

    public InsertEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        // Set the validator to the default validator.
        mValidator = Pattern.compile(".*");

        mTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (mCommands != null) {
                    if (count != before) {
                        InsertCommandDispatcher.getInstance()
                                .dispatchCommands(mCommands, ON_TEXT_CHANGED, true);
                        validate();
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };

        addTextChangedListener(mTextWatcher);
    }

    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event) {

        // Fix for the LG (and some other Android SDK versions) keyboard bug.
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            clearFocus();
        }

        return super.onKeyPreIme(keyCode, event);
    }

    public void setValidator(Pattern validator) {
        mValidator = validator;
    }

    public boolean validate() {

        if (mValidator == null) {
            InsertLogger.d("No validator.");
            return true;
        }

        final Matcher matcher = mValidator.matcher(getText());
        final boolean matches = matcher.matches();

        if (mCommands == null) {
            InsertLogger.d("No commands.");
        } else {
            InsertCommandDispatcher.getInstance()
                    .dispatchCommands(mCommands,
                                      matches ? ON_VALID : ON_INVALID,
                            true);
        }

        return matches;
    }

    public void setCommands(List<InsertCommand> commands) {
        mCommands = commands;
    }

    @Override
    public void setStrokeWidth(int strokeWidth) {
        mStrokeWidth = strokeWidth;
        adjustTextPadding(strokeWidth);
    }

    private void adjustTextPadding(int strokeWidth) {
        setPadding(getPaddingLeft() + strokeWidth,
                getPaddingTop() + strokeWidth,
                getPaddingRight() + strokeWidth,
                getPaddingBottom() + strokeWidth);
    }

    @Override
    public void setStrokeColor(int strokeColor) {
        mStrokeColor = strokeColor;
    }

    @Override
    public void setCornerRadius(float cornerRadius) {
        mCornerRadii = new float[] {cornerRadius, cornerRadius, cornerRadius,
                cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius};
    }

    @Override
    public void setCornerRadii(float[] cornerRadii) {
        mCornerRadii = cornerRadii;
    }

    @Override
    public void setBackgroundColor(int backgroundColor) {
        mBackgroundColor = backgroundColor;
    }

    @Override
    public void renderView() {
        mBackgroundDrawable.setColor(mBackgroundColor);

        if (mStrokeWidth > 0) {
            mBackgroundDrawable.setStroke(mStrokeWidth, mStrokeColor);
        }

        if (mCornerRadii != null) {
            mBackgroundDrawable.setCornerRadii(mCornerRadii);
        }

        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN) {
            //noinspection deprecation
            setBackgroundDrawable(mBackgroundDrawable);
        } else {
            setBackground(mBackgroundDrawable);
        }

        invalidate();
    }

}
