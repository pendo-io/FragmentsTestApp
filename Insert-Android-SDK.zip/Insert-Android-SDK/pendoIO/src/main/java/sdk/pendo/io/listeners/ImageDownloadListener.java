package sdk.pendo.io.listeners;

import android.net.Uri;
import android.view.ViewGroup;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;

import sdk.pendo.io.actions.InsertCommandParameterInjector;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.Utils;

import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason;

/**
 * Handles the image download callbacks during the insert lifecycle.
 */
public final class ImageDownloadListener implements Picasso.Listener {

    public static final String ANALYTICS_PARAM_CONNECTIVITY_ERROR = "connectivity_error";

    private WeakReference<Tracker> mTracker;
    private WeakReference<ViewGroup> mContent;
    private WeakReference<JSONObject> mAdditionalInfo;
    private WeakReference<ViewGroup> mContainer;

    public void prepareForImageDownload(Tracker tracker,
                                        ViewGroup content,
                                        ViewGroup container,
                                        JSONObject additionalInfo) {

        mContainer = new WeakReference<>(container);
        mTracker = new WeakReference<>(tracker);
        mContent = new WeakReference<>(content);
        mAdditionalInfo = new WeakReference<>(additionalInfo);
    }

    @Override
    public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {

        // We need to make sure all the weak reference members are legit.
        // Before using them for analytics generation.
        if ((mTracker != null)
                && (mContent != null)
                && (mAdditionalInfo != null)
                && (mContainer != null)) {

            final Tracker tracker = mTracker.get();

            // Try to send analytics.
            try {
                Utils.requireNonNull(tracker, "Analytics failed: Tracker is null!");
                final JSONObject additionalInfo = mAdditionalInfo.get();
                Utils.requireNonNull(additionalInfo, "Analytics failed: AdditionalInfo is null!");

                try {
                    additionalInfo.put(ANALYTICS_PARAM_CONNECTIVITY_ERROR, exception.getMessage());
                } catch (JSONException ignore) {
                }

                if (tracker.getGenericAnalytics() != null ) {
                    InsertCommandParameterInjector.getInstance().handleInsertNoConnectivityAnalytics(
                            tracker.getGenericAnalytics().getInsertId());
                } else {
                    //TODO: remove this.
                    AnalyticsUtils.sendInsertNotDisplayedAnalyticsEvent(tracker,
                            NotDisplayReason.ERROR_REASON_IMAGE,
                            additionalInfo);
                }

            } catch (NullPointerException analyticsFailed) {
                InsertLogger.e(analyticsFailed, analyticsFailed.getMessage());
            }

            // TODO: 4/7/16 Notify on closed?.

            // try to remove the view.
            try {
                final ViewGroup content = mContent.get();
                Utils.requireNonNull(content, "Remove view failed: Content is null!");
                final ViewGroup container = mContainer.get();
                Utils.requireNonNull(container, "Remove view failed: Container is null!");
                content.removeView(container);
            } catch (NullPointerException removeViewFailed) {
                InsertLogger.e(removeViewFailed, removeViewFailed.getMessage());
            }
        }
    }
}

