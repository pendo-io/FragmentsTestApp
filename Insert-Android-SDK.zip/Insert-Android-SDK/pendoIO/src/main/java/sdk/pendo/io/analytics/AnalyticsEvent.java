package sdk.pendo.io.analytics;

import android.support.annotation.Nullable;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Analytics events enum.
 *
 * Created by assaf on 6/18/15.
 */
public enum AnalyticsEvent {

    // Generic Inserts:
    GUIDE_RECEIVED("guideReceived"),
    GUIDE_DISPLAYED("guideDisplayed"),
    GUIDE_DISMISSED("guideDismissed"),
    GUIDE_NOT_DISPLAYED("guideNotDisplayed"),
    APP_SCREEN_LEFT("AppScreenLeft"),
    CUSTOM_EVENT_OCCURRED("CustomEventOccurred"),
    TRACK_EVENT("trackEvent"),

    // Specific Inserts:
    INSERT_ELEMENT_CLICKED("InsertElementClicked"),
    VIDEO_PLAY("VideoPlayed"),
    VIDEO_PAUSE("VideoPaused"),
    VIDEO_STOPPED("VideoStopped"),
    VIDEO_ORIENTATION_CHANGE("VideoOrientationChanged"),
    VIDEO_RESUMED("VideoResumed"),
    VIDEO_BUFFERING("VideoBuffering"),
    VIDEO_FULL_SCREEN("VideoFullScreen"),
    FORM_SUBMITTED("FormSubmitted"),
    PAGER_FLOW("PagerFlow"),

    // Generic Application:
    APP_SESSION_START("AppSessionStart"),
    APP_SESSION_END("AppSessionEnd"),
    APP_IN_BACKGROUND("AppInBackground"),
    APP_IN_FOREGROUND("AppInForeground"),

    // Specific Application:
    APP_SCREEN_VIEWED("AppScreenViewed"),
    APP_BUTTON_CLICKED("AppButtonClicked"),
//    APP_IMAGE_CLICKED("AppImageClicked"),
    LIST_ITEM_CLICKED("ListItemClicked"),
//    APP_ELEMENT_VIEWED("AppElementViewed"),

    // SDK errors:
    SDK_EXCEPTION("SdkException"),
    SDK_ERROR("SdkError"),
    SECURITY_EXCEPTION("SecurityException"),

    UNKNOWN("Unknown");

    private final String mValue;

    AnalyticsEvent(String value) {
        mValue = value;
    }

    public String getValue() {
        return mValue;
    }

    private static final Map<String, AnalyticsEvent> LOOKUP_BY_EVENT = new HashMap<>();
    static {
        for (AnalyticsEvent event : EnumSet.allOf(AnalyticsEvent.class)) {
            LOOKUP_BY_EVENT.put(event.getValue(), event);
        }
    }

    @Nullable
    public static AnalyticsEvent findEvent(String event) {
        final AnalyticsEvent analyticsEvent = LOOKUP_BY_EVENT.get(event);
        return analyticsEvent != null ? analyticsEvent : UNKNOWN;
    }
}
