package sdk.pendo.io.utilities

import android.os.Debug
import org.json.JSONObject

import java.security.MessageDigest

object HashingUtils {

    private const val SHA1_ALGORITHM_NAME = "SHA-1"
    private const val UTF8_ENCODING = "UTF-8"
    private val digest = MessageDigest.getInstance(SHA1_ALGORITHM_NAME)

    @Throws(Exception::class)
    @Synchronized
    fun encryptSHA1(jsonObject: JSONObject): String {
        digest.reset()
        digest.update(jsonObject.toString().toByteArray(charset(UTF8_ENCODING)))
        return Utils.bytesToHex(digest.digest())
    }
}
