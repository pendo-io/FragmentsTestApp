package sdk.pendo.io.views.listener;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.view.MotionEventCompat;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicInteger;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.dialogs.ProgressDialog;
import sdk.pendo.io.dialogs.TestModeDialog;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.utilities.PairingUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.ViewUtils;
import sdk.pendo.io.views.FlashView;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.utilities.PairingUtils.showFlashScreenAndCapture;

/**
 * Pendo's Floating Listener Button.
 * <p/>
 * Created by assaf on 4/12/15.
 */
@SuppressLint({"ViewConstructor", "ClickableViewAccessibility"})
// We don't instantiate this view with the view's constructors for now.
public final class FloatingListenerButton extends ImageButton
        implements View.OnClickListener, FlashView.OnFlashViewFinished {

    public static final String INSERT_CAPTURE_BUTTON_DESCRIPTION = "insert_capture_button";
    public static final String INSERT_PAIRED_CONNECTED_BUTTON_DESCRIPTION = "insert_paired_connected_button";
    public static final String INSERT_PAIRED_DISCONNECTED_BUTTON_DESCRIPTION = "insert_paired_disconnected_button";
    public static final String INSERT_TEST_MODE_CONNECTED_BUTTON_DESCRIPTION = "insert_test_mode_connected_button";
    public static final String INSERT_TEST_MODE_DISCONNECTED_BUTTON_DESCRIPTION = "insert_test_mode_disconnected_button";
    private static final int FLOATING_BUTTON_ELEVATION = 0;
    private static final int PRE_PROGRESS_BAR_TIMEOUT = 500;
    private static final int BUTTON_STATE_CHANGE_TIMEOUT = 450;
    private static final int PRE_FLASH_TIMEOUT = 200;
    private static final int INVALID_POINTER_ID = -1;
    /* States for capture button animation */
    private static final int FIRST_STATE_SHOW_NUMBER_THREE = 1;
    private static final int SECOND_STATE_SHOW_NUMBER_TWO = 2;
    private static final int THIRD_STATE_SHOW_NUMBER_ONE = 3;
    private static final int FLASH_STATE = 4;
    private static final int LIMBO_STATE = 5;
    /**
     * Max allowed distance to move during a "click", in DP.
     */
    private static final float MAX_CLICK_DISTANCE = ViewUtils.convertDpToPx(15);

    /**
     * Max allowed duration for a "click", in milliseconds.
     */
    private static final long MAX_CLICK_DURATION = 250;
    private static final Object LOCK = new Object();
    private static final String SCREEN_SEND_MODE_TAG = "screenSend";
    private static final String TEST_MODE_TAG = "testMode";

    private static float sLastTouchX;
    private static float sLastTouchY;
    private static float sPosX = -1;
    private static float sPosY = -1;
    private static boolean sMovedOrTookScreenshot = false;
    private static int sLastButtonState = FIRST_STATE_SHOW_NUMBER_THREE;
    private static volatile AtomicInteger sButtonState =
            new AtomicInteger(FIRST_STATE_SHOW_NUMBER_THREE);
    private static boolean sFinishedAnimation = false;
    private static ProgressDialog sDialogFragment = null;
    private static TestModeDialog sTestModeDialog = null;

    // The ‘active pointer’ is the one currently moving our object.
    private int mActivePointerId = INVALID_POINTER_ID;
    private Handler mAnimationTimeoutHandler;
    private Runnable mShowSecondButtonRunnable;
    private Runnable mShowFirstButtonRunnable;
    private Runnable mFlashRunnable;
    private Runnable mFinishedRunnable;
    private boolean mButtonClicked = false;
    private long mPressStartTime;
    private float mPressedX;
    private float mPressedY;
    private AtomicInteger mDrawableResource = new AtomicInteger(-1);
    private Rect mDisplayRect = new Rect();
    private Rect mViewRealRect = new Rect();

    /**
     * Constructs the floating listener button.
     */
    public FloatingListenerButton() {
        super(Pendo.getApplicationContext());
        init();
    }

    public static ProgressDialog getDialogFragment() {
        return sDialogFragment;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void init() {
        // The button isn't clicked now, the animation hasn't started yet,
        // and the state should be set to the first state of the animation.
        try {

            mButtonClicked = false;
            sFinishedAnimation = false;
            sButtonState.set(FIRST_STATE_SHOW_NUMBER_THREE);

            if (SocketEventFSM.getInstance().isPairedMode()) {
                setImageResource(SocketEventFSM.isSocketConnected() ?
                        R.drawable.insert_pair_connected : R.drawable.insert_pair);

            } else if (SocketEventFSM.getInstance().isTestMode()) {
                setImageResource(SocketEventFSM.isSocketConnected() ?
                        R.drawable.insert_test_mode_connected : R.drawable.insert_test_mode);

            } else { //capture mode
                setImageResource(R.drawable.insert_camcam);
                InsertContentDescriptionManager.getInstance().setContentDescription(this,
                        getContext().getString(
                                R.string.insert_capture_mode_accessibility_description), null);
            }

            //Define the runnables for the animation transitions.
            mAnimationTimeoutHandler = new Handler();
            mShowSecondButtonRunnable = new Runnable() {
                @Override
                public void run() {
                    sButtonState.set(SECOND_STATE_SHOW_NUMBER_TWO);
                    invalidate();
                }
            };
            mShowFirstButtonRunnable = new Runnable() {
                @Override
                public void run() {
                    sButtonState.set(THIRD_STATE_SHOW_NUMBER_ONE);
                    invalidate();
                }
            };
            mFlashRunnable = new Runnable() {
                @Override
                public void run() {
                    sButtonState.set(FLASH_STATE);
                    invalidate();
                }
            };
            mFinishedRunnable = new Runnable() {
                @Override
                public void run() {
                    handleReadyToCapture();
                }
            };
            setBackgroundColor(Color.TRANSPARENT);
            setOnClickListener(this);
            setClickable(true);
            invalidate();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
            Toast.makeText(getContext(),
                    getResources().getString(R.string.insert_pairing_error_occurred),
                    Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Handling the situation where the marketer clicked
     * the button and the capture is ready to be done
     * we should consider whether to perform a standard capture
     * or notify the socket that marketer is ready (in identify screen scenario)
     */
    private void handleReadyToCapture() {
       InsertLogger.i("Sending view to Pendo.");
       mButtonClicked = false;
       sFinishedAnimation = true;
       showFlashScreenAndCapture();
    }

    @Override
    protected void onDraw(@NonNull final Canvas canvas) {
        // In case the current position is not right for the screen
        // (e.g. for cases like orientation change) we reset the capture button position
        if (sPosX > getResources().getDisplayMetrics().widthPixels
                || (sPosY > getResources().getDisplayMetrics().heightPixels)) {
            resetPosition();
        }

        try {
            getWindowVisibleDisplayFrame(mDisplayRect);
        } catch (Exception e) {
            InsertLogger.d(e, "Attempt to read from field mVisibleInsets on a null attachInfo of the view in question.");
        }

        getGlobalVisibleRect(mViewRealRect);

        if (sPosX >= mDisplayRect.left && sPosX + getWidth() <= mDisplayRect.right) {
            setX(sPosX);
        } else {
            sPosX = getX();
        }

        if (mViewRealRect.bottom - mViewRealRect.top < getHeight()) {
            sPosY -= getHeight() - (mViewRealRect.bottom - mViewRealRect.top);
        }

        if (sPosY >= mDisplayRect.top && sPosY + getHeight() <= mDisplayRect.bottom) {
            setY(sPosY);
        } else {
            if (!sMovedOrTookScreenshot) {
                sPosY = getY() - getBottom();
            } else {
                sPosY = getY();
            }
        }

        // In case this this a marketer device and it is not in capture mode
        // we should show the paired/test button (connected style or not).
        if (SocketIOUtils.getSessionToken() != null && !captureButtonRequired()) {

            if (SocketEventFSM.getInstance().isTestMode()) {

                //set correct icon image and description for test mode.
                if (SocketEventFSM.isSocketConnected()) {
                    if (mDrawableResource.getAndSet(
                            R.drawable.insert_test_mode_connected) != R.drawable.insert_test_mode_connected) {
                        setImageResource(R.drawable.insert_test_mode_connected);
                        InsertContentDescriptionManager.getInstance().setContentDescription(this,
                                Pendo.getApplicationContext().getString(
                                        R.string.insert_test_mode_accessibility_description),
                                INSERT_TEST_MODE_CONNECTED_BUTTON_DESCRIPTION);
                    }
                } else {
                    if (mDrawableResource.getAndSet(
                            R.drawable.insert_test_mode) != R.drawable.insert_test_mode) {
                        setImageResource(R.drawable.insert_test_mode);
                        InsertContentDescriptionManager.getInstance().setContentDescription(this,
                                Pendo.getApplicationContext().getString(
                                        R.string.insert_test_mode_disconnected_button_accessibility_description),
                                INSERT_TEST_MODE_DISCONNECTED_BUTTON_DESCRIPTION);
                    }
                }

            } else {

                //set correct icon image and description for pair mode.
                if (SocketEventFSM.isSocketConnected()) {
                    if (mDrawableResource.getAndSet(
                            R.drawable.insert_pair_connected) != R.drawable.insert_pair_connected) {
                        setImageResource(R.drawable.insert_pair_connected);
                        InsertContentDescriptionManager.getInstance().setContentDescription(
                                this, Pendo.getApplicationContext().getString(
                                        R.string.insert_paired_connected_button_accessibility_description),
                                INSERT_PAIRED_CONNECTED_BUTTON_DESCRIPTION);
                    }
                } else {
                    if (mDrawableResource.getAndSet(
                            R.drawable.insert_pair) != R.drawable.insert_pair) {
                        setImageResource(R.drawable.insert_pair);
                        InsertContentDescriptionManager.getInstance().setContentDescription(this,
                                Pendo.getApplicationContext().getString(
                                        R.string.insert_paired_disconnected_button_accessibility_description),
                                INSERT_PAIRED_DISCONNECTED_BUTTON_DESCRIPTION);
                    }
                }
            }

        } else {
            if (sFinishedAnimation) {
                sFinishedAnimation = false;
                mButtonClicked = false;
            } else if (!mButtonClicked && captureButtonRequired()) {

                if (mDrawableResource.getAndSet(
                        R.drawable.insert_camcam) != R.drawable.insert_camcam) {
                    setImageResource(R.drawable.insert_camcam);
                    InsertContentDescriptionManager.getInstance().setContentDescription(this,
                            getContext().getString(
                                    R.string.insert_capture_mode_accessibility_description), null);
                }

            } else if (mButtonClicked && captureButtonRequired()) {
                switch (sButtonState.get()) {
                    case FIRST_STATE_SHOW_NUMBER_THREE:
                        // Draw the button.
                        if (sButtonState.getAndIncrement() == FIRST_STATE_SHOW_NUMBER_THREE) {
                            InsertLogger.d("Floating Button - THREE STATE");
                            sLastButtonState = FIRST_STATE_SHOW_NUMBER_THREE;
                            sButtonState.set(LIMBO_STATE);

                            if (mDrawableResource.getAndSet(R.drawable.insert_three3)
                                    != R.drawable.insert_three3) {
                                setImageResource(R.drawable.insert_three3);
                            }

                            mAnimationTimeoutHandler.postDelayed(
                                    mShowSecondButtonRunnable,
                                    BUTTON_STATE_CHANGE_TIMEOUT);
                        }
                        break;
                    case SECOND_STATE_SHOW_NUMBER_TWO:
                        // Draw the button.
                        if (sButtonState.getAndIncrement() == SECOND_STATE_SHOW_NUMBER_TWO) {
                            InsertLogger.d("Floating Button - TWO STATE");
                            sLastButtonState = SECOND_STATE_SHOW_NUMBER_TWO;
                            sButtonState.set(LIMBO_STATE);

                            if (mDrawableResource.getAndSet(
                                    R.drawable.insert_two2) != R.drawable.insert_two2) {
                                setImageResource(R.drawable.insert_two2);
                            }

                            setScaleType(ScaleType.FIT_CENTER);
                            mAnimationTimeoutHandler.postDelayed(
                                    mShowFirstButtonRunnable,
                                    BUTTON_STATE_CHANGE_TIMEOUT);
                        }
                        break;
                    case THIRD_STATE_SHOW_NUMBER_ONE:
                        if (sButtonState.getAndIncrement() == THIRD_STATE_SHOW_NUMBER_ONE) {
                            sLastButtonState = THIRD_STATE_SHOW_NUMBER_ONE;
                            InsertLogger.d("Floating Button - ONE STATE");
                            sButtonState.set(LIMBO_STATE);

                            if (mDrawableResource.getAndSet(
                                    R.drawable.insert_one1) != R.drawable.insert_one1) {
                                setImageResource(R.drawable.insert_one1);
                            }

                            mAnimationTimeoutHandler.postDelayed(
                                    mFlashRunnable,
                                    BUTTON_STATE_CHANGE_TIMEOUT);
                        }
                        break;
                    case FLASH_STATE:
                        if (sButtonState.getAndIncrement() == FLASH_STATE) {
                            sLastButtonState = FLASH_STATE;
                            sFinishedAnimation = true;
                            mButtonClicked = false;
                            InsertLogger.d("Floating Button - DONE STATE");
                            mAnimationTimeoutHandler.postDelayed(mFinishedRunnable,
                                    PRE_FLASH_TIMEOUT);
                        }
                        break;
                    case LIMBO_STATE:
                        if (sLastButtonState == FIRST_STATE_SHOW_NUMBER_THREE) {
                            if (mDrawableResource.getAndSet(R.drawable.insert_three3)
                                    != R.drawable.insert_three3) {
                                setImageResource(R.drawable.insert_three3);
                            }
                        } else if (sLastButtonState == SECOND_STATE_SHOW_NUMBER_TWO) {

                            if (mDrawableResource.getAndSet(
                                    R.drawable.insert_two2) != R.drawable.insert_two2) {
                                setImageResource(R.drawable.insert_two2);
                            }

                        } else if (sLastButtonState == THIRD_STATE_SHOW_NUMBER_ONE) {
                            if (mDrawableResource.getAndSet(
                                    R.drawable.insert_one1) != R.drawable.insert_one1) {
                                setImageResource(R.drawable.insert_one1);
                            }
                        }
                        break;
                    default:
                        InsertLogger.d("Unknown state: " + sButtonState.get());
                        break;
                }
            }
        }
        super.onDraw(canvas);
    }

    private boolean captureButtonRequired() {
        return SocketEventFSM.getInstance().isCaptureMode() || SocketEventFSM.getInstance().isIdentifyMode();
    }

    @Override
    public void setElevation(float elevation) {
        super.setElevation(FLOATING_BUTTON_ELEVATION);
    }

    private void resetPosition() {
        sPosX = getX();
        sPosY = getY();
    }

    @Override
    @SuppressWarnings("ClickableViewAccessibility")
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        try {
            final int action = MotionEventCompat.getActionMasked(event);
            final float x = event.getRawX();
            final float y = event.getRawY();
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    // Remember where we started (for dragging)
                    InsertLogger.d("MotionEvents - ActionDown");
                    sLastTouchX = x;
                    sLastTouchY = y;

                    mPressStartTime = System.currentTimeMillis();
                    mPressedX = event.getX();
                    mPressedY = event.getY();

                    // Save the ID of this pointer (for dragging)
                    mActivePointerId = MotionEventCompat.getPointerId(event, 0);
                    break;

                case MotionEvent.ACTION_MOVE:
                    // Calculate the distance moved
                    InsertLogger.d("MotionEvents - ActionMove");
                    final float dx = x - sLastTouchX;
                    final float dy = y - sLastTouchY;

                    sPosX += dx;
                    sPosY += dy;

                    // Invalidate so onDraw() will get called.
                    invalidate();

                    // Remember this touch position for the next move event
                    sLastTouchX = x;
                    sLastTouchY = y;
                    sMovedOrTookScreenshot = true;
                    break;

                case MotionEvent.ACTION_UP:
                    InsertLogger.d("MotionEvents - ActionUp");

//                if (SocketEventFSM.getInstance().isPairedMode() || SocketEventFSM.getInstance()
//                        .isTestMode()) {
//                    sTestModeDialog.dismiss();
//                }
                    long pressDuration = System.currentTimeMillis() - mPressStartTime;

                    // If the view didn't really move.
                    if (pressDuration < MAX_CLICK_DURATION
                            && Utils.distance(mPressedX, mPressedY,
                            event.getX(), event.getY()) < MAX_CLICK_DISTANCE) {
                        if (SocketEventFSM.getInstance().isTestMode() || SocketEventFSM.getInstance()
                                .isPairedMode()) {
                            sTestModeDialog
                                    = TestModeDialog.newInstance(SocketEventFSM.getInsertNames());
                            sTestModeDialog.show(
                                    ApplicationObservers.getInstance().getCurrentVisibleActivity()
                                            .getFragmentManager(),
                                    TEST_MODE_TAG);
                        }
                        sMovedOrTookScreenshot = false;
                        performClick();
                    }

                    mActivePointerId = INVALID_POINTER_ID;
                    break;

                case MotionEvent.ACTION_CANCEL:
                    InsertLogger.d("MotionEvents - ActionCancel");
                    mActivePointerId = INVALID_POINTER_ID;
                    break;

                case MotionEvent.ACTION_POINTER_UP:
                    InsertLogger.d("MotionEvents - ActionPointerUp");
                    final int pointerIndex = MotionEventCompat.getActionIndex(event);
                    final int pointerId = MotionEventCompat.getPointerId(event, pointerIndex);

                    if (pointerId == mActivePointerId) {
                        // This was our active pointer going up. Choose a new
                        // active pointer and adjust accordingly.
                        final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
                        sLastTouchX = event.getRawX();
                        sLastTouchY = event.getRawY();
                        mActivePointerId = MotionEventCompat.getPointerId(event, newPointerIndex);
                    }
                    break;
                default:
                    InsertLogger.d("Unknown action: " + action);
                    break;
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return super.onTouchEvent(event);
    }

    @Override
    public void onClick(View v) {
        // If the view wasn't moved, but it was clicked.
        sFinishedAnimation = false;
        if (!sMovedOrTookScreenshot) {
            mButtonClicked = true;
            invalidate();
        } else {
            InsertLogger.i("Not sending view.");
            sMovedOrTookScreenshot = false;
        }
    }


    @Override
    public void flashFinished() {
        if (SocketEventFSM.getInstance().isIdentifyMode()) {
            // In identification mode we are not showing the sending image dialog fragment
            PairingUtils.captureScreen(FloatingListenerButton.this);
        } else {
            Runnable captureRunnable = new Runnable() {
                @Override
                public void run() {
                    final Activity currentActivity = ApplicationObservers.getInstance()
                            .getCurrentVisibleActivity();
                    Builder.removeActiveInstances();
                    sDialogFragment = new ProgressDialog();
                    sDialogFragment.show(currentActivity.getFragmentManager(),
                            SCREEN_SEND_MODE_TAG);
                    PairingUtils.captureScreen(FloatingListenerButton.this);
                }
            };
            mAnimationTimeoutHandler.postDelayed(captureRunnable, PRE_PROGRESS_BAR_TIMEOUT);
        }
    }



    /**
     * Sets the visibility of the pairing button
     *
     * @param visible True is the pairing button should be visible, false otherwise
     */
    public static void setVisibility(final boolean visible) {
        final Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        final ViewGroup root = (ViewGroup) activity.findViewById(android.R.id.content);
        if (root != null) {
            final FloatingListenerButton listenerButton = (FloatingListenerButton) root
                    .findViewWithTag(activity
                            .getString(R.string.insert_pairing_buttton_name_tag));
            if (listenerButton != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (visible) {
                            listenerButton.setVisibility(View.VISIBLE);
                        } else {
                            listenerButton.setVisibility(View.GONE);
                        }
                    }
                });
            }
        }
    }

    public static final class Builder {
        private FrameLayout.LayoutParams mParams;

        @SuppressLint("RtlHardcoded")
        private int mGravity = Gravity.RIGHT | Gravity.BOTTOM;
//        private int mSize = ViewUtils.convertDpToPx(64);

        public Builder() {
            mParams = new FrameLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            mParams.gravity = mGravity;
        }

        public static void removeActiveInstances() {
            synchronized (LOCK) {
                for (final Activity activity : ApplicationObservers.getInstance().getAllVisibleActivities()) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            final ViewGroup root = (ViewGroup) activity
                                    .findViewById(android.R.id.content);
                            FloatingListenerButton listenerButton = null;
                            if (root != null) {
                                listenerButton = (FloatingListenerButton) root
                                        .findViewWithTag(activity
                                                .getString(R.string.insert_pairing_buttton_name_tag));
                            }
                            if (listenerButton != null) {
                                root.removeView(listenerButton);
                            }
                        }
                    });
                }
            }
        }

        public Builder withMargins(int left, int top, int right, int bottom) {
            mParams.setMargins(
                    ViewUtils.convertDpToPx(left),
                    ViewUtils.convertDpToPx(top),
                    ViewUtils.convertDpToPx(right),
                    ViewUtils.convertDpToPx(bottom));
            return this;
        }

        public FloatingListenerButton create() {
            final Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
            final ViewGroup root = (ViewGroup) activity.findViewById(android.R.id.content);
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    final FloatingListenerButton button = new FloatingListenerButton();
                    button.setTag(activity.getString(R.string.insert_pairing_buttton_name_tag));
                    InsertContentDescriptionManager.getInstance().setContentDescription(button,
                            activity.getString(
                                    R.string.insert_capture_button_accessibility_description),
                            INSERT_CAPTURE_BUTTON_DESCRIPTION);
                    if (SocketEventFSM.getInstance().isPairedMode()) {
                        InsertContentDescriptionManager.getInstance().setContentDescription(
                                button,
                                SocketEventFSM.isSocketConnected() ?
                                        activity.getString(
                                                R.string.insert_paired_connected_button_accessibility_description) : activity.getString(
                                        R.string.insert_paired_disconnected_button_accessibility_description),
                                SocketEventFSM.isSocketConnected() ?
                                        INSERT_PAIRED_CONNECTED_BUTTON_DESCRIPTION : INSERT_PAIRED_DISCONNECTED_BUTTON_DESCRIPTION);
                    } else if (SocketEventFSM.getInstance().isTestMode()) {
                        InsertContentDescriptionManager.getInstance().setContentDescription(
                                button, SocketEventFSM.isSocketConnected() ?
                                        activity.getString(
                                                R.string.insert_test_mode_connected_button_accessibility_description) : activity.getString(
                                        R.string.insert_test_mode_disconnected_button_accessibility_description),
                                SocketEventFSM.isSocketConnected() ?
                                        INSERT_TEST_MODE_CONNECTED_BUTTON_DESCRIPTION : INSERT_TEST_MODE_DISCONNECTED_BUTTON_DESCRIPTION);
                    }
                    button.setVisibility(View.VISIBLE);
                    mParams.gravity = mGravity;
                    withMargins(0, 0, 16, 16);
                    root.addView(button, mParams);
                }
            });
            return null;
        }
    }
}
