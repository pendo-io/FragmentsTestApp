package sdk.pendo.io.handlers;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.felipecsl.gifimageview.library.GifImageView;
import com.trello.rxlifecycle3.android.RxLifecycleAndroid;


import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertPreparationManager;
import sdk.pendo.io.cache.InsertGifCache;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.ViewUtils;

import static sdk.pendo.io.actions.InsertCommandAction.InsertInternalAction.IMAGES_SET;
import static sdk.pendo.io.actions.InsertCommandAction.InsertInternalAction.PREFETCH_IMAGES;
import static sdk.pendo.io.actions.InsertCommandEventType.InsertPreparationEventType.PREFETCH_IMAGES_END;

/**
 * Created by itayvallach on 20/06/2016.
 *
 * This class is responsible for loading a given gif image via a url correctly to a supplied view.
 * This is done according to the following steps:
 *      o Get the image's sizes via an http url connection.
 *      o Find out the devices display metrics.
 *      o Load the image after being resized according to the metrics supplied.
 */
public final class LoadGifCorrectlyHandler {

    private String mInsertId;
    private static final String NO_INSERT_ID = "";
    private static final String IMAGE_FETCH_RESULT = "ImageFetchResult";
    private static final InsertCommandsEventBus.Parameter SUCCESS =
            new InsertCommandsEventBus.Parameter(IMAGE_FETCH_RESULT, "boolean", "true");
    private static final InsertCommandsEventBus.Parameter FAIL =
            new InsertCommandsEventBus.Parameter(IMAGE_FETCH_RESULT, "boolean", "false");

    /**
     *
     * @param currentCnxt The context we're running in
     * @param currentImageView the imageView we want to inject the bitmap into
     */
    public LoadGifCorrectlyHandler(Context currentCnxt,
                                   GifImageView currentImageView, String url) {

        mInsertId = NO_INSERT_ID;
        startObserver((Activity) currentCnxt, currentImageView, url);
    }

    /**
     *
     * @param currentCnxt The context we're running in
     * @param currentImageView the imageView we want to inject the bitmap into
     * @param insertId the insert id.
     */
    public LoadGifCorrectlyHandler(Context currentCnxt, GifImageView currentImageView,
                                   String url, String insertId) {
        mInsertId = insertId;
        startObserver((Activity) currentCnxt, currentImageView, url);
    }

    private void startObserver(final Activity currentCnxt, final GifImageView currentImageView,
                               final String url) {
        Observable.just(url)
                .subscribeOn(Schedulers.io())
                .map(new Function<String, byte[]>() {
                    @Override
                    public byte[] apply(String receivedUrl) {
                        byte[] cachedGifBytes = InsertGifCache.getInstance().get(url);
                        if (cachedGifBytes != null) {
                            return InsertGifCache.getInstance().get(url);

                        } else {
                            byte[] result = InsertGifCache.getUrlAsBytes(receivedUrl);
                            return result != null ? result : new byte[0];
                        }

                    }
                })
                .filter(new Predicate<byte[]>() {
                    @Override
                    public boolean test(byte[] bytes) {
                        if (bytes.length == 0) {
                            if (!mInsertId.equals(NO_INSERT_ID)) {
                                InsertCommandDispatcher.getInstance().dispatchCommand(
                                        new InsertCommand.Builder(
                                                PREFETCH_IMAGES, PREFETCH_IMAGES_END)
                                                .setDestinationId(InsertPreparationManager.COMMAND_ACTION_DESTINATION)
                                                .setSourceId(mInsertId)
                                                .addParameter(FAIL)
                                                .build(), false
                                );
                            }
                            return false;
                        }
                        return true;
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .compose(RxLifecycleAndroid.<byte[]>bindView(currentImageView))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(InsertObserver.create(new Consumer<byte[]>() {
                    @Override
                    public void accept(byte[] gifByteArray) {
                        currentImageView.setBytes(gifByteArray);
                        Bitmap bmp = BitmapFactory.decodeByteArray(gifByteArray, 0, gifByteArray.length);
                        int screenWidth = currentCnxt.getWindowManager().getDefaultDisplay().getWidth();
                        int screenHeight = currentCnxt.getWindowManager().getDefaultDisplay().getHeight();
                        int density = Math.round(ViewUtils.getDisplayMetrics().density);
                        int imageWidth = bmp.getWidth();
                        int imageHeight = bmp.getHeight();
                        int scaledWidth = imageWidth * Math.round(density);
                        int scaledHeight = imageHeight * Math.round(density);
                        if (!(scaledWidth > screenWidth && scaledHeight > screenHeight)) {
                            currentImageView.getLayoutParams().width = scaledWidth;
                            currentImageView.getLayoutParams().height = scaledHeight;
                        } else {
                            currentImageView.getLayoutParams().width = imageWidth;
                            currentImageView.getLayoutParams().height = imageHeight;
                        }
                        currentImageView.startAnimation();
                        if (InsertGifCache.getInstance().get(url) == null) {
                            InsertGifCache.getInstance().put(url, gifByteArray);
                        }
                        if (!mInsertId.equals(NO_INSERT_ID)) {
                            InsertCommandDispatcher.getInstance().dispatchCommand(
                                    new InsertCommand.Builder(
                                            IMAGES_SET, PREFETCH_IMAGES_END)
                                            .setDestinationId(InsertPreparationManager.COMMAND_ACTION_DESTINATION)
                                            .setSourceId(mInsertId)
                                            .addParameter(SUCCESS)
                                            .build(), false
                            );
                        }
                    }
                }));
    }

}
