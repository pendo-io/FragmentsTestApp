package sdk.pendo.io.intelligence;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.lang3.builder.DiffResult;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;

import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.models.AccessibilityData;
import sdk.pendo.io.events.ConditionData;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.utilities.TriggerUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.ViewHierarchyUtility;
import sdk.pendo.io.utilities.ViewUtils;

/**
 * Intelligence about views.
 * <p/>
 * Created by assaf on 6/9/15.
 */
public final class ViewIntel {
    public static final String RESULT_KEY = "result";

    // FIXME: 7/22/15 Get from server at some point.
    private static final int LIST_ITEMS_PENALTY = 10;
    private static final int TEXT_STRINGS_PENALTY = 40;
    private static final int CHILD_COUNT_PENALTY = 5;

    public static final int FULL_CONFIDENCE = 100;
    // FIXME: 7/22/15 Get from server at some point.
    private static final int MINIMUM_CONFIDENCE = 80;
    private static final int RELAXED_MINIMUM_CONFIDENCE = 70;

    public static ViewHierarchyUtility.ViewCallback sGetFirstTextForView =
            new ViewHierarchyUtility.ViewCallback() {

                private final static String mKey = "STRING_RESOURCES";

                @Override
                public boolean performActionOnView(@Nullable View view, Bundle oBundle) {

                    if (view == null) {
                        return false;
                    }

                    if (view instanceof TextView) {
                        String textFromView = ((TextView) view).getText().toString();

                        if (TextUtils.isEmpty(textFromView)) {
                            return false;
                        }

                        // Shorten the text if it's too long.
                        textFromView = Utils.truncateStringToLength(textFromView).toString();

                        getData().putString(RESULT_KEY, textFromView);
                        return true;
                    }

                    return false;
                }
            };

    private ViewIntel() {
    }

    public static synchronized IdentificationData getViewIntelId(@Nullable final View view, Boolean includeText, Boolean includeAccessibility) {

        IdentificationData o = new IdentificationData();

        if (view == null) {
            return o;
        }

        o.setPredicate(view);

        if (includeText) {
            if (view instanceof TextView && !(view instanceof EditText)) {
                o.setText(((TextView) view).getText().toString());
            }
        }

        if (ViewUtils.isViewATabView(view)) {
            TextView firstTextViewChild = ViewUtils.getFirstChildTextView(view);
            if (firstTextViewChild != null && firstTextViewChild.getText() != null) {
                o.setText(firstTextViewChild.getText().toString().trim());
            }
        }

        if (view.getId() != View.NO_ID) {

            String viewId = ViewUtils.getViewId(view);
            if (viewId != null) {
                o.setId(viewId);
            }
        }

        ViewParent parent = view.getParent();
        ArrayList<String> parentsId = new ArrayList<>();
        while (parent != null) {
            if (parent instanceof View) {
                String parentId = ViewUtils.getViewId(((View) parent));
                if (parentId != null) {
                    parentsId.add(parentId);
                }
            }
            parent = parent.getParent();
        }

        o.setIdOfParents(parentsId);

        if (view instanceof ViewGroup) {
            o.setChildCount(((ViewGroup) view).getChildCount());
        }

//        int positionInList = ViewUtils.getViewPositionInList(view);
//        if (positionInList != -1) {
//            o.setListItem(positionInList, null, null);
//        }

        if (ViewUtils.isViewInsideList(view)) {
            o.setInsideList(true);
        }

        ViewParent viewParent = view.getParent();
        if (viewParent instanceof ViewGroup) {
            int indexInParent = ((ViewGroup) viewParent).indexOfChild(view);
            if (indexInParent != -1) {
                o.setIndexInParent(indexInParent);
            }
        }

        if (ViewUtils.isViewInsideDrawer()) {
            o.setInsideDrawer(true);
        }

        if (ViewUtils.isViewAKnownList(view)) {
            o.setIsList(true);
        }

        if (includeAccessibility) {
            // Get accessibilityData if available
            AccessibilityData accessibilityData = InsertContentDescriptionManager.getInstance().getAccessibilityData(view);

            if (accessibilityData != null) {
                o.setAccessibilityData(accessibilityData);
            }
        }

        o.setType(view.getClass().getSimpleName());
        return o;
    }

    /**
     * Compares 2 given {@link IdentificationData}.
     *
     * @param reqID            <b>this parameter can be a specific {@link View} </b>{@link IdentificationData}
     *                         <b>or a more generic one (e.g. the any element predicate).</b>
     * @param viewID           this parameter must be a specific {@link View}'s {@link IdentificationData}.
     * @param viewManipulation whether to treat this compare for view manipulation.
     * @return a {@link Pair} that it's left variable tells where or not the
     * {@link IdentificationData} matched, and the right variable gives the confidence.
     */
    public static synchronized Pair<Boolean, Integer> compareIdentificationData(
            @NonNull IdentificationData reqID, @NonNull IdentificationData viewID,
            boolean viewManipulation, @Nullable ConditionData condition) {

        DiffResult diffs = reqID.diff(viewID);
        int confidence = FULL_CONFIDENCE;

        // If both identification data are the same, return true with confidence 100.
        if (diffs.getNumberOfDiffs() == 0 && !TriggerUtils.isConditionRelevantForComparingViews(condition)) {
            return Pair.of(Boolean.TRUE, confidence);
        }

        // Identification data are not the same.
        List<Diff<?>> diffList = diffs.getDiffs();

        for (Diff<?> diff : diffList) {
            String fieldName = diff.getFieldName();
            if (IdentificationData.FIELD_PARENT_ID.equals(fieldName)) {
                confidence = 0;
                break;
            } else if (IdentificationData.FIELD_INDEX_IN_PARENT.equals(fieldName)) {
                confidence = 0;
                break;
            } else if (IdentificationData.FIELD_ID_OF_PARENTS.equals(fieldName)
                    && !viewManipulation) {
                // The reason to check for viewManipulation here is that sometimes in a list
                // the view might have different number of parent ids. This can happen when
                // the view was created but wasn't yet added to the list.
                confidence = 0;
                break;
            } else if (IdentificationData.FIELD_ID.equals(fieldName)) {
                confidence = 0;
                break;
            } else if (IdentificationData.FIELD_TYPE.equals(fieldName)) {
                confidence = 0; // FIXME: 11/23/15 For proguarded release this will fail.
                break;
            } else if (IdentificationData.FIELD_CHILD_COUNT.equals(fieldName)) {
                confidence -= CHILD_COUNT_PENALTY;
                continue;
            } else if (IdentificationData.RA_PREDICATE.equals(fieldName)) {
                confidence = 0;
                break;
            }
        }

        // TODO: 7/13/15 calculate the true here using the confidence.
        return Pair.of((confidence >= RELAXED_MINIMUM_CONFIDENCE), confidence);
    }
}
