package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

public class AnalyticsConfigurationModel {

    @SerializedName("bufferQueueSize")
    private int mBufferQueueSize;

    @SerializedName("bufferDuration")
    private int mBufferDuration;

    @SerializedName("includePageViewTexts")
    private boolean mIncludePageViewTexts;

    @SerializedName("includeFeatureClickTexts")
    private boolean mIncludeFeatureClickTexts;

    @SerializedName("includePageViewAccessibility")
    private boolean mIncludePageViewAccessibility;

    @SerializedName("includeFeatureClickAccessibility")
    private boolean mIncludeFeatureClickAccessibility;

    @SerializedName("maxStorageSizeMB")
    private float mMaxStorageSizeMB;

    public int getBufferQueueSize() {
        return mBufferQueueSize;
    }

    public void setBufferQueueSize(int bufferQueueSize) {
        mBufferQueueSize = bufferQueueSize;
    }

    public int getBufferDuration() {
        return mBufferDuration;
    }

    public void setBufferDuration(int bufferDuration) {
        mBufferDuration = bufferDuration;
    }

    public boolean isIncludePageViewTexts() {
        return mIncludePageViewTexts;
    }

    public void setIncludePageViewTexts(boolean includePageViewTexts) {
        this.mIncludePageViewTexts = includePageViewTexts;
    }

    public boolean isIncludeFeatureClickTexts() {
        return mIncludeFeatureClickTexts;
    }

    public void setIncludeFeatureClickTexts(boolean includeFeatureClickTexts) {
        mIncludeFeatureClickTexts = includeFeatureClickTexts;
    }

    public float getMaxStoragesizeMB() {
        return mMaxStorageSizeMB;
    }

    public void setMaxStoragesizeMB(float maxStorageSizeMB) {
        mMaxStorageSizeMB = maxStorageSizeMB;
    }

    public boolean isIncludePageViewAccessibility() {
        return mIncludePageViewAccessibility;
    }

    public void setIncludePageViewAccessibility(boolean mIncludePageViewAccessibility) {
        this.mIncludePageViewAccessibility = mIncludePageViewAccessibility;
    }

    public boolean isIncludeFeatureClickAccessibility() {
        return mIncludeFeatureClickAccessibility;
    }

    public void setIncludeFeatureClickAccessibility(boolean mIncludeFeatureClickAccessibility) {
        this.mIncludeFeatureClickAccessibility = mIncludeFeatureClickAccessibility;
    }
}
