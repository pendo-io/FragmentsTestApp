package sdk.pendo.io.network.socketio.configuration;

import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.network.responses.ScreenIdentificationData;
import sdk.pendo.io.network.responses.TriggerModel;

/**
 * Model for the data recieved during pairing
 * for the app verification stage
 */

public class IdentifyScreenData {

    @SerializedName("screenIdentificationData")
    public ScreenIdentificationData screenIdentificationData;

    @SerializedName("conditions")
    public TriggerModel.Conditions conditions;
}
