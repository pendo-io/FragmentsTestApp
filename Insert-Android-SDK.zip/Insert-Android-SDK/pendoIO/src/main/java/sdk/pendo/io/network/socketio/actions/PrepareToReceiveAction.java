package sdk.pendo.io.network.socketio.actions;

import android.graphics.Bitmap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import sdk.pendo.io.network.socketio.SocketIOManager;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.listeners.EmitterListener;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by tomerlevinson on 10/25/15.
 * <p/>
 * This class is used for prepareToReceiveScreen & readyToReceiveScreen events.
 * prepareToReceiveScreen event - Mobile notifies the initiator that image message is ready to be
 * sent. readyToReceiveScreen event - UI notifies the mobile that it is ready to receive image.
 * <p/>
 * The first event expects a readyToReceiveScreen response from the server. This class is part of
 * the protocol defined in the Pendo wiki
 *
 * @ https://sites.google.com/a/insert.io/wiki/development/websockets-api
 */
public final class PrepareToReceiveAction {

    private PrepareToReceiveAction() {
    }

    /*
      * This method emits the prepareToReceiveScreen event, which tells the server to ready up
      * for a screen. We also add a listener here for the readyToReceiveScreen event which we
      * receive from the server, which tells us that we can continue with the screen sending,
      * which is done on the call function we override here.
     */
    public static void prepareToReceiveScreenAndSend(final JSONArray viewHierarchy,
                                                     final Bitmap bitmap)
    {
        JSONObject data = new JSONObject();

        SocketIOManager.getInstance()
                .removeAll(SocketEvents.EVENT_READY_TO_RECEIVE_SCREEN.getCommand());

        SocketIOUtils.emitToSocket(SocketEvents.EVENT_PREPARE_TO_RECEIVE_SCREEN.getCommand(), data);

        SocketIOManager.getInstance().addListener(
                SocketEvents.EVENT_READY_TO_RECEIVE_SCREEN.getCommand(),
                new EmitterListener() {
                    @Override
                    public void call(Object... args) {
                        try {
                            SocketIOUtils.sendCapturedScreen(
                                    SocketEvents.EVENT_SCREEN_CAPTURED,
                                    viewHierarchy,
                                    bitmap,
                                    null);
                            SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_CAPTURE_MODE_SCREEN_CAPTURED);
                        } catch (JSONException e) {
                            InsertLogger.e(e, e.getMessage());
                        }
                    }
                });
    }


}


