package sdk.pendo.io.network.interfaces;

public enum AnalyticsServerEndpoint {
    PRODUCTION("https://data.mobile.pendo.io"),
    CUSTOM("");

    private String mUri;

    AnalyticsServerEndpoint(String url){
        mUri = url;
    }

    public String getUrl() {
        return mUri;
    }

    /**
     * Sets the analytics endpoint uri
     * @param uri
     * @return the analytics Endpoint with the url inside
     */
    public AnalyticsServerEndpoint setUrl(String uri) {
        mUri = uri;
        return this;
    }

}
