package sdk.pendo.io.data.structures;
/*
 * Copyright 2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.support.annotation.NonNull;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * A WeakValueHashMap is implemented as a HashMap that maps keys to
 * WeakValues.  Because we don't have access to the innards of the
 * HashMap, we have to wrap/unwrap value objects with WeakValues on
 * every operation.  Fortunately WeakValues are small, short-lived
 * objects, so the added allocation overhead is tolerable. This
 * implementaton directly extends java.util.HashMap.
 *
 * @author	Markus Fuchs
 * @see		java.util.HashMap
 * @see     java.lang.ref.WeakReference
 */

public final class WeakValueHashMap<K, V> extends AbstractMap<K, V> {

    private static final int DEFAULT_SIZE = 16;

    // the internal hash map to the weak references of the actual value objects
    private HashMap<K, WeakValue<V>> references;

    // the garbage collector's removal queue
    private ReferenceQueue<V> gcQueue;


    /**
     * Creates a WeakValueHashMap with a desired initial capacity
     * @param capacity - the initial capacity
     */
    public WeakValueHashMap(int capacity) {
        references = new HashMap<>(capacity);
        gcQueue = new ReferenceQueue<>();
    }

    /**
     * Creates a WeakValueHashMap with an initial capacity of {@link #DEFAULT_SIZE}
     */
    public WeakValueHashMap() {
        this(DEFAULT_SIZE);
    }

    /**
     * Creates a WeakValueHashMap and copies the content from an existing map
     * @param map - the map to copy from
     */
    public WeakValueHashMap(Map<? extends K, ? extends V> map) {
        this(map.size());
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet() ) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override
    public V put(K key, V value) {
        processQueue();
        WeakValue<V> valueRef = new WeakValue<>(key, value, gcQueue);
        return getReferenceValue(references.put(key, valueRef));
    }

    @Override
    public V get(Object key) {
        processQueue();
        return getReferenceValue(references.get(key));
    }

    @Override
    public V remove(Object key) {
        return getReferenceValue(references.remove(key));
    }

    @Override
    public void clear() {
        references.clear();
    }

    @Override
    public boolean containsKey(Object key) {
        processQueue();
        return references.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        processQueue();
        for (Map.Entry<K, WeakValue<V>> entry : references.entrySet()) {
            if (value == getReferenceValue(entry.getValue())) {
                return true;
            }
        }
        return false;
    }

    @NonNull
    @Override
    public Set<K> keySet() {
        processQueue();
        return references.keySet();
    }

    @Override
    public int size() {
        processQueue();
        return references.size();
    }

    @NonNull
    @Override
    public Set<Map.Entry<K,V>> entrySet() {
        processQueue();

        Set<Map.Entry<K,V>> entries = new LinkedHashSet<>();
        for (Map.Entry<K,WeakValue<V>> entry : references.entrySet()) {
            entries.add(new AbstractMap.SimpleEntry<>(entry.getKey(), getReferenceValue(entry.getValue())));
        }
        return entries;
    }

    @NonNull
    public Collection<V> values() {
        processQueue();

        Collection<V> values = new ArrayList<>();
        for (WeakValue<V> valueRef : references.values()) {
            values.add(getReferenceValue(valueRef));
        }
        return values;
    }

    private V getReferenceValue(WeakValue<V> valueRef) {
        return valueRef == null ? null : valueRef.get();
    }

    // remove entries once their value is scheduled for removal by the garbage collector
    @SuppressWarnings("unchecked")
    private void processQueue() {
        WeakValue<V> valueRef;
        while ( (valueRef = (WeakValue<V>) gcQueue.poll()) != null ) {
            references.remove(valueRef.getKey());
        }
    }

    // for faster removal in {@link #processQueue()} we need to keep track of the key for a value
    private class WeakValue<T> extends WeakReference<T> {
        private final K key;

        private WeakValue(K key, T value, ReferenceQueue<T> queue) {
            super(value, queue);
            this.key = key;
        }

        private K getKey() {
            return key;
        }
    }
}
