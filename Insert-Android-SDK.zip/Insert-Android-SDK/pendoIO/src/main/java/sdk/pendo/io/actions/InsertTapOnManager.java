package sdk.pendo.io.actions;

import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import io.reactivex.Observable;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.R;
import sdk.pendo.io.listeners.ApplicationObservers;

/**
 * Created by tomerlevinson on 5/16/16.
 * <p>
 * This class is responsible for the tap on event consequences.
 * i.e when a tap on event occurs, we display a loading "dialog" (layout to be precise),
 * that has a spinner inside of it, and also has a timer.
 * The timer is needed for insert dismissal purposes in case we've waited for too long.
 */
public final class InsertTapOnManager {
    //Constants
    private static final int DEFAULT_TRANSPARENT_COLOR = 0xCC000000;
    private static final int TAP_ON_TIMEOUT = 10000;
    private static final int DEFAULT_ALPHA = 204;
    private static final String TAP_ON_SPINNER_DESCRIPTION = "TAP_ON_SPINNER";
    private static final BehaviorSubject<Boolean> IS_TAP_ON_TIME_EXPIRED =
            BehaviorSubject.createDefault(false);
    private static LinearLayout sTapOnLinearLayout;
    private static Handler sTimeoutExpiredHandler;
    private static Runnable sTimeoutExpiredRunnable;

    private InsertTapOnManager() {
        //not called
    }
    /*
     * Get tap on done as observable that emits true/false according
     * to whether the tap on timeout has expired.
     */
    public static Observable<Boolean> getTapOnTimeExpiredObservable() {
        return IS_TAP_ON_TIME_EXPIRED;
    }

    public static synchronized void resetTapOn() {
        if (isTapOnLayoutExist()) {
            if (sTimeoutExpiredHandler != null && sTimeoutExpiredRunnable != null) {
                sTimeoutExpiredHandler.removeCallbacks(sTimeoutExpiredRunnable);
            }
            removeAddedTapOnLayouts();
        }
    }

    /*
     * Setter for the tap on done behavioral subject.
     */
    private static void setTapOnTimeExpired(boolean isTimeExpired) {
        IS_TAP_ON_TIME_EXPIRED.onNext(isTimeExpired);
    }

    /*
     * Removes the added tap on indication linear layout from the current activity tree.
     */
    private static void removeAddedTapOnLayouts() {

        // FIXME: 11/30/16 Get the activity once.
        // Remove the added tap on linear layout.
        final ViewGroup contentView = (ViewGroup) ApplicationObservers
                .getInstance().getCurrentVisibleActivity()
                .getWindow().getDecorView().getRootView();
        if (contentView != null) {
            Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
            if (currentActivity != null) {
                currentActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (sTapOnLinearLayout != null) {
                            sTapOnLinearLayout.setVisibility(View.GONE);
                            contentView.removeView(sTapOnLinearLayout);
                        }
                    }
                });
            }
        }
        sTapOnLinearLayout = null;
    }

    /*
     *  In case we have the tap on dialog on,
     *  remove the spinner from it.
     */
    public static void removeSpinnerFromLayout() {
        if (sTapOnLinearLayout != null) {
            View progressBarView = sTapOnLinearLayout.findViewById(R.id.tapOnDialogProgressBar);
            if (progressBarView != null) {
                progressBarView.setVisibility(View.GONE);
            }
        }
    }

    public static boolean isTapOnTimeoutExpired() {
        return isTapOnLayoutExist() && IS_TAP_ON_TIME_EXPIRED.getValue();
    }

    /*
     * Check if the dialog is on.
     */
    public static boolean isTapOnLayoutExist() {
        return sTapOnLinearLayout != null;
    }

    /*
     * Set timeout for the tap on action.
     */
    private static void setTimeoutForTapOn() {
        setTapOnTimeExpired(false);
        sTimeoutExpiredHandler  = new Handler();
        sTimeoutExpiredRunnable = new Runnable() {
            @Override
            public void run() {
                setTapOnTimeExpired(true);
            }
        };
        sTimeoutExpiredHandler.postDelayed(sTimeoutExpiredRunnable, TAP_ON_TIMEOUT);

    }

    /*
     * Creates a linear layout for the tap on loading screen.
     * Inside that linear layout we have a relative layout holding a progress bar.
     * (The relative layout is for centering purposes inside the linear layout)
     *  ***.The background colors are taken from the currently used colors in the insert
     *      floating background.(May want to change this in the future)
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public static void runTapOnIndication() {
        Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        // Color drawable with the floating background color and alpha.
        ColorDrawable colorDrawable = new ColorDrawable(DEFAULT_TRANSPARENT_COLOR);
        colorDrawable.setAlpha(DEFAULT_ALPHA);
        // Let's create the linear layout for the on tap screen loading background.
        sTapOnLinearLayout = new LinearLayout(Pendo.getApplicationContext());
        sTapOnLinearLayout.setLayoutParams(
                new ViewGroup.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT));
        sTapOnLinearLayout.setId(R.id.tapOnDialogLayout);
        int sdk = android.os.Build.VERSION.SDK_INT;
        if (sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
            sTapOnLinearLayout.setBackgroundDrawable(colorDrawable);
        } else {
            sTapOnLinearLayout.setBackground(colorDrawable);
        }
        //Create the progress bar and the relative layout that holds it.
        ProgressBar pb = new ProgressBar(currentActivity, null, android.R.attr.progressBarStyle);
        pb.setId(R.id.tapOnDialogProgressBar);
        pb.setContentDescription(TAP_ON_SPINNER_DESCRIPTION);
        pb.setIndeterminate(true);
        RelativeLayout.LayoutParams pbParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);
        pbParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        RelativeLayout relativeLayout = new RelativeLayout(Pendo.getApplicationContext());
        relativeLayout.setGravity(Gravity.CENTER);
        relativeLayout.addView(pb);
        sTapOnLinearLayout.addView(relativeLayout, pbParams);
        if (currentActivity != null) {
            if (currentActivity.getWindow() != null
                    && currentActivity.getWindow().getDecorView() != null) {
                ViewGroup contentView = (ViewGroup) ApplicationObservers.getInstance()
                        .getCurrentActivityRootView();
                //Add the newly created linear layout to the activity.
                contentView.addView(sTapOnLinearLayout);
                setTimeoutForTapOn();
            }
        }
    }
}
