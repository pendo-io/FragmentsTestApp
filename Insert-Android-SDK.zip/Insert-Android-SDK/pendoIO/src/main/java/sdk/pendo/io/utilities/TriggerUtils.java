package sdk.pendo.io.utilities;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;

import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.events.ConditionData;
import sdk.pendo.io.events.ConditionData.ConditionParam;
import sdk.pendo.io.events.ConditionData.ConditionType;
import sdk.pendo.io.events.ConditionData.Operator;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.intelligence.IntelManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.responses.TriggerModel;

import static sdk.pendo.io.events.ConditionData.NUMBER_VALUE;
import static sdk.pendo.io.events.ConditionData.STRING_VALUE;

/**
 * Created by itayvallach on 15/09/2016.
 */
public final class TriggerUtils {

    private TriggerUtils() {}

    public static final String LOGICAL_OPERATOR_OR = "OR";

    /**
     * Iterates through the trigger's conditions and checks them.
     * @param trigger - The input trigger for which we check its conditions.
     * @param rootView - Optional param needed for conditions of type ELEMENT_INFO.
     *                 we need the root view in order to find the value for the condition
     *                 using the ElementInfo by traversing in the view hierarchy.
     * @return True if all of the input trigger's conditions are met. False otherwise.
     */
    public static boolean satisfiesAllConditions(TriggerModel trigger, @Nullable View rootView) {

        // Before getting to the conditions, first verify that preferences are valid.
        if (!PreferencesUtils.isConditionalPreferencesValid(trigger.getConfiguration().getPreferences())) {
            return false;
        }

        boolean isAndOperator = !LOGICAL_OPERATOR_OR.equalsIgnoreCase(trigger.getConditionsOperator());

        for (ConditionData condition : trigger.getConditions()) {

            switch (ConditionType.get(condition.getType())) {

                case ELEMENT_INFO: {
                    IdentificationData elementInfo = condition.getTypeValue();

                    if (rootView != null && elementInfo != null) {
                        View foundView = IntelManager.findViewInHierarchy(rootView, elementInfo, true, condition);
                        Operator operator = ConditionData.Operator.get(condition.getOperator());

                        if (foundView == null && operator != Operator.NOT_EXISTS) {
                            if (isAndOperator) {
                                return false;
                            }
                            break;
                        }

                        if (foundView != null && operator == Operator.NOT_EXISTS) {
                            if (isAndOperator) {
                                return false;
                            }
                            break;
                        }

                        if (!isAndOperator) {
                            return true;
                        }

                    }
                    break;
                }

                case SCRIPT: {
//                    if (!TriggerUtils.satisfiesFieldValueCondition(condition,
//                            (String) JavascriptRunner.runCode(
//                                    condition.getTypeValue(), String.class))) {
//                        if (isAndOperator) {
//                            return false;
//                        }
//
//                    } else if (!isAndOperator) {
//                        return true;
//                    }
                    break;
                }

                case SHARED_PREFERENCE: {
//                    if (!TriggerUtils.satisfiesFieldValueCondition(condition,
//                            SettingsUtils.getSetting(condition.getTypeValue(), null))) {
//
//                        if (isAndOperator) {
//                            return false;
//                        }
//
//                    } else if (!isAndOperator) {
//                        return true;
//                    }
                    break;
                }
            }

        }

        return isAndOperator ? true : false;
    }

    /**
     * A simple method which takes a value and checks a condition regarding it.
     * @param condition The condition we need to check whether our mainValue satisfies or not.
     * @param mainValue The main value we check whether or not it meets the condition.
     * @return True if the mainValue satisfies the condition. False otherwise.
     */
    public static boolean satisfiesFieldValueCondition(ConditionData condition, String mainValue) {
        Operator operator = ConditionData.Operator.get(condition.getOperator());
        ConditionParam[] params = condition.getParameters();

        try {
            ConditionParam param = params[0];
            if (STRING_VALUE.equals(param.getType())) {
                String paramValue = param.getValue().toLowerCase();
                mainValue = mainValue.toLowerCase();

                switch (operator) {

                    case STR_EQUALS:
                        if (!mainValue.equals(paramValue)) {
                            return false;
                        }
                        break;

                    case STR_NOT_EQUALS:
                        if (mainValue.equals(paramValue)) {
                            return false;
                        }
                        break;

                    case STARTS_WITH:
                        if (!mainValue.startsWith(paramValue)) {
                            return false;
                        }
                        break;
                    case ENDS_WITH:
                        if (!mainValue.endsWith(paramValue)) {
                            return false;
                        }
                        break;
                    case CONTAINS:
                        if (!mainValue.contains(paramValue)) {
                            return false;
                        }
                        break;
                    case NOT_CONTAINS:
                        if (mainValue.contains(paramValue)) {
                            return false;
                        }
                        break;
                }

            } else if (NUMBER_VALUE.equals(param.getType())) {
                double doubleMainValue;
                double paramValue;

                try {
                    // Remove any non-digit characters except '.'
                    String newMainValue = mainValue.replaceAll("[^\\d.]", "");
                    if (TextUtils.isEmpty(newMainValue)) {
                        // In case the filtered string is empty, we don't need to parse it
                        return false;
                    }
                    doubleMainValue = Double.valueOf(newMainValue);

                    String newParamValue = param.getValue().replaceAll("[^\\d.]", "");
                    if (TextUtils.isEmpty(newParamValue)) {
                        // In case the filtered string is empty, we don't need to parse it
                        return false;
                    }
                    paramValue = Double.valueOf(newParamValue);
                } catch (Exception e) {
                    InsertLogger.e("Error while parsing number from currency string condition  " + e.getMessage());
                    return false;
                }

                switch (operator) {

                    case NUM_EQUALS:
                        if (doubleMainValue != paramValue) {
                            return false;
                        }
                        break;

                    case NUM_NOT_EQUALS:
                        if (doubleMainValue == paramValue) {
                            return false;
                        }
                        break;

                    case LESS_THAN:
                        if (doubleMainValue >= paramValue) {
                            return false;
                        }
                        break;
                    case LESS_THAN_OR_EQUALS:
                        if (doubleMainValue > paramValue) {
                            return false;
                        }
                        break;
                    case GREATER_THAN:
                        if (doubleMainValue <= paramValue) {
                            return false;
                        }
                        break;
                    case GREATER_THAN_OR_EQUALS:
                        if (doubleMainValue < paramValue) {
                            return false;
                        }
                        break;
                }

            }
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    /**
     * Checks whether a specific condition should be taken into account when comparing two views.
     * Any operator other than "EXISTS" makes the condition relevant as we need to check
     * "Greater Than", "Smaller Than", etc.
     * @param condition - The condition we're checking if relevant.
     * @return True if the condition's operator is anything but "EXISTS" (then it's relevant). False otherwise.
     */
    public static boolean isConditionRelevantForComparingViews(ConditionData condition) {
        return condition != null
                && !Operator.get(condition.getOperator()).equals(Operator.EXISTS)
                && !Operator.get(condition.getOperator()).equals(Operator.NOT_EXISTS);
    }

    public static boolean isFullScreenInsertTrigger(@NonNull TriggerModel trigger) {
        if (trigger.getInsertIds() != null) {
            for (String insertId : trigger.getInsertIds()) {
                if (!InsertsManager.getInsert(insertId).getConfiguration().isMultipleShows()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * After trigger is triggered, update its dependencies if such exist.
     * @param triggerModel - the trigger that was triggered.
     */
    public static void handleTriggerFlow(TriggerModel triggerModel) {

        // If ScreenLeft was triggered, set its flow back to false
        // (it now needs another ScreenView event in order to satisfy the flow).
        if (triggerModel.getConfiguration().getScreenViewDependency() > 0) {
            triggerModel.setSatisfiesFlow(false);
            triggerModel.resetDispatchCommands();
        }

        // If ScreenView was triggered, find the ScreenLeft event
        // that depends on it and set its flow as satisfied.
        int screenLeftDependency = triggerModel.getConfiguration().getScreenLeftDependency();
        if (screenLeftDependency > 0) {
            TriggerModel screenLeftTrigger = EventsManager.getInstance()
                    .getFlowTrigger(screenLeftDependency);
            if (screenLeftTrigger != null) {
                screenLeftTrigger.setSatisfiesFlow(true);
            }
        }
    }
}


