package sdk.pendo.io.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;

import sdk.pendo.io.R;

/**
 * Created by tomerlevinson on 10/28/15.
 */
public class ProgressDialog extends DialogFragment {

    private static Dialog sDialog = null;
    private static final int TRANSPARENT_COLOR = 0xCCFFFFFF;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    /*
     *  Getter function for last non-null dialog.
     *  When a new dialog fragment is instanstiated, the dialog is null,
     *  therefore we need to save the last non-null dialog.
     */
    public Dialog getLastDialog(){
        return sDialog;
    }

    @Override
    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance())
            getDialog().setDismissMessage(null);
        super.onDestroyView();
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        setRetainInstance(true);
        setCancelable(true);
        sDialog = new Dialog(getActivity());
        sDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        sDialog.setContentView(R.layout.activity_pairing_mode);
        ProgressBar pb = (ProgressBar) sDialog.findViewById(R.id.progress_bar);
        pb.setIndeterminate(true);
        Drawable indeterminateDrawable = pb.getIndeterminateDrawable();
        pb.setIndeterminateDrawable(indeterminateDrawable);
        final Window window = sDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        window.setBackgroundDrawable(new ColorDrawable(TRANSPARENT_COLOR));
        return sDialog;
    }
}
