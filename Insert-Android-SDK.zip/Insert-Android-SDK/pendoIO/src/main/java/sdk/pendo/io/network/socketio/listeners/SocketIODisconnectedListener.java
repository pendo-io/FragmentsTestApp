package sdk.pendo.io.network.socketio.listeners;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.logging.InsertLogger;

public final class SocketIODisconnectedListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got Disconnect");
        SocketEventFSM.getInstance().updateSocketConnectedObservable(false);
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_SOCKET_DISCONNECTED, args);
    }
}
