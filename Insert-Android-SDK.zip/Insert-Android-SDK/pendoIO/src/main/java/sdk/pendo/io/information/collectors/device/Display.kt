package sdk.pendo.io.information.collectors.device

import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.utilities.ViewUtils
import sdk.pendo.io.utilities.add
import java.util.*

/**
 * Collect  information about the display.

 * Created by assaf on 4/14/15.
 */
internal class Display : Collector() {

    override fun collectData(json: JSONObject) {

        // Get the device display.
        addDisplayInfo(json)
    }

    /**
     * Adds JSON representing the display information.

     * @param info The JSONObject to receive the display information.
     */
    private fun addDisplayInfo(info: JSONObject) {

        val dm = DisplayMetrics()
        val wm = application!!.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val width: Int
        val height: Int
        val dens: Int

        height = addJellybeanProperties(dm, display)
        width = dm.widthPixels
        dens = dm.densityDpi

        val wi = width.toDouble() / dens.toDouble()
        val hi = height.toDouble() / dens.toDouble()
        val displaySize = Math.sqrt(Math.pow(wi, 2.0) + Math.pow(hi, 2.0))

        val displayJSON = JSONObject()
        //displayJSON.add("display", Build.DISPLAY);
        //displayJSON.add("id", display.getDisplayId());
        displayJSON.add("width", width)
        displayJSON.add("height", height)
        displayJSON.add("density", dens)
        val doubleValueString = String.format(Locale.US, "%.2f", displaySize)
        displayJSON.add("size", java.lang.Double.valueOf(doubleValueString))
        addLollipopProperties(display, displayJSON)
        displayJSON.add("refresh_rate", display.refreshRate.toDouble())

        info.add("display", displayJSON)
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private fun addLollipopProperties(display: android.view.Display, displayJSON: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val refreshRates = JSONArray()
            val supportedRefreshRates = display.supportedRefreshRates
            for (supportedRefreshRate in supportedRefreshRates) {
                refreshRates.add(supportedRefreshRate.toDouble())
            }

            displayJSON.add("supported_refresh_rates", refreshRates)
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    private fun addJellybeanProperties(dm: DisplayMetrics, display: android.view.Display): Int {
        val height: Int
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            display.getRealMetrics(dm)
            height = dm.heightPixels
        } else {
            display.getMetrics(dm)
            height = dm.heightPixels + ViewUtils.getNavigationBarHeight()
        }
        return height
    }
}
