package sdk.pendo.io.utilities.script;

import java.util.HashSet;
import java.util.Set;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.utilities.AnalyticsUtils;

import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.ScriptError.JS_ERROR;

/**
 * Javascript sandbox implementation.
 *
 * Created by assaf on 11/6/16.
 */
final class JavascriptSandboxImpl implements ScriptSandbox {
    private static volatile JavascriptSandboxImpl INSTANCE;

    private Set<Class> mWhitelistClasses = new HashSet<>();
    private boolean mStrictMode = true;

    private JavascriptSandboxImpl() { }
    public static synchronized JavascriptSandboxImpl getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new JavascriptSandboxImpl();
        }

        return INSTANCE;
    }

    @Override
    public boolean setSandboxModeAndWhitelist(Pendo.PendoOptions options) {
        mStrictMode = options.getStrictMode();
        return mWhitelistClasses.addAll(options.getWhitelist());
    }

    @SuppressWarnings("SimplifiableIfStatement")
    @Override
    public boolean allowClassAccess(Class<?> type) {

        // Check if the class is the application context or the Java class loader.
        if (type.equals(Pendo.getApplicationContext().getClass())) {
            return true;
        } else if (type.equals(Pendo.class.getClassLoader().getClass())) {
            return true;
        }

        // Check if the class is either Pendo's, Java or JSON.
        final String canonicalName = type.getCanonicalName();
        if (canonicalName.startsWith("sdk.pendo.io.")) { // Pendo's own code.
            return true;

        } if (canonicalName.startsWith("external.sdk.pendo.io.")) { // Pendo's libraries.
            return true;

        } else if (canonicalName.startsWith("java.")) { // Java's code.
            return true;

        } else if (canonicalName.startsWith("org.json.")) { // JSON support.
            return true;
        }

        // Check if the class was white listed.
        if (!mWhitelistClasses.isEmpty() && mWhitelistClasses.contains(type)) {
            return true;
        }

        // Send analytics about the unauthorized class access attempt.
        if (mStrictMode) {
            AnalyticsUtils.sendScriptableError(
                    JS_ERROR,
                    "Trying to access an unauthorized class: '" + canonicalName + "'");
        }

        // If none of the above, check if we run under strict mode.
        // If we run strictly, then return false, meaning disallow access to the class.
        return !mStrictMode;
    }

    @Override
    public boolean allowFieldAccess(Class<?> type, Object instance, String fieldName) {
        return true;
    }

    @Override
    public boolean allowMethodAccess(Class<?> type, Object instance,
                                     String methodName) {
        return true;
    }

    @Override
    public boolean allowStaticFieldAccess(Class<?> type, String fieldName) {
        return true;
    }

    @Override
    public boolean allowStaticMethodAccess(Class<?> type, String methodName) {
        return true;
    }

}
