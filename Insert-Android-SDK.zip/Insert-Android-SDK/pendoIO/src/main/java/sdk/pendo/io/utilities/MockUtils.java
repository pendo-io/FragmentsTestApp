package sdk.pendo.io.utilities;

import android.provider.Settings;

import java.nio.charset.Charset;

import sdk.pendo.io.Pendo;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Utility class for mocking.
 *
 * Created by assaf on 5/4/15.
 */
public final class MockUtils {
    private MockUtils() {}

    public static String getMockMACAddress() {

        String UUID = Settings.Secure.getString(Pendo.getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
        byte[] UUIDBytes = UUID.getBytes(Charset.forName(ENCODING_UTF_8));
        String mockMAC = Utils.bytesToHex(UUIDBytes);

        StringBuilder mac = new StringBuilder("IN:");
        for (int i = 0; i < 4; i = i + 2) {
            mac.append(mockMAC.charAt(i));
            mac.append(mockMAC.charAt(i + 1));
            mac.append(":");
        }
        mac.append("ST");

        return mac.toString();
    }
}
