package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import external.sdk.pendo.io.dynamicview.DynamicView;
import external.sdk.pendo.io.tooltip.InsertTooltipManager;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.constants.Constants;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.TooltipUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;
import sdk.pendo.io.views.InsertViewHolder;

public class ToolTipVisualInsert extends VisualInsertBase {

    private static final String DP_DIMEN_POSTFIX = "dp";
    private static final String EMPTY_STRING = "";

    private static final String CLICK_ACTION_CLICK_THROUGH_VALUE = "click_through";

    private View mAnchorView;
    private GenericInsertAnalyticsData analyticsData;
    private final HashMap<String, Object> mTooltipPropertiesToBePopulated = new HashMap<>();

    private static final HashSet<String> SUPPORTED_TOOLTIP_PROPERTIES =
            new HashSet<>(Arrays.asList(Constants.ViewAttrsConsts.POSITION,
                    Constants.ViewAttrsConsts.BACKGROUND,
                    Constants.ViewAttrsConsts.FONT_FAMILY,
                    Constants.ViewAttrsConsts.TEXT_COLOR,
                    Constants.ViewAttrsConsts.TEXT,
                    Constants.ViewAttrsConsts.TEXT_STYLE,
                    Constants.ViewAttrsConsts.TEXT_SIZE,
                    Constants.ViewAttrsConsts.TEXT_DIRECTION,
                    Constants.ViewAttrsConsts.PADDING,
                    Constants.ViewAttrsConsts.GRAVITY,
                    Constants.ViewAttrsConsts.FRAME_COLOR,
                    Constants.ViewAttrsConsts.FRAME_WIDTH,
                    Constants.ViewAttrsConsts.FRAME_RADIUS));


    public ToolTipVisualInsert(@Nullable GuideModel guideModel, VisualInsertLifecycleListener listener) {
        super(guideModel, listener);
    }

    public final void init(@Nullable WeakReference<View> viewRef, GenericInsertAnalyticsData analyticsData, String activatedBy) {
        super.init(activatedBy, analyticsData);
        mAnchorView = (viewRef != null) ? viewRef.get() : null;
        this.analyticsData = analyticsData;
        JsonArray givenPropertiesFromJSON = getToolTipProperties();
        if (givenPropertiesFromJSON != null) {
            extractProperties(givenPropertiesFromJSON, mTooltipPropertiesToBePopulated, SUPPORTED_TOOLTIP_PROPERTIES);
        }

    }

    /**
     *
     * @return the instance of InsertTooltipManager with it's Context set to the current activity.
     */
    private static synchronized InsertTooltipManager getTooltipManager() {
        // Used in order to reset the context to the current activity.
        InsertTooltipManager.resetContext(ApplicationObservers.getInstance()
                .getCurrentVisibleActivity());
        return InsertTooltipManager.getInstance();
    }

    private InsertTooltipManager.Gravity getPosition() {

        String position = (String) mTooltipPropertiesToBePopulated.get(Constants.ViewAttrsConsts.POSITION);

        try {
            return InsertTooltipManager.Gravity.valueOf(position.toUpperCase(Locale.US));
        } catch (IllegalArgumentException ignore) {

        } catch (Exception e) {
            return InsertTooltipManager.Gravity.TOP;
        }

        // Return default.
        return InsertTooltipManager.Gravity.TOP;
    }

    private String getStrokeColor() {
        return (String) mTooltipPropertiesToBePopulated.get(Constants.ViewAttrsConsts.FRAME_COLOR);
    }

    private String getStrokeWidthInDp() {
        return (String) mTooltipPropertiesToBePopulated.get(Constants.ViewAttrsConsts.FRAME_WIDTH);
    }

    private String getFrameRadiusInDp() {
        return (String) mTooltipPropertiesToBePopulated.get(Constants.ViewAttrsConsts.FRAME_RADIUS);
    }

    /**
     * Method creates the inner view set as the tooltip's content.
     * We use dynamic view, by supplying it with the json.
     * Default close policy is touch anywhere on screen.
     * close policy: click outside
     * closeDelay is currently disabled (set as 0) support for mInsertTimeout will be added soon
     * @return true
     */
    public synchronized final boolean show() {
        final InsertTooltipManager tooltipManager = getTooltipManager();
        final String idHash = analyticsData.getInsertId();
        JsonObject toolTipContent = getToolTipContentJson();
        String currentStepIndex = StepSeenManager.getInstance().getCurrentStepId();
        final View viewFromJson = DynamicView.createView(
                mAnchorView.getContext(),
                toolTipContent, null,
                InsertViewHolder.class, getGuideId(), currentStepIndex);

        final boolean touchPassThrough = getTouchPassThrough();
        final String strokeWidth = getStrokeWidthInDp() != null ? getStrokeWidthInDp().replace(DP_DIMEN_POSTFIX, EMPTY_STRING) : null;
        final String frameRadius = getFrameRadiusInDp() != null ? getFrameRadiusInDp().replace(DP_DIMEN_POSTFIX, EMPTY_STRING) : null;
        final String strokeColor = getStrokeColor();

        ApplicationObservers.getInstance().getCurrentVisibleActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {

                long closeDelay = TimeUnit.SECONDS.toMillis(NO_CLOSE_DELAY);


                InsertTooltipManager.Builder builder = new InsertTooltipManager.Builder(idHash)
                        .anchor(mAnchorView, getPosition())
                        .closePolicy(
                                closeDelay)
                        .background(getBackground())
                        .toggleArrow(true)
                        .withCustomView(viewFromJson)
                        .insertId(StepSeenManager.getInstance().getCurrentStepId())
                        .withCallback(new InsertTooltipManager.onTooltipClosingCallback() {
                            @Override
                            public void onClosing(String id, boolean fromUser, boolean containsTouch, long displayDuration, boolean wasShown) {
                                if (wasShown) {
                                    if (fromUser) {
                                        InsertCommandParameterInjector.getInstance().handleInsertUserActionAnalytics(
                                                analyticsData.getInsertId(),
                                                displayDuration);
                                    } else {
                                        InsertCommandParameterInjector.getInstance().handleInsertTimeoutAnalytics(
                                                analyticsData.getInsertId(),
                                                displayDuration);
                                    }
                                }
                            }

                            @Override
                            public void onTouchOutside(final String id) {
                                handleTouchOutsideTooltip(id);
                            }
                        });
                if (strokeWidth != null && strokeColor != null) {
                    builder.strokeColor(strokeColor).strokeWidth(strokeWidth);
                }
                if (frameRadius != null) {
                    builder.frameRadius(frameRadius);
                }
                builder.withTouchPassThrough(touchPassThrough);

                boolean showed = tooltipManager.show(builder.build());

                if (!showed) {
                    if (getTracker() != null) {
                        AnalyticsUtils.sendInsertNotDisplayedAnalyticsEvent(getTracker(), GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_UNKNOWN, mAdditionalInfo);
                    }
                } else {
                    getAndSetShowing(true);
                }
            }
        });

        return true;
    }

    private void handleTouchOutsideTooltip(final String insertId) {
        final JsonObject tooltipMetaData = getToolTipWidgetWrapperJsonObject();
        if (tooltipMetaData == null) {
            InsertLogger.d("No actions to handle touch outside tooltip event.");
            return;
        }
        final JsonArray actions =
                JsonUtils.optJsonArray(tooltipMetaData, InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);
        if (actions != null && actions.size() > 0) {
            final JavascriptRunner.InsertContext insertContext =
                    new JavascriptRunner.InsertContext(insertId);
            List<InsertCommand> commands =
                    InsertCommand.getInsertCommandsWithParameters(
                            actions,
                            InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.createInsertMetadataParams(insertId),
                            insertContext);

            JavascriptRunner.InsertContext.addBasicParamsToInsertCommands(commands);
            InsertCommandDispatcher.getInstance().dispatchCommands(commands, InsertCommandEventType.UserEventType.TAP_ON, true);
        }
    }

    @Override
    void onDestroy() {
        super.onDestroy();

        cancelDuration();

        if (mListener != null) {
            mListener.onDestroy(getGuideId());
        }

        mShowing.set(false);

        setTracker(null);

        InsertsManager.removeVisualInsertInitedObservable(getGuideId());
        mAnchorView = null;
    }

    private static void extractProperties(@NonNull JsonArray properties,
                                          @NonNull HashMap<String, Object> elementBoundProperties,
                                          @NonNull HashSet<String> relevantProperties) {

        for (JsonElement property : properties) {

            if (property.isJsonObject()) {
                final JsonObject jsonObject = property.getAsJsonObject();
                String name = jsonObject.get(Constants.DynamicViewsConsts.NAME).getAsString();

                if (!relevantProperties.contains(name)) {
                    continue;
                }

                String type = jsonObject.get(Constants.DynamicViewsConsts.TYPE).getAsString();
                JsonElement value = jsonObject
                        .get(Constants.DynamicViewsConsts.VALUE);

                if (Constants.SpecialViewAttrTypeConsts.JSON.equals(type)) {
                    elementBoundProperties.put(name, value.getAsJsonObject());
                } else {
                    elementBoundProperties.put(name, value.getAsString());
                }

                if (elementBoundProperties.size() == relevantProperties.size()) {
                    break;
                }
            }
        }
    }

    private String getBackground() {
        String rawColor = (String) mTooltipPropertiesToBePopulated.get(Constants.ViewAttrsConsts.BACKGROUND);
        return TooltipUtils.convertRRGGBBAAToAARRGGBBColor(rawColor);
    }

    /**
     * currently only supporting a single action (close) we remove the tooltip.
     * @param command
     */
    @Override
    void insertTypeDependentCommandHandle(InsertCommand command) {
        InsertTooltipManager.getInstance().remove(analyticsData.getInsertId());
    }

    /**
     * assuming we only have a single step.
     * @return json array containing the supported properties of the tooltip from the json
     */
    @Nullable
    private JsonArray getToolTipProperties() {
        if (getSteps() != null && getSteps().size() > 0) {
            return InsertActionConfiguration.getTooltipProperties(getSteps().get(StepSeenManager.getInstance().getCurrentStepIndex()).getAsJsonObject());
        }

        return null;
    }

    /**
     * assuming we only have a single step
     * @return JsonObject containing the content of the tooltip (the actual building blocks)
     */
    @Nullable
    private JsonObject getToolTipContentJson() {
        Integer currentStepIndex = StepSeenManager.getInstance().getCurrentStepIndex();
        if (currentStepIndex != null) {
            return InsertActionConfiguration.getTooltipContent(getSteps().get(currentStepIndex).getAsJsonObject());
        }
        return null;
    }

    /**
     * assuming we only have a single step
     * @return JsonObject representing the tooltip (the actual building blocks)
     */
    @Nullable
    private JsonObject getToolTipJsonObject() {
        if (getSteps() != null && getSteps().size() > 0) {
            return InsertActionConfiguration.getTooltipWidgetJsonObject(getSteps().get(StepSeenManager.getInstance().getCurrentStepIndex()).getAsJsonObject());
        }

        return null;
    }

    /**
     * assuming we only have a single step
     * @return JsonObject representing the tooltip wrapper object (the actual building blocks)
     */
    @Nullable
    private JsonObject getToolTipWidgetWrapperJsonObject() {
        if (getSteps() != null && getSteps().size() > 0) {
            return InsertActionConfiguration.getTooltipWidgetWrapperObject(getSteps().get(StepSeenManager.getInstance().getCurrentStepIndex()).getAsJsonObject());
        }

        return null;
    }

    /**
     *
     * @return if the view should be "click transparent" when pressing out of the actual tooltip
     */
    private boolean getTouchPassThrough() {
        if (getToolTipWidgetWrapperJsonObject() == null) {
            return false;
        }
        JsonArray properties = getToolTipWidgetWrapperJsonObject().getAsJsonArray(TooltipUtils.PROPERTIES_KEY);
        JsonObject clickActionProperty = TooltipUtils.getPropertyWithName(properties, Constants.ViewAttrsConsts.CLICK_ACTION_PROPERTY);
        if (clickActionProperty != null) {
            return CLICK_ACTION_CLICK_THROUGH_VALUE.equalsIgnoreCase(clickActionProperty.get(Constants.DynamicViewsConsts.VALUE).getAsString());
        }
        return false;
    }

}
