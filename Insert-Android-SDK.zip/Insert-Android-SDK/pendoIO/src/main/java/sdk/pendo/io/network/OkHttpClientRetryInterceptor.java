package sdk.pendo.io.network;

import java.io.IOException;

import javax.net.ssl.SSLPeerUnverifiedException;

import external.sdk.pendo.io.okhttp3.Interceptor;
import external.sdk.pendo.io.okhttp3.Request;
import external.sdk.pendo.io.okhttp3.Response;
import external.sdk.pendo.io.okhttp3.ResponseBody;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.logging.profiling.ProfilingManager;
import sdk.pendo.io.utilities.APIUtils;

import static sdk.pendo.io.logging.profiling.ProfilingManager.ProfilerType.PERFORMANCE;

/**
 * Intercepts all the Retrofit network request and response to support retries and profiling.
 */
public class OkHttpClientRetryInterceptor implements Interceptor {
    private static final int TRY_COUNT = 3;

    @Override
    public final Response intercept(Interceptor.Chain chain) throws IOException {
        Response response = null;
        try {
            Request request = chain.request();
            markRequestSent(request);

            // try the request
            response = chain.proceed(request);
            markResponseGot(response);

            int tryCount = 0;
            while (!isResponseAcceptable(response) && tryCount < TRY_COUNT) {
                ResponseBody body = response.body();
                if (body != null) {
                    String bodyString = APIUtils.INSTANCE.getResponseBodyAsString(body);
                    if (APIUtils.INSTANCE.isUnexpectedAPIError(bodyString)) {
                        APIUtils.INSTANCE.logBackendError(response.code(), response.message(), bodyString);
                        break;
                    }
                }

                InsertLogger.d("intercept  Request is not successful - " + tryCount);

                tryCount++;
                markRequestSent(request);
                // retry the request
                InsertLogger.d("intercept Retrying " + response.request().url());
                response = chain.proceed(request);

                markNetworkEvent("Got " + String.valueOf(response.code()) + " for " + response.request().url());
            }
        } catch (Exception e) {
            if (e instanceof SSLPeerUnverifiedException) {
                InsertLogger.e(e, e.getMessage());
            } else {
                InsertLogger.d(e, e.getMessage());
            }
        }

        // otherwise just pass the original response on
        return response;
    }

    /**
     * Checks whether a response is successful or we got 401 (un authenticated) in those cases we don't want to retry.
     *
     * @param response
     * @return
     */
    private boolean isResponseAcceptable(Response response) {
        // Acceptable response is also unauthorized or kill switch response. no need to re-try
        return response.isSuccessful() || response.code() == 401  || response.code() == 451;
    }

    private void markRequestSent(Request request) {
        markNetworkEvent("Sent " + request.url());
    }

    private void markResponseGot(Response response) {
        markNetworkEvent("Got " + String.valueOf(response.code()) + "for " + response.request().url());
    }

    private void markNetworkEvent(String message) {
        ProfilingManager.getInstance().mark(PERFORMANCE, message);
    }
}
