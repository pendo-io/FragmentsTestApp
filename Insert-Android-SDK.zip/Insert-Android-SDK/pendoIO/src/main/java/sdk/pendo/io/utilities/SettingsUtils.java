package sdk.pendo.io.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;

import sdk.pendo.io.BuildConfig;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.R;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Utility class for the SDK settings.
 *
 * Created by assaf on 5/4/15.
 */
public final class SettingsUtils {


    private SettingsUtils() {}

    private static final String INSERT_SETTINGS = "insert_settings";

    private static final Object RESOURCES_LOCK = new Object();
    private static volatile String sSDKVersion;

    public static String getSDKVersion() {

        String result = sSDKVersion;

        if (result == null) { // 1st check (no lock)
            synchronized (RESOURCES_LOCK) {
                result = sSDKVersion;
                if (result == null) // 2nd check (w/ lock)
                    sSDKVersion = result = getResourceString(R.string.insert_sdk_version);
            }
        }

        return result;
    }


    /**
     * @param id the integer resource id.
     */
    public static Integer getResourceInt(int id) {
        return ResourceUtils.getResources().getInteger(id);
    }

    /**
     * @param id the string resource id.
     */
    public static String getResourceString(int id) {
        return ResourceUtils.getResources().getString(id);
    }

    public static void storeSetting(String key, String value) {
        getSettingsEditor().putString(key, value).apply();
    }

    public static String getSetting(String key, String defaultValue) {
        return getSettingsSharedPreferences().getString(key, defaultValue);
    }

    public static void storeBooleanSetting(String key, boolean value) {
        getSettingsEditor().putBoolean(key, value).apply();
    }

    public static Boolean getBooleanSetting(String key, boolean defaultValue) {
        return getSettingsSharedPreferences().getBoolean(key, defaultValue);
    }

    private static SharedPreferences.Editor getSettingsEditor() {
        return getSettingsSharedPreferences().edit();
    }

    private static SharedPreferences getSettingsSharedPreferences() {
        return Pendo.getApplicationContext()
                .getSharedPreferences(INSERT_SETTINGS, Context.MODE_PRIVATE);
    }

    /**
     * Returns the custom url that was defined in the host app metada as "insert_custom_url"
     *
     * @param context the application context.
     *
     * @return the url.
     */
    public static String getCustomInsertUrl(@NonNull Context context) {
        String packageName = context.getPackageName();
        ApplicationInfo ai;
        try {
            ai = context.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            Bundle bundle = ai.metaData;
            if (bundle != null) {
                return bundle.getString(context.getString(R.string.insert_custom_url));
            }
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }

        return null;
    }

    /**
     * Returns the custom url that was defined in the host app metadata as "insert_custom_analytics_url"
     *
     * @param context the application context.
     *
     * @return the url.
     */
    public static String getCustomInsertAnalyticsUrl(@NonNull Context context) {
        String packageName = context.getPackageName();
        ApplicationInfo ai;
        try {
            ai = context.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            Bundle bundle = ai.metaData;
            if (bundle != null) {
                return bundle.getString(context.getString(R.string.insert_custom_analytics_url));
            }
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }

        return null;
    }

    /**
     * Returns whether the host app defined debug logging metada . this will be defined with  "insert_debug_logging" metadata
     *
     * @param context the application context.
     *
     * @return the url.
     */
    public static boolean getDebugLoggingEnabled(@NonNull Context context) {
        String packageName = context.getPackageName();
        ApplicationInfo ai;
        try {
            ai = context.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            Bundle bundle = ai.metaData;
            if (bundle != null) {
                return bundle.getBoolean(context.getString(R.string.insert_debug_log));
            }
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }

        return false;
    }

    /**
     * Returns whether the host app defined debug logging metada . this will be defined with  "insert_debug_logging" metadata
     *
     * @param context the application context.
     *
     * @return the url.
     */
    public static String getAppIdForTesting(@NonNull Context context) {
        String packageName = context.getPackageName();
        ApplicationInfo ai;
        try {
            ai = context.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            Bundle bundle = ai.metaData;
            if (bundle != null) {
                return bundle.getString(context.getString(R.string.insert_app_id_testing));
            }
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }

        return null;
    }

    /**
     * Returns whether the host app defined accessibility option in its metada . this will be defined with  "insert_accessibility" metadata
     *
     * @param context the application context.
     *
     * @return whether accessibility is enabled in the application.
     */
    public static synchronized Boolean getAccessibilityEnabled(@NonNull Context context) {
        try {
            String packageName = context.getPackageName();
            ApplicationInfo ai;
            ai = context.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            Bundle bundle = ai.metaData;
            if (bundle != null) {
                return bundle.getBoolean(context.getString(R.string.insert_accessibility));
            }
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

        return false;
    }

    /**
     * Returns whether the host app defined custom socket url . this will be defined with  "insert_custom_socket_url" metadata
     *
     * @param context the application context.
     *
     * @return the url.
     */
    public static String getCustomSocketUrl(@NonNull Context context) {
        String packageName = context.getPackageName();
        ApplicationInfo ai;
        try {
            ai = context.getPackageManager().getApplicationInfo(packageName, PackageManager.GET_META_DATA);

            Bundle bundle = ai.metaData;
            if (bundle != null) {
                return bundle.getString(context.getString(R.string.insert_custom_socket_url));
            }
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.i(e, e.getMessage());
        }

        return null;
    }

    /**
     * Checks whether the host app is in debuggable state. used mainly for analytics
     * @return
     */
    public static boolean isHostAppDebuggable() {
        return (0 != (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE));
    }

    public static ApplicationInfo getApplicationInfo() { return Pendo.getApplicationContext().getApplicationInfo(); }
}
