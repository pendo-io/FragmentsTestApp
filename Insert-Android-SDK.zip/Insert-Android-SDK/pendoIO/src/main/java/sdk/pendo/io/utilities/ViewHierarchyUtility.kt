package sdk.pendo.io.utilities

import android.annotation.TargetApi
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v4.widget.DrawerLayout
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

import org.apache.commons.lang3.tuple.Pair
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

import java.util.ArrayList
import java.util.HashSet

import sdk.pendo.io.events.ConditionData
import sdk.pendo.io.events.IdentificationData
import sdk.pendo.io.intelligence.IntelManager
import sdk.pendo.io.intelligence.ViewIntel
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.views.listener.FloatingListenerButton
import sdk.pendo.io.views.watcher.InsertTextWatcher

import sdk.pendo.io.constants.Constants.ViewCaptureConsts
import sdk.pendo.io.events.ConditionData.ConditionType.ELEMENT_INFO
import java.nio.charset.Charset

/**
 * This class is used for ViewHierarchy utilities.
 *
 *
 * Created by assaf on 3/31/15.
 */
object ViewHierarchyUtility {

    interface ViewStateCallback {
        fun onViewFound(view: View, identificationData: IdentificationData, locationOnStateViews: Int?)
    }

    fun getCurrentRootView(activity: Activity): View {
        return activity.window.decorView
    }

    /**
     * Returns a [,][<] representing the view hierarchy
     * and the screen state.
     *
     * @param view the root view to start from.
     *
     * @return [,][<] representing the view hierarchy
     * and the screen state.
     */
    fun getViewTreeAndScreenState(view: View?): Pair<JSONArray, JSONArray>? {

        if (view == null) {
            return null
        }

        val tree = JSONArray()
        val screenState = JSONArray()
        getViewTreeAndScreenState(view, tree, screenState, null)

        return Pair.of(tree, screenState)
    }

    /**
     * Returns a [,][<] representing the view hierarchy
     * and the screen state. also, comparing the captured screen to old screen and state identification data
     *
     * @param view the root view to start from.
     *
     * @param conditions the conditions relevant for the comparison
     * @return [,][<] representing the view hierarchy
     * and the screen state.
     */
    fun getViewTreeAndScreenStateComparedToOldState(
            view: View?,
            conditions: List<ConditionData>,
            oldStateViewNewStateViewMap: MutableList<Pair<Int, IdentificationData>>
    ): Pair<JSONArray, JSONArray>? {
        if (view == null) {
            return null
        }


        val tree = JSONArray()
        val screenState = JSONArray()
        getViewTreeAndScreenState(
                view, tree, screenState,
                CompareViewStateCallback(conditions, oldStateViewNewStateViewMap)
        )

        return Pair.of(tree, screenState)
    }

    /**
     * Traverse the view hierarchy using DFS and convert it into JSON.
     *
     * @param view the root view to start from.
     * @param tree the JSON array to populate with the tree.
     * @param screenState the JSON array to populate with the screen state views.
     */
    private fun getViewTreeAndScreenState(
            view: View,
            tree: JSONArray,
            screenState: JSONArray,
            callback: ViewStateCallback?
    ) {

        val discoverySet = HashSet<View>()
        getViewTreeAndScreenState(
                view,
                tree,
                discoverySet,
                0,
                0,
                true,
                ViewUtils.isViewAKnownList(view),
                screenState,
                callback
        )
    }

    /**
     * Return the RAElementInfo JSON that will include what was in the old elementInfo, with the following changes:
     * 1) "predicate" key-value pair will  include the old predicate, stripped of texts.
     * 2) A new key, "text" will be added that will hold the text of the element in question, in case it exists.
     * @param identificationData
     * @return the new RAElementInfo JSON as described above
     * @throws JSONException
     */
    @Throws(JSONException::class)
    fun createRAElementInfoJSON(identificationData: IdentificationData): JSONObject {
        val raElementInfoJSON = identificationData.toJSON()
        var raPredicate: String? = null

        if (raElementInfoJSON.has(IdentificationData.RA_PREDICATE)) {
            raPredicate = raElementInfoJSON.getString(IdentificationData.RA_PREDICATE)
            raElementInfoJSON.remove(IdentificationData.RA_PREDICATE)
        }

        if (raElementInfoJSON.has(IdentificationData.PREDICATE)) {
            raElementInfoJSON.remove(IdentificationData.PREDICATE)
        }

        if (raPredicate != null) {
            raElementInfoJSON.put(IdentificationData.PREDICATE, raPredicate)
        }

        return raElementInfoJSON
    }

    /**
     * Return the RAElementInfo JSON that will include what was in the old elementInfo, with the following changes:
     * 1) "predicate" key-value pair will  include the old predicate, stripped of texts.
     * 2) A new key, "text" will be added that will hold the text of the element in question, in case it exists.
     * @param view
     * @return the new RAElementInfo JSON as described above
     * @throws JSONException
     */
    @Throws(JSONException::class)
    fun createRAElementInfoJSON(view: View, includeText: Boolean, includeAccessibility: Boolean): JSONObject {
        return createRAElementInfoJSON(ViewIntel.getViewIntelId(view, includeText, includeAccessibility))
    }


    private fun getViewTreeAndScreenState(
            view: View?, tree: JSONArray,
            discoverySet: HashSet<View>,
            depth: Int, fakeZ: Int,
            isFlat: Boolean,
            isParentAList: Boolean,
            screenState: JSONArray,
            callback: ViewStateCallback?
    ): Int {

        // FIXME Nir: Add old view identifiaction list
        // When comparing the new view with the old list find the required view, it set it as mandatory and add to the mapping od old index vs new index
        var recMaxDepth = depth + fakeZ
        // If the view is invisible ignore it.
        if (view == null || !ViewUtils.isViewInsideDisplay(view)
        ) {
            return recMaxDepth
        }

        // We need to know if the view is a list for the position of it's children.
        val viewIsList = ViewUtils.isViewAKnownList(view)

        try {
            val viewAsJSON = viewToJSON(view, isParentAList)
            if (viewAsJSON == null) {
                InsertLogger.e("View as JSON is null!")
                return recMaxDepth
            }

            viewAsJSON.put("classHierarchy", Utils.listToJSONArray(Utils.getAllClasses(view)))


            val id = ViewUtils.getViewId(view)
            if (id != null) {
                viewAsJSON.put("id", id)
            }

            val viewIdentificationData = ViewIntel.getViewIntelId(view, true, true) // Always include text and accessibility in capture

            if (IntelManager.isViewScreenStateCandidate(view)) {
                callback?.onViewFound(view, viewIdentificationData, screenState.length())
                screenState.put(viewIdentificationData.toJSON())
                viewAsJSON.put("screen_state_ref", screenState.length() - 1)
            }

            try {
                if (!viewAsJSON.has(ViewCaptureConsts.DESCRIPTIVE_TEXT)) {
                    val viewContentDescription = view.contentDescription
                    // Text is decoded to Base64.
                    val text = viewIdentificationData.text

                    if (view !is ViewGroup && text != null && text.isNotEmpty()) {
                        viewAsJSON.put(ViewCaptureConsts.DESCRIPTIVE_TEXT, Base64.decode(text, PredicateUtils.BASE64_FLAGS).toString(Charset.defaultCharset()))
                    } else if (!TextUtils.isEmpty(viewContentDescription)) {
                        viewAsJSON.put(ViewCaptureConsts.DESCRIPTIVE_TEXT, viewContentDescription.toString())
                    } else {
                        viewAsJSON.put(ViewCaptureConsts.DESCRIPTIVE_TEXT, view.javaClass.simpleName)
                    }

                }
            } catch (ignore: NullPointerException) {
            }

            val raElementInfoJSON = createRAElementInfoJSON(viewIdentificationData)
            // Add "retroElementInfo"
            viewAsJSON.put(IdentificationData.RETROACTIVE_ELEMENT_INFO, raElementInfoJSON)

            viewAsJSON.put("zIndex", recMaxDepth)
            viewAsJSON.put(IdentificationData.RETROACTIVE_ELEMENT_INFO_HASH, HashingUtils.encryptSHA1(
                    raElementInfoJSON
            ))
            tree.put(viewAsJSON)
            discoverySet.add(view)

            if (view is ViewGroup) {

                val isDrawerLayout = view.isDrawerLayout()
                val isDrawerLayoutOpen =
                        isDrawerLayout && (view as DrawerLayout).isDrawerOpen(Gravity.START)
                val childCount = view.childCount

                if (childCount > 0) {

                    val childrenView: JSONArray = if (isFlat) {
                        tree
                    } else {
                        JSONArray()
                    }

                    val step =
                            if (!isDrawerLayoutOpen) {
                                // If this is a drawer layout and it's closed, take all it's siblings but not it.
                                (0 until if (isDrawerLayout) childCount - 1 else childCount)
                            } else { // If the drawer is open, we only take the drawer layout and not it's siblings.
                                childCount - 1 downTo childCount - 1
                            }

                    for (i in step) {

                        val viewChild = view.getChildAt(i)
                        if (!discoverySet.contains(viewChild)) {
                            val recDepth = getViewTreeAndScreenState(
                                    viewChild,
                                    childrenView,
                                    discoverySet,
                                    recMaxDepth + 1,
                                    i,
                                    isFlat,
                                    viewIsList,
                                    screenState,
                                    callback
                            )

                            if (recMaxDepth < recDepth) {
                                recMaxDepth = recDepth
                            }
                        }
                    }

                    if (!isFlat) {
                        viewAsJSON.put("children_views", childrenView)
                    }
                }
            }

            return recMaxDepth + 1
        } catch (e: JSONException) {
            InsertLogger.e(e, e.message)
        }

        return -1
    }

    private fun viewToJSON(view: View?, isParentAList: Boolean): JSONObject? {
        if (view == null) {
            return null
        }

        val retJSON = JSONObject()

        try {

            retJSON.put("clickable", view.isPendoClickable())

            val positionJSON = JSONObject()

            val viewVisibleRect = ViewUtils.getViewVisibleRect(view)
            positionJSON.put("left", viewVisibleRect.left)
            positionJSON.put("top", viewVisibleRect.top)
            positionJSON.put("width", viewVisibleRect.width())
            positionJSON.put("height", viewVisibleRect.height())

            retJSON.put("position", positionJSON)
            addICSProperties(view, retJSON)

        } catch (e: JSONException) {
            InsertLogger.e(e, e.message)
        }

        if (isParentAList) {
            val viewParent = view.parent
            var pos = -1
            when (viewParent) {
                is AbsListView -> pos = (viewParent as AdapterView<*>).getPositionForView(view)
                is RecyclerView -> pos = viewParent.getChildAdapterPosition(view)
                else -> {
                    if (viewParent != null) {
                        InsertLogger.w(
                                "Parent is list but none that we know?!"
                                        + " (" + viewParent.javaClass.simpleName + ")")
                    } else{
                        InsertLogger.w("(viewParent was null)")
                    }
                }
            }

            if (pos >= 0) {
                try {
                    retJSON.put("list_position", pos)
                } catch (e: JSONException) {
                    InsertLogger.e(e, e.message)
                }

            }
        }

        if (view is TextView) {
            if (!retJSON.has(ViewCaptureConsts.TEXT)) {
                val text = view.text.toString()

                // Shorten the text if it's too long.
                val finalText = Utils.truncateStringToLength(text).toString()

                try {
                    retJSON.put(ViewCaptureConsts.TEXT, finalText)
                    retJSON.put(ViewCaptureConsts.TEXT_TRUNCATED, finalText.length < text.length)
                } catch (e: JSONException) {
                    InsertLogger.e(e, e.message)
                }

            }
        }

        return retJSON
    }

    fun addListenersToViewHierarchy(view: View) {
        addListenersToViewHierarchy(view, HashSet())
    }

    private fun addListenersToViewHierarchy(view: View, discoverySet: HashSet<View>) {

        discoverySet.add(view)
        if (view is FloatingListenerButton) {
            return
        }

        if (view.isPendoClickable()) {
            ViewUtils.setTouchDelegateOnView(view)
        }

        if (view is TextView) {
            InsertTextWatcher.addTextWatcher(view)
        }

        if (view is ScrollView) { // FIXME: 4/6/15 Remove?
            //            ViewUtils.setOnHierarchyChangeListenerForScrollView((ScrollView) view);

        } else if (view is ListView || view is GridView) {
            val abv = view as AbsListView
            ViewUtils.setAdapterDataSetObserverForGridOrListView(abv)
            ViewUtils.setOnItemClickListenerForGridOrListView(abv)
        } else if (view.isDrawerLayout()) {
            ViewUtils.setDrawerListenerForDrawerLayout(view as DrawerLayout)
        }

        if (view is ViewGroup) {

            val childCount = view.childCount

            if (childCount > 0) {

                for (i in 0 until childCount) {

                    val viewChild = view.getChildAt(i)
                    if (!discoverySet.contains(viewChild)) {
                        addListenersToViewHierarchy(viewChild, discoverySet)
                    }
                }
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1)
    @Throws(JSONException::class)
    private fun addICSProperties(view: View, retJSON: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            retJSON.put("has_on_click_listeners", view.hasOnClickListeners())
        }
    }

    /**
     * Traverse the view hierarchy using DFS and running the callback on each view. The traversal
     * stops if callback returns true or if reached end.
     *
     * @param view the root view to start from.
     * @param callback the callback to run on each view.
     * @param classes the classes on which we want to perform the callback.
     */
    @SafeVarargs
    fun traverseViewHierarchy(
            view: View,
            callback: ViewCallback,
            vararg classes: Class<out View>
    ) {

        val callbacks = ArrayList<ViewCallback>()
        callbacks.add(callback)
        traverseViewHierarchy(view, callbacks, *classes)
    }

    /**
     * Traverse the view hierarchy using DFS and running the callback on each view. The traversal
     * stops if callback returns true or if reached end.
     *
     * @param view the root view to start from.
     * @param callbacks the callback list to run on each view.
     * @param classes the classes on which we want to perform the callback.
     */
    @SafeVarargs
    fun traverseViewHierarchy(
            view: View,
            callbacks: List<ViewCallback>,
            vararg classes: Class<out View>
    ) {

        val discoverySet = HashSet<View>()
        traverseViewHierarchy(view, discoverySet, callbacks, *classes)
    }

    @SafeVarargs
    private fun traverseViewHierarchy(
            view: View,
            discoverySet: HashSet<View>,
            callbacks: List<ViewCallback>,
            vararg classes: Class<out View>
    ): Boolean {

        if (runPerformActionOnView(view, callbacks, *classes)) {
            return true
        }

        discoverySet.add(view)

        if (view is ViewGroup) {

            val childCount = view.childCount

            if (childCount > 0) {

                for (i in 0 until childCount) {

                    val viewChild = view.getChildAt(i)
                    if (!discoverySet.contains(viewChild)) {

                        if (traverseViewHierarchy(viewChild, discoverySet, callbacks, *classes)) {
                            return true
                        }
                    }
                }
            }
        }

        return false
    }

    @SafeVarargs
    private fun runPerformActionOnView(
            view: View,
            callbacks: List<ViewCallback>,
            vararg classes: Class<out View>
    ): Boolean {

        // If there are no classes, perform the action regardless.
        var performAction = classes.isEmpty()

        // If there are classes, we perform the action
        // only on views that are instances of the classes we are provided.
        if (classes.isNotEmpty()) {

            for (aClass in classes) {

                if (view.javaClass.isInstance(aClass)) {
                    performAction = true
                    break
                }
            }
        }

        if (performAction) {

            var retVal = false
            for (callback in callbacks) {
                retVal = retVal or callback.performActionOnView(view, callback.data)
            }

            return retVal
        }

        return false
    }

    abstract class ViewCallback {

        var data: Bundle? = null
            private set

        /**
         * Performs action of a view.
         *
         * @param view The view on perform the action upon.
         * @param oBundle A bundle that can be used to collect data.
         *
         * @return True if the traversal on the view's hierarchy should stop and collapse, false
         * otherwise.
         */
        abstract fun performActionOnView(view: View?, oBundle: Bundle?): Boolean

        fun reset() {
            data = Bundle()
        }
    }

    private class CompareViewStateCallback internal constructor(
            private val mConditions: List<ConditionData>?,
            oldConditionIndexNewElementInfoViewMap: MutableList<Pair<Int, IdentificationData>>
    ) : ViewStateCallback {
        private var mOldStateViewNewStateViewMap: MutableList<Pair<Int, IdentificationData>>? = null

        init {
            mOldStateViewNewStateViewMap = oldConditionIndexNewElementInfoViewMap
        }

        override fun onViewFound(
                view: View,
                identificationData: IdentificationData,
                locationOnStateViews: Int?
        ) {
            // Check if the view is contained in the list of old state views,
            // If it does mark the view as found in the old state do the following:
            // 1. Change the mandatory field value of the new view to be as the old one
            // 2. Add the old view index vs. the new index to the map
            // 3. Mark the old view as found in the old state
            if (mConditions == null) {
                return
            }
            for (condition in mConditions) {
                val operator = ConditionData.Operator.get(condition.operator)
                if (ELEMENT_INFO.equals(ConditionData.ConditionType.get(condition.type)!!) && operator!!.equals(
                                ConditionData.Operator.EXISTS
                        )
                ) {

                    val oldIdentificationData = condition.typeValue
                    val identificationComparison = ViewIntel.compareIdentificationData(
                            oldIdentificationData,
                            identificationData,
                            false, condition
                    ) ?: continue
// Check if the identification data is identical with 100% confidence
                    if (identificationComparison.left && identificationComparison.right == ViewIntel.FULL_CONFIDENCE) {
                        addComparisonToMap(condition, identificationData)
                    }
                }
            }

        }

        private fun addComparisonToMap(
                locationOnStateViews: ConditionData,
                newElementInfo: IdentificationData
        ) {
            val locationOnOldStateViews = mConditions!!.indexOf(locationOnStateViews)
            mOldStateViewNewStateViewMap!!.add(
                    Pair.of(
                            locationOnOldStateViews,
                            newElementInfo
                    )
            )
        }
    }
}

@Suppress("SpellCheckingInspection")
internal fun View.isDrawerLayout(): Boolean {
    return (this is DrawerLayout || this.javaClass.canonicalName == "androidx.drawerlayout.widget.DrawerLayout")
}

fun View.isPendoClickable(): Boolean {

    if (this is ScrollView
            || this is AbsListView
            || this is ViewPager
            || this.isDrawerLayout()
    ) {
        return false
    }

    var clickable = false

    /*
     * In case we stumble upon an instance of AbsListView - in our case
     * either a ListView or GridView, we configure it's children to be clickable, so that
     * the web can identify them properly.
     */
    if (this.parent is AbsListView) {
        clickable = (this.parent as AbsListView).onItemClickListener != null
    }

    if (!clickable) {
        if (ViewUtils.hasOnClickListeners(this) || this.touchDelegate != null) {
            clickable = true
        } else if (this is Spinner && this.onItemSelectedListener != null) {
            clickable = true
        }
    }

    return clickable || this.isClickable
}