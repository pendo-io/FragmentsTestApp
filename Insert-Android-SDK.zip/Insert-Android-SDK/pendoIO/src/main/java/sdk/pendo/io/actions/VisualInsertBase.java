package sdk.pendo.io.actions;

import android.app.Activity;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.ViewGroup;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Flowable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.processors.PublishProcessor;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.animations.StatusBarColorAnimation;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.models.StepSeen;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.utilities.PersistenceUtils;

import static sdk.pendo.io.actions.InsertCommand.InsertCommandScope.INSERT_COMMAND_SCOPE_ANY;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.ADVANCE_GUIDE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.DISMISS_INSERT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.NOTIFY_CLOSE;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_DISMISSED_BACK_BUTTON;
import static sdk.pendo.io.actions.InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY;
import static sdk.pendo.io.constants.Constants.GeneralConsts.IRRELEVANT;
import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;


public abstract class VisualInsertBase extends GuideModel {

    public static final String INSERT_COMMAND_VISUAL_INSERT_DEST = "VisualInsert";
    public static final String DISMISS_VISIBLE_INSERTS = "dismissVisibleGuides";
    public static final String GUIDE_STEP_ID_PARAMETER_NAME = "guideStepId";
    public static final String DEFAULT_ACTIVATED_BY = "";


    static final long NO_CLOSE_DELAY = 0;

    String mActivatedBy = "";
    long mStartDuration;
    long mAccumulativeTime = 0;

    VisualInsertType mVisualInsertType;

    VisualInsertLifecycleListener mListener;

    private Disposable mDismissSubscription;
    private Disposable mAdvanceSubscription;
    JSONObject mAdditionalInfo = new JSONObject();

    AtomicBoolean mShowing = new AtomicBoolean(false);

    Activity mActivity;
    VisualAnimationManager mVisualAnimationManager;
    StatusBarColorAnimation mStatusBarColorAnimation = null;

    public static final Predicate<InsertCommand> VISUAL_INSERT_DISMISS_FILTER = InsertCommand
            .createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_COMMAND_VISUAL_INSERT_DEST,
                    DISMISS_INSERT,
                    INSERT_COMMAND_EVENT_TYPE_ANY,
                    INSERT_COMMAND_SCOPE_ANY);

    public static final Predicate<InsertCommand> GUIDE_ADVANCE_FILTER = InsertCommand
            .createFilter(InsertCommand.COMMAND_STRING_ANY,
                    INSERT_COMMAND_VISUAL_INSERT_DEST,
                    ADVANCE_GUIDE,
                    INSERT_COMMAND_EVENT_TYPE_ANY,
                    INSERT_COMMAND_SCOPE_ANY);

    @SuppressWarnings("CheckStyle")
    public enum VisualInsertType {
        FULL_SCREEN(R.id.insert_visual_scrollview_container, R.layout.insert_visual_insert),
        BANNER(R.id.insert_visual_container, R.layout.insert_banner);

        public final int mContainerId;
        public final int mLayoutId;

        VisualInsertType(int containerId, int layoutId) {
            mContainerId = containerId;
            mLayoutId = layoutId;
        }

        public int getContainerId() {
            return mContainerId;
        }

        public int getLayoutId() {
            return mLayoutId;
        }
    }

    void setStartDuration(long startDuration) {
        mStartDuration = startDuration;
    }

    VisualInsertBase(@Nullable StepGuideModel stepGuideModel, VisualInsertLifecycleListener listener) {
        super(stepGuideModel);
        mListener = listener;
    }

    VisualInsertBase(@Nullable GuideModel guideModel, VisualInsertLifecycleListener listener) {
        super(guideModel);
        mListener = listener;
    }

    public String getActivatedBy() {
        return mActivatedBy;
    }

    protected void init(String activatedBy, GenericInsertAnalyticsData analyticsData) {
        setTracker(InsertAnalytics.newTracker(analyticsData));
        mActivatedBy = activatedBy;
        mListener.onCreate(this);
        subscribeDelegates();
    }

    public final long getDuration() {
        return (System.currentTimeMillis() - mStartDuration) + mAccumulativeTime;
    }

    public final boolean isShowing() {
        return mShowing.get();
    }

    final boolean getAndSetShowing(boolean showing) {
        return mShowing.getAndSet(showing);
    }

    final void cancelDuration() {
        try {
            cancelTimeout(false);
            mDestroyingSubject.onNext(IRRELEVANT);
        } catch (Exception ignore) {
        }
    }

    /**
     * Returns the insert visual insert type such as: FULL_SCREEN, BANNER
     *
     * @return the VisualInsertType for this specific insert
     */
    VisualInsertType getVisualInsertType() {
        return mVisualInsertType;
    }

    /**
     * Returns the insert container view id
     *
     * @return int representing the container view id
     */
    int getContainerId() {

        return mVisualInsertType.getContainerId();
    }

    void setRootView(ViewGroup rootView) {
    }

    void startTimeout() {
    }

    @Nullable
    ViewGroup getRootView() {
        return null;
    }

    @Nullable
    protected ViewGroup getContainer() {
        return null;
    }

    void onDestroy() {
    }

    public void cancelTimeout(boolean forceCancelTimeoutEntirely) {
    }

    public abstract boolean show();

    final PublishProcessor mDestroyingSubject = PublishProcessor.create();

    void subscribeDelegates() {

        mDismissSubscription = InsertCommandsEventBus.getInstance()
                .subscribe(destroyed(),
                        VISUAL_INSERT_DISMISS_FILTER,
                        mDismissInsertObserver);
        mAdvanceSubscription = InsertCommandsEventBus.getInstance()
                .subscribe(destroyed(),
                        GUIDE_ADVANCE_FILTER,
                        mDismissInsertObserver);
    }

    void unsubscribeDismissAndAdvance() {
        if (mDismissSubscription != null && !mDismissSubscription.isDisposed()) {
            mDismissSubscription.dispose();
            mDismissSubscription = null;
        }
        if (mAdvanceSubscription != null && !mAdvanceSubscription.isDisposed()) {
            mAdvanceSubscription.dispose();
            mAdvanceSubscription = null;
        }
    }

    protected void handleCappingAndNullifyStepSeen() {
        if (getGeneralGuideConfiguration() != null
                && getGeneralGuideConfiguration().getCapping() != null) {
            GuideCapping guideCapping = getGeneralGuideConfiguration().getCapping();
            guideCapping.consumeOne();
            StepSeenManager.getInstance().setCurrentStepSeen(null);
        }
    }

    /**
     * An observable sending a next when this {@link VisualInsert} is being destroyed.
     * <p>
     * Example: use it with a takeUntil on your observable to ensure it's not going to leak
     */
    private Flowable destroyed() {
        return mDestroyingSubject;
    }

    private Consumer<InsertCommand> mDismissInsertObserver = new Consumer<InsertCommand>() {
        @Override
        public void accept(final InsertCommand insertCommand) {
            InsertLogger.d(insertCommand.toString());
            try {

                if (GuideUtils.isBlockingInsert(VisualInsertBase.this) //always false
                        && !(InsertCommandEventType.SdkEventType.HOST_APP_DEVELOPER_CALL.equals(
                        insertCommand.getEventType())
                        && DISMISS_VISIBLE_INSERTS.equals(insertCommand.getSourceId()))) {
                    return;
                }

                String insertIdString = insertCommand.getParamValueFromCommand(
                        InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.GUIDE_ID);
                if (!DISMISS_VISIBLE_INSERTS.equals(insertCommand.getSourceId())
                        && (TextUtils.isEmpty(insertIdString) || !getGuideId().equals(insertIdString))) {
                    // Don't handle the command in case it is not a dismiss all command
                    // and the insert id is not identical to the current insert
                    return;
                }

                // In case the close was initiated from actionable block,
                // set more properties in the analytics.
                String actionType = insertCommand.getEventType().eventType;
                final String sourceId = insertCommand.getSourceId();
                try {
                    mAdditionalInfo.put(AnalyticsProperties.ACTION_TYPE, actionType);
                    mAdditionalInfo.put(AnalyticsProperties.ELEMENT_ID, sourceId);
                } catch (JSONException e) {
                    InsertLogger.e(e.getMessage());
                }
                final InsertCommand notifyClose =
                        new InsertCommand.Builder(NOTIFY_CLOSE, INSERT_COMMAND_EVENT_TYPE_ANY)
                                .setSourceId(getGuideId())
                                .setScope(insertCommand.getScope())
                                .setParameters(InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.createInsertMetadataParams(getGuideId()))
                                .build();

                ApplicationObservers.getInstance().getActivityInsideApp()
                        .filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean isInsideApp) {
                                return isInsideApp;
                            }
                        })
                        .firstElement()
                        .subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                            @Override
                            public void accept(Boolean isInsideApp) {
                                InsertCommandDispatcher.getInstance().dispatchCommand(notifyClose, true);
                            }
                        }));

                if (InsertCommandEventType.SdkEventType.TIME_OUT.equals(insertCommand.getEventType())) {
                    if (getTracker() != null && getTracker().getGenericAnalytics() != null) {
                        InsertCommandParameterInjector.getInstance().handleInsertTimeoutAnalytics(
                                getGuideId(),
                                getDuration());
                    } else {
                        InsertCommandParameterInjector.getInstance().handleInsertTimeoutAnalytics(
                                getGuideId(),
                                getDuration());
                    }
                }

                if (InsertCommandDispatcher.PredefinedCommands.SOURCE_ID_BACK_BUTTON.equals(insertCommand.getSourceId())) {
                    if (getTracker() != null && getTracker().getGenericAnalytics() != null) {
                        ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
                        if (VisualInsertManager.getInstance().getVisualInsert(getGuideId()) != null) {
                            specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.SEEN_REASON,
                                    TYPE_STRING,
                                    VisualInsertManager.getInstance().getVisualInsert(getGuideId()).getActivatedBy()));
                        }
                        InsertCommandParameterInjector.getInstance()
                                .addGenericParamsInjectAndDispatch(VisualInsertBase.this,
                                        GUIDE_DISMISSED_BACK_BUTTON.eventType, specificParams);

                        PersistenceUtils.removeStoredInsertDisplayedAnalytics(getGuideId());
                    }
                }

                insertTypeDependentCommandHandle(insertCommand);
                long currentTimeMS = System.currentTimeMillis();
                GuidesConfigurationManager.INSTANCE.setLastSeenTimeMS(currentTimeMS);
                if (insertCommand.getAction().equals(DISMISS_INSERT)) {
                    handleCappingAndNullifyStepSeen();
                    // Make sure the next guide fires a view trigger.
                    fireNextTriggerForScreenChangeOnceNoInsertIsDisplayed();
                }
                if (insertCommand.getAction().equals(ADVANCE_GUIDE)) {
                    List<InsertCommandsEventBus.Parameter> insertCommandParameters = insertCommand.getParameters();
                    String nextStepIdFromParameters = null;
                    if (insertCommandParameters != null) {
                        for (InsertCommandsEventBus.Parameter insertCommandParameter : insertCommandParameters) {
                            final String parameterName = insertCommandParameter.getParameterName();
                            if (parameterName.equals(GUIDE_STEP_ID_PARAMETER_NAME)) {
                                nextStepIdFromParameters = insertCommandParameter.getParameterValue();
                            }
                        }
                    }

                    String currentStepIdSeen = StepSeenManager.getInstance().getCurrentStepId();
                    // Next step index
                    if (getGuideStepIndex(currentStepIdSeen) == null) {
                        InsertLogger.w("Current guide step seen is null, not continuing to next guide");
                        return;
                    }
                    Integer nextGuideStepIndex = getGuideStepIndex(currentStepIdSeen) + 1;
                    if (nextStepIdFromParameters != null) {
                        nextGuideStepIndex = getGuideStepIndex(nextStepIdFromParameters);
                    }
                    if (nextGuideStepIndex < getSteps().size()) {
                        String guideStepId;
                        if (nextStepIdFromParameters != null) {
                            guideStepId = nextStepIdFromParameters;
                        } else {
                            guideStepId = getGuideStepId(nextGuideStepIndex);
                        }
                        if (guideStepId.equals(DEFAULT_GUIDE_STEP_ID)) {
                            handleCappingAndNullifyStepSeen();
                        } else {
                            StepSeenManager.getInstance().setCurrentStepSeen(new StepSeen(getGuideId(), guideStepId, getGuideStepLocation(guideStepId)));
                            // Make sure the next step runs a view trigger.
                            fireNextTriggerForScreenChangeOnceNoInsertIsDisplayed();
                        }
                    } else {
                        handleCappingAndNullifyStepSeen();
                    }
                }
                unsubscribeDismissAndAdvance();
            } catch (Exception e) {
                InsertLogger.e(e.getMessage());
            }
        }
    };

    private void fireNextTriggerForScreenChangeOnceNoInsertIsDisplayed() {
        VisualInsertManager.getInstance().getIsFullScreenInsertShowingObservable().filter(new Predicate<Boolean>() {
            @Override
            public boolean test(Boolean isFullScreenInsertShowing) {
                return !isFullScreenInsertShowing;
            }
        }).firstElement().subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
            @Override
            public void accept(Boolean aBoolean) {
                ScreenManager.INSTANCE.screenDidChange();
            }
        }));
    }

    abstract void insertTypeDependentCommandHandle(InsertCommand command);


    /**
     * Returns the visual animation manager of this visual insert
     *
     * @return VisualAnimationManager
     */
    public VisualAnimationManager getAnimationManager() {
        return mVisualAnimationManager;
    }
}
