package sdk.pendo.io.activities;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.WindowManager;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.utilities.GuideUtils;

import static sdk.pendo.io.actions.InsertCommandDispatcher.PredefinedCommands.BACK_PRESSED;
import static sdk.pendo.io.actions.VisualInsertBase.DEFAULT_ACTIVATED_BY;

public final class InsertVisualActivity extends BaseRxActivity {

    public static final String EXTRA_DEFAULT_INVALID_INSERT_ID = "";
    public static final String EXTRA_DEFAULT_INVALID_ACTIVATED_BY = "";

    // Unique ID for this activity so we can identify its instances throughout the app.
    public static final int ID = 0;

    private static final String EXTRA_INSERT_ID = "INSERT_ID";
    private static final String EXTRA_ACTIVATED_BY = "ACTIVATED_BY";

    private static boolean sIsPreview;
    private static Disposable sAnimationEndedSub;

    private GenericInsertAnalyticsData mIga;
    private long mStartTime;
    private long mAccumulativeTime = 0;

    // Manages the time the insert was displayed to the user.
    private InsertObserver<ApplicationFlowManager.AppFlowState> mAppFlowListener =
            InsertObserver.create(new Consumer<ApplicationFlowManager.AppFlowState>() {
                @Override
                public void accept(ApplicationFlowManager.AppFlowState appFlowState) {

                    if (ApplicationFlowManager.AppFlowState.IN_BACKGROUND.equals(appFlowState)) {
                        mAccumulativeTime = getDuration();
                    } else {
                        mStartTime = System.currentTimeMillis();
                    }
                }
            });

    private Disposable mSubscription;
    private VisualInsert mVisualInsert;

    @NonNull
    public static Intent getVisualActivityIntent(boolean isPreview, String insertId, ActivationManager.ActivationEvents activationEvent) {
        Intent retIntent = new Intent(Pendo.getApplicationContext(), InsertVisualActivity.class);
        Bundle extras = new Bundle();
        extras.putString(EXTRA_INSERT_ID, insertId);
        extras.putString(EXTRA_ACTIVATED_BY, activationEvent.getActivationEvent());
        retIntent.putExtras(extras);
        setIsPreview(isPreview);
        return retIntent;
    }

    // TODO: 9/6/15 A better solution for this.
    public static void setIsPreview(boolean isPreview) {
        sIsPreview = isPreview;
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Copy the previous activity window parameter flags to this ours.
//        Activity activity = ApplicationObservers.getInstance().getCurrentActivity();
//        if (activity != null) {
//            Window win = activity.getWindow();
//            WindowManager.LayoutParams winParams = win.getAttributes();
//
//            getWindow().getAttributes().flags = winParams.flags;
//        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        try { // this try catch is here is order to wrap exception we get in youtube fragment: java.lang.IllegalStateException: android.os.DeadObjectException in some cases
            super.onSaveInstanceState(outState);
        } catch (Exception ignore) {

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

            String insertId = getIntent().getStringExtra(EXTRA_INSERT_ID);
            if (insertId.equals(EXTRA_DEFAULT_INVALID_INSERT_ID)) {
                InsertLogger.w("Aborting showing guide, as the guide id received is invalid");
                abort();
            }
            String activatedBy = getIntent().getStringExtra(EXTRA_ACTIVATED_BY);
            if (activatedBy == null || activatedBy.equals(EXTRA_DEFAULT_INVALID_ACTIVATED_BY)) {
                activatedBy = DEFAULT_ACTIVATED_BY;
                InsertLogger.w("Activation method was not received");
            }

            GuideModel guideModel = null;
            // In case this is a preview insert we should
            // take the insert explicitly from the socketFSM
            if (sIsPreview) {
                guideModel = SocketEventFSM.getInstance().getPreviewInsert();
            } else {
                guideModel = GuideManager.INSTANCE.getGuide(insertId);
            }
            mIga = InsertAnalytics.getInstance()
                    .newGuideGenericAnalytics(guideModel);

            mVisualInsert = new VisualInsert(guideModel, VisualInsertManager.getInstance());
            boolean success = GuideUtils
                    .showVisualInsert(this, mVisualInsert, mIga, activatedBy);

            if (!success) {
                abort();
            }

            unsubscribeAppFlowListener();

            if (guideModel != null) {
                String guideId = guideModel.getGuideId();
                if (guideId != null) {
                    final Predicate<InsertCommand> insertClosedFilter = InsertCommand
                            .createFilter(guideId,
                                    InsertCommand.COMMAND_STRING_ANY,
                                    InsertCommandGlobalAction.NOTIFY_CLOSE,
                                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

                    InsertCommandsEventBus.getInstance().subscribe(
                            this.<InsertCommand>bindToLifecycle(),
                            insertClosedFilter,
                            new Consumer<InsertCommand>() {
                                @Override
                                public void accept(InsertCommand insertCommand) {
                                    // In case visual was closed, we will wait
                                    // until animation ends in order to finish the activity.
                                    sAnimationEndedSub = mVisualInsert.getAnimationManager()
                                            .getFinishedAnimationObservable()
                                            .subscribeWith(InsertObserver.create(new Consumer<Boolean>() {
                                                @Override
                                                public void accept(
                                                        Boolean finishedAnimation) {
                                                    if (finishedAnimation) {
                                                        finish();
                                                        overridePendingTransition(0, 0);
                                                        unsubscribeEndAnimation();
                                                    }
                                                }
                                            }));

                                }
                            });
                }
            }
            mSubscription = ApplicationFlowManager.getInstance().getAppFlowChanges()
                    .subscribeWith(mAppFlowListener);
            mStartTime = System.currentTimeMillis();
        } catch (Exception e) {
            finish();
            InsertLogger.e(e, e.getMessage());
        }
    }

    private static void unsubscribeEndAnimation() {
        if (sAnimationEndedSub != null) {
            sAnimationEndedSub.dispose();
            sAnimationEndedSub = null;
        }
    }

    private long getDuration() {
        return (System.currentTimeMillis() - mStartTime) + mAccumulativeTime;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        VisualInsertManager.getInstance().setIsFullScreenInsertShowing(false);
        mVisualInsert = null;
        try {
            unsubscribeAppFlowListener();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    private void unsubscribeAppFlowListener() {
        if (mSubscription != null) {
            mSubscription.dispose();
        }
    }

    private void abort() {
        // TODO: 7/5/15 Analytics.
        finish();
    }

    @Override
    public void onBackPressed() {

        // Takes care of a rare edge case where if the user is in fullscreen mode and pressed back,
        // the subscriber of the visualInsert will stay subscribed.
        try {
            InsertCommand backPressedCommand = BACK_PRESSED;
            backPressedCommand.setParameters(InsertCommandGlobalAction
                    .InsertInfoConsts
                    .createInsertMetadataParams(mVisualInsert.getGuideId()));
            InsertCommandDispatcher.getInstance().dispatchCommand(backPressedCommand, false);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        super.onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        try {
            super.onConfigurationChanged(newConfig);
            ApplicationObservers.getInstance().onConfigurationChangedActivityUpdate();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }
}
