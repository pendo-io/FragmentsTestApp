package sdk.pendo.io.information.collectors.application

import android.annotation.TargetApi
import android.content.pm.PackageManager
import android.content.pm.ProviderInfo
import android.os.Build
import android.os.PatternMatcher
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.ResourceUtils
import sdk.pendo.io.utilities.add

/**
 * Collect information about the application's content providers.

 * Created by assaf on 4/14/15.
 */
internal class ContentProviders : Collector() {

    override fun collectData(json: JSONObject) {

        // Add info about the application's content providers.
        addContentProviders(json)
    }

    /**
     * Adds information about the application's content providers to a JSON.

     * @param info The JSON to receive the information about the application's content providers.
     */
    private fun addContentProviders(info: JSONObject) {
        try {
            val appProviders = application!!.packageManager.getPackageInfo(packageName,
                    PackageManager.GET_PROVIDERS or PackageManager.GET_URI_PERMISSION_PATTERNS)

            val providers = appProviders.providers
            if (providers != null) {
                val providerArray = JSONArray()

                for (provider in providers) {
                    val providerJSON = JSONObject()
                    providerJSON.add("provider_authority", provider.authority)
                    providerJSON.add("provider_enabled", provider.enabled)
                    providerJSON.add("provider_exported", provider.exported)
                    providerJSON.add("provider_grantUriPermissions", provider.grantUriPermissions)
                    providerJSON.add("provider_icon", provider.icon)
                    providerJSON.add("provider_initOrder", provider.initOrder)
                    providerJSON.add("provider_label", ResourceUtils.getStringFromResource(provider.labelRes) ?: "??")
                    providerJSON.add("provider_multiprocess", provider.multiprocess)
                    providerJSON.add("provider_name", provider.name)
                    providerJSON.add("provider_process", provider.processName)
                    providerJSON.add("provider_readPermission", provider.readPermission)
                    providerJSON.add("provider_writePermission", provider.writePermission)

                    if (provider.uriPermissionPatterns != null) {
                        val uriPrmPtrn = JSONArray()
                        for (uriPermissionPattern in provider.uriPermissionPatterns) {
                            val uppJSON = JSONObject()
                            uppJSON.add("type", contentProviderTypeToString(uriPermissionPattern.type))
                            uppJSON.add("path", uriPermissionPattern.path)
                            uriPrmPtrn.add(uppJSON)
                        }
                        providerJSON.add("provider_uriPermissionPatterns", uriPrmPtrn)
                    }

                    if (provider.pathPermissions != null) {
                        val pthPrm = JSONArray()
                        for (pathPermission in provider.pathPermissions) {
                            val ppJSON = JSONObject()
                            ppJSON.add("path", pathPermission.path)
                            ppJSON.add("type", contentProviderTypeToString(pathPermission.type))
                            ppJSON.add("read", pathPermission.readPermission)
                            ppJSON.add("write", pathPermission.writePermission)
                            pthPrm.add(ppJSON)
                        }
                        providerJSON.add("provider_pathPermissions", pthPrm)
                    }

                    addJellybeanProperties(provider, providerJSON)
                    providerArray.add(providerJSON)
                }

                try {
                    info.add("providers", providerArray)
                } catch (e: JSONException) {
                    InsertLogger.e(e, "${e.message}")
                }

            }
        } catch (e: PackageManager.NameNotFoundException) {
            InsertLogger.e(e, "Failed to get content providers.")
        }

    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    private fun addJellybeanProperties(provider: ProviderInfo, providerJSON: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            providerJSON.add("provider_flags", provider.flags)
        }
    }

    companion object {

        /**
         * Took from [android.os.PatternMatcher.toString].

         * @param type The content provider type.
         * *
         * @return String representation of the content provider type.
         */
        fun contentProviderTypeToString(type: Int): String {
            when (type) {
                PatternMatcher.PATTERN_LITERAL -> return "LITERAL"
                PatternMatcher.PATTERN_PREFIX -> return "PREFIX"
                PatternMatcher.PATTERN_SIMPLE_GLOB -> return "GLOB"
                else -> return "UNKNOWN"
            }
        }
    }
}
