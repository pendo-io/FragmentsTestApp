package sdk.pendo.io.exceptions

/**
 * Pendo's exception for dynamic view errors.
 *
 * Created by Oren Dayan 21/1/20
 */
class PendoInitializedStateException(message: String) : IllegalStateException(message)
