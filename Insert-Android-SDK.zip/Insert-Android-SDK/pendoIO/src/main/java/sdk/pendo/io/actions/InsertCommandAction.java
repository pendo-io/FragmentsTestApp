package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;

/**
 * Actions to use with {@link InsertCommand}.
 *
 * Created by assaf on 3/28/16.
 */
@SuppressWarnings({"unused", "CheckStyle"})
public class InsertCommandAction {

    public static final InsertCommandAction INSERT_COMMAND_ACTION_ANY = new InsertCommandAction("ANY");

    public final String action;

    private InsertCommandAction(String action) {
        this.action = action;
    }

    private static HashMap<String, InsertCommandAction> sActionMap = new HashMap<>();
    public static synchronized InsertCommandAction getAction(String action) {
        if (sActionMap.isEmpty()) {
            generateActionMap();
        }

        return sActionMap.get(action);
    }

    @Override
    public String toString() {
        return "Action = {" + action + "}";
    }

    @Override
    public int hashCode() {
        return action.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof InsertCommandAction)) {
            return false;
        } else if (o == this) {
            return true;
        }

        return action.equals(((InsertCommandAction) o).action);
    }

    private static void generateActionMap() {
        Class[] classes = {
                InsertInternalAction.class,
                InsertCommandViewGeneralAction.class,
                InsertCommandFormAction.class,
                InsertCommandRadioButtonAction.class,
                InsertCommandRadioGroupAction.class,
                InsertCommandTextAction.class,
                InsertCommandButtonAction.class,
                InsertCommandVideoAction.class,
                InsertCommandPagerAction.class,
                InsertCommandPageAction.class,
                InsertCommandGlobalAction.class,
                InsertCommandRunnableAction.class
        };

        for (Class aClass : classes) {
            final Field[] fields = aClass.getDeclaredFields();

            for (Field field : fields) {
                final int modifiers = field.getModifiers();
                if (Modifier.isPublic(modifiers) && Modifier.isStatic(modifiers)) {
                    try {
                        final InsertCommandAction actionField = (InsertCommandAction) field.get(aClass);

                        sActionMap.put(actionField.action, actionField);
                    } catch (Exception ignore) { }
                }
            }
        }
    }

    public static class InsertCommandActionDeserializer implements JsonDeserializer<InsertCommandAction> {
        @Override
        public InsertCommandAction deserialize(JsonElement json, Type typeOfT,
                                               JsonDeserializationContext context)
                throws JsonParseException {
            return getAction(json.getAsString());
        }
    }

    /** Internal Pendo actions **/
    public static final class InsertInternalAction extends InsertCommandAction {
        private InsertInternalAction(String action) {
            super(action);
        }

        public static final InsertInternalAction PREFETCH_IMAGES = new InsertInternalAction("prefetchImages");
        public static final InsertInternalAction IMAGES_SET = new InsertInternalAction("imagesSet");
    }

    public static final class InsertCommandViewGeneralAction extends InsertCommandAction {
        private InsertCommandViewGeneralAction(String action) {
            super(action);
        }

        public static final InsertCommandViewGeneralAction ENABLE = new InsertCommandViewGeneralAction("enable");
        public static final InsertCommandViewGeneralAction ENABLE_ACTION = new InsertCommandViewGeneralAction("enableAction");
        public static final InsertCommandViewGeneralAction SET_BACKGROUND_COLOR = new InsertCommandViewGeneralAction("setBackgroundColor");
        public static final InsertCommandViewGeneralAction SET_VISIBILITY = new InsertCommandViewGeneralAction("setVisibility");
    }

    public static final class InsertCommandFormAction extends InsertCommandAction {
        private InsertCommandFormAction(String action) {
            super(action);
        }

        public static final InsertCommandFormAction SUBMIT = new InsertCommandFormAction("submit");
        public static final InsertCommandFormAction UPDATE = new InsertCommandFormAction("update");
        public static final InsertCommandFormAction SET_VALUE_FOR_KEY = new InsertCommandFormAction("setValueForKey");
    }

    public static final class InsertCommandRadioButtonAction extends InsertCommandAction {
        private InsertCommandRadioButtonAction(String action) {
            super(action);
        }

        public static final InsertCommandRadioButtonAction SELECT = new InsertCommandRadioButtonAction("select");
    }

    public static final class InsertCommandRadioGroupAction extends InsertCommandAction {
        private InsertCommandRadioGroupAction(String action) {
            super(action);
        }

        public static final InsertCommandRadioGroupAction SELECT_RADIO_BUTTON = new InsertCommandRadioGroupAction("selectRadioButton");
    }

    public static class InsertCommandTextAction extends InsertCommandAction {
        private InsertCommandTextAction(String action) {
            super(action);
        }

        public static final InsertCommandTextAction SET_TEXT = new InsertCommandTextAction("setText");
    }

    public static final class InsertCommandButtonAction extends InsertCommandTextAction {
        private InsertCommandButtonAction(String action) {
            super(action);
        }
    }

    public static final class InsertCommandVideoAction extends InsertCommandAction {
        private InsertCommandVideoAction(String action) {
            super(action);
        }

        public static final InsertCommandVideoAction PLAY = new InsertCommandVideoAction("play");
        public static final InsertCommandVideoAction STOP = new InsertCommandVideoAction("stop");
        public static final InsertCommandVideoAction REWIND = new InsertCommandVideoAction("rewind");
        public static final InsertCommandVideoAction SEEK = new InsertCommandVideoAction("seek");
        public static final InsertCommandVideoAction PAUSE = new InsertCommandVideoAction("pause");
    }

    public static final class InsertCommandPagerAction extends InsertCommandAction {
        private InsertCommandPagerAction(String action) {
            super(action);
        }

        public static final InsertCommandPagerAction CHANGE_PAGE = new InsertCommandPagerAction("changePage");
        public static final InsertCommandPagerAction NEXT_PAGE = new InsertCommandPagerAction("nextPage");
        public static final InsertCommandPagerAction PREVIOUS_PAGE = new InsertCommandPagerAction("previousPage");
    }

    public static final class InsertCommandPageAction extends InsertCommandAction {
        private InsertCommandPageAction(String action) {
            super(action);
        }

        public static final InsertCommandPageAction VALIDATE = new InsertCommandPageAction("validate");
    }

    public static final class InsertCommandRunnableAction extends InsertCommandAction {
        private InsertCommandRunnableAction(String action) {
            super(action);
        }

        public static final InsertCommandRunnableAction RUN_JAVA_SCRIPT = new InsertCommandRunnableAction("evaluate");
    }

    public static final class InsertCommandGlobalAction extends InsertCommandAction {
        private InsertCommandGlobalAction(String action) {
            super(action);
        }

        public static final InsertCommandGlobalAction DISMISS_INSERT = new InsertCommandGlobalAction("dismissGuide");
        public static final InsertCommandGlobalAction ADVANCE_GUIDE = new InsertCommandGlobalAction("nextStep");
        public static final InsertCommandGlobalAction CHANGE_SCREEN = new InsertCommandGlobalAction("changeScreen");
        public static final InsertCommandGlobalAction OPEN_URL = new InsertCommandGlobalAction("openLink");
        public static final InsertCommandGlobalAction SHOW_ALERT = new InsertCommandGlobalAction("showAlert");
        public static final InsertCommandGlobalAction SEND_ANALYTICS = new InsertCommandGlobalAction("sendAnalytics");
        public static final InsertCommandGlobalAction SEND_APP_SPECIFIC_ANALYTICS = new InsertCommandGlobalAction("sendAppSpecificAnalytics");
        public static final InsertCommandGlobalAction SEND_APP_GENERIC_ANALYTICS = new InsertCommandGlobalAction("sendAppGenericAnalytics");
        public static final InsertCommandGlobalAction SEND_GUIDE_GENERIC_ANALYTICS = new InsertCommandGlobalAction("sendGuideGenericAnalytics");
        public static final InsertCommandGlobalAction SEND_GUIDE_PARAMETERIZED_GENERIC_ANALYTICS = new InsertCommandGlobalAction("sendGuideParameterizedGenericAnalytics");
        public static final InsertCommandGlobalAction SEND_CUSTOM_ANALYTICS = new InsertCommandGlobalAction("customAnalyticsAction");
        public static final InsertCommandGlobalAction NOTIFY_CLOSE = new InsertCommandGlobalAction("notifyClose");
        public static final InsertCommandGlobalAction IN_ANIMATION_DONE = new InsertCommandGlobalAction("inAnimationDone");
        public static final InsertCommandGlobalAction OUT_ANIMATION_DONE = new InsertCommandGlobalAction("outAnimationDone");

        public static final class SendInsertGenericAnalyticsConsts {
            /** Mandatory = true. */
            public static final String ANALYTICS_TYPE = "analyticsType";
            /** ANALYTICS_TYPE type. */
            public static final String GUIDE_DISMISSED = "guideDismissed";

            /** Mandatory = false (= true for insertDismissed). */
            public static final String DISMISSED_BY = "dismissBy";
            public static final String DISMISSED_REASON = "dismiss_reason";

            public static List<InsertCommandsEventBus.Parameter> createInsertDismissedAnalyticsParams(@NonNull String dismissedBy) {
                LinkedList<InsertCommandsEventBus.Parameter> retList = new LinkedList<>();

                retList.add(new InsertCommandsEventBus.Parameter(ANALYTICS_TYPE, TYPE_STRING , GUIDE_DISMISSED));
                retList.add(new InsertCommandsEventBus.Parameter(DISMISSED_BY, TYPE_STRING , dismissedBy));

                return retList;
            }
        }

        public static final class InsertInfoConsts {

            public static final String INSERT_ID = "internalInsertId";
            public static final String GUIDE_ID = "guideId";
            public static final String EXTERNAL_ENDPOINT_URL = "endpointURL";

            public static List<InsertCommandsEventBus.Parameter> createInsertMetadataParams(String insertId) {
                LinkedList<InsertCommandsEventBus.Parameter> retList = new LinkedList<>();

                retList.add(new InsertCommandsEventBus.Parameter(GUIDE_ID, TYPE_STRING , insertId));

                return retList;
            }

            public static InsertCommandsEventBus.Parameter createInsertMetadataParam(String insertId) {
                return new InsertCommandsEventBus.Parameter(GUIDE_ID, TYPE_STRING , insertId);
            }
        }
    }
}
