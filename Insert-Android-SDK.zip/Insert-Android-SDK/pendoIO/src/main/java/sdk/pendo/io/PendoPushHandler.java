package sdk.pendo.io;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationCompat.Style;
import android.text.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import sdk.pendo.io.activities.PendoGateActivity;
import sdk.pendo.io.logging.InsertLogger;

import static android.support.v4.app.NotificationCompat.PRIORITY_HIGH;
import static sdk.pendo.io.activities.PendoGateActivity.INSERT_PUSH_DATA_KEY;
import static sdk.pendo.io.activities.PendoGateActivity.SHOW_INSERT_LINK_KEY;

/**
 * Created by itayvallach on 24/05/2017.
 */

final class PendoPushHandler {

    public static final String NOTIFICATION_JSON_DATA_KEY = "pinpoint.jsonBody";
    public static final String NOTIFICATION_CORDOVA_JSON_ADDITIONAL_DATA_KEY = "additionalData";
    public static final String NOTIFICATION_CHANNEL_DEFAULT_NAME = "Notifications";
    public static final String NOTIFICATION_CHANNEL_ID = "pendo_notification_channel_id";

    // Keys to get notification data.
    private static final String NOTIFICATION_TITLE_PUSH_KEY = "title";
    private static final String NOTIFICATION_BODY_PUSH_KEY = "body";
    private static final String NOTIFICATION_COLOR_PUSH_KEY = "color";
    private static final String NOTIFICATION_SOUND_PUSH_KEY = "sound";
    private static final String NOTIFICATION_SMALL_ICON_PUSH_KEY = "small_icon";
    private static final String NOTIFICATION_LARGE_ICON_PUSH_KEY = "large_icon";
    private static final String NOTIFICATION_IMAGE_PUSH_KEY = "image_url";
    private static final String NOTIFICATION_CLICK_ACTION_KEY = "click_action";
    public static final String NOTIFICATION_URL_KEY = "url";
    
    private static final String NOTIFICATION_DEFAULT_SOUND = "default";


    /**
     * Main method for handling push notifications from Pendo.
     *
     * If using GCM - call this method from the class in your app that
     * extends GcmListenerService in the onMessageReceived method. Pass
     * the 'data' Bundle as an argument.
     * If using FCM - call this method from the class in your app that
     * extends FirebaseMessagingService in the onMessageReceived method.
     * Pass the RemoteMesssage.getData() Map as an argument.
     *
     * @param data - the Bundle (in GCM case)
     *             or Map (in FCM case) containing the push data.
     */
    public static void handlePendoPush(Object data) {
        JSONObject dataJson;

        try {
            if (data instanceof JSONObject) { // Cordova
                dataJson = ((JSONObject) data).getJSONObject(NOTIFICATION_CORDOVA_JSON_ADDITIONAL_DATA_KEY)
                        .getJSONObject(NOTIFICATION_JSON_DATA_KEY);
            } else if (data instanceof Bundle) { // GCM
                dataJson = new JSONObject(((Bundle) data).getString(NOTIFICATION_JSON_DATA_KEY));
            } else { // FCM
                dataJson = new JSONObject(((Map<String, String>) data).get(NOTIFICATION_JSON_DATA_KEY));
            }

            int requestCode = (int) System.currentTimeMillis();
            Context context = Pendo.getApplicationContext();

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                    .setContentTitle(getContentTitle(context, dataJson))
                    .setContentText(getContentText(dataJson))
                    .setSmallIcon(getIconResourceId(context, dataJson, NOTIFICATION_SMALL_ICON_PUSH_KEY))
                    .setSound(getSound(context, dataJson))
                    .setStyle(getStyle(dataJson))
                    .setColor(getColor(dataJson))
                    .setContentIntent(getPendingIntent(context, dataJson, requestCode))
                    .setPriority(PRIORITY_HIGH) // setPriority is deprecated in API 26 and corresponds to IMPORTANCE_HIGH when creating Channel.
                    .setAutoCancel(true);
            setLargeIconIfNeeded(context, builder, dataJson);
            ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE))
                    .notify(requestCode, builder.build());
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - not showing notification! : " + e.getMessage(), e);
        }
    }

    // Helper method to obtain the notification title text.
    private static String getContentTitle(Context context, JSONObject data) {
        String result = context.getPackageManager()
                .getApplicationLabel(context.getApplicationInfo()).toString();
        try {
            String contentTitle = data.getString(NOTIFICATION_TITLE_PUSH_KEY);
            if (!TextUtils.isEmpty(contentTitle)) {
                result = contentTitle;
            }
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - contentTitle : " + e.getMessage(), e);
        }

        return result;
    }

    // Helper method to obtain the notification body text.
    private static String getContentText(JSONObject data) {
        try {
        return data.getString(NOTIFICATION_BODY_PUSH_KEY);
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - contentText : " + e.getMessage(), e);
            return "";
        }
    }

    // Helper method to obtain the notification small icon resource id.
    private static int getIconResourceId(Context context, JSONObject data, String key) {
        try {
            final String drawableResourceName = data.getString(key);

            if (!TextUtils.isEmpty(drawableResourceName)) {
                final int resId = context.getResources()
                        .getIdentifier(drawableResourceName, "drawable", context.getPackageName());
                if (resId != 0) {
                    return resId;
                }
            }

            return key.equals(NOTIFICATION_SMALL_ICON_PUSH_KEY) ? context.getApplicationInfo().icon : 0;

        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - iconResourceId : " + e.getMessage(), e);

            // 0 is an invalid resource id, so use it to indicate failure to
            // retrieve the resource.
            return 0;
        }
    }

    // Helper method to obtain the notification sound.
    private static Uri getSound(Context context, JSONObject data) {
        Uri result = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        try {
            String soundFileName = data.getString(NOTIFICATION_SOUND_PUSH_KEY);
            if (!TextUtils.isEmpty(soundFileName) && !soundFileName.equals(NOTIFICATION_DEFAULT_SOUND)) {
                result = Uri.parse("android.resource://" + context.getPackageName() + "/raw/" + soundFileName);
            }
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - sound : " + e.getMessage(), e);
        }

        return result;
    }

    // Helper method to obtain the notification style.
    // The image should have 2:1 aspect ratio, but your main content
    // should be in 43:24 ratio (~1.79) as some devices crop past this width.
    private static Style getStyle(JSONObject data) {
        Style style = null;
        try {
            String imageUrl = data.getString(NOTIFICATION_IMAGE_PUSH_KEY);
            if (!TextUtils.isEmpty(imageUrl)) {
                try {
                    Bitmap notificationImage = new DownloadPushImageTask().execute(imageUrl).get();
                    if (notificationImage != null) {
                        style = new NotificationCompat.BigPictureStyle()
                                .bigPicture(notificationImage)
                                .setSummaryText(data.getString(NOTIFICATION_BODY_PUSH_KEY));

                    } else {
                        style = new NotificationCompat.BigTextStyle()
                                .bigText(NOTIFICATION_BODY_PUSH_KEY);
                    }
                } catch (Exception e) {
                    InsertLogger.e("Failed to download image for push notification");
                }
            }
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - largeIcon : " + e.getMessage(), e);
        }
        return style;
    }

    // Helper method to obtain the notification small icon background color. The color is
    // respected only on Android >= 5.0 and only affects background of the *small* icon.
    private static int getColor(JSONObject data) {
        int color = Color.TRANSPARENT;
        try {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (data.has(NOTIFICATION_COLOR_PUSH_KEY)) {
                    final String colorString = data.getString(NOTIFICATION_COLOR_PUSH_KEY);
                    if (!TextUtils.isEmpty(colorString)) {
                        try {
                            color = Color.parseColor(colorString);
                        } catch (final IllegalArgumentException ex) {
                            InsertLogger.w("Couldn't parse notification color.", ex);
                            color = Color.TRANSPARENT;
                        }
                    }
                }
            }
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - color : " + e.getMessage(), e);
        }
        return color;
    }

    // Helper method to obtain the pending intent for the notification.
    private static PendingIntent getPendingIntent(Context context, JSONObject dataJson, int requestCode) {
        Intent intent = new Intent(context, PendoGateActivity.class);
        try {
            JSONObject action = dataJson.getJSONObject(NOTIFICATION_CLICK_ACTION_KEY);
            if (action.has(NOTIFICATION_URL_KEY) &&
                    !TextUtils.isEmpty(action.getString(NOTIFICATION_URL_KEY))) {
                intent.putExtra(NOTIFICATION_URL_KEY, action.getString(NOTIFICATION_URL_KEY));
            } else {
                intent.putExtra(INSERT_PUSH_DATA_KEY, dataJson.getString(INSERT_PUSH_DATA_KEY));

                if (dataJson.has(SHOW_INSERT_LINK_KEY)) {
                    intent.putExtra(SHOW_INSERT_LINK_KEY, dataJson.getString(SHOW_INSERT_LINK_KEY));
                }
            }
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - clickAction/insertData : " + e.getMessage(), e);
        }

        return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_ONE_SHOT);
    }

    // Helper method to obtain and set the notification large icon, if needed.
    // Icon can either be downloaded from a URL or retrieved from drawable resources.
    private static void setLargeIconIfNeeded(Context context, NotificationCompat.Builder builder, JSONObject data) {
        try {
            String largeIconUrl = data.getString(NOTIFICATION_LARGE_ICON_PUSH_KEY);
            if (!TextUtils.isEmpty(largeIconUrl)) {
                if (largeIconUrl.startsWith("http")) {
                    Bitmap largeIcon = new DownloadPushImageTask().execute(largeIconUrl).get();
                    if (largeIcon != null) {
                        builder.setLargeIcon(largeIcon);
                    }
                } else { // Try to retrieve from resources.
                    int resId = getIconResourceId(context, data, NOTIFICATION_LARGE_ICON_PUSH_KEY);
                    if (resId != 0) {
                        builder.setLargeIcon(BitmapFactory.decodeResource(context.getResources(), resId));
                    }
                }
            }
        } catch (final InterruptedException e) {
            InsertLogger.e("Interrupted when downloading image : " + e.getMessage(), e);
        } catch (final ExecutionException e) {
            InsertLogger.e("Failed execute download image thread : " + e.getMessage(), e);
        } catch (final JSONException e) {
            InsertLogger.e("Failed to parse push json data - largeIcon : " + e.getMessage(), e);
        }
    }


    /**
     *  Creates the NotificationChannel, but only on API 26+ because
     *  the NotificationChannel class is new and not in the support library.
     *  @param context the Application Context to get the NotificationManager.
     */
    @SuppressLint("NewApi")
    public static void createNotificationChannelIfNeeded(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    NOTIFICATION_CHANNEL_DEFAULT_NAME,
                    NotificationManager.IMPORTANCE_HIGH);

            context.getSystemService(NotificationManager.class)
                    .createNotificationChannel(channel);
        }
    }

    // Helper class to download icons/images for the notification.
    private static class DownloadPushImageTask extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... urls) {

            try {
                return BitmapFactory.decodeStream((new URL(urls[0])).openConnection().getInputStream());
            } catch (final OutOfMemoryError e) {
                InsertLogger.e("Image is too heavy, ran out of memory trying to download it.", e);
                return null;
            } catch (final Exception ex) {
                InsertLogger.e("Cannot download or find image for rich notification.", ex);
                return null;
            }
        }
    }
}
