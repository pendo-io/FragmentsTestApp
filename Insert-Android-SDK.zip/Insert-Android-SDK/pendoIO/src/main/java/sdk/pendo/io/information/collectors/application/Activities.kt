package sdk.pendo.io.information.collectors.application

import android.annotation.TargetApi
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.ResourceUtils
import sdk.pendo.io.utilities.ViewUtils
import sdk.pendo.io.utilities.add

/**
 * Collect information about the application's activities.

 * Created by assaf on 4/14/15.
 */
internal class Activities : Collector() {

    override fun collectData(json: JSONObject) {

        // Add the application's activities.
        addActivities(json)
    }

    /**
     * Adds infomation about all the activities in the application to the JSON.

     * @param info The JSON to receive the activities info.
     */
    private fun addActivities(info: JSONObject) {
        try {
            val appActivities = application!!.packageManager.getPackageInfo(packageName,
                    PackageManager.GET_ACTIVITIES)

            val activities = appActivities.activities
            if (activities != null) {
                val activitiesArray = JSONArray()

                for (activity in activities) {
                    val actJSON = addKitkatWatchActivityProperties(activity)

                    actJSON.add("activity_configChanges", activity.configChanges) // FIXME: 4/7/15 Should we get the types instead of just the int?

                    addLollipopActivityProperties(activity, actJSON)

                    actJSON.add("activity_enabled", activity.enabled)
                    actJSON.add("activity_exported", activity.exported)
                    actJSON.add("activity_icon", activity.icon)
                    actJSON.add("activity_label", ResourceUtils.getStringFromResource(activity.labelRes) ?: "??")
                    actJSON.add("activity_launchMode", convertLaunchModeToString(activity.launchMode))
                    actJSON.add("activity_name", activity.name)

                    addJellybeanActivityProperties(activity, actJSON)

                    if (activity.permission != null) {
                        actJSON.add("activity_permission", activity.permission)
                    }

                    actJSON.add("activity_process", activity.processName)
                    actJSON.add("activity_screenOrientation", ViewUtils.activityOrientationToString(activity.screenOrientation))
                    actJSON.add("activity_taskAffinity", activity.taskAffinity)
                    actJSON.add("activity_theme", Integer.toHexString(activity.theme))
                    actJSON.add("activity_uiOptions", Integer.toHexString(activity.uiOptions))
                    actJSON.add("activity_softInputMode", Integer.toHexString(activity.softInputMode))
                    actJSON.add("activity_flags", Integer.toHexString(activity.flags))

                    activitiesArray.add(actJSON)
                }

                info.add("activities", activitiesArray)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            InsertLogger.e(e, "Failed to get activities.")
        }

    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private fun addJellybeanActivityProperties(activity: ActivityInfo, actJSON: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            actJSON.add("activity_parentActivityName", activity.parentActivityName)
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private fun addLollipopActivityProperties(activity: ActivityInfo, actJSON: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            actJSON.add("activity_documentLaunchMode",
                    convertDocumentLaunchModeToString(activity.documentLaunchMode))
            actJSON.add("activity_maxRecents", activity.maxRecents)
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT_WATCH)
    private fun addKitkatWatchActivityProperties(activity: ActivityInfo): JSONObject {
        val actJSON = JSONObject()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            actJSON.add("activity_banner", activity.banner)
        }
        return actJSON
    }

    /**
     * Converts the document launch mode from int to string.
     *
     * @param documentLaunchMode The document launch mode.
     *
     * @return A readable string representing the document launch mode.
     */
    private fun convertDocumentLaunchModeToString(documentLaunchMode: Int): String {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            when (documentLaunchMode) {
                ActivityInfo.DOCUMENT_LAUNCH_NONE -> return "DOCUMENT_LAUNCH_NONE"
                ActivityInfo.DOCUMENT_LAUNCH_INTO_EXISTING -> return "DOCUMENT_LAUNCH_INTO_EXISTING"
                ActivityInfo.DOCUMENT_LAUNCH_ALWAYS -> return "DOCUMENT_LAUNCH_ALWAYS"
                ActivityInfo.DOCUMENT_LAUNCH_NEVER -> return "DOCUMENT_LAUNCH_NEVER"
            }
        }

        return "????"
    }

    /**
     * Converts the launch mode from int to string.

     * @param launchMode The launch mode.
     * *
     * @return A readable string representing the launch mode.
     */
    private fun convertLaunchModeToString(launchMode: Int): String {

        when (launchMode) {
            ActivityInfo.LAUNCH_MULTIPLE -> return "LAUNCH_MULTIPLE"
            ActivityInfo.LAUNCH_SINGLE_TOP -> return "LAUNCH_SINGLE_TOP"
            ActivityInfo.LAUNCH_SINGLE_TASK -> return "LAUNCH_SINGLE_TASK"
            ActivityInfo.LAUNCH_SINGLE_INSTANCE -> return "LAUNCH_SINGLE_INSTANCE"
        }

        return "????"
    }
}
