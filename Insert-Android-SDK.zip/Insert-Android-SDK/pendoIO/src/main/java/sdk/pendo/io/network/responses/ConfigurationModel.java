package sdk.pendo.io.network.responses;

import com.google.gson.annotations.SerializedName;

/**
 * Pendo's class for the configuration model of the init protocol.
 *
 * Created by assaf on 5/13/15.
 */
public class ConfigurationModel {

    private static class AnalyticsModel {

        @SerializedName("bufferQueueSize")
        int mBufferQueueSize;

        @SerializedName("bufferDuration")
        int mBufferDuration;

        @SerializedName("sendRetroactiveScreenEvents")
        boolean mRetroactiveScreenEventsEnabled;

        @SerializedName("sendRetroactiveClickEvents")
        boolean mRetroactiveClickEventsEnabled;

        @SerializedName("includePageViewTexts")
        boolean mIncludePageViewTexts;

        @SerializedName("includeFeatureClickTexts")
        boolean mIncludeFeatureClickTexts;

    }

    @SerializedName("analytics")
    AnalyticsModel mAnalytics;

    @SerializedName("sessionTimeout")
    int mSessionTimeoutSeconds;

    public int getAnalyticsBufferQueueSize() {
        return mAnalytics.mBufferQueueSize;
    }

    public int getAnalyticsBufferDuration() {
        return mAnalytics.mBufferDuration;
    }

    public int getSessionTimeoutSeconds() {
        return mSessionTimeoutSeconds;
    }

    public boolean isRAScreenEventsEnabled() {
        return mAnalytics.mRetroactiveScreenEventsEnabled;
    }

    public boolean isRAClickEventsEnabled() {
        return mAnalytics.mRetroactiveClickEventsEnabled;
    }

    public boolean isIncludePageViewTexts() {
        return mAnalytics.mIncludePageViewTexts;
    }

    public boolean isIncludeFeatureClickTexts() {
        return mAnalytics.mIncludeFeatureClickTexts;
    }

}
