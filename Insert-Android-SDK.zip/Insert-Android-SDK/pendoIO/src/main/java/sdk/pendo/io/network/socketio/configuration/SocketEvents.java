package sdk.pendo.io.network.socketio.configuration;

/**
 * Holds the socket protocol events
 */
public enum SocketEvents {
    // PAIRED_MODE
    EVENT_PAIRED_MODE_UPDATE("updatePairedMode"),
    EVENT_PAIRED_MODE_UPDATED("pairedModeUpdated"),
    EVENT_RESET_STATE("resetState"),
    // PREVIEW_MODE
    EVENT_PREVIEW_ON_DEVICE("previewOnDevice"),
    EVENT_PREVIEW_DISPLAYED("previewDisplayed"),
    // CAPTURE_MODE
    EVENT_CAPTURE_MODE_ENTER("enterCaptureMode"),
    EVENT_CAPTURE_MODE_ENTERED("captureModeEntered"),
    EVENT_CAPTURE_MODE_EXIT("exitCaptureMode"),
    EVENT_CAPTURE_MODE_EXITED("captureModeExited"),
    EVENT_PREPARE_TO_RECEIVE_SCREEN("prepareToReceiveScreen"),
    EVENT_READY_TO_RECEIVE_SCREEN("readyToReceiveScreen"),
    EVENT_SCREEN_CAPTURED("screenCaptured"),
    // TEST_MODE
    EVENT_CAPTURE_MODE_SCREEN_RECEIVED("screenReceived"),
    EVENT_TEST_MODE_ENTER("enterTestMode"),
    EVENT_TEST_MODE_ENTERED("testModeEntered"),
    EVENT_TEST_MODE_EXIT("exitTestMode"),
    EVENT_TEST_MODE_EXITED("testModeExited"),
    // IDENTIFICATION
    EVENT_IDENTIFY_MODE_ENTER("enterIdentificationMode"),
    EVENT_IDENTIFY_MODE_ENTERED("identificationModeEntered"),
    EVENT_IDENTIFY_MODE_EXIT("exitIdentificationMode"),
    EVENT_IDENTIFY_MODE_EXITED("identificationModeExited"),
    EVENT_IDENTIFY_SCREEN_IDENTIFIED("stateIdentified"),
    //MIS
    EVENT_TERMINATE("terminateSession"),
    EVENT_INVALID("invalid") ;

    public static final String EVENT_SUCCESS = "isSuccessful";
    private final String mCommand;

    SocketEvents(String command) {
        this.mCommand = command;
    }

    public String getCommand() {
        return mCommand;
    }
}