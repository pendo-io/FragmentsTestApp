package sdk.pendo.io.events

import io.reactivex.functions.Consumer
import org.json.JSONArray
import sdk.pendo.io.reactive.InsertOnErrorHandler
import sdk.pendo.io.sdk.manager.ApplicationFlowManager
import sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_BACKGROUND
import sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_FOREGROUND
import sdk.pendo.io.utilities.PersistenceUtils

object RAScreenDisplayDurationManager {
	private var startTime: Long = 0
	private var accumulativeTime: Long = 0
	private var currentScreen: String = ""

	private val appFlowListener = Consumer<ApplicationFlowManager.AppFlowState> { appFlowState ->
		if (IN_BACKGROUND == appFlowState) {
			val currentInterval = System.currentTimeMillis() - startTime
			PersistenceUtils.persistScreenLeftIntervalledAnalytics(
				startTime, currentInterval,
				currentScreen.hashCode()
			)
			accumulativeTime += currentInterval
		} else if (IN_FOREGROUND == appFlowState) {
			startTime = System.currentTimeMillis()
		}
	}

	init {
		ApplicationFlowManager.getInstance().getAppFlowChanges(true).subscribe(appFlowListener, InsertOnErrorHandler())
	}

	fun getScreenDisplayDuration(): Long {
		val lastInterval: Long = System.currentTimeMillis() - startTime
		PersistenceUtils.persistScreenLeftIntervalledAnalytics(
			startTime, lastInterval,
			currentScreen.hashCode()
		)
		val totalDuration = lastInterval + accumulativeTime
		startTime = 0
		accumulativeTime = 0
		return totalDuration
	}


	fun getScreenActiveTime(): JSONArray {
		return PersistenceUtils.getFullTimeIntervalledAnalyticsScreenLeft(currentScreen.hashCode().toString())
	}

	fun beginCountingScreenDisplayDuration(screenId: String) {
		currentScreen = screenId
		PersistenceUtils.removeScreenLeftIntervalledAnalytics(currentScreen.hashCode())
		startTime = System.currentTimeMillis()
		accumulativeTime = 0
	}
}
