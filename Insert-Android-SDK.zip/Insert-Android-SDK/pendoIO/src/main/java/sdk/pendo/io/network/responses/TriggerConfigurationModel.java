package sdk.pendo.io.network.responses;

import android.support.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import sdk.pendo.io.events.TriggerPreference;

/**
 * Created by assaf on 5/13/15.
 */
public final class TriggerConfigurationModel {

    @SerializedName("preferences")
    private List<TriggerPreference> mPreferences;

    @SerializedName("delaySec")
    private long mDelaySeconds;

    @SerializedName("viewConditions")
    private ViewConditionsModel mViewConditions;

    @SerializedName("dependsOnScreenView")
    private Dependency mScreenViewDependency;

    @SerializedName("dependentScreenLeft")
    private Dependency mScreenLeftDependency;

    @Nullable
    public String getPredicate() {
        return mViewConditions != null ? mViewConditions.getPredicate() : null;
    }

    public List<TriggerPreference> getPreferences() {
        return mPreferences;
    }

    public long getDelaySec() {
        return mDelaySeconds;
    }

    public int getScreenViewDependency() {
        return mScreenViewDependency != null ? mScreenViewDependency.triggerId : 0;
    }

    public int getScreenLeftDependency() {
        return mScreenLeftDependency != null ? mScreenLeftDependency.triggerId : 0;
    }

    private class Dependency {

        @SerializedName("triggerId")
        private int triggerId;

        @SerializedName("inOrder")
        private boolean inOrder;
    }


}
