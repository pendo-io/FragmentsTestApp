package sdk.pendo.io.fonts;

import com.joanzapata.iconify.Icon;
import com.joanzapata.iconify.IconFontDescriptor;

/**
 * Pendo's fonts.
 *
 * Created by assaf on 7/3/16.
 */
public final class InsertIoModule implements IconFontDescriptor {

    public static final String ICON_FONT_FAMILY_NAME = "FontInsert";

    private static final String ICONIFY_FONT_INSERT_FILE_NAME = "iconify/font-insert.ttf";

    @Override
    public String ttfFileName() {
        return ICONIFY_FONT_INSERT_FILE_NAME;
    }

    @Override
    public Icon[] characters() {
        return InsertIoIcons.values();
    }
}
