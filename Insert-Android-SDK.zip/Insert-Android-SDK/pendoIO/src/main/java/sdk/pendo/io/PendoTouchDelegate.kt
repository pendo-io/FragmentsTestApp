package sdk.pendo.io

import android.graphics.Rect
import android.os.Handler
import android.support.v4.widget.DrawerLayout
import android.view.MotionEvent
import android.view.TouchDelegate
import android.view.View
import android.view.ViewConfiguration
import android.widget.AbsListView
import android.widget.ScrollView
import io.reactivex.disposables.Disposable
import io.reactivex.functions.Consumer
import org.json.JSONObject
import sdk.pendo.io.actions.*
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.reactive.InsertOnErrorHandler
import sdk.pendo.io.sdk.manager.AnalyticsManager
import sdk.pendo.io.sdk.manager.ScreenManager
import sdk.pendo.io.utilities.ViewHierarchyUtility

/**
 * Touch Delegate class to override clicks if needed.
 */
class PendoTouchDelegate(bounds: Rect?, private val delegateView: View) :
        TouchDelegate(bounds, delegateView) {
    private val OVERRIDE_CLICK_BY_SDK: Boolean = true
    private val IGNORE_CLICK_BY_SDK: Boolean = false
    private var originalTouchDelegate: TouchDelegate? = null
    private var mSubscription: Disposable? = null
//	private const val INSERT_VISUAL_ACTIVITY_CLASS_NAME : String = "insertvisualactivity"

    private var mLongClickDetected: Boolean = false
    private val mLongPressRunnable: Runnable = Runnable {
        run {
            val elementInfoRA = ViewHierarchyUtility.createRAElementInfoJSON(delegateView, ScreenManager.includeFeatureClickTexts, ScreenManager.includeFeatureClickAccessibility)
            AnalyticsManager.handleClickEvent(elementInfoRA)
            mLongClickDetected = true
        }
    }
    private val mLongPressHandler: Handler = Handler()


    fun setOriginalTouchDelegate(touchDelegate: TouchDelegate) {
        originalTouchDelegate = touchDelegate
    }

    /**
     * Check if original delegate exists, if it does, perform it instead of the delegateView's onClick.
     * @param event - the motion event to perform.
     * @return click overriden by sdk or not.
     */
    private fun checkOriginalDelegateAndPerformClick(event: MotionEvent, isGuideRunning: Boolean): Boolean {
        try {
            val finalOriginalTouchDelegate: TouchDelegate? = originalTouchDelegate
            if (finalOriginalTouchDelegate != null) {
                return finalOriginalTouchDelegate.onTouchEvent(event)
            } else {
                if (isGuideRunning) {
                    delegateView.performClick()
                    return true
                }
            }
        } catch (e: Exception) {
            InsertLogger.e(e)
        }

        return false
    }

    /**
     * First run our click logic which will show a guide if possible,
     * and then proceed with the host app's click once the animation was
     * done and we were notified that the guide was closed.
     * @param event - the motion event to perform.
     * @return whether to let host app continue with it's click or not.
     */
    private fun runGuideFollowedByHostAppClicks(event: MotionEvent, elementInfoRA: JSONObject): Boolean {
        var insertId = InsertAction.NO_ID
        var runningInsert = false
        var activityDestroyed = true

        try {
            InsertLogger.d("Clicked view: " + delegateView.toString())
            activityDestroyed = InsertsManager.isActivityDestroyed()
            if (!activityDestroyed) {
                insertId = ActivationManager.handleClick(elementInfoRA)
                runningInsert = insertId != InsertAction.NO_ID
            }
        } catch (e: Exception) {
            InsertLogger.d(e)
        }
        if (activityDestroyed || !runningInsert) {
            // Let onTouch handle the click or if not present, pass it along to the next handler
            // by returning false
            return checkOriginalDelegateAndPerformClick(event, false)
        } else if (mSubscription == null) {
            try {
                mSubscription = InsertCommandsEventBus.getInstance()
                        .commandEventBus
                        .compose(
                                VisualAnimationManager.waitForAnimationDoneAndNotifyClose((insertId))
                        ).firstElement()
                        .subscribe(Consumer { insertCommand ->
                            InsertLogger.d(insertCommand.toString())
                            checkOriginalDelegateAndPerformClick(event, true)
                            if (mSubscription != null) {
                                mSubscription = null
                            }
                        }
                                , InsertOnErrorHandler())

            } catch (e: Exception) {
                InsertLogger.e(e)
            }
            // We will handle the click in guide showing
            return true
        }
        // No one handled the click, pass it on to others to handle
        return false
    }

    /**
     * Handle touch event.
     */
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        val finalOriginalTouchDelegate: TouchDelegate? = originalTouchDelegate

        when (event?.action) {
            MotionEvent.ACTION_DOWN -> {
                mLongPressHandler.postDelayed(mLongPressRunnable, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_UP -> {
                mLongPressHandler.removeCallbacks(mLongPressRunnable)
                val rect = Rect()
                delegateView.getGlobalVisibleRect(rect)

                if (!rect.contains(event.rawX.toInt(), event.rawY.toInt()) || mLongClickDetected) {
                    mLongClickDetected = false
                    return finalOriginalTouchDelegate?.onTouchEvent(event) ?: false
                }

                try {
                    var elementInfoRA = JSONObject()
                    if (!ScreenManager.disableAppAnalytics) {
                        elementInfoRA = ViewHierarchyUtility.createRAElementInfoJSON(delegateView, ScreenManager.includeFeatureClickTexts, ScreenManager.includeFeatureClickAccessibility)
                        AnalyticsManager.handleClickEvent(elementInfoRA)
                    }
                    return if (delegateView !is ScrollView
                            && delegateView !is AbsListView
                            && delegateView !is DrawerLayout
                    ) {
                        runGuideFollowedByHostAppClicks(event, elementInfoRA)
                    } else {
                        finalOriginalTouchDelegate?.onTouchEvent(event)
                                ?: delegateView.performClick()
                    }
                } catch (e: Exception) {
                    InsertLogger.e(e, e.message)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val x: Float = event.x
                val y: Float = event.y
                val slop: Int = ViewConfiguration.get(delegateView.context).scaledTouchSlop
                if ((x < 0 - slop) || (x >= delegateView.width + slop) ||
                        (y < 0 - slop) || (y >= delegateView.height + slop)) {
                    mLongClickDetected = false
                    mLongPressHandler.removeCallbacks(mLongPressRunnable)
                }
            }
            else -> {
                mLongClickDetected = false
                mLongPressHandler.removeCallbacks(mLongPressRunnable)
            }
        }
        return finalOriginalTouchDelegate?.onTouchEvent(event) ?: false
    }
}
