package sdk.pendo.io.network.interfaces;

import external.sdk.pendo.io.retrofit2.Response;
import external.sdk.pendo.io.retrofit2.http.GET;
import io.reactivex.Observable;
import sdk.pendo.io.models.InitModel;

/**
 * Pendo REST API for GetAuthToken.
 *
 * Created by assaf on 5/11/15.
 */
public interface Init {

    @GET("v" + RestAPI.REST_API_VERSION + "/devices/init")
    Observable<Response<InitModel>> initSdk();
}
