package sdk.pendo.io.utilities;

import android.view.View;

import com.jakewharton.rxbinding3.view.RxView;
import com.trello.rxlifecycle3.android.RxLifecycleAndroid;

import java.util.WeakHashMap;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by assaf on 1/31/17.
 */
public final class GlobalLayoutDebouncer {

    private int mCallCounter = 0;
    private long[] mDelays = {0, 0, 50, 100, 150, 250, 375};
    private static final long MAX_DELAY = 500;

    private static volatile GlobalLayoutDebouncer INSTANCE;

    private final WeakHashMap<View, Observable<Object>> mDebounceMap =
            new WeakHashMap<>();

    private GlobalLayoutDebouncer() { }
    public static synchronized GlobalLayoutDebouncer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GlobalLayoutDebouncer();
        }

        return INSTANCE;
    }

    public synchronized Observable<Object> getDebouncer(final View key) {
        InsertLogger.d("Number of debouncers: " + mDebounceMap.size());
        if (mDebounceMap.containsKey(key)) {
            return mDebounceMap.get(key);
        } else {

            final Observable<Object> viewObservable = RxView.globalLayouts(key)
                    .observeOn(AndroidSchedulers.mainThread())
                    .compose(RxLifecycleAndroid.bindView(key))
                    .debounce(++mCallCounter >= mDelays.length ? MAX_DELAY : mDelays[mCallCounter], TimeUnit.MILLISECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .doFinally(new Action() {
                        @Override
                        public void run() {
                            try {
                                mDebounceMap.remove(key);
                            } catch (Exception ignore) {
                            }
                        }
                    });

            mDebounceMap.put(key, viewObservable);
            return viewObservable;
        }
    }
}
//public class Debouncer <T> {
//
//    public interface Callback<T> {
//        public void call(T item);
//    }
//
//    private final ScheduledExecutorService mSched = Executors.newScheduledThreadPool(1);
//    private final ConcurrentHashMap<WeakReference<T>, TimerTask> mDelayedMap = new ConcurrentHashMap<>();
//    private final Callback<WeakReference<T>> mCallback;
//    private final long mInterval;
//    private final TimeUnit mUnit;
//
//    public Debouncer(Callback<WeakReference<T>> c, long interval, TimeUnit unit) {
//        mCallback = c;
//        mInterval = interval;
//        mUnit = unit;
//    }
//
//    public void call(WeakReference<T> key) {
//        TimerTask task = new TimerTask(key);
//
//        TimerTask prev;
//        do {
//            prev = mDelayedMap.putIfAbsent(key, task);
//            if (prev == null)
//                mSched.schedule(task, mInterval, mUnit);
//
//            // Exit only if new task was added to map, or existing task was extended successfully.
//        } while (prev != null && !prev.extend());
//    }
//
//    public void terminate() {
//        mSched.shutdownNow();
//    }
//
//    // The task that wakes up when the wait time elapses
//    private class TimerTask implements Runnable {
//        private final WeakReference<T> mKey;
//        private final Object mLock = new Object();
//
//        // Due time always in milliseconds.
//        private long mDueTime;
//
//        public TimerTask(WeakReference<T> key) {
//            mKey = key;
//            extend();
//        }
//
//        public boolean extend() {
//            synchronized (mLock) {
//
//                if (mDueTime < 0) {
//                    // Task has been shutdown
//                    return false;
//                }
//
//                mDueTime = System.currentTimeMillis() + mUnit.toMillis(mInterval);
//                return true;
//            }
//        }
//
//        public void run() {
//            synchronized (mLock) {
//                long remaining = mDueTime - System.currentTimeMillis();
//
//                if (remaining > 0) { // Re-schedule task
//                    mSched.schedule(this, mUnit.convert(remaining, TimeUnit.MILLISECONDS), mUnit);
//
//                } else { // Mark as terminated and invoke mCallback
//                    mDueTime = -1;
//                    try {
//                        mCallback.call(mKey);
//                    } finally {
//                        mDelayedMap.remove(mKey);
//                    }
//                }
//            }
//        }
//    }
//}
