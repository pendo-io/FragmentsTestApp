package sdk.pendo.io.network.socketio.utilities;

import android.app.Activity;
import android.app.Dialog;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

import sdk.pendo.io.R;
import sdk.pendo.io.dialogs.ErrorDialog;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.views.listener.FloatingListenerButton;

/**
 * Handles socket dialogs such as successful capture, network errors, etc..
 */
public class SocketDialogUtils {
    private static final int AUTO_DISMISS_TIMEOUT = 5000;
    private static final String ERROR_TAG = "error";

    public static void showCaptureSuccessDialog() {
        Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        final Dialog dialog = FloatingListenerButton.getDialogFragment().getLastDialog();
        currentActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (dialog != null && dialog.isShowing()) {
                    dialog.setContentView(R.layout.capture_successful);
                    Handler successAutoDismissHandler = new Handler();
                    Runnable successAutoDismissRunnable = new Runnable() {
                        @Override
                        public void run() {
                            dialog.dismiss();
                        }
                    };
                    successAutoDismissHandler.postDelayed(successAutoDismissRunnable,
                            AUTO_DISMISS_TIMEOUT);
                    ImageView image = (ImageView) dialog.findViewById(
                            R.id.imageViewSuccess);
                    View dialogView = (View) image.getParent();
                    dialogView.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                }
            }
        });
    }

    public static void showCaptureFailDialog() {
        Dialog progressDialog =
                FloatingListenerButton.getDialogFragment().getLastDialog();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        final ErrorDialog mErrorDialog = ErrorDialog.newInstance(
                R.layout.capture_fail, R.id.imageViewFail);
        mErrorDialog.show(
                ApplicationObservers.getInstance().getCurrentVisibleActivity()
                        .getFragmentManager(),
                ERROR_TAG);
    }

}
