package sdk.pendo.io.network.responses;

import com.google.gson.annotations.SerializedName;

import java.util.Date;
import java.util.List;

/**
 * Pendo's kill switch model.
 * <p/>
 * Created by nir
 */
public final class KillSwitchModel {
    public static final String KILL_SWITCH_EXPIRATION = "expiration";
    public static final String KILL_SWITCH_VERSIONS = "versions";
    private static final Long KILL_SWITCH_NEVER_EXPIRES = null;

    @SerializedName(KILL_SWITCH_EXPIRATION)
    private Long mExpirationInMilliseconds; // e.g.: UNIX time format  in milliseconds (epoc). -1 == never expires.
    private Date mExpirationDate;

    @SerializedName(KILL_SWITCH_VERSIONS)
    private List<String> mAffectedVersions;


    public Long getExpiration() {
        return mExpirationInMilliseconds;
    }

    public void setExpiration(Long expiration) {
        mExpirationInMilliseconds = expiration;
    }

    public synchronized boolean isExpired() {
        if (mExpirationInMilliseconds == KILL_SWITCH_NEVER_EXPIRES) {
            return false;
        }

        Date now = new Date();
        now.getTime();
        return now.after(getExpirationDate());
    }

    private Date getExpirationDate() {
        if (mExpirationDate == null) {
            mExpirationDate = new Date(mExpirationInMilliseconds);
        }
        return mExpirationDate;
    }

    public List<String> getAffectedVersions() {
        return mAffectedVersions;
    }

    public void setAffectedVersions(List<String> affectedVersions) {
        mAffectedVersions = affectedVersions;
    }

    public boolean isCurrentSDKVersionAffected(String currentSDKVersion) {
        if (mAffectedVersions != null && mAffectedVersions.contains(currentSDKVersion)) {
            return true;
        }
        return false;
    }

}
