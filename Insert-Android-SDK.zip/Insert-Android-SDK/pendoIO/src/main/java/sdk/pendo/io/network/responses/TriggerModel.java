package sdk.pendo.io.network.responses;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.events.ConditionData;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.ScreenDisplayDurationManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.utilities.ReactiveUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner.InsertContext;

import static sdk.pendo.io.analytics.AnalyticsProperties.SCREEN_DISPLAY_DURATION;
import static sdk.pendo.io.analytics.AnalyticsProperties.SCREEN_ID;


/**
 * Created by assaf on 5/13/15.
 */
public final class TriggerModel {

    @SerializedName("id")
    private int mId;

    @SerializedName("configuration")
    private TriggerConfigurationModel mConfiguration;

    @SerializedName("inserts")
    private ArrayList<InsertRefModel> mInsertRefModels;

    @SerializedName(InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME)
    private JsonArray mCommands;

    @SerializedName("conditions")
    private Conditions mConditions;

    private final AtomicBoolean mSatisfiesFlow = new AtomicBoolean(true);

    private int mScreenId = 0;

    public void setScreenId(int screenId) {
        mScreenId = screenId;
    }

    public int getScreenId() {
        return mScreenId;
    }

    public int getId() {
        return mId;
    }

    public TriggerConfigurationModel getConfiguration() {
        return mConfiguration;
    }

    @Nullable
    public List<InsertRefModel> getInsertRefModels() {

        if (mInsertRefModels == null) {
            return null;
        }

        List<InsertRefModel> clone = new ArrayList<>(mInsertRefModels.size());
        for (InsertRefModel insert : mInsertRefModels) {
            clone.add(InsertRefModel.copy(insert));
        }
        return clone;
    }

    @NonNull
    public List<InsertCommand> getCommands() {
        List<InsertCommand> result = new LinkedList<>();
        if (mCommands == null) {
            InsertLogger.d("No actions.");

        } else {
            result = InsertCommand.getInsertCommands(mCommands);

            InsertContext insertContext = new InsertContext();
            if (mScreenId > 0) {
                insertContext.set(SCREEN_DISPLAY_DURATION,
                        String.valueOf(ScreenDisplayDurationManager.getInstance()
                                .getScreenDisplayDuration(mScreenId)));
                insertContext.set(SCREEN_ID, String.valueOf(mScreenId));
            }
            for (InsertCommand command : result) {
                command.setContext(insertContext);
            }
        }
        return result;
    }

    /**
     * Dispatches commands and adds custom event context in case there are parameters.
     * @param parameters  custom event parameters.
     * @return
     */
    public void dispatchCommands(@Nullable final Map<String, String> parameters) {
        EventsManager.getInstance().setTriggerDispatched(mId);
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                List<InsertCommand> insertCommands = getCommands();
                if (parameters != null) {
                    for (InsertCommand insertCommand : insertCommands) {
                        InsertContext insertCommandContext = new InsertContext();
                        insertCommandContext.set(AnalyticsProperties.CUSTOM_EVENT_PARAMS,
                                (new JSONObject(parameters).toString()));
                        insertCommand.setContext(insertCommandContext);
                    }
                }
                InsertCommandDispatcher.getInstance().dispatchCommands(insertCommands,
                        InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY, false);
            }
        });
    }

    public boolean hasInsertId(String insertId) {
        return getInsertIds().contains(insertId);
    }


    public boolean removeInsertIds(List<String> insertIds) {

        ArrayList<InsertRefModel> removeFromList = new ArrayList<>();

        if (mInsertRefModels != null) {
            for (InsertRefModel insertRefModel : mInsertRefModels) {
                if (insertIds.contains(insertRefModel.id)) {
                    removeFromList.add(insertRefModel);
                }
            }
            return mInsertRefModels.removeAll(removeFromList);
        }

        return false;
    }

    public List<String> getInsertIds() {
        LinkedList<String> retList = new LinkedList<>();

        if (mInsertRefModels != null) {
            for (InsertRefModel insertRefModel : mInsertRefModels) {
                retList.add(insertRefModel.id);
            }
        }

        return retList;
    }

    public List<ConditionData> getConditions() {
        return mConditions.conditionsData != null ? mConditions.conditionsData : new LinkedList<ConditionData>();
    }

    public String getConditionsOperator() {
        return mConditions != null ? mConditions.operator : null;
    }

    public void resetDispatchCommands() {
        EventsManager.getInstance().resetTriggerDispatched(mId);
    }

    public boolean satisfiesFlow() {
        return mSatisfiesFlow.get();
    }

    public void setSatisfiesFlow(boolean bool) {
        mSatisfiesFlow.set(bool);
    }



    public final class Conditions {

        @SerializedName("conditionsLogicalOperator")
        String operator;

        @SerializedName("conditionsData")
        List<ConditionData> conditionsData;

        public List<ConditionData> getConditionsData(){
            return conditionsData;
        }
    }
}
