package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

public class DebugConfigurationModel {
    @SerializedName("refreshIntervalMs")
    private int mRefreshIntervalMs;

    public int getRefreshIntervalMs() {
        return mRefreshIntervalMs;
    }

    public void setRefreshIntervalMs(int refreshIntervalMs) {
        mRefreshIntervalMs = refreshIntervalMs;
    }
}
