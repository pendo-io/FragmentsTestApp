package sdk.pendo.io.logging.profiling;

import android.util.Pair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import sdk.pendo.io.utilities.InsertProfiler;

/**
 * Manages the insert profilers such as: performance, data usage, general info.
 */
public class ProfilingManager {

    public enum ProfilerType {
        PERFORMANCE("Performance Stats"),
        DATA("Data Stats"),
        GERNEAL_INFO("General Info"),
        INSERTS_INFO("Inserts Info");

        private String mType;

        ProfilerType(String type) {
            mType = type;
        }

        public String getType() {
            return mType;
        }
    }

    public static final String TAG_PENDO_PROFILER = "Pendo-Profiler";
    private static volatile ProfilingManager INSTANCE;
    private Map<ProfilerType, InsertProfiler> mProfilers = new HashMap<>();
    public static final String PROFILER_LOG_SEPERATOR = ";";

    private ProfilingManager() {
        mProfilers.put(ProfilerType.PERFORMANCE, new PerformanceProfiler());
        mProfilers.put(ProfilerType.DATA, new DataProfiler());
        mProfilers.put(ProfilerType.GERNEAL_INFO, new GeneralInfoProfiler());
        mProfilers.put(ProfilerType.INSERTS_INFO, new InsertsInfoProfiler());
    }

    public static synchronized ProfilingManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ProfilingManager();
        }

        return INSTANCE;
    }

    public void mark(ProfilerType type, String message) {
        mProfilers.get(type).mark(message);
    }

    public List<Pair<String, InsertProfiler>> getProfilers() {
        List<Pair<String, InsertProfiler>> profilers = new ArrayList<>();
        for (Map.Entry<ProfilerType, InsertProfiler> entry : mProfilers.entrySet()) {
            profilers.add(new Pair<>(entry.getKey().getType(), entry.getValue()));
        }
        return profilers;
    }
}
