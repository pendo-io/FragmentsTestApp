package sdk.pendo.io.views.pager;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.trello.rxlifecycle3.android.RxLifecycleAndroid;

import org.apache.commons.lang3.time.StopWatch;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.atomic.AtomicBoolean;

import external.sdk.pendo.io.dynamicview.DynamicProperty;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.VisualInsertBase;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;
import sdk.pendo.io.views.InsertFragment;
import sdk.pendo.io.views.custom.ViewBaseScriptBridge;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.createInsertMetadataParams;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPagerAction.CHANGE_PAGE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPagerAction.NEXT_PAGE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPagerAction.PREVIOUS_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_CHANGE_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_FIRST_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_INNER_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_LAST_PAGE;
import static sdk.pendo.io.actions.VisualInsert.VISUAL_INSERT_DISMISS_FILTER;
import static sdk.pendo.io.constants.Constants.GeneralConsts.RTL;

/**
 * Pendo's pager view.
 * Created by assaf on 3/7/16.
 */
public final class InsertPager extends ViewPager implements ViewBaseScriptBridge.PagerScriptBridge {

    private static final String INSERT_PAGER_SWIPEABLE = "swipeable";
    private static final String INSERT_PAGER_SHOW_PAGE_INDICATOR = "showPageIndicator";
    private static final String INSERT_PAGER_DISABLE_ANIMATION = "disableAnimation";
    private static final String INSERT_PAGER_DIRECTION = "direction";

    private boolean mSwipeable = false;
    private boolean mDisableAnimation = false;
    private boolean mIsRTL = false;
    private List<InsertCommand> mCommands;

    public InsertPager(Context context) {
        this(context, null);
    }

    public InsertPager(Context context, AttributeSet attrs) {
        super(context, attrs);

        InsertCommandsEventBus.getInstance()
                .subscribe(RxLifecycleAndroid.<InsertCommand>bindView(this),
                           VISUAL_INSERT_DISMISS_FILTER,
                           new Consumer<InsertCommand>() {
                        @Override
                        public void accept(InsertCommand insertCommand) {
                            String insertIdString =
                                    insertCommand.getParamValueFromCommand(
                                            InsertInfoConsts.GUIDE_ID);
                            if (TextUtils.isEmpty(insertIdString)) {
                                return;
                            }
                            final VisualInsertBase visualInsert = VisualInsertManager
                                    .getInstance()
                                    .getVisualInsert(insertIdString);

                            if (visualInsert == null) {
                                InsertLogger.w("Cannot send analytics, visual insert is null.");
                                return;
                            }

                            final Tracker tracker = visualInsert.getTracker();

                            if (tracker == null) {
                                InsertLogger.w("Cannot send analytics, tracker is null.");
                                return;
                            }

                            if (mCurrentFragment != -1) {
                                final InsertFragment fragment = (InsertFragment)
                                        ((InsertPagerAdapter) getAdapter())
                                                .getItem(mCurrentFragment);
                                if (fragment != null) {
                                    // Keep the displayed duration of the last page.
                                    if (mPageDisplayedDuration.isStarted() || mPageDisplayedDuration.isSuspended()) {
                                        mPageDisplayedDuration.stop();
                                    }
                                    final long time = mPageDisplayedDuration.getTime();
                                    mPagesDurationStack.push(Pair.create(
                                            fragment.getFragmentId(), time));
                                    mPageDisplayedDuration.reset();
                                    if (mPageDisplayedDuration.isStopped()) {
                                        mPageDisplayedDuration.reset();
                                    }
                                    if (!mPageDisplayedDuration.isStarted()) {
                                        mPageDisplayedDuration.start();
                                    }
                                } else {
                                    InsertLogger.w("Fragment '" + mCurrentFragment
                                                     + "' returned null.");
                                }
                            }

                            JSONArray pages = new JSONArray();
                            for (Pair<String, Long> pair : mPagesDurationStack) {
                                JSONObject pageDuration = new JSONObject();
                                try {
                                    pageDuration.put("pageId", pair.first);
                                    pageDuration.put("durationMillis", pair.second);
                                } catch (JSONException ignore) {
                                }
                                pages.put(pageDuration);
                            }

                            HashMap<String, Object> additionalInfo = new HashMap<>();
                            additionalInfo.put("pages", pages);
                            final CharSequence contentDescription = getContentDescription();

                            if (!TextUtils.isEmpty(contentDescription)) {
                                additionalInfo.put("pagerId", contentDescription);
                            }

                            AnalyticsUtils.sendAnalytics(AnalyticsEvent.PAGER_FLOW,
                                                         tracker,
                                                         additionalInfo);
                        }
                    });
    }

    private void subscribeActionHandlers(String elementId) {
        final Predicate<InsertCommand> pagerFilter = InsertCommand.createFilter(
                InsertCommand.COMMAND_STRING_ANY,
                elementId,
                InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                InsertCommandScope.INSERT_COMMAND_SCOPE_ANY);

        InsertCommandsEventBus.getInstance().subscribe(RxLifecycleAndroid.<InsertCommand>bindView(this),
                                                       pagerFilter,
                                                       new Consumer<InsertCommand>() {
                    @Override
                    public void accept(InsertCommand insertCommand) {
                        InsertLogger.d(insertCommand.toString());

                        final InsertCommandAction action = insertCommand.getAction();

                        final List<InsertCommandsEventBus.Parameter> parameters =
                                insertCommand.getParameters();


                        final int pageCount = getAdapter().getCount();
                        if (CHANGE_PAGE.equals(action)) {

                            if (parameters == null) {
                                InsertLogger.w("Got " + insertCommand.getAction()
                                                 + " and " + insertCommand.getEventType()
                                                 + " without parameters! Doing nothing.");

                                return;
                            }

                            int toPage = Integer.MIN_VALUE;
                            for (InsertCommandsEventBus.Parameter parameter : parameters) {
                                final String parameterName = parameter.getParameterName();
                                if ("toPage".equals(parameterName)
                                        && "integer".equals(parameter.getValueType())) {

                                    try {
                                        toPage = Integer.parseInt(parameter.getParameterValue());
                                    } catch (Exception notMajor) {
                                        InsertLogger.w(notMajor, notMajor.getMessage());
                                    }
                                }
                            }

                            if (toPage > Integer.MIN_VALUE) {
                                // In case pager is RTL, set page to correct value
                                // (counting from the last page backwards)
                                toPage = mIsRTL ? pageCount - 1 - toPage : toPage;

                                if (0 <= toPage && toPage < pageCount) {
                                    setCurrentItem(toPage);
                                } else {
                                    InsertLogger.w("Cannot change page to: " + toPage
                                            + " number of pages: " + pageCount);
                                }
                            }
                        } else if (NEXT_PAGE.equals(action)) {

                            final int currentItem = getCurrentItem();
                            if (mIsRTL) {
                                // If pager is RTL then our next page will be going backwards, therefore
                                // need to verify that our current page isn't 0 before going backwards.
                                if (currentItem > 0) {
                                    setCurrentItem(currentItem - 1); // Going backwards to our next page.
                                } else {
                                    InsertLogger.w("Cannot change to next page, current: " + currentItem
                                            + " number of pages: " + pageCount);
                                }

                            } else if (currentItem < pageCount - 1) {
                                setCurrentItem(currentItem + 1);
                            } else {
                                InsertLogger.w("Cannot change to next page, current: " + currentItem
                                                 + " number of pages: " + pageCount);
                            }

                        } else if (PREVIOUS_PAGE.equals(action)) {

                            final int previousPage = mPagesStack.pop();
                            if (0 <= previousPage && previousPage < pageCount) {
                                mSkipBackStackPush.set(true);
                                setCurrentItem(previousPage);
                            } else {
                                InsertLogger.w("Cannot change to previous page,"
                                                       + " previous page: '" + previousPage + "'"
                                                       + " number of pages: '" + pageCount + "'.");
                            }
                        }
                    }
                });
    }

    public void setDisableAnimation(boolean disableAnimation) {
        mDisableAnimation = disableAnimation;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        return mSwipeable && super.onInterceptTouchEvent(event);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return mSwipeable && super.onTouchEvent(event);
    }

    @Override
    public void setCurrentItem(int item) {
        super.setCurrentItem(item, !mDisableAnimation);
    }

    private int mPreviousFragment = -1;
    private int mCurrentFragment = -1;

    @Override
    protected void onPageScrolled(int position, float offset, int offsetPixels) {
        super.onPageScrolled(position, offset, offsetPixels);

        if (offset == 0.0f) {

            mPreviousFragment = mCurrentFragment;
            mCurrentFragment = position;

            onPageChanged();
        }

        if (mCommands == null || mCommands.isEmpty()) {
            return;
        }

        // Dispatch the given commands for each of the events.
        if (offset == 0.0f) {
            InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, ON_CHANGE_PAGE, true);
            if (position == 0) {

                // If this is the first page (position 0), in RTL pager it would actually be the last page.
                InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, mIsRTL ? ON_LAST_PAGE : ON_FIRST_PAGE, true);
            } else if (position == getAdapter().getCount() - 1) {

                // Same here, the last position will actually be the first position if it's RTL pager.
                InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, mIsRTL ? ON_FIRST_PAGE :ON_LAST_PAGE, true);
            } else {
                InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, ON_INNER_PAGE, true);
            }
        }
    }

    private Stack<Integer> mPagesStack = new Stack<>();
    private AtomicBoolean mSkipBackStackPush = new AtomicBoolean(false);
    private StopWatch mPageDisplayedDuration = new StopWatch();
    private Stack<Pair<String, Long>> mPagesDurationStack = new Stack<>();

    private synchronized void onPageChanged() {

        // Start the timer.
        if (mCurrentFragment != -1 && mPreviousFragment == -1) {
            if (mPageDisplayedDuration.isStopped()) {
                mPageDisplayedDuration.reset();
            }
            if (!mPageDisplayedDuration.isStarted()) {
                mPageDisplayedDuration.start();
            }
        }

        // Call the page to dispatch it's command.
        if (mPreviousFragment != -1) {
            final InsertFragment fragment = (InsertFragment)
                    ((InsertPagerAdapter) getAdapter()).getItem(mPreviousFragment);
            if (fragment != null) {

                // Keep the displayed duration of the last page.
                if (mPageDisplayedDuration.isStarted() || mPageDisplayedDuration.isSuspended()) {
                    mPageDisplayedDuration.stop();
                }
                final long time = mPageDisplayedDuration.getTime();
                mPageDisplayedDuration.reset();
                if (mPageDisplayedDuration.isStopped()) {
                    mPageDisplayedDuration.reset();
                }
                if (!mPageDisplayedDuration.isStarted()) {
                    mPageDisplayedDuration.start();
                }
                mPagesDurationStack.push(Pair.create(fragment.getFragmentId(), time));

                if (!mSkipBackStackPush.getAndSet(false)) {
                    mPagesStack.push(mPreviousFragment);
                }

                fragment.onDisappear();
            } else {
                InsertLogger.w("Fragment '" + mPreviousFragment + "' returned null.");
            }
        }

        if (mCurrentFragment != -1) {
            final InsertFragment fragment = (InsertFragment)
                    ((InsertPagerAdapter) getAdapter()).getItem(mCurrentFragment);
            if (fragment != null) {
                fragment.onAppear();
            } else {
                InsertLogger.w("Fragment '" + mCurrentFragment + "' returned null.");
            }
        }
    }


    private void setSwipeablePager(boolean isSwipeable) {
        mSwipeable = isSwipeable;
    }

    private void setIsRTL(boolean isRTL) {
        mIsRTL = isRTL;
    }

    private boolean getIsRTL() {
        return mIsRTL;
    }

    private void setCommands(List<InsertCommand> commands) {
        mCommands = commands;
    }

    public static View insertPagerFactory(Context context, ViewGroup parent,
                                          JsonObject pagerJson, String insertId) throws JSONException {

        final Activity activity = (Activity) context;
        final View inflated =
                activity.getLayoutInflater().inflate(R.layout.view_pager, parent, false);
        InsertPager insertPager = (InsertPager) inflated.findViewById(R.id.insrt_view_pager);

        if (insertPager == null) {
            return null;
        }

        final JsonArray actions =
                JsonUtils.optJsonArray(pagerJson, InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);
        final JavascriptRunner.InsertContext insertContext =
                new JavascriptRunner.InsertContext(insertId);
        final List<InsertCommand> commands =
                InsertCommand.getInsertCommandsWithParameters(
                        actions,
                        createInsertMetadataParams(insertId),
                        insertContext);
        insertPager.setCommands(commands);

        final JsonArray properties = JsonUtils.optJsonArray(pagerJson,
                InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);

        boolean showPageIndicator = true;
        boolean disableAnimation = false;

        if (properties != null) {
            for (int i = 0; i < properties.size(); i++) {
                final JsonObject prop = JsonUtils.optJsonObject(properties, i);

                if (prop != null && "id".equals(JsonUtils.optString(prop,"name"))) {
                    insertPager.setContentDescription(JsonUtils.optString(prop,"value"));
                } else if (prop != null && INSERT_PAGER_SWIPEABLE.equals(JsonUtils.optString(prop,"name"))) {

                    // Set whether this pager is swipe enabled.
                    insertPager.setSwipeablePager(JsonUtils.optBoolean(prop,"value", false));

                } else if (prop != null
                        && INSERT_PAGER_SHOW_PAGE_INDICATOR.equals(JsonUtils.optString(prop,"name"))) {

                    // Set whether to show the page indicator.
                    showPageIndicator = JsonUtils.optBoolean(prop, "value", true);

                } else if (prop != null
                        && INSERT_PAGER_DISABLE_ANIMATION.equals(JsonUtils.optString(prop,"name"))) {

                    // Set whether to show the page indicator.
                    disableAnimation = JsonUtils.optBoolean(prop,"value", false);
                } else if (prop != null
                    && INSERT_PAGER_DIRECTION.equals(JsonUtils.optString(prop,"name"))) {

                    // Set direction of the pager, either ltr/rtl.
                    insertPager.setIsRTL(RTL.equalsIgnoreCase(JsonUtils.optString(prop, "value", "ltr")));
                }
            }
        }

        JsonArray jViews = pagerJson.getAsJsonArray("pages");
        if (jViews != null) {
            final FragmentManager fragmentManager = activity.getFragmentManager();

            InsertPagerAdapter pagerAdapter =
                    new InsertPagerAdapter(fragmentManager, jViews, insertId, insertPager.getIsRTL());
            insertPager.setAdapter(pagerAdapter);

            if (insertPager.getIsRTL()) {
                insertPager.setCurrentItem(jViews.size() - 1);
            }

            final CirclePageIndicator indicator = (CirclePageIndicator)
                    inflated.findViewById(R.id.insrt_view_pager_indicator);

            insertPager.setDisableAnimation(disableAnimation);

            if (showPageIndicator) {
                indicator.setViewPager(insertPager);
            } else {
                indicator.setVisibility(View.GONE);
            }
        }

        // Iterate json and get all properties in array.
        JsonArray jArray = pagerJson
                .getAsJsonArray(InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);
        if (jArray != null) {
            for (int i = 0; i < jArray.size(); i++) {
                DynamicProperty p = new DynamicProperty(jArray.get(i).getAsJsonObject());
                if (p.isValid() && DynamicProperty.NAME.ID.equals(p.name)) {
                    insertPager.subscribeActionHandlers(p.getValueString());
                    break;
                }
            }
        }

        InsertContentDescriptionManager.getInstance().setContentDescription(inflated, activity.getString(
                        R.string.insert_pager_accessibility_description), null);
        return inflated;
    }

    @Override
    public Integer getPageNumber() {
        return getCurrentItem();
    }

    @Override
    public ViewBaseScriptBridge getViewScriptBridge() {
        return this;
    }

    @Override
    public String getType() {
        return ViewBaseScriptBridgeUtils.getType(this);
    }
}
