package sdk.pendo.io.actions;

import android.support.annotation.Nullable;
import android.view.View;

import com.google.gson.JsonElement;

import sdk.pendo.io.actions.visual_manipulation.ChangeTextAction;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.network.responses.InsertModel;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.actions.AppTweakInterface.TweakMode;

/**
 * App tweak insert class.
 * <p/>
 * Created by tomerlevinson on 12/14/15.
 */
public class AppTweakInsert extends InsertAction {

    private AppTweakInterface mAppTweakAction;

    public AppTweakInsert(InsertModel insertModel) {
        super(InsertActions.APP_TWEAK.type, insertModel);
        TweakMode tweakMode = insertModel.configuration.getTweakMode();

        if (tweakMode == null) {

            InsertLogger.w("Got tweak mode null.");
            return;
        }

        switch (tweakMode) {
            case CHANGE_IMAGE:
                //Nothing to do here
                break;
            case CHANGE_TEXT:
            case HIGHLIGHTER:
                final JsonElement mainScreen = insertModel.configuration.getMainScreen();
                if (mainScreen != null && mainScreen.isJsonObject()) {
                    final JsonElement screenContents = InsertActionConfiguration
                            .getScreenContents(mainScreen.getAsJsonObject());

                    if (screenContents != null && screenContents.isJsonObject()) {
                        mAppTweakAction = new ChangeTextAction(screenContents.getAsJsonObject()
                                .get(InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES)
                                .getAsJsonArray());
                    } else {
                        InsertLogger.w("Got screen content that is not JSON object: '"
                                + (screenContents == null
                                ?
                                "screen content is null."
                                :
                                screenContents.getAsString()) + "'.");
                    }
                } else {
                    InsertLogger.w("Got main screen that is not JSON object: '"
                            + (mainScreen == null
                            ?
                            "main screen is null."
                            :
                            mainScreen.getAsString()) + "'.");
                }
                break;
            default:
                break;
        }
    }

    public final boolean runInsert(GenericInsertAnalyticsData iga, final View view) {
        InsertAnalytics.newTracker(iga);
        return mAppTweakAction.runInsert(iga, view);
    }

    public final TweakMode getInsertType() {
        return mAppTweakAction.getInsertType();
    }

    @Nullable
    public final String getText() {
        if (mAppTweakAction instanceof ChangeTextAction) {
            return ((ChangeTextAction) mAppTweakAction).getText();
        }

        return null;
    }
}
