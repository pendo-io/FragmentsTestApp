package sdk.pendo.io.utilities;

import android.view.View;
import android.app.Activity;
import org.apache.commons.lang3.tuple.Pair;
import java.util.ArrayList;
import java.util.List;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.events.InsertEvent.EventActions;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.network.responses.ElementModel;
import sdk.pendo.io.network.responses.TriggerModel;

/**
 * Created by nirsegev on 4/5/16.
 */
public final class ElementUtils {
    private ElementUtils() {
    }

    /**
     * Finds tap-on events for a given view.
     * @param activityName - the name of the activity where the view resides.
     * @param viewIntelId - the IdentificationData of the view.
     * @return a list of the tap-on events for the given view,
     * along with the correct triggers for these events.
     */
    public static List<Pair<InsertEvent, List<TriggerModel>>> chooseClickEventsByView(
            String activityName,
            IdentificationData viewIntelId) {
        List<Pair<InsertEvent, List<TriggerModel>>> result = new ArrayList<>();

        List<ElementModel> allElements = EventsManager.getInstance()
                .getAllElements(activityName, viewIntelId);

        Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        View root = ViewHierarchyUtility.INSTANCE.getCurrentRootView(activity);

        if (allElements != null) {
            // flag to verify we don't add more than 1 full screen insert.
            boolean addedFullScreenInsertTrigger = false;
            for (ElementModel element : allElements) {
                InsertEvent clickEvent = EventsManager.getInstance()
                        .getEventByActionAndElement(EventActions.CLICK, element);
                if (clickEvent != null) {
                    if (clickEvent.getConfiguration().isStateSensitive()) {
                        List<TriggerModel> triggerList = new ArrayList<>();
                        if (clickEvent.getTriggers() != null) {
                            for (TriggerModel trigger : clickEvent.getTriggers()) {
                                boolean isFullScreenInsertTrigger =
                                        TriggerUtils.isFullScreenInsertTrigger(trigger);

                                // If full screen insert was not added yet check this trigger
                                // or if it's not that kind of trigger.
                                if (!addedFullScreenInsertTrigger || !isFullScreenInsertTrigger) {
                                    if (trigger.satisfiesFlow()) {
                                        if (TriggerUtils.satisfiesAllConditions(trigger, root)) {
                                            triggerList.add(trigger);

                                            // Change flag to true so we don't add more events with
                                            // full screen insert triggers.
                                            if (isFullScreenInsertTrigger) {
                                                addedFullScreenInsertTrigger = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (!triggerList.isEmpty()) {
                            result.add(Pair.of(clickEvent, triggerList));
                        }
                    }
                }
            }
        }
        return result;
    }
}
