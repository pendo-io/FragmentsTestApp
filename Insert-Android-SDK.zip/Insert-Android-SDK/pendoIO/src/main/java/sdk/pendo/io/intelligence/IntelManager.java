package sdk.pendo.io.intelligence;

import android.support.annotation.Nullable;
import android.support.v4.view.PagerTabStrip;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import android.widget.TextView;

import org.apache.commons.lang3.time.StopWatch;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import sdk.pendo.io.data.structures.WeakValueHashMap;
import sdk.pendo.io.events.ConditionData;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.PredicateUtils;
import sdk.pendo.io.utilities.ResourceUtils;
import sdk.pendo.io.utilities.ViewUtils;

/**
 * Manages the view intelligence.
 * <p/>
 * Created by assaf on 6/11/15.
 */
public final class IntelManager {

    private static volatile IntelManager INSTANCE;

    public static synchronized IntelManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new IntelManager();
        }

        return INSTANCE;
    }


    private IntelManager() {

    }

    public static void init() {
        getInstance();
    }

    private static final WeakValueHashMap<Integer, View> S_FINDER_CACHE = new WeakValueHashMap<>();
    private static final ReentrantReadWriteLock RWL = new ReentrantReadWriteLock();
    private static final ReentrantReadWriteLock.WriteLock WRITE_LOCK = RWL.writeLock();
    private static final ReentrantReadWriteLock.WriteLock READ_LOCK = RWL.writeLock();

    @Nullable
    private static View getViewFromCache(Integer key) {
        READ_LOCK.lock();
        try {
            return S_FINDER_CACHE.get(key);
        } finally {
            READ_LOCK.unlock();
        }
    }

    private static void putViewInCache(Integer key, View view) {
        WRITE_LOCK.lock();
        try {

            // Do not add items that are within a list to the cache.
            ViewParent viewParent = view.getParent();

            while (viewParent != null && viewParent instanceof View) {
                View parent = (View) viewParent;
                if (parent instanceof PagerTabStrip
                        || ViewUtils.isViewAKnownList(parent)) {
                    return;
                } else {
                    viewParent = parent.getParent();
                }
            }

            S_FINDER_CACHE.put(key, view);
        } finally {
            WRITE_LOCK.unlock();
        }
    }

    /**
     * Searches the given {@link View} for views that matches the {@link IdentificationData}.
     * If at least one {@link View} is found, the method will return a {@link View}, if none
     * are found the method will return null.
     * Any extra {@link View}s that are found will be returned inside the
     * {@link List<View>} extraViews parameter.
     *
     * @param container the {@link View} inside which the method will search.
     * @param requiredIdentificationData the sought after {@link View}'s {@link IdentificationData}.
     * @param extraViews {@link List<View>} for extra views (optional).
     * @param insideDisplay whether to look only in the boarders of the display or not.
     *
     * @return If at least one {@link View} is found, the method will return a {@link View}, if none
     * are found the method will return null.
     */
    @Nullable
    public static View findViewInHierarchy(View container, IdentificationData requiredIdentificationData,
                                           @Nullable List<View> extraViews, boolean insideDisplay,
                                            @Nullable ConditionData condition) {

        if (container == null || requiredIdentificationData == null) {
            return null;
        }

        StopWatch watch = new StopWatch();
        if (watch.isStopped()) {
            watch.reset();
        }
        if (!watch.isStarted()) {
            watch.start();
        }
        try {
            // Look for cached views only if we aren't looking for multiple views.
            final int hash = (container.hashCode() * 7) + (requiredIdentificationData.hashCode() * 31);
            if (extraViews == null) {
                View cachedView = getViewFromCache(hash);
                if (cachedView != null && PredicateUtils
                        .compareIdentificationDetailsWithView(
                                requiredIdentificationData,
                                cachedView, condition)) {

                    InsertLogger.d("View cache found!");
                    if (insideDisplay && !ViewUtils.isViewInsideDisplay(cachedView)) {
                        InsertLogger.d("Outside the display.");
                        return null;
                    }
                    return cachedView;
                }
            }

            Set<View> subTress = new HashSet<>();
            final String id = requiredIdentificationData.getId();
            if (id != null) {
                InsertLogger.d("Identification data has ID.");
                int viewId = ResourceUtils.getIdFromString(id);
                if (viewId != View.NO_ID) {
                    rFindViewsByIdInHierarchy(container, new HashSet<View>(), subTress, viewId);

                    HashSet<View> discover = new HashSet<>();
                    for (View view : subTress) {
                        View v = rFindViewInHierarchy(view, requiredIdentificationData,
                                discover, insideDisplay, condition);
                        if (v != null) {
                            if (extraViews == null) {
                                putViewInCache(hash, v);
                                return v;
                            } else {
                                extraViews.add(v);
                            }
                        }
                    }

                    if (extraViews == null || extraViews.isEmpty()) {
                        return null;
                    } else {
                        return extraViews.remove(0);
                    }
                }
            }

            final ArrayList<String> idOfParents = requiredIdentificationData.getIdOfParents();
            if (idOfParents != null && !idOfParents.isEmpty()) {
                InsertLogger.d("Identification data has parents IDs.");
                rFindViewsByIdInHierarchy(container, new HashSet<View>(), idOfParents, subTress);

                HashSet<View> discover = new HashSet<>();
                for (View view : subTress) {
                    View v = rFindViewInHierarchy(view, requiredIdentificationData,
                            discover, insideDisplay, condition);
                    if (v != null) {
                        if (extraViews == null) {
                            putViewInCache(hash, v);
                            return v;
                        } else {
                            extraViews.add(v);
                        }
                    }
                }

                if (extraViews == null || extraViews.isEmpty()) {
                    return null;
                } else {
                    return extraViews.remove(0);
                }
            }

            final View view =
                    rFindViewInHierarchy(container, requiredIdentificationData, new HashSet<View>(), true, condition);
            putViewInCache(hash, view);
            return view;
        } finally {
            if (watch.isStarted() || watch.isSuspended()) {
                watch.stop();
            }
            InsertLogger.i("Finding view took: " + watch.getTime() + " Millis");
        }
    }

    @Nullable
    public static View findViewInHierarchy(View container, IdentificationData identificationData,
                                           boolean insideDisplay, @Nullable ConditionData condition) {
        return findViewInHierarchy(container, identificationData, null, insideDisplay, condition);
    }

    private static void rFindViewsByIdInHierarchy(View view,
                                                  HashSet<View> discoverySet,
                                                  ArrayList<String> idOfParents,
                                                  Set<View> subTress) {
        try {

            discoverySet.add(view);

            if (view instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) view;

                int childCount = vg.getChildCount();

                if (childCount > 0) {

                    for (int i = 0; i < childCount; i++) {

                        View viewChild = vg.getChildAt(i);
                        View searchView = viewChild;

                        if (searchView == null) {
                            continue;
                        }

                        // Look after the last known parent we can find in the current child view.
                        for (String parentId : idOfParents) {
                            int id = ResourceUtils.getIdFromString(parentId);
                            if (id != View.NO_ID) {
                                final View parentView = searchView.findViewById(id);
                                if (parentView != null) {
                                    searchView = parentView;
                                }
                            }
                        }
                        // In case the view child has changed - meaning we've found a legit parent,
                        // update the subtrees Set with the parent's view.
                        if (!searchView.equals(viewChild)) {
                            subTress.add(searchView);
                        }

                        if (!discoverySet.contains(viewChild)) {
                            rFindViewsByIdInHierarchy(viewChild, discoverySet, idOfParents, subTress);
                        }
                    }
                }
            }
        } catch (NullPointerException e) {
            InsertLogger.d(e);
        }
    }

    private static void rFindViewsByIdInHierarchy(View view, HashSet<View> discoverySet,
                                                  Set<View> subTress, int viewId) {

        if (view == null) {
            return;
        }

        if (view.getId() == viewId) {
            subTress.add(view);
        }

        discoverySet.add(view);

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;

            int childCount = vg.getChildCount();

            if (childCount > 0) {

                for (int i = 0; i < childCount; i++) {

                    View viewChild = vg.getChildAt(i);
                    if (!discoverySet.contains(viewChild)) {
                        rFindViewsByIdInHierarchy(viewChild, discoverySet, subTress, viewId);
                    }
                }
            }
        }
    }

    @Nullable
    private static View rFindViewInHierarchy(View view,
                                             IdentificationData viewIdData,
                                             HashSet<View> discoverySet,
                                             boolean searchInsideDisplay,
                                             @Nullable ConditionData condition) {

        // If the view is invisible or outside the display ignore it.
        // TODO: 9/21/15 Do we want to ignore things outside the display?
        if (view == null || view.getVisibility() != View.VISIBLE
                || (searchInsideDisplay && !ViewUtils.isViewInsideDisplay(view))) {
            return null;
        }
        // Old code, not collecting texts and accessibility
        IdentificationData idData = ViewIntel.getViewIntelId(view, false, false);
        if (ViewIntel.compareIdentificationData(viewIdData, idData, false, condition).getLeft()) {
            return view;
        }

        discoverySet.add(view);

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;

            int childCount = vg.getChildCount();

            if (childCount > 0) {

                for (int i = 0; i < childCount; i++) {

                    View viewChild = vg.getChildAt(i);
                    if ((viewChild != null) && (!discoverySet.contains(viewChild))) {
                        View retView = rFindViewInHierarchy(
                                viewChild, viewIdData, discoverySet, searchInsideDisplay, condition);

                        if (retView != null) {
                            return retView;
                        }
                    }
                }
            }
        }

        return null;
    }

    @Nullable
    public static <T> View findViewInHierarchy(View container, Class<T> cls) {
        return rFindViewInHierarchy(container, cls, new HashSet<View>());
    }

    @Nullable
    private static <T> View rFindViewInHierarchy(View view, Class<T> cls,
                                                 HashSet<View> discoverySet) {

        if (cls.isInstance(view)) {
            return view;
        }

        discoverySet.add(view);

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;

            int childCount = vg.getChildCount();

            if (childCount > 0) {

                for (int i = 0; i < childCount; i++) {

                    View viewChild = vg.getChildAt(i);
                    if (!discoverySet.contains(viewChild)) {
                        View retView = rFindViewInHierarchy(viewChild, cls, discoverySet);

                        if (retView != null) {
                            return retView;
                        }
                    }
                }
            }
        }

        return null;
    }

    @Nullable
    public static <T> View findViewInHierarchy(View container, String contentDesc) {
        return rFindViewInHierarchy(container, contentDesc, new HashSet<View>());
    }

    @Nullable
    private static <T> View rFindViewInHierarchy(View view, String contentDesc,
                                                 HashSet<View> discoverySet) {

        if (view == null) {
            return null;
        }

        final CharSequence contentDescription = view.getContentDescription();
        if (contentDescription != null && contentDesc.equals(contentDescription.toString())) {
            return view;
        }

        discoverySet.add(view);

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;

            int childCount = vg.getChildCount();

            if (childCount > 0) {

                for (int i = 0; i < childCount; i++) {

                    View viewChild = vg.getChildAt(i);
                    if (!discoverySet.contains(viewChild)) {
                        View retView = rFindViewInHierarchy(viewChild, contentDesc, discoverySet);

                        if (retView != null) {
                            return retView;
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Checks whether the given view is a candidate for "marketeer screen state".
     *
     * @param view the view to check.
     *
     * @return True if the view is a candicate by @Keren's standards, false otherwise.
     */
    public static boolean isViewScreenStateCandidate(View view) {
        return ViewUtils.isViewInsideDisplay(view)
                && (view instanceof TextView || view instanceof ImageView);
    }
}
