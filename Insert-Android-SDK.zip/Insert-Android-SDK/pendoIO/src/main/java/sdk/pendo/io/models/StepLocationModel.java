package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

public class StepLocationModel {
    @SerializedName("pageSelector")
    private String mPageSelector;

    @SerializedName("featureSelector")
    private String mFeatureSelector;

    @SerializedName("featureLocationId")
    private String mFeatureLocationId;

    @SerializedName("pageLocationId")
    private String mPageLocationId;

    @SerializedName("gravity")
    private String mGravity;

    public String getPageLocationId() {
        return mPageLocationId;
    }

    public String getFeatureLocationId() {
        return mFeatureLocationId;
    }

    public String getPageSelector() {
        return mPageSelector;
    }

    public String getFeatureSelector() {
        return mFeatureSelector;
    }

    public String getGravity() {
        return mGravity;
    }
}
