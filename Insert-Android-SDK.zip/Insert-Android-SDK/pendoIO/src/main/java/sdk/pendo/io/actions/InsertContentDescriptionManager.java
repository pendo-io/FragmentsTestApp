package sdk.pendo.io.actions;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.models.AccessibilityData;
import sdk.pendo.io.utilities.SettingsUtils;

/**
 * Created by tomerlevinson on 9/8/16.
 *
 * The class is in charge of content description in cases of accessibility enabled,
 * and accessibility feature disabled.
 * It also holds methods related to the accessibility feature.
 */
public final class InsertContentDescriptionManager {
    private static volatile InsertContentDescriptionManager sInstance;
    private static final Object LOCK = new Object();
    private Boolean mAccessibilityEnabled = null;

    public static synchronized InsertContentDescriptionManager getInstance() {
        InsertContentDescriptionManager result = sInstance;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = sInstance;
                if (result == null) { // 2nd check (w/ lock)
                    sInstance = result = new InsertContentDescriptionManager();
                }
            }
        }
        return result;
    }

    private InsertContentDescriptionManager() {
    }

    /**
     * Function checks whether the accessiblity feature is enabled.
     * @return whether accessibility feature is enabled.
     */
    public synchronized boolean isAccessibilityEnabled() {
        if (mAccessibilityEnabled == null) {
            Boolean accessibilityEnabled = null;
            if (Pendo.getApplicationContext() != null) {
                accessibilityEnabled = SettingsUtils.getAccessibilityEnabled(
                        Pendo.getApplicationContext());
            }
            if (accessibilityEnabled == null) {
                mAccessibilityEnabled = false;
            } else {
                mAccessibilityEnabled = accessibilityEnabled;
            }
        }

        return mAccessibilityEnabled;
    }

    /**
     * TextViews have to be clickable as well as set concerning the content description, therefore
     * this separate method.
     * @param tView The view in question.
     * @param textToSet The text to set as the views content description.
     * @return
     */
    public void setTextViewImportance(TextView tView, String textToSet) {
        if (isAccessibilityEnabled()) {
            tView.setClickable(true);
            tView.setContentDescription(textToSet);
        }
    }

    /**
     * Sets the content description for the view in question.
     * @param view - The view we're setting the content description for.
     * @param accessibilityContentDescription - Content description for accessibility feature
     * @param defaultContentDescription - Content description when accessibility is disabled.
     * @return
     */
    public void setContentDescription(View view, String accessibilityContentDescription,
                                      String defaultContentDescription) {
        if (isAccessibilityEnabled()) {
            if (accessibilityContentDescription != null) {
                view.setContentDescription(accessibilityContentDescription);
            }
        } else {
            if (defaultContentDescription != null) {
                view.setContentDescription(defaultContentDescription);
            }
        }
    }

    /**
     * Sets the accessibility level for the view and all of its descendants to
     * IMPORTANT_FOR_ACCESSIBILITY_NO.
     * @param v - The view we're working on.
     */
    public void setNotImportantForAccessibilityRecursively(View v) {
        if (isAccessibilityEnabled()) {
            for (int i = ((ViewGroup) v).getChildCount() - 1; i >= 0; i--) {
                final View child = ((ViewGroup) v).getChildAt(i);
                if (child instanceof ViewGroup) {
                    setNotImportantForAccessibilityRecursively(child);
                } else {
                    if (child != null) {
                        if (android.os.Build.VERSION.SDK_INT >= 16) {
                            child.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                        }
                    }
                }
            }
        }
    }

    /**
     * Sets the accessibility level for the view and all of its descendants to
     * IMPORTANT_FOR_ACCESSIBILITY_YES.
     * @param v - The view we're working on.
     */
    public void setImportantRecursively(View v) {
        for (int i = ((ViewGroup) v).getChildCount() - 1; i >= 0; i--) {
            final View child = ((ViewGroup) v).getChildAt(i);
            if (child instanceof ViewGroup) {
                setNotImportantForAccessibilityRecursively(child);
            } else {
                if (child != null) {
                    if (android.os.Build.VERSION.SDK_INT >= 16) {
                        child.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
                    }
                }
            }
        }
    }

    /**
     * Sets the accessibility level for the view
     * IMPORTANT_FOR_ACCESSIBILITY_YES.
     * @param v - The view we're working on.
     */
    public void setImportantForAccessibility(View v) {
        if (isAccessibilityEnabled() && v != null) {
            if (android.os.Build.VERSION.SDK_INT >= 16) {
                v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            }
        }
    }

    /**
     * Gets the accessibility data for the view if available.
     * @param v - The view we're working on.
     * @return accessibility data for the view based on its content description.
     */
    public AccessibilityData getAccessibilityData(View v) {
        CharSequence csContentDescription = v.getContentDescription();
        if (csContentDescription != null && csContentDescription.length() > 0) {
            // Convert to String (non-null)
            String contentDescription = csContentDescription.toString();
            // Return new data object
            return new AccessibilityData(contentDescription);
        }

        return null;
    }
}
