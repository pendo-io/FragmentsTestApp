package sdk.pendo.io.cache;

import android.app.ActivityManager;
import android.content.Context;
import android.os.AsyncTask;
import android.util.LruCache;

import com.squareup.picasso.Callback;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;

import external.sdk.pendo.io.okhttp3.OkHttpClient;
import external.sdk.pendo.io.okhttp3.Request;
import external.sdk.pendo.io.okhttp3.Response;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by itayvallach on 24/06/2016.
 *
 * This class is responsible for caching gif images. Since Picasso's cache must store
 * values as Bitmaps, whereas Gifs are represented as byte[], we must use an independent
 * cache. Hopefully this is a temporary solution.
 */

public class InsertGifCache extends LruCache<String, byte[]> {

    private static volatile InsertGifCache INSTANCE;
    private static volatile OkHttpClient okHttpClient;
    private static final int DEFAULT_BUFFER_SIZE = 1024 * 4;
    private static final int EOF = -1;

    private InsertGifCache(int cacheSize) {
        super(cacheSize);
    }

    public static synchronized InsertGifCache getInstance() {
        if (INSTANCE == null) {
            ActivityManager am = (ActivityManager) Pendo.getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
            int memClassBytes = am.getMemoryClass() * 1024 * 1024;

            //We use only 6.67% of available memory for this cache.
            int cacheSize = memClassBytes / 15;
            INSTANCE = new InsertGifCache(cacheSize);
        }

        return INSTANCE;
    }

    @Override
    protected int sizeOf(String key, byte[] value) {
        return value.length;
    }

    public static void fetchGifIntoCache(final String url, final Callback callback) {
        new AsyncTask<String, Void, byte[]>() {
            @Override
            protected byte[] doInBackground(final String... params) {
                final String gifUrl = params[0];

                if (gifUrl == null)
                    return null;

                try {
                    return getUrlAsBytes(gifUrl);

                } catch (OutOfMemoryError e) {
                    InsertLogger.e("GifDecode OOM: " + gifUrl + "error =  " + e);
                    return null;
                }
            }

            @Override
            protected void onPostExecute(final byte[] bytes) {
                if (bytes == null) {
                    if (callback != null) {
                        callback.onError(null);
                    }
                }
                else {
                    getInstance().put(url, bytes);
                    if (callback != null) {
                        callback.onSuccess();
                    }
                }
            }

        }.execute(url);
    }

    /**
     * Takes a url and returns its body as a byte array (used for gif image urls that we need as byte[]).
     * This method must run on a background thread as it uses network calls.
     * @param urlString the url as a string.
     * @return a byte array representing the url's body.
     */
    public static byte[] getUrlAsBytes(final String urlString) {
        InputStream in = null;
        try {
            final String decodedUrl = URLDecoder.decode(urlString, "UTF-8");
            final URL url = new URL(decodedUrl);
            final Request request = new Request.Builder().url(url).build();
            if (okHttpClient == null) {
                okHttpClient = new OkHttpClient();
            }
            final Response response = okHttpClient.newCall(request).execute();
            in = response.body().byteStream();
            return toByteArray(in);
        } catch (final MalformedURLException e) {
            InsertLogger.d("Malformed URL", e);
        } catch (final OutOfMemoryError e) {
            InsertLogger.d("Out of memory", e);
        } catch (final UnsupportedEncodingException e) {
            InsertLogger.d("Unsupported encoding", e);
        } catch (final IOException e) {
            InsertLogger.d("IO exception", e);
        } catch (Exception ignore) {
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                }
            }
        }
        return null;
    }

    /**
     * reads an InputStream and outputs it as a byte array.
     * @param input the InputStream object.
     * @return The input as a byte array representation.
     * @throws IOException
     */
    public static byte[] toByteArray(final InputStream input) {
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        int n;
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];

        try {
            while (EOF != (n = input.read(buffer))) {
                output.write(buffer, 0, n);
            }
        } catch (final IOException e) {
            InsertLogger.d("IO exception", e);
        }

        return output.toByteArray();
    }
}
