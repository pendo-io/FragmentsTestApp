package sdk.pendo.io.network.socketio.listeners;

import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.logging.InsertLogger;

public final class ResetStateListener extends EmitterListener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got: resetState");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_RESET_STATE, args);
    }
}
