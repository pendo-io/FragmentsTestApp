package sdk.pendo.io.utilities;

import io.reactivex.Scheduler;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.network.interfaces.ApiAction;

/**
 * Rx utilities which can be reused throughout the system.
 * Created by nirsegev on 24/07/2016.
 */
public final class ReactiveUtils {
    private ReactiveUtils() { }

    /**
     * Schedules an api action and set the dedicated worker
     * @param action
     */
    public static void schedule(ApiAction action) {
        final Scheduler.Worker worker = Schedulers.io().createWorker();
        action.setWorker(worker);
        worker.schedule(action);
    }
}
