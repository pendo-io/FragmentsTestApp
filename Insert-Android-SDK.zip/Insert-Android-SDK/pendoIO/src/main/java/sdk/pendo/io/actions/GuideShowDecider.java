package sdk.pendo.io.actions;

import android.Manifest;
import android.util.Pair;
import android.view.View;

import java.lang.ref.WeakReference;
import java.util.List;

import kotlin.Triple;
import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.Quadruple;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.ConnectivityUtils;

/**
 * Responsible for deciding if and which insert should be shown
 * once an event was triggered
 * Created by tomerlevinson on 2/22/16.
 */
final class GuideShowDecider {
    private static volatile GuideShowDecider INSTANCE;

    private GuideShowDecider() {}

    public static synchronized GuideShowDecider getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GuideShowDecider();
        }
        return INSTANCE;
    }

    boolean shouldShowGuide(String guideId, boolean isPreviewGuide, int stepIndex) {
        if (hasInternet()) {
            if (isPreviewGuide || SocketEventFSM.getInstance().isTestMode()) {
                return true;
            }
            GuideModel guideModel = GuideManager.INSTANCE.getGuide(guideId);
            long currentTimeMS = System.currentTimeMillis();
            if (
                    // Check if we are about to show a new guide (we're currently on it's first step)
                    // If we are about to show a new guide and there's throttling enabled, and we're
                    // inside the time period where we can't show, then we return false.
                    StepSeenManager.getInstance().getCurrentStepSeen() != null &&
                    StepSeenManager.getInstance().getCurrentStepIndex() != null &&
                    StepSeenManager.getInstance().getCurrentStepIndex() == 0 &&
                    GuidesConfigurationManager.INSTANCE.getIsThrottlingEnabled() != null &&
                    GuidesConfigurationManager.INSTANCE.getIsThrottlingEnabled() &&
                    GuidesConfigurationManager.INSTANCE.getLastSeenTimeMS() != null &&
                    guideModel != null &&
                    guideModel.getGuideStepModel(stepIndex) != null &&
                    guideModel.getGuideStepModel(stepIndex).getConfiguration() != null &&
                    // Check if we're still not eligible to show a guide throttling time wise
                    ((currentTimeMS + guideModel.getGuideStepModel(stepIndex).getConfiguration().getDelayMs() - GuidesConfigurationManager.INSTANCE.getLastSeenTimeMS()) <=
                            GuidesConfigurationManager.INSTANCE.getThrottlingIntervalMS())) {
                // Nullify current step seen due to not being able to show it.
                StepSeenManager.getInstance().setCurrentStepSeen(null);
                return false;
            }
            // In case we're in the middle of a multistep don't mind throttling.
            if (StepSeenManager.getInstance().getCurrentStepSeen() != null &&
                    StepSeenManager.getInstance().getCurrentStepIndex() != null &&
                    StepSeenManager.getInstance().getCurrentStepIndex() > 0) {
                return true;
            }
            GuideCapping guideCapping;
            if (guideModel != null
                    && guideModel.getGeneralGuideConfiguration() != null
                    && guideModel.getGeneralGuideConfiguration().getCapping() != null) {
                guideCapping = guideModel.getGeneralGuideConfiguration().getCapping();
                if (guideCapping != null) {
                    return hasCappingLeft(guideCapping, guideModel) && !isShowingFullSizeInsert() && !isShowingCurrentGuide(
                            guideId);
                }
            }
        }
        return false;
    }
    private boolean hasCappingLeft(GuideCapping guideCapping, GuideModel guideModel) {
        if (!guideCapping.canConsumeOne()) {
            InsertCommandParameterInjector.getInstance().handleInsertCappedOutAnalytics(guideModel);
            return false;
        }
        return true;
    }
    public Quadruple<GuideModel, Integer, ActivationManager.ActivationEvents, WeakReference<View>> chooseSingleGuideBasedOnCapping(List<Quadruple<String, Integer, ActivationManager.ActivationEvents, WeakReference<View>>> guideIds) {
        if (hasInternet() && !isShowingFullSizeInsert()) {
            if (guideIds.size() > 0) {
                for (Quadruple<String, Integer, ActivationManager.ActivationEvents, WeakReference<View>> guideIdStepIdPairActivationPair : guideIds) {
                    GuideModel guideModel = GuideManager.INSTANCE.getGuide(guideIdStepIdPairActivationPair.getFirst());
                    if (guideModel != null
                            && guideModel.getGeneralGuideConfiguration() != null
                            && guideModel.getGeneralGuideConfiguration().getCapping() != null) {
                        GuideCapping guideCapping = guideModel.getGeneralGuideConfiguration().getCapping();
                        if (guideCapping.canConsumeOne()) {
                            return new Quadruple<>(GuideManager.INSTANCE.getGuide(guideIdStepIdPairActivationPair.getFirst()), guideIdStepIdPairActivationPair.getSecond(), guideIdStepIdPairActivationPair.getThird(),guideIdStepIdPairActivationPair.getFourth());
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Checks whether the required insert is not currently being shown
     *
     * @return true if a required insert is currently being shown false otherwise.
     */
    private boolean isShowingCurrentGuide(String requiredInsertId) {
        return VisualInsertManager.getInstance().isInsertShowing(requiredInsertId);
    }

    /**
     * Checks whether a full screen insert is currently being showed
     *
     * @return true if a full screen insert is currently being shown false otherwise.
     */
    private boolean isShowingFullSizeInsert() {
        return VisualInsertManager.getInstance().isAnyFullScreenInsertShowing();
    }


    private boolean hasInternet() {
//        if (mInsertAction.configuration.hasVideoView()
//                || mInsertAction.configuration.hasImageView()) {
        if (AndroidUtils.isPermissionGranted(Manifest.permission.ACCESS_NETWORK_STATE)
                && !ConnectivityUtils.hasConnectivity()) {
            InsertLogger.d("Not showing insert due to connectivity.");
            return false;
        }
//        }
        return true;
    }
}
