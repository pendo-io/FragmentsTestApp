package sdk.pendo.io.information.collectors

import android.content.Context
import org.json.JSONObject
import sdk.pendo.io.Pendo
import sdk.pendo.io.logging.InsertLogger

/**
 * A collector interface.

 * Created by assaf on 4/8/15.
 */
internal abstract class Collector {

    private var mCalled: Boolean = false
    internal var packageName: String = ""

    internal val application: Context?
        get() {
            val application = Pendo.getApplication().applicationContext
            return application
        }

    private fun init() {

        val instance = Pendo.getInstance()
        if (instance == null) {
            InsertLogger.w("Pendo is null!")

            throw IllegalStateException("Pendo SDK is null.")
        }

        // Skip if already done.
        if (application != null && mCalled) {
            return
        }

        packageName = application!!.applicationInfo.packageName

        mCalled = true
    }

    fun addInformation(json: JSONObject) {
        init()
        collectData(json)
    }

    /**
     * Collects the data and adds it to the JSON.
     * @param json The JSON to add the collected data to.
     */
    protected abstract fun collectData(json: JSONObject)
}
