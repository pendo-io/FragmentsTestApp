package sdk.pendo.io;

/**
 * Created by nirsegev on 5/11/16.
 */
public interface PendoPhasesCallbackInterface {
    /**
     * Interface for listening to the Pendo SDK initialization phases
     */
    void onInitStarted();
    void onInitComplete();
    void onInitFailed();
}
