package sdk.pendo.io.intelligence;

import android.support.annotation.Nullable;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;

/**
 * Utility methods for intelligence.
 * <p/>
 * Created by assaf on 6/11/15.
 */
public final class IntelUtils {
    private IntelUtils() {
    }

    @Nullable
    /** package */ static HashMap<String, Integer> getAllStringsResources() {

        String packageName = Pendo.getApplicationContext().getPackageName();

        try {
            Class<?> appRStringClass = null;
            Class<?> appRClass = Class.forName(packageName + ".R");

            for (Class<?> aClass : appRClass.getDeclaredClasses()) {

                if (aClass.getSimpleName().equals(TYPE_STRING)) {
                    appRStringClass = aClass;
                    break;
                }
            }

            if (appRStringClass == null) {
                InsertLogger.d("Cannot find string class.");
                return null;
            }

            HashMap<String, Integer> stringsToIdMapping = new HashMap<>();
            for (Field field : appRStringClass.getDeclaredFields()) {

                if (Modifier.isStatic(field.getModifiers())
                        && !Modifier.isPrivate(field.getModifiers())
                        && field.getType().equals(int.class)) {

                    try {
                        int id = field.getInt(null);

                        stringsToIdMapping.put(field.getName(), id);
                    } catch (IllegalAccessException e) {
                        InsertLogger.d(e, e.getMessage());
                    }
                }
            }

            return stringsToIdMapping;
        } catch (ClassNotFoundException e) {
            InsertLogger.d(e, e.getMessage());
        }

        return null;
    }
}
