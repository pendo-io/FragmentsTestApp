package sdk.pendo.io.listeners.views;

import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import sdk.pendo.io.events.PassiveTriggersListener;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.sdk.manager.ScreenManager;

/**
 * Implements {@link android.support.v4.widget.DrawerLayout.DrawerListener} that holds reference
 * to multiple {@link android.support.v4.widget.DrawerLayout.DrawerListener}.
 *
 * Created by assaf on 11/25/15.
 */
public final class InsertDrawerListener implements DrawerLayout.DrawerListener {

    private ArrayList<DrawerLayout.DrawerListener> mDrawerListeners = new ArrayList<>();
    private static AtomicBoolean sIsDrawerOpened = new AtomicBoolean(false);
    private static final double DRAWER_CLOSE_SLIDE_OFFSET = 0.15;

    private WeakReference<View> mDrawerLayout;

    public InsertDrawerListener(View drawerLayout) {
        mDrawerLayout = new WeakReference<>(drawerLayout);
        sIsDrawerOpened.set(isDrawerOpen((DrawerLayout) drawerLayout));
        ScreenManager.INSTANCE.updateDrawerState(getIsShowingDrawerValue());
    }

    public boolean addListener(DrawerLayout.DrawerListener drawerListener) {
        return mDrawerListeners.add(drawerListener);
    }

    public static synchronized boolean getIsShowingDrawerValue() {
        return sIsDrawerOpened.get();
    }

    public void clearListeners() {
        mDrawerListeners.clear();
    }

    @Override
    public void onDrawerSlide(View drawerView, float slideOffset) {
        if (slideOffset < DRAWER_CLOSE_SLIDE_OFFSET) {
            sIsDrawerOpened.set(false);
        }
        for (DrawerLayout.DrawerListener l : mDrawerListeners) {
            l.onDrawerSlide(drawerView, slideOffset);
        }
    }

    @Override
    public void onDrawerOpened(View drawerView) {

        sIsDrawerOpened.set(true);
        PassiveTriggersListener.INSTANCE.activityStateChange();

        for (DrawerLayout.DrawerListener l : mDrawerListeners) {
            l.onDrawerOpened(drawerView);
        }
    }

    @Override
    public void onDrawerClosed(View drawerView) {

        sIsDrawerOpened.set(false);
        PassiveTriggersListener.INSTANCE.activityStateChange();

        for (DrawerLayout.DrawerListener l : mDrawerListeners) {
            l.onDrawerClosed(drawerView);
        }
    }

    @Override
    public void onDrawerStateChanged(int newState) {

        if (newState == DrawerLayout.STATE_IDLE) {
            View drawer = mDrawerLayout.get();
            if (drawer != null) {
                boolean drawerOpen = isDrawerOpen((DrawerLayout) drawer);
                sIsDrawerOpened.set(drawerOpen);
                PassiveTriggersListener.INSTANCE.activityStateChange();
            }
        }

        for (DrawerLayout.DrawerListener l : mDrawerListeners) {
            l.onDrawerStateChanged(newState);
        }
    }

    private static boolean isDrawerOpen(DrawerLayout drawer) {
        return drawer.isDrawerOpen(Gravity.START);
    }

    @Nullable
    public static Object extractDrawerListener(DrawerLayout drawerLayout) {
        try {
            Field refl_mListener = DrawerLayout.class.getDeclaredField("mListener");
            refl_mListener.setAccessible(true);
            Object ret = refl_mListener.get(drawerLayout);

            if (ret == null) {
                Field refl_mListeners = DrawerLayout.class.getDeclaredField("mListeners");
                refl_mListeners.setAccessible(true);
                ret = refl_mListeners.get(drawerLayout);
            }

            return ret;

        } catch (IllegalAccessException e) {
            InsertLogger.e(e, e.getMessage());
        } catch (NoSuchFieldException e) {
            InsertLogger.e(e, "SDK version: " + Build.VERSION.SDK_INT);
        }

        return null;
    }
}
