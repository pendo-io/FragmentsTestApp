package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.annotations.SerializedName;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import sdk.pendo.io.actions.configurations.CachingPolicy;
import sdk.pendo.io.actions.configurations.InsertTypeValue;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.TooltipUtils;

import static sdk.pendo.io.actions.AppTweakInterface.TweakMode;
import static sdk.pendo.io.actions.InsertAction.INSERT_INSERT_DELAY;

/**
 * Pendo's action configuration class.
 * <p>
 * Created by assaf on 5/6/15.
 */
public class InsertActionConfiguration {

    public static final String NAME = "name";
    public static final String TYPE = "type";

    public static final String MODE = "mode";
    public static final String TIMEOUT = "timeout";
    public static final String SCREENS = "screens";
    public static final String GUIDE_CACHING_POLICY = "cachingPolicy";
    public static final String MULTIPLE_SHOWS = "multiple";
    public static final String PRIORITY = "priority";
    public static final String GUIDE_SCREEN_CONTENT = "content";
    public static final String GUIDE_SCREEN_CONTENT_GUIDE = "guide";
    public static final String GUIDE_SCREEN_WIDGET = "widget";
    public static final String GUIDE_BUILDING_BLOCK_WIDGET = "widget";
    public static final String GUIDE_BUILDING_BLOCK_ID = "id";
    public static final String GUIDE_BUILDING_BLOCK_ACTIONS = "actions";
    public static final String GUIDE_BUILDING_BLOCK_PROPERTIES = "properties";
    public static final String GUIDE_BUILDING_BLOCK_VIEWS = "views";
    public static final String GUIDE_WIDGET_BASE_BUILDING_BLOCK_NAME = "Base";
    public static final String GUIDE_SCREEN_WIDGET_PROPERTIES = "properties";
    public static final String GUIDE_TRANSITION = "transition";

    public static final int FIRST_CHILD_INDEX = 0;

    private static final String TOOLTIP_WIDGET_NAME = "Tooltip";
    public enum InsertMode {
        BLOCKING("blocking"),
        NON_BLOCKING("nonblocking");

        private final String mType;

        private static final Map<String, InsertMode> LOOKUP_TABLE = new HashMap<>();

        static {
            for (InsertMode s : EnumSet.allOf(InsertMode.class)) {
                LOOKUP_TABLE.put(s.mType, s);
            }
        }

        InsertMode(String type) {
            this.mType = type;
        }

        public boolean equals(InsertMode insertMode) {
            return this.mType.equals(insertMode.mType);
        }

        @Nullable
        public static InsertMode get(String type) {
            return LOOKUP_TABLE.get(type);
        }
    }

    @SerializedName(NAME)
    String name;

    @SerializedName(TYPE)
    String type;

    @SerializedName(MODE)
    private String mode;

    @SuppressWarnings("unused")
    @SerializedName(SCREENS)
    private JsonElement mScreens;

    @SerializedName(TIMEOUT)
    InsertTypeValue timeout;

    @SerializedName(MULTIPLE_SHOWS)
    private boolean mMultipleShows;

    @SerializedName(GUIDE_TRANSITION)
    private JsonElement mTransitions;

    @SerializedName(PRIORITY)
    private int mPriority;

    @SerializedName(GUIDE_CACHING_POLICY)
    private CachingPolicy mCachingPolicy;

    @SerializedName(INSERT_INSERT_DELAY)
    private InsertTypeValue insertDelay;

    public final InsertMode getMode() {
        return InsertMode.get(mode);
    }

    public final boolean isMultipleShows() {
        return mMultipleShows;
    }

    public final int getPriority() {
        return mPriority;
    }

    public final JsonElement getScreens() {
        return mScreens;
    }

    public final InsertTypeValue getTimeout() {
        return timeout;
    }

    public final CachingPolicy getCachingPolicy() {
        return mCachingPolicy;
    }

    @Nullable
    public InsertTypeValue getInsertDelay() {
        return insertDelay;
    }

    @Nullable
    public final JsonElement getMainScreen() {
        if (mScreens != null) {
            if (mScreens.isJsonArray()) {
                final JsonArray jsonArray = mScreens.getAsJsonArray();
                if (jsonArray != null && jsonArray.size() > 0) {
                    return jsonArray.get(0);
                } else {
                    InsertLogger.d("No screens given!");
                }
            } else if (mScreens.isJsonObject()) {
                return mScreens;
            }
        }

        return null;
    }

    public final boolean matchMainWidgetName(String widgetName) {
        final JsonElement mainScreen = getMainScreen();

        if (mainScreen != null) {
            if (mainScreen.isJsonObject()) {
                final String screenWidgetName = getScreenWidgetName(mainScreen.getAsJsonObject());

                return screenWidgetName != null && screenWidgetName.equals(widgetName);
            }
        }

        return false;
    }

    @Nullable
    public static JsonElement getScreenContents(@NonNull JsonObject screen) {
        try {
            if (screen.has(GUIDE_SCREEN_CONTENT)) {
                JsonObject guideScreenContent = (JsonObject) screen.get(GUIDE_SCREEN_CONTENT);
                JsonObject screenContent = new JsonObject();
                if (guideScreenContent.has(GUIDE_SCREEN_CONTENT_GUIDE)) {
                    screenContent = new JsonParser().parse(guideScreenContent.get(GUIDE_SCREEN_CONTENT_GUIDE).toString()).getAsJsonObject();
                }
                if (!hasBaseBuildingBlock(screenContent)) {
                    return null;
                } else {
                    JsonArray contentJson = new JsonArray();
                    if (screenContent.has(GUIDE_BUILDING_BLOCK_VIEWS)) {
                        contentJson = screenContent.get(GUIDE_BUILDING_BLOCK_VIEWS).getAsJsonArray();
                    }
                    if (contentJson != null && contentJson.size() > 0) {
                        return contentJson.get(0);
                    } else {
                        return null;
                    }
                }
            }

            if (screen.has(GUIDE_SCREEN_WIDGET)) {
                return screen;
            }
        } catch (Exception e ) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    @Nullable
    static JsonArray getTooltipProperties(final JsonObject guideStep) {
        try {
            return getScreenContents(guideStep).getAsJsonObject()
                    .getAsJsonArray(GUIDE_BUILDING_BLOCK_VIEWS)
                    .get(FIRST_CHILD_INDEX).getAsJsonObject()
                    .getAsJsonArray(GUIDE_BUILDING_BLOCK_PROPERTIES);

        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    @Nullable
    static JsonObject getTooltipContent(final JsonObject guideStep) {
        try {
            JsonElement screenContent = getScreenContents(guideStep);
            if (screenContent != null) {
                JsonObject tooltipJsonObject = screenContent.getAsJsonObject()
                        .getAsJsonArray(GUIDE_BUILDING_BLOCK_VIEWS)
                        .get(FIRST_CHILD_INDEX).getAsJsonObject();

                return TooltipUtils.wrapWithLinearLayout(tooltipJsonObject);
            } else {
                InsertLogger.i("No screen content found in object", guideStep);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    @Nullable
    static JsonObject getTooltipWidgetWrapperObject(final JsonObject guideStep) {
        try {
            JsonElement screenContent = getScreenContents(guideStep);
            if (screenContent != null) {
                return screenContent.getAsJsonObject();
            } else {
                InsertLogger.i("No screen content found in object", guideStep);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    @Nullable
    static JsonObject getTooltipWidgetJsonObject(final JsonObject guideStep) {
        try {
            JsonElement screenContent = getScreenContents(guideStep);
            if (screenContent != null) {
                return screenContent.getAsJsonObject()
                        .getAsJsonArray(GUIDE_BUILDING_BLOCK_VIEWS)
                        .get(FIRST_CHILD_INDEX).getAsJsonObject();

            } else {
                InsertLogger.i("No screen content found in object", guideStep);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }

    /**
     * Check if the JsonObject in question has a base building block wrapper.
     *
     * @param guideJson - the Json we want to check.
     * @return true if the json has a wrapper of base building block, false otherwise.
     */
    private static boolean hasBaseBuildingBlock(@NonNull JsonObject guideJson) {
        if (guideJson.has(GUIDE_BUILDING_BLOCK_ACTIONS)
                && guideJson.has(GUIDE_BUILDING_BLOCK_ID)
                && guideJson.has(GUIDE_BUILDING_BLOCK_PROPERTIES)
                && guideJson.has(GUIDE_BUILDING_BLOCK_VIEWS)
                && guideJson.has(GUIDE_BUILDING_BLOCK_WIDGET)) {
            String widgetName = guideJson.get(GUIDE_BUILDING_BLOCK_WIDGET).getAsString();
            String widgetId = guideJson.get(GUIDE_BUILDING_BLOCK_ID).getAsString();
            if (widgetName.equals(GUIDE_WIDGET_BASE_BUILDING_BLOCK_NAME)
//                    && widgetId.equals(GUIDE_WIDGET_BASE_BUILDING_BLOCK_ID)
            ) {
                return true;
            }
        }
        return false;
    }

    @Nullable
    public static String getScreenWidgetName(@NonNull JsonObject screen) {
        if (screen.has(GUIDE_SCREEN_CONTENT)) {
            screen = screen.get(GUIDE_SCREEN_CONTENT).getAsJsonObject();
        }

        final JsonElement widget = screen.get(GUIDE_SCREEN_WIDGET);
        if (widget != null && widget.isJsonPrimitive()) {

            return widget.getAsString();
        }

        return null;
    }

    @Nullable
    public final TweakMode getTweakMode() {
        return TweakMode.get(name);
    }

    public enum VisualInsertType {
        TOOLTIP(TOOLTIP_WIDGET_NAME),
        FULLSCREEN("Fullscreen");

        public final String name;

        VisualInsertType(String name) {
            this.name = name;
        }
    }

    /**
     * Under the assumption we only have two types of guides at the moment, tooltip and fullscreen
     * For a given step we return it is a tooltip if it has such widget type, and fullscreen
     * otherwise.
     * @param guideStep
     * @return matching InsertType
     */
    public static VisualInsertType getStepVisualInsertType(JsonObject guideStep) {
        try {
            JsonElement screenContent = getScreenContents(guideStep);
            if (screenContent != null) {
                String widgetType = screenContent.getAsJsonObject()
                        .getAsJsonArray(GUIDE_BUILDING_BLOCK_VIEWS)
                        .get(FIRST_CHILD_INDEX).getAsJsonObject()
                        .getAsJsonObject().get(GUIDE_BUILDING_BLOCK_WIDGET).getAsString();
                if (VisualInsertType.TOOLTIP.name.contentEquals(widgetType)) {
                    return VisualInsertType.TOOLTIP;
                }
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return VisualInsertType.FULLSCREEN;

    }
}
