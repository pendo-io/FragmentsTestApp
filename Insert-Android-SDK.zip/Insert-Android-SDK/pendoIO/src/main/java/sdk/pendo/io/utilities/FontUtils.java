package sdk.pendo.io.utilities;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.res.ResourcesCompat;
import android.view.View;
import android.widget.TextView;

import external.sdk.pendo.io.dynamicview.DynamicProperty;

import com.joanzapata.iconify.Icon;
import com.joanzapata.iconify.IconDrawable;

import org.json.JSONArray;
import org.json.JSONException;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.fonts.InsertIoIcons;
import sdk.pendo.io.fonts.InsertIoModule;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Pendo's font utility class.
 * <p>
 * Created by tomerlevinson on 3/29/16.
 */
public final class FontUtils {
    private FontUtils() {
    }

    public static final int DEFAULT_FONT_ICON_SIZE = 32;

    public static char getChar(@NonNull final String character) {
        return character.charAt(0);
    }

    @Nullable
    public static Icon getIcon(final char key, final String iconFontFamily) {
        return getIcon(key, iconFontFamily, null);
    }

    @Nullable
    public static Icon getIcon(final char key, final String iconFontFamily, Icon defaultIcon) {
        if (InsertIoModule.ICON_FONT_FAMILY_NAME.equalsIgnoreCase(iconFontFamily)) {
            final InsertIoIcons icon = InsertIoIcons.findIcon(key);

            if (icon != null) {
                return icon;
            }
        }

        return defaultIcon;
    }

    public static IconDrawable createIconDrawable(@NonNull Context context, int iconSize,
                                                  int iconColor, @NonNull Icon icon) {
        return new IconDrawable(context, icon)
                .color(iconColor)
                .sizePx(iconSize);
    }

    /**
     * Utility method for getting the {@link Typeface}.
     *
     * @param fontFamily the font family.
     * @param textStyle  the text style.
     * @return the {@code Typeface}.
     * @throws JSONException
     */
    public static Typeface getTypeface(String fontFamily, int textStyle) {
        String font = FontUtils.chooseFontFromArray(fontFamily, textStyle);
        if (font != null) {
            return Typeface.create(font, textStyle);
        } else {
            return FontListParser.loadExternalFontByName(fontFamily);
        }
    }

    public static int getTextStyle(DynamicProperty textStyleDynProp) {

        int textStyle;
        if (textStyleDynProp != null) {
            switch (textStyleDynProp.type) {
                case INTEGER: {
                    textStyle = textStyleDynProp.getValueInt();
                }
                break;
                case STRING: {
                    String textStyleString = textStyleDynProp.getValueString();
                    if ("bold".equals(textStyleString)) {
                        textStyle = Typeface.BOLD;
                    } else if ("italic".equals(textStyleString)) {
                        textStyle = Typeface.ITALIC;
                    } else if ("bold_italic".equals(textStyleString)) {
                        textStyle = Typeface.BOLD_ITALIC;
                    } else {
                        textStyle = Typeface.NORMAL;
                    }
                }
                break;
                default: {
                    //Our fallback for underline.
                    textStyle = Typeface.NORMAL;
                }
                break;
            }
        } else {
            textStyle = Typeface.NORMAL;
        }

        return textStyle;
    }

    @Nullable
    public static String chooseFontFromArray(String fontFamilyArray, int textStyle) {
        JSONArray fontListArray = null;
        try {
            fontListArray = new JSONArray(fontFamilyArray);
        } catch (JSONException e) {
            fontListArray = null;
        }
        if (fontFamilyArray != null) {
            return fontFamilyArray;
        }
        if (fontListArray == null) {
            return null;
        }
        for (int i = 0; i < fontListArray.length(); i++) {
            String font = null;
            try {
                font = fontListArray.get(i).toString();
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            if (font == null) {
                return null;
            }
            final Typeface typeface = Typeface.create(font, textStyle);
            if (typeface != null) {
                return font;
            }
        }

        return null;
    }

    /*
     * Receives a fonts string array inside a string.
     * Returns the first valid font inside that array or returns null.
     * In a case of null the system will choose its default font.
     * (as Typeface.create can receive a null)
     *
     * @param: receivedFontFamilyArray
     *         e.g input : "['sans-serif', 'monospace', 'Pacifico']"
     *
     * @return: String , the chosen font.
     *         e.g "Pacifico"
     */
    public static String chooseAndSetFontFromArray(String receivedFontFamilyArray,
                                                   DynamicProperty textStyleProperty,
                                                   TextView view) {
        int textStyle = getTextStyle(textStyleProperty);
        final String font = chooseFontFromArray(receivedFontFamilyArray, textStyle);
        int fontIdentifier = Pendo.getApplicationContext().getResources().getIdentifier(font,"font", Pendo.getApplicationContext().getPackageName());
        try {
            Typeface fontInResources = ResourcesCompat.getFont(Pendo.getApplicationContext(), fontIdentifier);
            if (fontInResources != null) {
                view.setTypeface(fontInResources);
                return font;
            }
        } catch (Resources.NotFoundException e) {
            InsertLogger.d("Font not in resources");
        }
        if (font != null) {
            view.setTypeface(Typeface.create(font, textStyle));
            return font;
        }
        return null;
    }

    /*
     * Receives either a valid font family or a null.
     * Checks whether the received font family is external,
     * if it is, we load it and return successfully.
     *
     * @param receivedFontFamily - font family String.
     * @param textView - the view we will apply the typeface in case it's external.
     *
     * @return boolean - true in case we loaded the external font, false otherwise.
     */
    public static Boolean checkIfExternalAndLoad(String receivedFontFamily, TextView textView) {
        Typeface externalFontTypeface = null;
        if (receivedFontFamily != null) {
            externalFontTypeface = FontListParser.loadExternalFontByName(
                    receivedFontFamily);
        }
        if (externalFontTypeface != null) {
            textView.setTypeface(externalFontTypeface);
            return true;
        }
        return false;
    }

    public static void setTypefaceWithStyle(String fontFamily, final int textStyle, View view) {
        ((TextView) view).setTypeface(
                Typeface.create(fontFamily,
                        textStyle));
    }
}
