package sdk.pendo.io.reactive.observers;

import android.support.annotation.NonNull;

import java.security.cert.CertPathValidatorException;
import java.util.NoSuchElementException;

import io.reactivex.Maybe;
import io.reactivex.Scheduler;
import io.reactivex.MaybeObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.utilities.AnalyticsUtils;

/**
 * Implements default MaybeObserver behaviour and can get any action from clients. this is done to make
 * sure we have a onError implementation so the errors will be contained in RX error handling rather
 * than through unhandled exception Created by itayvallach on 8/1/18.
 */
public final class InsertMaybeObserver<T> implements MaybeObserver<T> {

    private Consumer<? super T> mOnSuccess;
    private Consumer<Throwable> mOnError;
    private Action mOnComplete;
    private Consumer<? super Disposable> mOnSubscribe;
    private Disposable mDisposable;

    private InsertMaybeObserver(final Consumer<? super T> onSuccess,
                                final Consumer<Throwable> onError,
                                final Action onComplete,
                                final Consumer<? super Disposable> onSubscribe) {

        mOnSuccess = onSuccess;
        mOnError = onError;
        mOnComplete = onComplete;
        mOnSubscribe = onSubscribe;
    }

    @Override
    public void onComplete() {
        if (mOnComplete != null) {
            try {
                mOnComplete.run();
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    }



    @Override
    public void onError(Throwable e) {
        if (shouldReportException(e)) {
            AnalyticsUtils.sendExceptionReport(e);
        }
        if (mOnError != null) {
            try {
                mOnError.accept(e);
            } catch (Exception e1) {
                InsertLogger.e(e1, e1.getMessage());
            }
        }
    }

    private boolean shouldReportException(Throwable e) {
        return !(e instanceof NoSuchElementException)
                && !(e instanceof CertPathValidatorException);
    }

    @Override
    public void onSubscribe(Disposable d) {
        mDisposable = d;
        if (mOnSubscribe != null) {
            try {
                mOnSubscribe.accept(d);
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    }

    public Disposable getDisposable() {
        return mDisposable;
    }

    @Override
    public void onSuccess(T t) {
        try {
            mOnSuccess.accept(t);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }


    public static final class Builder<T> {
        private Consumer<Throwable> mOnError = null;
        private Action mOnComplete = null;
        private Consumer<? super T> mOnSuccess = null;
        private Consumer<? super Disposable> mOnSubscribe;

        Builder<T> addOnSuccessConsumer(final Consumer<? super T> onSuccess) {
            mOnSuccess = onSuccess;
            return this;
        }

        Builder<T> addOnErrorConsumer(final Consumer<Throwable> onError) {
            mOnError = onError;
            return this;
        }

        Builder<T> addOnCompleteAction(final Action onComplete) {
            mOnComplete = onComplete;
            return this;
        }

        Builder<T> addOnSubscribe(final Consumer<? super Disposable> onSubscribe) {
            mOnSubscribe = onSubscribe;
            return this;
        }

        InsertMaybeObserver<T> build() {
            return new InsertMaybeObserver<>(mOnSuccess, mOnError, mOnComplete, mOnSubscribe);
        }
    }

    /**
     * Creates an {@link InsertMaybeObserver} with a callback to handle
     * the item the {@link Maybe} emits.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onSuccess
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     *
     * @return a {@link InsertMaybeObserver} with a callback for {@link MaybeObserver#onSuccess(T)}.
     *
     * @throws IllegalArgumentException if {@code onSuccess} is null
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     */
    @SuppressWarnings("SSBasedInspection")
    @NonNull
    public static <T> InsertMaybeObserver<T> create(@NonNull final Consumer<T> onSuccess) {
        //noinspection ConstantConditions
        if (onSuccess == null) {
            throw new IllegalArgumentException("onSuccess can not be null");
        }

        return new InsertMaybeObserver.Builder<T>()
                .addOnSuccessConsumer(onSuccess)
                .addOnErrorConsumer(new InsertOnErrorHandler())
                .build();
    }

    /**
     * Creates an {@link InsertMaybeObserver} with callbacks to handle
     * the item the {@link Maybe} emits and any error notification it issues.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onSuccess
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     * @param onError
     *             the {@code Consumer<Throwable>} you have designed
     *             to accept any error notification from the Observable.
     *
     * @return a {@link InsertMaybeObserver} with a callbacks for {@link MaybeObserver#onSuccess(T)}
     * and {@link MaybeObserver#onError(Throwable)}.
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     *
     * @throws IllegalArgumentException
     *             if {@code onNext} is null, or
     *             if {@code onError} is null
     */
    @NonNull
    public static <T> InsertMaybeObserver<T> create(@NonNull final Consumer<T> onSuccess,
                                                    @NonNull final Consumer<Throwable> onError) {
        //noinspection ConstantConditions
        if (onSuccess == null) {
            throw new IllegalArgumentException("onSuccess can not be null");
        }
        //noinspection ConstantConditions
        if (onError == null) {
            throw new IllegalArgumentException("onError can not be null");
        }

        return new InsertMaybeObserver.Builder<T>()
                .addOnSuccessConsumer(onSuccess)
                .addOnErrorConsumer(onError)
                .build();
    }

    /**
     * Creates an {@link InsertMaybeObserver} with callbacks to handle
     * the item the {@link Maybe} emits and any error notification or
     * completion notification it issues.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onSuccess
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     * @param onError
     *             the {@code Consumer<Throwable>} you have designed
     *             to accept any error notification from the Observable.
     * @param onComplete
     *             the {@code Action} you have designed
     *             to accept a completion notification from the Observable.
     *
     * @return a {@link InsertMaybeObserver} with a callbacks for {@link MaybeObserver#onSuccess(T)},
     * {@link MaybeObserver#onError(Throwable)} and {@link MaybeObserver#onComplete()}.
     *
     * @throws IllegalArgumentException
     *             if {@code onNext} is null, or
     *             if {@code onError} is null, or
     *             if {@code onComplete} is null
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     */
    @NonNull
    public static <T> InsertMaybeObserver<T> create(@NonNull final Consumer<T> onSuccess,
                                                    @NonNull final Consumer<Throwable> onError,
                                                    @NonNull final Action onComplete) {

        //noinspection ConstantConditions
        if (onSuccess == null) {
            throw new IllegalArgumentException("onSuccess can not be null");
        }
        //noinspection ConstantConditions
        if (onError == null) {
            throw new IllegalArgumentException("onError can not be null");
        }
        //noinspection ConstantConditions
        if (onComplete == null) {
            throw new IllegalArgumentException("onComplete can not be null");
        }

        return new InsertMaybeObserver.Builder<T>()
                .addOnSuccessConsumer(onSuccess)
                .addOnErrorConsumer(onError)
                .addOnCompleteAction(onComplete)
                .build();
    }

    /**
     * Creates an {@link InsertMaybeObserver} with callbacks to handle
     * the item the {@link Maybe} emits and any error notification or
     * completion notification it issues.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onSuccess
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     * @param onError
     *             the {@code Consumer<Throwable>} you have designed
     *             to accept any error notification from the Observable.
     * @param onComplete
     *             the {@code Action} you have designed
     *             to accept a completion notification from the Observable.
     * @param onSubscribe
     *             the {@code Consumer<Subsctiption>} you have designed
     *             to accept any Subscription to the Observable.
     *
     * @return a {@link InsertMaybeObserver} with a callbacks for {@link MaybeObserver#onSuccess(T)},
     * {@link MaybeObserver#onError(Throwable)} and {@link MaybeObserver#onComplete()}.
     *
     * @throws IllegalArgumentException
     *             if {@code onNext} is null, or
     *             if {@code onError} is null, or
     *             if {@code onComplete} is null
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     */
    @NonNull
    public static <T> InsertMaybeObserver<T> create(@NonNull final Consumer<T> onSuccess,
                                                    @NonNull final Consumer<Throwable> onError,
                                                    @NonNull final Action onComplete,
                                                    @NonNull Consumer<? super Disposable> onSubscribe) {

        //noinspection ConstantConditions
        if (onSuccess == null) {
            throw new IllegalArgumentException("onSuccess can not be null");
        }
        //noinspection ConstantConditions
        if (onError == null) {
            throw new IllegalArgumentException("onError can not be null");
        }
        //noinspection ConstantConditions
        if (onComplete == null) {
            throw new IllegalArgumentException("onComplete can not be null");
        }
        //noinspection ConstantConditions
        if (onSubscribe == null) {
            throw new IllegalArgumentException("onSubscribe can not be null");
        }

        return new InsertMaybeObserver.Builder<T>()
                .addOnSuccessConsumer(onSuccess)
                .addOnErrorConsumer(onError)
                .addOnCompleteAction(onComplete)
                .addOnSubscribe(onSubscribe)
                .build();
    }
}
