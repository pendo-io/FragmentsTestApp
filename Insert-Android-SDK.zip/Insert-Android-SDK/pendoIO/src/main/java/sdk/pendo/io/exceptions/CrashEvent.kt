package sdk.pendo.io.exceptions

import android.app.Application
import android.content.Context
import sdk.pendo.io.utilities.AnalyticsUtils
import java.lang.ref.WeakReference

/**
 * Pendo's crash event handling
 *
 * Created by Oren Dayan 23/1/20
 */
class CrashEvent {

    private val mDefaultUncaughtExceptionHandler: Thread.UncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler()
    private val mCaughtExceptionHandler: Thread.UncaughtExceptionHandler

    init {
        mCaughtExceptionHandler = Thread.UncaughtExceptionHandler { thread, ex ->
            AnalyticsUtils.sendExceptionReport(ex)
            mDefaultUncaughtExceptionHandler.uncaughtException(thread, ex)
        }
        Thread.setDefaultUncaughtExceptionHandler(mCaughtExceptionHandler) }
}
