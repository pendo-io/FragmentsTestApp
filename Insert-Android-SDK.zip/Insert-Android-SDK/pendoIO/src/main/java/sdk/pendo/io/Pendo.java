package sdk.pendo.io;

import android.Manifest;
import android.app.Activity;
import android.app.Application;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresPermission;
import android.support.v4.os.UserManagerCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.joanzapata.iconify.Iconify;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.analytics.AnalyticEventsManager;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.exceptions.CrashEvent;
import sdk.pendo.io.exceptions.PendoInitializedStateException;
import sdk.pendo.io.fonts.InsertIoModule;
import sdk.pendo.io.information.collectors.ApplicationInfoCollector;
import sdk.pendo.io.information.collectors.DeviceInfoCollector;
import sdk.pendo.io.intelligence.IntelManager;
import sdk.pendo.io.listeners.ActivityLifeCycleListener;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertDebugTree;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.logging.InsertReleaseTree;
import sdk.pendo.io.logging.profiling.ProfilingManager;
import sdk.pendo.io.models.AppKeyData;
import sdk.pendo.io.models.InitModel;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.CertificatePinningTrustManager;
import sdk.pendo.io.network.SetupAction;
import sdk.pendo.io.network.SetupManager;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.network.killswitch.KillSwitchManager;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.sdk.manager.AnalyticsManager;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.InsertProfiler;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.utilities.PersistenceUtils;
import sdk.pendo.io.utilities.ReactiveUtils;
import sdk.pendo.io.utilities.SettingsUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.logging.profiling.ProfilingManager.ProfilerType.PERFORMANCE;
import static sdk.pendo.io.network.socketio.state.machines.SocketEventFSM.States.STATE_NOT_PAIRED;

/**
 * Pendo's SDK.
 * <p/>
 * Created by assaf on 4/5/15.
 */
@SuppressWarnings("unused")
public final class Pendo {

    public static final String TAG = "Pendo";
    private static volatile Pendo INSTANCE;
    private static final String EMPTY_VISITOR = "";
    private static final String EMPTY_ACCOUNT = "";
    private static final String APP_KEY_NOT_VALID = "Your app key is not valid.";
    private static String sInitReceivedAppKey = null;
    private static PendoInitParams sInitReceivedPendoInitParams = null;
    private static PhoneUnlockedReceiver sPhoneUnblockedReceiver = null;
    private static Application sInitReceivedApplication = null;
    private static CrashEvent sCrashEvent = null;

    /**
     * Pendo IO Ltd. options class.
     * <p>
     * Controls strict mode and classes white-list for JavaScripts.
     * </p>
     */
    public static final class PendoOptions {

        // Where the SDK runs in strict mode or not.
        private final boolean mStrictMode;

        // The white-listed classes for strict mode.
        private final Set<Class> mWhitelistClasses = new HashSet<>();

        private final List<Pair<String, String>> mPins = new ArrayList<>();

        private boolean mIgnoreFirstOnCreate = false;

        private boolean mFragmentIdentificationEnabled = false;

        // True if sdk was inited from an activity and not from Application class.
        private boolean mIsInitedFromActivity = false;

        private String mEnvironment = null;

        //Disable analytics for react framework
        private boolean mDisableAppAnalytics = false;


        /**
         * Pendo's options constructor.
         *
         * @param strictMode       Whether the SDK runs in strict mode or not.<p>
         *                         True means that only a small subset of classes are accessible from JS.
         *                         </p>
         * @param whitelistClasses When running in strict mode this is used to white-list classes
         *                         for JS access.
         */
        private PendoOptions(boolean strictMode, Set<Class> whitelistClasses,
                             List<Pair<String, String>> pins, boolean ignoreFirstOnCreate,
                             Activity firstActivity, boolean fragmentIdentificationEnabled, String environment, boolean disableAnalytics) {
            mStrictMode = strictMode;
            mWhitelistClasses.addAll(whitelistClasses);
            mPins.addAll(pins);
            mIgnoreFirstOnCreate = ignoreFirstOnCreate;
            if (firstActivity != null) {
                mIsInitedFromActivity = true;
                ApplicationObservers.getInstance().addVisibleActivity(firstActivity);
            }
            mFragmentIdentificationEnabled = fragmentIdentificationEnabled;
            mEnvironment = environment;
            mDisableAppAnalytics = disableAnalytics;
        }

        /**
         * Pendo's options constructor.
         *
         * @param strictMode Whether the SDK runs in strict mode or not.<p>
         *                   True means that only a small subset of classes are accessible from JS.
         *                   </p>
         */
        private PendoOptions(boolean strictMode) {
            mStrictMode = strictMode;
        }

        public Set<Class> getWhitelist() {
            return mWhitelistClasses;
        }

        public boolean getIsInitedFromActivity() {
            return mIsInitedFromActivity;
        }

        public boolean getStrictMode() {
            return mStrictMode;
        }

        public boolean getIgnoreFirstOnCreate() {
            return mIgnoreFirstOnCreate;
        }

        public boolean getFragmentIdentificationEnabled() {
            return mFragmentIdentificationEnabled;
        }

        public List<Pair<String, String>> getPins() {
            return mPins;
        }

        public String getEnvironment() {
            return mEnvironment;
        }

        @SuppressWarnings("unused")
        public static final class Builder {
            private boolean mStrictMode;
            private boolean mFragmentIdentificationEnabled = false;
            private Activity mFirstActivityCordova;
            private Set<Class> mWhitelistClasses = new HashSet<>();
            private final List<Pair<String, String>> mPins = new ArrayList<>();
            private boolean mIgnoreFirstOnCreate = false;
            private String mEnvironment = null;
            private Map<String,Object> mAdditionalOptions;


            /**
             * Set whether the SDK runs in strict mode or not.
             *
             * @param strictMode Whether the SDK runs in strict mode or not.<p>
             *                   True means that only a small subset of classes are accessible from JS.
             *                   </p>
             * @return Builder.
             */
            public Builder setStrictMode(boolean strictMode) {
                mStrictMode = strictMode;
                return this;
            }

            /**
             * Set whether the SDK will identify a screen by it's fragment and activity rather only by the activity.
             *
             * @param fragmentIdentificationEnabled Whether we want the SDK to operate in the way depicted above.
             * @return Builder.
             */
            public Builder setFragmentIdentificationEnabled(boolean fragmentIdentificationEnabled) {
                mFragmentIdentificationEnabled = fragmentIdentificationEnabled;
                return this;
            }

            /**
             * Used in order to set the first activity of the application.
             * Used in cordova.
             *
             * @param firstActivity - the first activity of the app.
             * @return Builder.
             */
            public Builder setFirstActivity(Activity firstActivity) {
                mFirstActivityCordova = firstActivity;
                return this;
            }

            /**
             * Sets the classes to white-list. (Clears any previously set classes).<p>
             * To remove all classes, it accepts an empty set.
             * </p>
             *
             * @param whitelistClasses The classes to white-list for JS access.
             * @return Builder.
             */
            public Builder setWhitelistClasses(@NonNull Set<Class> whitelistClasses) {
                mWhitelistClasses.clear();
                mWhitelistClasses.addAll(whitelistClasses);
                return this;
            }

            /**
             * Convenient method to add a class to white-list.
             *
             * @param klass The class to add as white-listed for JS access.
             * @return Builder.
             */
            public Builder addWhitelistClass(@NonNull Class klass) {
                mWhitelistClasses.add(klass);
                return this;
            }

            /**
             * Convenient method to add classes to white-list.
             *
             * @param classes The classes to add as white-listed for JS access.
             * @return Builder.
             */
            public Builder addWhitelistClass(@NonNull Class... classes) {
                Collections.addAll(mWhitelistClasses, classes);
                return this;
            }

            /**
             * Pins certificates for {@code pattern} (<b>For debug applications only</b>).
             *
             * @param pattern lower-case host name or wildcard pattern such as {@code *.example.com}.
             * @param pins    SHA-256 or SHA-1 hashes. Each pin is a hash of a certificate's Subject Public Key
             *                Info, base64-encoded and prefixed with either {@code sha256/} or {@code sha1/}.
             */
            public Builder addPinDebugOnly(String pattern, String... pins) {
                if (pattern == null) {
                    throw new NullPointerException("pattern == null");
                }

                for (String pin : pins) {
                    if (pin.startsWith("sha1/") || pin.startsWith("sha256/")) {
                        mPins.add(Pair.create(pattern, pin));
                    } else {
                        throw new IllegalArgumentException(
                                "pins must start with 'sha256/' or 'sha1/': " + pin);
                    }
                }

                return this;
            }

            /**
             * Convenient method to set the SDK Environment (<b>For debug applications only</b>).
             *
             * @param environment
             * @return
             */
            public Builder setEnvironmentDebugOnly(String environment) {
                mEnvironment = environment;
                return this;
            }

            public Builder setIgnoreFirstOnCreate(boolean ignoreFirstOnCreate) {
                mIgnoreFirstOnCreate = ignoreFirstOnCreate;
                return this;
            }

            public Builder setAdditionalOptions(Map<String, Object> additionalOptions) {
                this.mAdditionalOptions = additionalOptions;
                return this;
            }

            /**
             * @return Pendo Options with the requested options.
             */
            public PendoOptions build() {
                boolean disableAppAnalytics = (this.mAdditionalOptions  == null) ? false : (Boolean)mAdditionalOptions.get("disableAnalytics");
                return new PendoOptions(mStrictMode, mWhitelistClasses, mPins,
                        mIgnoreFirstOnCreate, mFirstActivityCordova, mFragmentIdentificationEnabled, mEnvironment, disableAppAnalytics);
            }
        }
    }

    /**
     * GSON Singleton to avoid GC overhead.
     */
    public static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(InsertCommandAction.class,
                    new InsertCommandAction.InsertCommandActionDeserializer())
            .registerTypeAdapter(InsertCommandEventType.class,
                    new InsertCommandEventType.InsertCommandEventTypeDeserializer())
            .create();

    private static Context sApplicationContext;
    private static AtomicBoolean sIsStartingInit = new AtomicBoolean(false);
    private static Application sApplication;
    private static boolean sInitialized = false;

    // Hold the host app app key
    private static String sAppKey = null;
    private static String sDataCenter = null;
    private static PendoOptions sPendoOptions = new PendoOptions(true);
    private static volatile Boolean sDebugLogEnabled = null;
    private static int sSessionTimeout = -1;
    private ActivityLifeCycleListener mActivityLifecycleListenerInstance = null;
    private static Disposable sCallbackInterfaceSubscription;
    private static String sVisitorId;
    private static String sAccountId;
    private static String sPersistedVisitorId;
    private static String sPersistedAccountId;
    private static AtomicBoolean sPauseGuideShowing = new AtomicBoolean(false);
    private static Map<String, String> sUserData;
    private static Map<String, String> sAccountData;
    //    private static BehaviorSubject<Boolean> sPushIdExists = BehaviorSubject.createDefault(false);
    private static BehaviorSubject<Boolean> sSetNewVisitor = BehaviorSubject.createDefault(false);
    //    private static String sPushId;
    private static final String NOTIFICATION_KEY = "notification";
    private static final String CLICK_ACTION_KEY = "click_action";

    // Receive all the errors rx catches throughout the app.
    private static Handler sInitFailedHandler = new Handler();
    private static InitTimeoutRunnable sInitTimeoutRunnable;
    // Responsible for the communication with the Pendo Backend.
    // private BackendApiManager mBackendManager;

    @Nullable
    public static Pendo getInstance() {
        return INSTANCE;
    }

    private static void resetInitListeners() {
        if (sCallbackInterfaceSubscription != null
                && !sCallbackInterfaceSubscription.isDisposed()) {
            sCallbackInterfaceSubscription.dispose();
        }
        if ((sInitFailedHandler != null) && (sInitTimeoutRunnable != null)) {
            sInitFailedHandler.removeCallbacks(sInitTimeoutRunnable);
        }
    }

    @RequiresPermission(Manifest.permission.INTERNET)
    public static synchronized void initSDK(Activity activity,
                                            String appKey,
                                            PendoInitParams params) {

        PendoOptions pendoOptions = new PendoOptions(true);

        if (params != null) {
            if (params.getPendoOptions() != null) {
                pendoOptions = params.getPendoOptions();
            }
            pendoOptions.mIgnoreFirstOnCreate = true;
            params.setPendoOptions(pendoOptions);
        } else {
            pendoOptions.mIgnoreFirstOnCreate = true;
            params = new PendoInitParams().setPendoOptions(pendoOptions);
        }

        pendoOptions.mIsInitedFromActivity = true;
        ApplicationObservers.getInstance().addVisibleActivity(activity);
        initSDK(activity.getApplication(), appKey, params);
    }


    private static void sendAppSessionEndAnalyticsAtSessionBeginning() {
        /**
         * Those analytics should not be sent in case of a new visitor.
         * When we have a new visitor switched, we already take care of this sending ourselves.
         * In any case, we will get to this if in case the application is in foreground and it's
         * the first time since launch.
         */
        if (!Pendo.getIsSwitchVisitorValue()) {
            // Send AppSessionEnd analytic with old session data.
            AnalyticsUtils.sendAppSessionEndedAnalytics(PersistenceUtils.getPersistedVisitorId(), PersistenceUtils.getPersistedAccountId());
        }
    }

    static class PhoneUnlockedReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                if (sInitReceivedApplication == null) {
                    return;
                }
                boolean shouldInit = false;
                if (context != null) {
                    KeyguardManager keyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        if (context.getApplicationContext() != null &&
                                UserManagerCompat.isUserUnlocked(context.getApplicationContext())) {
                            shouldInit = true;
                        }
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                        if (keyguardManager != null && !keyguardManager.isDeviceLocked()) {
                            shouldInit = true;
                        }
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        if (keyguardManager != null && !keyguardManager.isKeyguardSecure()) {
                            shouldInit = true;
                        }
                    } else {
                        shouldInit = true;
                    }
                }
                if (!shouldInit) {
                    Context applicationContext = sInitReceivedApplication.getApplicationContext();
                    if (applicationContext != null) {
                        KeyguardManager myKM = (KeyguardManager) applicationContext.getSystemService(Context.KEYGUARD_SERVICE);
                        if (myKM == null || !myKM.inKeyguardRestrictedInputMode()) {
                            shouldInit = true;
                        }
                    }
                }
                if (shouldInit) {
                    internalInitSDK(sInitReceivedApplication, sInitReceivedAppKey, sInitReceivedPendoInitParams);
                }
            } catch (Exception e) {
                Log.e(Pendo.TAG, e.getMessage());
            }
        }
    }

    private static void internalInitSDK(Application app, String appKey, PendoInitParams params) {
        // This has to happen before PersistenceUtils usage in order to initialize the application context!
        if (!sIsStartingInit.getAndSet(true)) {
            sApplicationContext = app.getApplicationContext();
            if (sPhoneUnblockedReceiver != null) {
                try {
                    app.unregisterReceiver(sPhoneUnblockedReceiver);
                } catch (IllegalArgumentException e) {
                    InsertLogger.d("Trying to unregister a non registered receiver");
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
            sendAppSessionEndAnalyticsAtSessionBeginning();
            setPersistedVisitorId(PersistenceUtils.getPersistedVisitorId());
            setPersistedAccountId(PersistenceUtils.getPersistedAccountId());
            if (params != null) {
                setupPhasesCallbacks(params.getCallbackInterface());
                setPendoOptions(params.getPendoOptions());

                // Set the environment override BEFORE validating the JWT appKey!
                if (sPendoOptions.getEnvironment() != null) {
                    if (SettingsUtils.isHostAppDebuggable()) {
                        Log.i(Pendo.TAG, "Using override environment: " + sPendoOptions.getEnvironment());
                        JsonWebTokenValidator.INSTANCE.setEnvironment(sPendoOptions.getEnvironment());
                    } else {
                        Log.i(Pendo.TAG, "Environment override ignore (Host app is not debuggable)");
                    }
                }
                setVisitorId(params.getVisitorId());
                setAccountId(params.getAccountId());
                if (params.getUserData() != null) {
                    setUserData(params.getUserData());
                } else {
                    SetupManager.getInstance().setUserDataSent(true);
                }
                if (params.getAccountData() != null) {
                    setAccountData(params.getAccountData());
                } else {
                    SetupManager.getInstance().setAccountDataSent(true);
                }
            } else {
                setPendoOptions(null);
                SetupManager.getInstance().setUserDataSent(true);
                SetupManager.getInstance().setAccountDataSent(true);
            }

            if (sInitialized) {
                throw new PendoInitializedStateException(getApplicationContext().getString(R.string.err_already_init));
            }

            sInitialized = true;

            INSTANCE = new Pendo(app, appKey);
        }
    }

    @RequiresPermission(Manifest.permission.INTERNET)
    public static synchronized void initSDK(Application app,
                                            String appKey,
                                            PendoInitParams params) {
        sInitReceivedAppKey = appKey;
        sInitReceivedPendoInitParams = params;
        sInitReceivedApplication = app;
        sPhoneUnblockedReceiver = new PhoneUnlockedReceiver();
        try {
            IntentFilter userPresentIntentFilter = new IntentFilter(Intent.ACTION_USER_PRESENT);
            app.registerReceiver(sPhoneUnblockedReceiver, userPresentIntentFilter);
            KeyguardManager myKM = (KeyguardManager) app.getApplicationContext().getSystemService(Context.KEYGUARD_SERVICE);
            if (myKM == null || !myKM.inKeyguardRestrictedInputMode()) {
                internalInitSDK(app, appKey, params);
                if (sPhoneUnblockedReceiver != null) {
                    try {
                        app.unregisterReceiver(sPhoneUnblockedReceiver);
                    } catch (IllegalArgumentException e) {
                        // Exception occurred due to not registering and trying to unregister.
                        Log.d(Pendo.TAG, "Trying to unregister a non registered receiver");
                    } catch (Exception e) {
                        Log.e(Pendo.TAG, e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            Log.e(Pendo.TAG, e.getMessage());
        }
    }

    /**
     * Call this in order to pause showing guides.
     */
    public static synchronized  void pauseGuides() {
        InsertLogger.d("Pausing guide showing.");
        sPauseGuideShowing.set(true);
    }

    /**
     * Call this in order to resume showing guides.
     */
    public static synchronized  void resumeGuides() {
        InsertLogger.d("Resuming guide showing.");
        sPauseGuideShowing.set(false);
    }

//    /**
//     * When calling this method any Pendo that is still visible will be dismissed.
//     *
//     * @throws IllegalStateException If called but {@link Pendo} is not initialized yet.
//     *                               Must call {@link Pendo#initSDK(Application, String, PendoInitParams)}
//     *                               before calling this method.
//     */
//    @SuppressWarnings({"unused", "CheckStyle"})
//    protected static synchronized void dismissVisibleGuides() throws IllegalStateException {
//
//        if (!sInitialized) {
//            throw new IllegalStateException(
//                    "Pendo SDK must be initialized before calling this method.");
//        }
//
//	    InsertsManager.getInstance().dismissVisibleGuides();
//    }

    private static void setupPhasesCallbacks(
            final PendoPhasesCallbackInterface callbackInterface) {
        if (callbackInterface != null) {
            // Notifying the host app on successful init: normal / marketers socket connection
            SuccessInitAction onSuccessInitAction = new SuccessInitAction(callbackInterface);
            sCallbackInterfaceSubscription = RestAPI.getNetworkInitedObservable()
                    .filter(
                            new Predicate<Boolean>() {
                                @Override
                                public boolean test(Boolean isInited) {
                                    return isInited;
                                }
                            })
                    .mergeWith(SocketEventFSM.isInPairedModeObservable())
                    .subscribe(onSuccessInitAction, new InsertOnErrorHandler());

            // notifying the host app in case of fail of init:
            // didn't get to regular init or socket are not paired.
            sInitTimeoutRunnable = new InitTimeoutRunnable(callbackInterface);
            sInitFailedHandler.postDelayed(sInitTimeoutRunnable, RestAPI.INIT_TIMEOUT_MILLIS);

            // Notify the host app when setup has started to inject it's user attributes
            BackendApiManager.getIsStartedInitObservable().filter(new Predicate<Boolean>() {
                @Override
                public boolean test(Boolean hasReceivedSetup) {
                    return hasReceivedSetup;
                }
            })
                    .firstElement()
                    .subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                        @Override
                        public void accept(Boolean hasReceivedSetup) {
                            if (callbackInterface != null) {
                                callbackInterface.onInitStarted();
                            }
                        }
                    }));
        }
    }

    private Pendo(Application app, String appKey) {
        try {
            sCrashEvent = new CrashEvent();
            AppKeyData appKeyData;
            if (appKey == null) {
                throw new PendoInitializedStateException(APP_KEY_NOT_VALID);
            }

            try {
                String validatedAppKey = JsonWebTokenValidator.INSTANCE.validate(appKey);
                appKeyData = Pendo.GSON.fromJson(validatedAppKey, AppKeyData.class);
            } catch (Exception e) {
                throw new PendoInitializedStateException(APP_KEY_NOT_VALID);
            }
            if (appKeyData == null) {
                throw new PendoInitializedStateException(APP_KEY_NOT_VALID);
            }

            sAppKey = appKeyData.getKey();
            sDataCenter = appKeyData.getDataCenter();
            sApplicationContext = app.getApplicationContext();
            sApplication = app;
            sInitReceivedApplication = null;
            PersistenceUtils.handlePendingAnalytics();
            AnalyticEventsManager.getInstance().flushAnalyticEventsIfExist();
            InsertAnalytics.getInstance();

            // Load all the IconFontFamilies we want to support here.
            Iconify.with(new InsertIoModule());

            JavascriptRunner.setSandboxMode(sPendoOptions);

            if (!sPendoOptions.getPins().isEmpty()) {
                if (SettingsUtils.isHostAppDebuggable()) {
                    CertificatePinningTrustManager.setAdditionalDebugPins(sPendoOptions.getPins());
                    Log.i(Pendo.TAG,
                            "Additional certificate pins added. "
                                    + "Note: additional certificate pins "
                                    + "can only be applied during debug.");
                } else {
                    Log.i(Pendo.TAG, "Additional certificate pins ignore.");
                }
            }

            // Decide regarding the debug tree according to the metadata
            ReactiveUtils.schedule(new ApiAction() {
                @Override
                protected void execute() {
                    if (isDebugLogEnabled()) {
                        InsertLogger.plant(new InsertDebugTree());
                    } else {
                        InsertLogger.plant(new InsertReleaseTree());
                    }
                }
            });

            if (KillSwitchManager.isKillSwitchOn()) {
                return;
            }
            InsertCommandDispatcher.getInstance().init();
            IntelManager.init();
            ScreenManager.INSTANCE.start();
            ScreenManager.INSTANCE.setDisableAppAnalytics(sPendoOptions.mDisableAppAnalytics);

            AnalyticsManager.INSTANCE.start();
            ActivationManager.INSTANCE.start();

            ProfilingManager.getInstance().mark(PERFORMANCE, "Application started");

            mActivityLifecycleListenerInstance = ActivityLifeCycleListener.getInstance();
            sApplication.registerActivityLifecycleCallbacks(mActivityLifecycleListenerInstance);

            // Usually we don't start loading Inserts here due to multiple inits issue, we only start the
            // loading after first Activity's onCreate. However if we have a flag to ignore first Activity's
            // onCreate (currently for Cordova apps since we miss the first Activity), we start the loading
            // here.
            if (sPendoOptions.getIgnoreFirstOnCreate()) {
                GuideUtils.startLoadingInserts(false, false);
            }

        } catch (Exception e) {
            Log.e(Pendo.TAG, e.getMessage());
        }
    }

    public static int getSessionTimeout() {
        return sSessionTimeout;
    }


    // TODO: Change access to Package. Now public for Google Analytics.
    public static Application getApplication() {
        return sApplication;
    }

    public static Context getApplicationContext() {
        return sApplicationContext;
    }

    public static String getPendoDeviceId() {
        return AndroidUtils.getDeviceId();
    }

    public static void setUserData(Map<String, String> userData) {
        sUserData = userData;
        if (userData != null && !userData.isEmpty()) {
            try {
                JSONObject userDataJSON = new JSONObject();
                userDataJSON.put(SetupAction.USER_ATTRIBUTES, (new JSONObject(sUserData)));
                BackendApiManager.getInstance().sendSetupResult(userDataJSON, false, false, true);
                return;
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        SetupManager.getInstance().setUserDataSent(true);
    }

    public static String getDataCenter() {
        return sDataCenter;
    }

    public static void setAccountData(Map<String, String> accountData) {
        sAccountData = accountData;
        if (accountData != null && !accountData.isEmpty()) {
            try {
                JSONObject accountDataJSON = new JSONObject();
                accountDataJSON.put(SetupAction.ACCOUNT_ATTRIBUTES, (new JSONObject(sAccountData)));
                BackendApiManager.getInstance().sendSetupResult(accountDataJSON, false, true, false);
                return;
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        SetupManager.getInstance().setAccountDataSent(true);
    }

    public static void setPendoOptions(PendoOptions pendoOptions) {
        if (pendoOptions == null) {
            sPendoOptions = new PendoOptions(true);
        } else {
            sPendoOptions = pendoOptions;
        }
    }

    public static Map<String, String> getUserData() {
        return sUserData;
    }

    public static Map<String, String> getAccountData() {
        return sAccountData;
    }

    public static synchronized boolean areGuidesPaused() {
        return sPauseGuideShowing.get();
    }

    public static JSONObject getUserDataAsJSONObject() {
        if (sUserData == null) {
            return null;
        }
        JSONObject userData = new JSONObject();
        for (Map.Entry<String, String> pair : sUserData.entrySet()) {
            try {
                userData.put(pair.getKey(), pair.getValue());
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return userData;
    }

    public static JSONObject getAccountDataAsJSONObject() {
        if (sAccountData == null) {
            return null;
        }
        JSONObject accountData = new JSONObject();
        for (Map.Entry<String, String> pair : sAccountData.entrySet()) {
            try {
                accountData.put(pair.getKey(), pair.getValue());
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return accountData;
    }

    public static String getPersistedVisitorId() {
        return sPersistedVisitorId;
    }

    private static void setPersistedVisitorId(String persistedVisitorId) {
        sPersistedVisitorId = persistedVisitorId;
    }

    private static void setPersistedAccountId(String persistedAccountId) {
        sPersistedAccountId = persistedAccountId;
    }

    public static String getPersistedAccountId() {
        return sPersistedAccountId;
    }

    public static String getVisitorId() {
        return sVisitorId;
    }

    private static void setVisitorId(String visitorId) {
        if (visitorId == null) {
            visitorId = EMPTY_VISITOR;
        }
        sVisitorId = visitorId;
        PersistenceUtils.persistVisitorId(sVisitorId);
    }

    private static void setAccountId(String accountId) {
        if (accountId == null) {
            accountId = EMPTY_ACCOUNT;
        }
        sAccountId = accountId;
        PersistenceUtils.persistAccountId(sAccountId);
    }

    public static String getAccountId() {
        return sAccountId;
    }

//    public static void setPushId(String pushId) {
//        if (pushId != null) {
//            sPushId = pushId;
//            sPushIdExists.onNext(true);
//
//            SetupManager.getInstance().sendPushIdToServer(sPushId);
//            if (sApplicationContext != null) {
//                PendoPushHandler.createNotificationChannelIfNeeded(sApplicationContext);
//            }
//
//        } else {
//            Log.w(Pendo.TAG, "Warning: Trying to set Push ID with NULL value. Ignoring.");
//        }
//    }

    public static Boolean getIsSwitchVisitorValue() {
        return sSetNewVisitor.getValue();
    }

    /**
     * Ends current session, resets all managers and listeners, and starts a new session
     * with the new parameters.
     *
     * @param visitorId
     * @param accountId
     * @param userData
     */
    public static void switchVisitor(final String visitorId, final String accountId, final Map<String, String> userData, final Map<String, String> accountData) {
        BackendApiManager.getIsInitCompleteAsObservable().filter(new Predicate<Boolean>() {
            @Override
            public boolean test(Boolean isInited) {
                return isInited;
            }
        }).firstElement().subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
            @Override
            public void accept(Boolean aBoolean) {
                try {
                    Log.i(Pendo.TAG, "Visitor Switched: visitorID = " + (visitorId == null ? "null" : visitorId)
                            + ", accountID = " + (accountId == null ? "null" : accountId)
                            + ", userData= " + (userData == null ? "null" : userData.toString())
                            + ", accountData = " + (accountData == null ? "null" : accountData.toString()));

                    InsertsManager.getInstance().dismissVisibleGuides();
                    InsertAnalytics.getInstance().flushCurrentBuffer();
                    resetInitListeners();
                    SetupManager.getInstance().reset();
                    resetUserAccountData();

                    // TODO: Remove this when we use stored AppSessionStart, AppSessionEnd JSONs.
                    // Get and save the previous visitor and account from persistence store before update the with new data IDEV-13424
                    setPersistedVisitorId(PersistenceUtils.getPersistedVisitorId());
                    setPersistedAccountId(PersistenceUtils.getPersistedAccountId());

                    // Send AppSessionEnd analytic with old session data.
                    AnalyticsUtils.sendAppSessionEndedAnalytics(getPersistedVisitorId(), getPersistedAccountId());
                    setVisitorId(visitorId);
                    setAccountId(accountId);
                    setUserData(userData);
                    setAccountData(accountData);

                    // Send AppSessionStart with new session data.
                    AnalyticsUtils.sendAppSessionStartedAnalytics();
                    GuideUtils.startLoadingInserts(true, true);
                    PersistenceUtils.removeStoredAnalytics();
                    PersistenceUtils.handlePendingAnalytics();
                    AnalyticEventsManager.getInstance().flushAnalyticEventsIfExist();
                    sSetNewVisitor.onNext(true);
                    ApplicationFlowManager.getInstance().appBackgroundToForegeound();
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }));
    }

    private static void resetUserAccountData() {
        SetupManager.getInstance().setUserDataSent(false);
        SetupManager.getInstance().setAccountDataSent(false);
    }

    /**
     * Ends current session, resets all managers and listeners, and starts a new session
     * with an anonymous visitor.
     */
    public static void clearVisitor() {
        PersistenceUtils.removeStoredVisitorAccountId();
        switchVisitor(EMPTY_VISITOR, EMPTY_ACCOUNT, null, null);
    }

//    /**
//     * This method is used to notify Pendo of an event which occurred in the app.
//     * Parameters can be added.
//     *
//     * @param eventName  - The name of the app event that occurred.
//     * @param parameters - Add more info about the event via the parameters dictionary.
//     */
//    public static void eventOccurred(String eventName, @Nullable Map<String, String> parameters) {
//        if (InsertsManager.isInited()) {
//            InsertsManager.getInstance().runCustomInserts(eventName, parameters);
//        }
//    }

    /**
     * Track an event that has happened in your application.
     *
     * @param eventName  - the name of the event.
     * @param properties - properties connected to the event.
     */
    public static void track(String eventName, @Nullable Map<String, String> properties) {
        if (TextUtils.isEmpty(eventName)) {
            return;
        }
        JSONObject analyticsJSON = new JSONObject();
        JSONObject propertiesJSON = new JSONObject();
        try {
            analyticsJSON.put(AnalyticsProperties.EVENT, eventName);
            analyticsJSON.put(AnalyticsProperties.TYPE, AnalyticsProperties.TRACK_EVENT_TYPE);
            if (properties != null) {
                for (Map.Entry<String, String> mapEntry : properties.entrySet()) {
                    propertiesJSON.put(mapEntry.getKey(), mapEntry.getValue());
                }
            }
            analyticsJSON.put(AnalyticsProperties.CUSTOM_EVENT_PROPERTIES, propertiesJSON);
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
        InsertAnalytics.newTracker().send(AnalyticsEvent.TRACK_EVENT.getValue(), analyticsJSON, null);
    }

//    public static String getPushId() {
//        return sPushId;
//    }

//    public static Observable<Boolean> getPushIdAsObservable() {
//        return sPushIdExists;
//    }

//    /**
//     * Checks whether the push came from Pendo by checking the data that came on the push.
//     *
//     * @param data the bundle from the push.
//     * @return true if push arrived from Pendo, false otherwise
//     */
//    public static boolean isPendoPush(Object data) {
//        if (data == null) {
//            return false;
//        }
//
//        boolean isBundle = false;
//        JSONObject dataJson;
//        try {
//            if (data instanceof Bundle) { // GCM
//                isBundle = true;
//                dataJson = new JSONObject(((Bundle) data).getString(NOTIFICATION_JSON_DATA_KEY));
//            } else { // FCM
//                dataJson = new JSONObject(
//                        ((Map<String, String>) data).get(NOTIFICATION_JSON_DATA_KEY));
//            }
//            return dataJson.has(INSERT_PUSH_DATA_KEY);
//
//        } catch (Exception e) {
//            if (isBundle) { // GCM
//                return ((Bundle) data).containsKey(INSERT_PUSH_DATA_KEY);
//            } else { // FCM
//                return ((Map) data).containsKey(INSERT_PUSH_DATA_KEY);
//            }
//        }
//    }

//    /**
//     * This method generates an appropriate PendingIntent object to be used
//     * when clicking on the notification.
//     *
//     * @param data the bundle from the push.
//     * @return a PendingIntent object based on Pendo's data on the push.
//     */
//    public static PendingIntent generatePendingIntentForPush(Bundle data) {
//        Intent intent = new Intent(getApplicationContext(), PendoGateActivity.class);
//        intent.putExtras(data);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//
//        Bundle notificationData = data.getBundle(NOTIFICATION_KEY);
//        if (notificationData != null) {
//            intent.setAction(notificationData.getString(CLICK_ACTION_KEY));
//        }
//
//        return PendingIntent.getActivity(getApplicationContext(), 0 /* Request code */, intent,
//                PendingIntent.FLAG_ONE_SHOT);
//    }

    public static boolean isDebugLogEnabled() {
        if (sDebugLogEnabled == null) {
            sDebugLogEnabled = SettingsUtils.getDebugLoggingEnabled(sApplicationContext);
        }

        InsertLogger.d(TAG, "Debug logging " + (sDebugLogEnabled ? "enabled" : "disabled") + ".");
        return sDebugLogEnabled;
    }

    public static String getAppKey() {
        return sAppKey;
    }

    public static PendoOptions getPendoOptions() {
        return sPendoOptions;
    }

    public static List<Pair<String, InsertProfiler>> getProfilers() {
        return ProfilingManager.getInstance().getProfilers();
    }

    public static void storeSessionTimeout(InitModel initModel) {
        if (initModel != null && initModel.getInitConfiguration() != null) {
            sSessionTimeout = initModel.getInitConfiguration().getSessionTimeout();
        } else {
            InsertLogger.d("Init model configuration is null in storeSessionTimeout. Response from server is 200.");
        }
    }

    public DeviceInfoCollector deviceInformationCollector() {
        return DeviceInfoCollector.Companion.getInstance();
    }

    public ApplicationInfoCollector applicationInfoCollector() {
        return ApplicationInfoCollector.Companion.getInstance();
    }

    private static class InitTimeoutRunnable implements Runnable {
        private PendoPhasesCallbackInterface mPendoPhasesCallbackInterface;

        InitTimeoutRunnable(PendoPhasesCallbackInterface pendoPhasesCallbackInterface) {

            this.mPendoPhasesCallbackInterface = pendoPhasesCallbackInterface;
        }

        @Override
        public void run() {
            resetInitListeners();

            // In case there was not a valid backend init and there device is not currently paired.
            // If the timeout reached -> notify the host app with onInitFailed.
            if (mPendoPhasesCallbackInterface != null
                    && (!RestAPI.getNetworkInited()
                    && STATE_NOT_PAIRED.equals(
                    SocketEventFSM.getInstance().getCurrentState()))) {
                InsertLogger.d("Pendo initialization got timeout without a valid init");
                mPendoPhasesCallbackInterface.onInitFailed();
                mPendoPhasesCallbackInterface = null;
            }
        }
    }

    private static class SuccessInitAction implements Consumer<Boolean> {
        private PendoPhasesCallbackInterface mCallbackInterface;

        SuccessInitAction(PendoPhasesCallbackInterface pendoPhasesCallbackInterface) {
            mCallbackInterface = pendoPhasesCallbackInterface;
        }

        @Override
        public void accept(Boolean isInited) {
            if (isInited) {
                resetInitListeners();
                if (mCallbackInterface != null) {
                    mCallbackInterface.onInitComplete();
                    mCallbackInterface = null;
                }
            }
        }
    }

    public static class PendoInitParams {
        private String mVisitorId;
        private String mAccountId;
        private Map<String, String> mUserData;
        private Map<String, String> mAccountData;
        private PendoOptions mPendoOptions;
        private PendoPhasesCallbackInterface mCallbackInterface;

        public PendoInitParams() {
        }

        public String getVisitorId() {
            return mVisitorId;
        }

        public PendoInitParams setVisitorId(String visitorId) {
            mVisitorId = visitorId;
            return this;
        }

        public String getAccountId() {
            return mAccountId;
        }

        public PendoInitParams setAccountId(String accountId) {
            mAccountId = accountId;
            return this;
        }

        public Map<String, String> getUserData() {
            return mUserData;
        }

        public PendoInitParams setUserData(Map<String, String> userData) {
            mUserData = userData;
            return this;
        }

        public Map<String, String> getAccountData() {
            return mAccountData;
        }

        public PendoInitParams setAccountData(Map<String, String> accountData) {
            mAccountData = accountData;
            return this;
        }

        public PendoOptions getPendoOptions() {
            return mPendoOptions;
        }

        public PendoInitParams setPendoOptions(PendoOptions pendoOptions) {
            mPendoOptions = pendoOptions;
            return this;
        }

        public PendoPhasesCallbackInterface getCallbackInterface() {
            return mCallbackInterface;
        }

        public PendoInitParams setCallbackInterface(
                PendoPhasesCallbackInterface callbackInterface) {
            mCallbackInterface = callbackInterface;
            return this;
        }
    }
}
