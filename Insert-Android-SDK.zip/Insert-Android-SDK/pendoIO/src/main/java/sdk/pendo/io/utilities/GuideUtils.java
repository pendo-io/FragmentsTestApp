package sdk.pendo.io.utilities;

import android.app.Activity;
import android.support.annotation.CheckResult;
import android.support.annotation.Nullable;
import android.view.View;
import java.lang.ref.WeakReference;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.StepSeenManager;
import sdk.pendo.io.actions.ToolTipVisualInsert;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.activities.InsertVisualActivity;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.cache.GuideCacheManager;
import sdk.pendo.io.events.EventConfiguration;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.exceptions.DynamicViewException;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;

/**
 * Created by nirsegev on 6/22/15.
 */
public final class GuideUtils {
    private GuideUtils() {
    }

//    @CheckResult
//    public static boolean showVisualInsert(final VisualInsert actionVisual,
//                                           GenericInsertAnalyticsData iga) {
//        return showVisualInsert(null, actionVisual, iga, null);
//    }

    @CheckResult
    public static boolean showVisualInsert(Activity activity,
                                           final VisualInsert visualGuide,
                                           GenericInsertAnalyticsData iga,
                                           String activatedBy) {
        try {
            String guideStepId = StepSeenManager.getInstance().getCurrentStepId();
            if (guideStepId != null) {
                visualGuide.init(activity, iga, activatedBy);
                InsertsManager.setVisualGuideStepInited(guideStepId, true);
                visualGuide.show();
            } else {
                InsertLogger.w("GuideUtils::showVisualInsert not showing guide due to stepId being null");
            }
        } catch (DynamicViewException e) {
            InsertLogger.e(e, (activity != null ? activity.getLocalClassName() + " " : "")
                    + "insert id: '" + visualGuide.getGuideId() + "'.");
            return false;
        }

        return true;
    }

    public static boolean showToolTipVisualInsert(@Nullable final WeakReference<View> view,
                                                  final ToolTipVisualInsert visualGuide,
                                                  GenericInsertAnalyticsData iga,
                                                  String activatedBy) {
        String guideStepId = StepSeenManager.getInstance().getCurrentStepId();
        if (guideStepId != null) {
            visualGuide.init(view, iga, activatedBy);
            InsertsManager.setVisualGuideStepInited(guideStepId, true);
            visualGuide.show();
        } else {
            InsertLogger.w("GuideUtils::showVisualInsert not showing guide due to stepId being null");
        }

        return true;
    }


    public static boolean isAppLaunchEvent(InsertEvent insertEvent) {
        return isAppLaunchAction(insertEvent.getConfiguration().getAction());
    }

    public static boolean isCustomEvent(InsertEvent insertEvent) {
        return InsertEvent.EventActions.CUSTOM_EVENT.equals(insertEvent.getConfiguration().getAction());
    }

    public static boolean isAppLaunchAction(String action) {
        return InsertEvent.EventActions.APP_LAUNCHED.equals(action);
    }

    public static boolean isDirectLinkEvent(InsertEvent insertEvent) {
        return isDirectLinkAction(insertEvent.getConfiguration().getAction());
    }

    public static boolean isDirectLinkAction(String action) {
        return InsertEvent.EventActions.DIRECT_LINK.equals(action);
    }

    public static boolean isScreenViewedAction(String action) {
        return InsertEvent.EventActions.SCREEN_VIEW.equals(action);
    }

    public static boolean isScreenViewedEvent(InsertEvent insertEvent) {
        return isScreenViewedAction(insertEvent.getConfiguration().getAction());
    }

    public static boolean isBlockingInsert(GuideModel guideModel) {
        return false;
    }

    public static InsertEvent generateGuideEvent(InsertEvent.EventActions eventAction) {
        InsertEvent event = new InsertEvent();
        EventConfiguration configuration = new EventConfiguration();
        configuration.setAction(eventAction);
        event.setConfiguration(configuration);
        return event;
    }


    public static InsertEvent generatePreviewEventFromInitModel() {
        return GuideUtils.generateGuideEvent(InsertEvent.EventActions.PREVIEW);
    }

    /**
     * @param localClassName the activity's name to check.
     * @return true if the given activity name is Pendo's activity.
     */
    public static boolean isInsertActivity(String localClassName) {
        return localClassName.endsWith(InsertVisualActivity.class.getName());
    }

    public static void startLoadingInserts(boolean forceNewInit, boolean fromSwitchVisitor) {
        if ((SocketIOUtils.getSessionToken() != null || SocketIOUtils.getAndResetEnteredFromGateActivity()) && !fromSwitchVisitor) {
            InsertLogger.d("session token is not null, ");

            // When session token exists (it's a marketer device)
            // and we don't have connectivity we load the pairing cache
            // to enable the marketer to work with his latest configured inserts
            if (!ConnectivityUtils.hasConnectivity()) {
                SocketIOUtils.loadCachedPairingInsertsAndRun();
            }

            // In case there is a session token
            // we should only authorize the user and not do an init process.
            SocketIOUtils.handleMarketerDeviceInit(false, true);
        } else {

            // It's a non - marketer device, load inserts from cache if not forced a new init.
            if (!forceNewInit) {
                GuideCacheManager.getInstance().loadCachedInsertAndEvents(GuideCacheManager.CACHE_FILE_NAME);
            }
            // Otherwise we have a standard init against the backend.
            BackendApiManager.getInstance().startBackendInitialization(forceNewInit);
        }
    }

}
