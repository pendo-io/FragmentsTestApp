package sdk.pendo.io.views.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.RadioButton;

import external.sdk.pendo.io.dynamicview.DynamicProperty;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.joanzapata.iconify.Icon;
import com.joanzapata.iconify.IconDrawable;

import org.json.JSONException;

import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.fonts.InsertIoIcons;
import sdk.pendo.io.utilities.FontUtils;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.ViewUtils;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.constants.Constants.GeneralConsts.RTL;

/**
 * Pendo's RadioButton
 *
 * Created by assaf on 8/26/15.
 */
public final class InsertRadioButton extends RadioButton {

    private static final Icon DEFAULT_SELECTED_ICON = InsertIoIcons.icon_dot_circled;
    private static final Icon DEFAULT_UNSELECTED_ICON = InsertIoIcons.icon_circle_empty;

    // TODO: 8/26/15 This and InsertCompoundButton is the same, we need to find a way to merge them.
    @ColorInt private int mCheckedTextColor;
    @ColorInt private int mCheckedBackgroundColor;
    @ColorInt private int mTextColor;
    @ColorInt private int mBackgroundColor;

    private MarginDrawable mUnSelectedBlank;
    private MarginDrawable mSelectedBlank;
    private MarginDrawable mSelectedDrawable;
    private MarginDrawable mUnSelectedDrawable;
    private int mIconSize = ViewUtils.convertDpToPx(FontUtils.DEFAULT_FONT_ICON_SIZE);
    private int mSelectedIconSize = ViewUtils.convertDpToPx(FontUtils.DEFAULT_FONT_ICON_SIZE);
    private float mSelectedTextSize = ViewUtils.convertSpToPx(16);
    private float mTextSize = ViewUtils.convertSpToPx(16);
    private Typeface mSelectedTypeFace = Typeface.DEFAULT;
    private Typeface mTypeFace = Typeface.DEFAULT;
    private int mPaddingLeft = 0;
    private int mPaddingTop = 0;
    private int mPaddingBottom = 0;
    private int mIconMarginRight = 0;
    private boolean mIsRTL;

    public InsertRadioButton(Context context) {
        super(context);
        init();
    }

    public InsertRadioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public InsertRadioButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public InsertRadioButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void setup(@NonNull JsonObject jsonObject) throws JSONException {
        final JsonArray props = JsonUtils.optJsonArray(
                jsonObject, InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);

        InsertContentDescriptionManager.getInstance().setContentDescription(this, getContext().getString(
                        R.string.insert_radio_button_accessibility_description), null);
        String selectedIcon = null;
        String unselectedIcon = null;
        String iconFontFamily = null;
        String selectedIconFontFamily = null;
        String fontFamily = null;
        String selectedFontFamily = null;
        int textStyle = Typeface.NORMAL;
        int selectedTextStyle = Typeface.NORMAL;
        int selectedIconColor = Color.WHITE;
        int unselectedIconColor = Color.WHITE;
        boolean checked = false;
        if (props != null) {
            for (int i = 0; i < props.size(); i++) {

                DynamicProperty prop = new DynamicProperty(props.get(i).getAsJsonObject());
                if (DynamicProperty.NAME.ICONSIZE.equals(prop.name)) {
                    mIconSize = prop.getValueInt();
                } else if (DynamicProperty.NAME.SELECTEDICONSIZE.equals(prop.name)) {
                    mSelectedIconSize = prop.getValueInt();
                } else if (DynamicProperty.NAME.ICONFONTFAMILY.equals(prop.name)) {
                    iconFontFamily = prop.getValueString();
                } else if (DynamicProperty.NAME.SELECTEDICON.equals(prop.name)) {
                    selectedIcon = prop.getValueString();
                } else if (DynamicProperty.NAME.UNSELECTEDICON.equals(prop.name)) {
                    unselectedIcon = prop.getValueString();
                } else if (DynamicProperty.NAME.SELECTEDICONCOLOR.equals(prop.name)) {
                    selectedIconColor = prop.getValueColor();
                } else if (DynamicProperty.NAME.UNSELECTEDICONCOLOR.equals(prop.name)) {
                    unselectedIconColor = prop.getValueColor();
                } else if (DynamicProperty.NAME.SELECTEDTEXTSIZE.equals(prop.name)) {
                    mSelectedTextSize = prop.getValueFloat();
                } else if (DynamicProperty.NAME.SELECTEDICONFONTFAMILY.equals(prop.name)) {
                    selectedIconFontFamily = prop.getValueString();
                } else if (DynamicProperty.NAME.SELECTEDTEXTSTYLE.equals(prop.name)) {
                    selectedTextStyle = FontUtils.getTextStyle(prop);
                } else if (DynamicProperty.NAME.SELECTEDTEXTFONTFAMILY.equals(prop.name)) {
                    selectedFontFamily = prop.getValueString();
                } else if (DynamicProperty.NAME.PADDING_BETWEEN.equals(prop.name)) {
                    mIconMarginRight = prop.getValueInt();
                } else if (DynamicProperty.NAME.PADDING_LEFT.equals(prop.name)) {
                    mPaddingLeft = prop.getValueInt();
                } else if (DynamicProperty.NAME.PADDING_TOP.equals(prop.name)) {
                    mPaddingTop = prop.getValueInt();
                } else if (DynamicProperty.NAME.PADDING_BOTTOM.equals(prop.name)) {
                    mPaddingBottom = prop.getValueInt();
                } else if (DynamicProperty.NAME.FONTFAMILY.equals(prop.name)) {
                    fontFamily = prop.getValueString();
                } else if (DynamicProperty.NAME.TEXTSTYLE.equals(prop.name)) {
                    textStyle = FontUtils.getTextStyle(prop);
                } else if (DynamicProperty.NAME.TEXTSIZE.equals(prop.name)) {
                    mTextSize = prop.getValueFloat();
                } else if (DynamicProperty.NAME.CHECKED.equals(prop.name)) {
                    checked = prop.getValueBoolean();
                } else if (DynamicProperty.NAME.TEXTDIRECTION.equals((prop.name))) {
                    mIsRTL = RTL.equals(prop.getValueString());
                }
            }
        }

        // Set the fonts Typeface.
        mTypeFace = FontUtils.getTypeface(fontFamily, textStyle);
        mSelectedTypeFace = FontUtils.getTypeface(selectedFontFamily, selectedTextStyle);

        if (checked) {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, mSelectedTextSize);
            setTypeface(mSelectedTypeFace);
        } else {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, mTextSize);
            setTypeface(mTypeFace);
        }

        // Set the required icons.
        mSelectedDrawable = createIconDrawable(selectedIcon, selectedIconFontFamily,
                                               selectedIconColor, mSelectedIconSize,
                                               DEFAULT_SELECTED_ICON);

        mUnSelectedDrawable = createIconDrawable(unselectedIcon, iconFontFamily,
                                                 unselectedIconColor, mIconSize,
                                                 DEFAULT_UNSELECTED_ICON);

        // Set the blank drawables to use as the radio button's drawable.
        setBlankDrawables();
        if (checked) {
            setButtonDrawable(mSelectedBlank);
        } else {
            setButtonDrawable(mUnSelectedBlank);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            setPaddingRelative(0, mPaddingTop, 0, mPaddingBottom);
        } else {
            setPadding(0, mPaddingTop, 0, mPaddingBottom);
        }
    }

    /**
     * Utility method for making the {@link IconDrawable} wrapped in {@link MarginDrawable}.
     *
     * @param icon the character for that icon.
     * @param iconFontFamily the icon font family.
     * @param iconColor the icon color.
     * @param iconSize the icon size.
     * @param defaultIcon the default icon in case the icon was not found.
     *
     * @return {@code IconDrawable} wrapped in {@code MarginDrawable}.
     */
    private MarginDrawable createIconDrawable(String icon, String iconFontFamily,
                                              int iconColor, int iconSize, Icon defaultIcon) {
        Icon iconify =
                FontUtils.getIcon(FontUtils.getChar(icon),
                                  iconFontFamily,
                                  defaultIcon);

        // Create the icon drawable.
        final IconDrawable iconDrawable =
                FontUtils.createIconDrawable(getContext(), iconSize, iconColor,
                                             iconify != null ? iconify : defaultIcon);

        // Return the drawable.
        return new MarginDrawable.Builder(iconDrawable)
                .setTopMargin(mPaddingTop)
                .setBottomMargin(mPaddingBottom)
                .setLeftMargin(mIsRTL ? mIconMarginRight : mPaddingLeft)
                .setRightMargin(mIsRTL ? mPaddingLeft : mIconMarginRight)
                .build();
    }

    /**
     * Set the blank drawables that are needed to make sure
     * the padding and size of the radio button is correct.
     */
    private void setBlankDrawables() {
        mUnSelectedBlank = new MarginDrawable.Builder(new IconDrawable(getContext(),
                                                                       InsertIoIcons.icon_blank)
                                                    .alpha(0)
                                                    .sizePx(mIconSize))
                .setTopMargin(mPaddingTop)
                .setBottomMargin(mPaddingBottom)
                .setLeftMargin(mPaddingLeft)
                .setRightMargin(mIconMarginRight)
                .build();

        mSelectedBlank = new MarginDrawable.Builder(new IconDrawable(getContext(),
                                                                     InsertIoIcons.icon_blank)
                                                    .alpha(0)
                                                    .sizePx(mSelectedIconSize))
                .setTopMargin(mPaddingTop)
                .setBottomMargin(mPaddingBottom)
                .setLeftMargin(mPaddingLeft)
                .setRightMargin(mIconMarginRight)
                .build();
    }

    private void init() {
        setGravity(Gravity.CENTER_VERTICAL);
    }

    /*
     * We override this method to make sure the drawables drew correctly.
     * @param canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        final boolean checked = isChecked();
        Drawable buttonDrawable = mUnSelectedDrawable;
        if (checked) {
            buttonDrawable = mSelectedDrawable;
        }

        if (buttonDrawable != null) {
            final int drawableHeight = buttonDrawable.getIntrinsicHeight();
            final int drawableWidth = buttonDrawable.getIntrinsicWidth();

            final int top = (getHeight() - drawableHeight) / 2;
            final int bottom = top + drawableHeight;
            final int left = isLayoutRtl() ? getWidth() - drawableWidth : 0;
            final int right = isLayoutRtl() ? getWidth() : drawableWidth;

            buttonDrawable.setBounds(left, top, right, bottom);

            final int scrollX = getScrollX();
            final int scrollY = getScrollY();
            if (scrollX == 0 && scrollY == 0) {
                buttonDrawable.draw(canvas);
            } else {
                canvas.translate(scrollX, scrollY);
                buttonDrawable.draw(canvas);
                canvas.translate(-scrollX, -scrollY);
            }
        }
    }

    private boolean isLayoutRtl() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1
                && (getLayoutDirection() == LAYOUT_DIRECTION_RTL);
    }

    public void setCheckedTextColor(@ColorInt int color) {
        mCheckedTextColor = color;
    }

    public void setCheckedBackgroundColor(@ColorInt int color) {
        mCheckedBackgroundColor = color;
    }

    public void setDefaultTextColor(@ColorInt int color) {
        mTextColor = color;
    }

    public void setDefaultBackgroundColor(@ColorInt int color) {
        mBackgroundColor = color;
    }

    @Override
    public void setChecked(boolean checked) {

        try {
            if (checked) {
                setBackgroundColor(mCheckedBackgroundColor);
                setTextColor(mCheckedTextColor);

                setTypeface(mSelectedTypeFace);
                setTextSize(TypedValue.COMPLEX_UNIT_PX, mSelectedTextSize);
                setButtonDrawable(mSelectedBlank);
            } else {
                setBackgroundColor(mBackgroundColor);
                setTextColor(mTextColor);

                setTypeface(mTypeFace);
                setTextSize(TypedValue.COMPLEX_UNIT_PX, mTextSize);
                setButtonDrawable(mUnSelectedBlank);
            }

            super.setChecked(checked);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }
}
