package sdk.pendo.io.utilities;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;

import sdk.pendo.io.R;
import sdk.pendo.io.async.CaptureScreenAndCompareToOldStateTask;
import sdk.pendo.io.async.CaptureScreenTask;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.socketio.configuration.IdentifyScreenData;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.views.FlashView;
import sdk.pendo.io.views.listener.FloatingListenerButton;

/**
 * Various utils for pairing flow
 */

public final class PairingUtils {

    private PairingUtils() { }

    public static void captureScreen(FloatingListenerButton pairingButton) {
        Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        View v = ViewHierarchyUtility.INSTANCE.getCurrentRootView(activity);

        CaptureScreenTask task;
        if (SocketEventFSM.getInstance().isIdentifyMode()) {
            task = createCaptureAndCompareScreenTask(activity, pairingButton);
        } else {
            task = createCaptureScreenTask(activity, pairingButton);
        }

        task.execute(v);
    }

    private static CaptureScreenTask createCaptureAndCompareScreenTask(
            Activity mActivity,
            final FloatingListenerButton pairingButton) {

        IdentifyScreenData identifyScreenData =
                SocketEventFSM.getInstance().getIdentifyScreenData();

        return new CaptureScreenAndCompareToOldStateTask(
                mActivity, identifyScreenData.conditions.getConditionsData(),
                identifyScreenData.screenIdentificationData,
                new CaptureScreenTask.CaptureScreenListener() {
                    @Override
                    public void onPreCaptureScreen() {
                        pairingButton.setVisibility(View.GONE);
                    }

                    @Override
                    public void onScreenCaptured() {
                        new FloatingListenerButton.Builder().create();
                        pairingButton.setVisibility(View.VISIBLE);
                    }
                });
    }

    private static CaptureScreenTask createCaptureScreenTask(
            Activity mActivity,
            final FloatingListenerButton pairingButton) {

        return new CaptureScreenTask(
                mActivity,
                new CaptureScreenTask.CaptureScreenListener() {
                    @Override
                    public void onPreCaptureScreen() {
                        pairingButton.setVisibility(View.GONE);
                    }

                    @Override
                    public void onScreenCaptured() {
                        pairingButton.setVisibility(View.VISIBLE);
                    }
                });
    }

    public static void showFlashScreenAndCapture() {
        InsertLogger.d("Floating Button - FLASH STATE");
        Activity mActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();

        // SocketIOManager.setIsScreenReceived(false);
        // If the view moved, then indicate that it stopped moving now.
        showFlash(mActivity);
    }

    public static void showFlash(final Activity activity) {
        activity.runOnUiThread(
                new Runnable() {
                    @Override
                    public void run() {
                        final ViewGroup root = (ViewGroup) activity
                                .findViewById(android.R.id.content);
                        final FloatingListenerButton listenerButton =
                                (FloatingListenerButton) root.findViewWithTag(activity
                                                                                      .getString(R.string.insert_pairing_buttton_name_tag));
                        FloatingListenerButton.Builder.removeActiveInstances();
                        new FlashView(activity)
                                .init(ViewHierarchyUtility.INSTANCE.getCurrentRootView(activity),
                                      listenerButton);
                    }
                }
        );
    }
}
