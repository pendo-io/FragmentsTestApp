package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import org.json.JSONObject;

import java.util.List;

import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;

/**
 * Pendo's {@link InsertCommand} analytics.
 *
 * Created by assaf on 4/6/16.
 */
public final class InsertCommandsAnalytics {
    private static volatile InsertCommandsAnalytics INSTANCE;

    public void handleCommandsAnalytics(@NonNull List<InsertCommand> commands) {

        for (InsertCommand command : commands) {

            if (isAnalyticsEventType(command.getEventType())) {
                try {
                    JSONObject moreInfo = new JSONObject();
                    moreInfo.put(AnalyticsProperties.ACTION_TYPE, command.getAction().action);
                    moreInfo.put(AnalyticsProperties.ELEMENT_ID, command.getSourceId());

                    String insertIdString = command.getParamValueFromCommand(InsertInfoConsts.GUIDE_ID);

                    if (TextUtils.isEmpty(insertIdString)) {
                        return;
                    }

                    final VisualInsertBase visualInsert = VisualInsertManager.getInstance().
                            getVisualInsert(insertIdString);

                    if (visualInsert == null) {
                        InsertLogger.w("VisualInsert is null aborting analytics.");
                        return;
                    }

                    final Tracker tracker = visualInsert.getTracker();
                    if (tracker == null) {
                        InsertLogger.w("VisualInsert tracker is null aborting analytics.");
                        return;
                    }

                    AnalyticsUtils.sendActionClickedAnalytics(
                            tracker,
                            AnalyticsEvent.INSERT_ELEMENT_CLICKED,
                            visualInsert.getDuration(),
                            moreInfo);

                    // FIXME: 4/28/16 Remove this when we get the analytics as action.
                    break;

                } catch (Exception ignore) {
                }
            }
        }
    }

    private boolean isAnalyticsEventType(InsertCommandEventType eventType) {
        return eventType.equals(InsertCommandEventType.UserEventType.TAP_ON);
    }

    private InsertCommandsAnalytics() { }
    public static synchronized InsertCommandsAnalytics getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InsertCommandsAnalytics();
        }

        return INSTANCE;
    }
}
