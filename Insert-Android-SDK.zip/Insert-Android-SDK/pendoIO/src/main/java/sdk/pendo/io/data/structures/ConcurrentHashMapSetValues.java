package sdk.pendo.io.data.structures;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * {@link ConcurrentHashMap} that store key that points to a {@link CopyOnWriteArrayList} of
 * values.
 * <p/>
 * Created by assaf on 2/24/16.
 */
public final class ConcurrentHashMapSetValues<K, V>
        extends ConcurrentHashMap<K, Set<V>> {

    /**
     * The value is inserted into the list mapped to the key. If the key is not in the map yet a new
     * {@link ConcurrentHashMap} will be created on behalf of the caller and the value will be added
     * to the list. The key will map to that list.
     *
     * @param key the key.
     * @param value the value.
     */
    public void add(K key, V value) {
        Set<V> values = getValues(key);

        if (value != null) {
            values.add(value);
        }
    }

    @Override
    public boolean containsValue(Object value) {

        /** Use super for checking for a {@link List} */
        if (value instanceof List) {
            return super.containsValue(value);


        } else {
            final Collection<Set<V>> allValues = values();

            for (Set<V> valuesList : allValues) {
                for (V v : valuesList) {
                    if (v.equals(value)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private Set<V> getValues(K key) {
        Set<V> values = get(key);

        if (values == null) {
            values = Collections.newSetFromMap(new ConcurrentHashMap<V, Boolean>());
            put(key, values);
        }

        return values;
    }
}
