package sdk.pendo.io.views;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.CornerPathEffect;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import sdk.pendo.io.R;

/**
 * The Pendo Logo, animated.
 *
 * Created by assaf on 4/19/15.
 */
public class InsertLogoView extends View {

    private final Paint mDashedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mSolidPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mRectPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Path mDashedSquarePath;
    private Path mSolidSquarePath;
    private float mOnInterval;
    private float mOffInterval;
    private float mWait;
    private int mDuration;
    private int mRadius;
    private ObjectAnimator mLogoDashAnimator;
    private float mDashedSquarePathLength;

    public InsertLogoView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public InsertLogoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.InsertLogoView, defStyleAttr, 0);
        try {
            if (a != null) {
                mDashedPaint.setStrokeWidth(a.getFloat(R.styleable.InsertLogoView_dashedStrokeWidth, 1.0f));
                mSolidPaint.setStrokeWidth(a.getFloat(R.styleable.InsertLogoView_solidStrokeWidth, 1.0f));
                mDashedPaint.setColor(a.getColor(R.styleable.InsertLogoView_dashedColor, 0xff000000));
                mSolidPaint.setColor(a.getColor(R.styleable.InsertLogoView_solidColor, 0xff000000));
                mOnInterval = a.getFloat(R.styleable.InsertLogoView_onInterval, 30.0f);
                mOffInterval = a.getFloat(R.styleable.InsertLogoView_offInterval, 30.0f);
                mDuration = a.getInt(R.styleable.InsertLogoView_duration, 4000);
                mRadius = a.getDimensionPixelSize(R.styleable.InsertLogoView_waitRadius, 50);
            }
        } finally {
            if (a != null) a.recycle();
        }

        mRectPaint.setColor(Color.WHITE);
        mRectPaint.setStyle(Paint.Style.FILL);

        init();
    }

    private void init() {
        mDashedPaint.setStyle(Paint.Style.STROKE);
        mDashedPaint.setStrokeJoin(Paint.Join.ROUND);
        mSolidPaint.setPathEffect(new CornerPathEffect(25.0f));
        mSolidPaint.setStrokeJoin(Paint.Join.ROUND);
        mSolidPaint.setStrokeCap(Paint.Cap.ROUND);
        mSolidPaint.setStyle(Paint.Style.STROKE);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        createLogoDashedSquarePath();
        createLogoSolidSquarePath();

        mLogoDashAnimator = ObjectAnimator.ofFloat(this, "wait", 1.0f, 0.0f).setDuration(mDuration);
        mLogoDashAnimator.setRepeatMode(ObjectAnimator.RESTART);
        mLogoDashAnimator.setRepeatCount(ObjectAnimator.INFINITE);
        mLogoDashAnimator.setDuration(30000);
        mLogoDashAnimator.setInterpolator(new LinearInterpolator());
        mLogoDashAnimator.start();
    }

    private void createLogoDashedSquarePath() {
        mDashedSquarePath = new Path();
        mDashedSquarePath.moveTo(0.0f, 0.0f);
        mDashedSquarePath.lineTo(mRadius * 6.0f, 0.0f);
        mDashedSquarePath.lineTo(mRadius * 6.0f, mRadius * 6.0f);
        mDashedSquarePath.lineTo(0.0f, mRadius * 6.0f);
        mDashedSquarePath.lineTo(0.0f, 0.0f);
        mDashedSquarePath.close();

        mDashedSquarePathLength = new PathMeasure(mDashedSquarePath, false).getLength();
    }

    private void createLogoSolidSquarePath() {
        mSolidSquarePath = new Path();
        mSolidSquarePath.moveTo(0.0f, 0.0f);
        mSolidSquarePath.lineTo(mRadius * 6.0f, 0.0f);
        mSolidSquarePath.lineTo(mRadius * 6.0f, mRadius * 6.0f);
        mSolidSquarePath.lineTo(0.0f, mRadius * 6.0f);
        mSolidSquarePath.lineTo(0.0f, 0.0f);
        mSolidSquarePath.close();
    }

    private static PathEffect createPathEffect(float pathLength, float onInterval, float offInterval, float phase, float offset) {
        return new DashPathEffect(new float[] { onInterval, offInterval },
                Math.max(phase * pathLength, offset));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Draw the dashed square.
        canvas.save();
        canvas.translate(getWidth() / 2.0f - mRadius * 2.0f, getHeight() / 2.0f - mRadius * 2.0f);
        canvas.drawPath(mDashedSquarePath, mDashedPaint);

        // Draw the solid square.
        canvas.restore();
        canvas.translate(getWidth() / 2.0f - mRadius * 4.0f, getHeight() / 2.0f - mRadius * 4.0f);
        canvas.drawRect(0, 0, mRadius * 6.0f, mRadius * 6.0f, mRectPaint);
        canvas.drawPath(mSolidSquarePath, mSolidPaint);
    }

    public float getWait() {
        return mWait;
    }

    public void setWait(float wait) {
        mWait = wait;
        mDashedPaint.setPathEffect(createPathEffect(mDashedSquarePathLength, mOnInterval, mOffInterval, mWait, mOffInterval));

        invalidate();
    }
}
