package sdk.pendo.io.network.socketio;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;

import external.sdk.pendo.io.okhttp3.OkHttpClient;
import external.sdk.pendo.io.socket.client.IO;
import external.sdk.pendo.io.socket.client.Socket;
import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.listeners.CaptureModeEnterListener;
import sdk.pendo.io.network.socketio.listeners.CaptureModeExitListener;
import sdk.pendo.io.network.socketio.listeners.CaptureModeScreenRecievedListener;
import sdk.pendo.io.network.socketio.listeners.ConnectionErrorListener;
import sdk.pendo.io.network.socketio.listeners.ErrorListener;
import sdk.pendo.io.network.socketio.listeners.IdentifyModeEnterListener;
import sdk.pendo.io.network.socketio.listeners.IdentifyModeExitListener;
import sdk.pendo.io.network.socketio.listeners.PairedModeUpdateListener;
import sdk.pendo.io.network.socketio.listeners.PreviewOnDeviceListener;
import sdk.pendo.io.network.socketio.listeners.ResetStateListener;
import sdk.pendo.io.network.socketio.listeners.SocketIOConnectedListener;
import sdk.pendo.io.network.socketio.listeners.SocketIODisconnectedListener;
import sdk.pendo.io.network.socketio.listeners.SocketIOTerminateListener;
import sdk.pendo.io.network.socketio.listeners.TestModeEnterListener;
import sdk.pendo.io.network.socketio.listeners.TestModeExitListener;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.utilities.InsertEndpointUtil;
import sdk.pendo.io.utilities.SettingsUtils;
import sdk.pendo.io.views.listener.FloatingListenerButton;

/**
 * Manager for Socket IO.
 * <p/>
 * Created by assaf on 4/19/15.
 */
public final class SocketIOManager {
    /*Constants*/
    public static final String SOCKET_QUERY_PARAM_AUTH_TOKEN = "token=";
    public static final String SOCKET_QUERY_PARAM_SESSION_TOKEN = "sessionToken=";
    public static final int SOCKET_TIMEOUT = 10000;
    public static final String ERROR_TAG = "error";
    public static final int SSL_PORT = 443;
    public static final String HTTPS_SCHEME = "https";
    public static final String VERSION_PARAM = "version";
    public static final String VERSION_2 = "v2";
    public static final String APP_VERSION_PARAM = "appVersion";
    private static final Object LOCK = new Object();
    public static final String WEBSOCKET_TRANSPORT = "websocket";
    public static final String SOCKET_QUERY_DELIMITER = "&";
    public static final String SOCKET_PATH = "/ws/socket.io"; // hard-coded socket.io path, requested and approved by Udi.
    private static volatile SocketIOManager sInstance;
    private volatile Socket mSocket;
    private static InsertAction sPreviewInsert;
    private SocketIOConnectedListener mOnConnectedListener = new SocketIOConnectedListener();
    private SocketIODisconnectedListener mOnDisconnectedListener = new SocketIODisconnectedListener();
    private SocketIOTerminateListener mOnTerminateListener = new SocketIOTerminateListener();
    private PairedModeUpdateListener mPairedModeUpdateListener = new PairedModeUpdateListener();
    private ResetStateListener mResetStateListener = new ResetStateListener();
    private PreviewOnDeviceListener mPreviewOnDeviceListener = new PreviewOnDeviceListener();
    private CaptureModeEnterListener mCaptureModeEnterListener = new CaptureModeEnterListener();
    private CaptureModeExitListener mCaptureModeExitListener = new CaptureModeExitListener();
    private CaptureModeScreenRecievedListener mCaptureModeScreenRecievedListener = new CaptureModeScreenRecievedListener();
    private TestModeEnterListener mOnTestModeEnterListener = new TestModeEnterListener();
    private TestModeExitListener mOnTestModeExitListener = new TestModeExitListener();
    private IdentifyModeEnterListener mOnIdentifyModeEnterListener = new IdentifyModeEnterListener();
    private IdentifyModeExitListener mOnIdentifyModeExitListener = new IdentifyModeExitListener();
    private ErrorListener mOnErrorListener = new ErrorListener();
    private ConnectionErrorListener mOnConnectionErrorListener = new ConnectionErrorListener();

    public static SocketIOManager getInstance() {
        SocketIOManager result = sInstance;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = sInstance;
                if (result == null) { // 2nd check (w/ lock)
                    //noinspection CheckStyle
                    sInstance = result = new SocketIOManager();
                }
            }
        }
        return result;
    }

    private SocketIOManager() {
        // For testing if a custom socket url exists use it instead of production endpoint
        String customSocketUrl = SettingsUtils.getCustomSocketUrl(Pendo.getApplicationContext());
        if (!TextUtils.isEmpty(customSocketUrl)) {
            URI customEndpointUri = URI.create(customSocketUrl);
            if (customEndpointUri != null) {
                SocketIOUtils.setCustomServerEnpdpoint(InsertEndpointUtil.INSTANCE.getCustomSocketUri());
            }
        }

        // Initiating the socket event FSM
        SocketEventFSM.getInstance();
    }


    public void terminateSession() {
        removePairedButtonInstances();
        SocketEventFSM.getInstance().setInitialState();
    }

    public void removePairedButtonInstances() {
        final Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        if (currentActivity != null) {
            FloatingListenerButton.Builder.removeActiveInstances();
        }
    }

    public void terminateSessionAndReInit() {
        terminateSession();
        BackendApiManager.getInstance().startBackendInitialization(true);
    }

    /**
     * Emits an event.
     * When you pass {@link external.sdk.pendo.io.socket.client.Ack} at the last argument,
     * then the acknowledge is done.
     *
     * @param event an event name.
     * @param args  data to send.
     * @return a reference to this object.
     */
    public Emitter emit(String event, Object... args) {
        return mSocket.emit(event, args);
    }

    public synchronized void setupSocket() throws URISyntaxException {
        disconnect();

        // Remove connect and disconnect listeners.
        if (mSocket != null) {
            mSocket.off();
        }


        // We are calling connect only if we have an access token
        IO.Options options = new IO.Options();
        options.reconnection = true;
        options.reconnectionDelay = TimeUnit.SECONDS.toMillis(2);
        options.forceNew = false;

        // Adding access token
        String s = SOCKET_QUERY_PARAM_AUTH_TOKEN
                + RestAPI.getAccessToken()
                + SOCKET_QUERY_DELIMITER
                + SOCKET_QUERY_PARAM_SESSION_TOKEN
                + SocketIOUtils.getSessionToken()
                + SOCKET_QUERY_DELIMITER
                + VERSION_PARAM + "="
                + VERSION_2
                + SOCKET_QUERY_DELIMITER
                + APP_VERSION_PARAM + "="
                + AndroidUtils.getAppVersionName();
        InsertLogger.d("sending this query to the socket " + s);
        options.query = s;

        URI serverURI = new URI(SocketIOUtils.getServerURI().toString());

        String scheme = serverURI.getScheme();
        // In case it is an http scheme use secure option
        if (!TextUtils.isEmpty(scheme) && scheme.equals(HTTPS_SCHEME)) {
            options.secure = true;
            try {
                OkHttpClient okHttpClient = RestAPI.getBaseOkHttpClient();
                options.callFactory = okHttpClient;
                options.webSocketFactory = okHttpClient;
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

        // Use websocket as transport
        options.transports = new String[]{WEBSOCKET_TRANSPORT};

        // Adding timeout
        options.timeout = SOCKET_TIMEOUT;

        // Adding hard-coded path:
        // if the path ('/ws/socket.io') was part of the url, socket.io would treat it as the socket namespace which we do not want.
        // therefore it was decided (by Udi) not to include it in the server url and just hard-code it to the options.path
        options.path = SOCKET_PATH;

        InsertLogger.d("opening socket to " + serverURI.toString());
        mSocket = IO.socket(serverURI, options);

        // Standard socket events
        mSocket.on(Socket.EVENT_CONNECT, mOnConnectedListener);
        mSocket.on(Socket.EVENT_RECONNECT, mOnConnectedListener);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, mOnErrorListener);
        mSocket.on(Socket.EVENT_DISCONNECT, mOnDisconnectedListener);
        mSocket.on(Socket.EVENT_CONNECT_ERROR, mOnConnectionErrorListener);
        mSocket.on(Socket.EVENT_RECONNECT_ERROR, mOnConnectionErrorListener);
        mSocket.on(Socket.EVENT_RECONNECT_FAILED, mOnConnectionErrorListener);
        mSocket.on(Socket.EVENT_ERROR, mOnErrorListener);

        // Proprietary events
        mSocket.on(SocketEvents.EVENT_PAIRED_MODE_UPDATE.getCommand(), mPairedModeUpdateListener);
        mSocket.on(SocketEvents.EVENT_RESET_STATE.getCommand(), mResetStateListener);
        mSocket.on(SocketEvents.EVENT_PREVIEW_ON_DEVICE.getCommand(), mPreviewOnDeviceListener);
        mSocket.on(SocketEvents.EVENT_CAPTURE_MODE_ENTER.getCommand(), mCaptureModeEnterListener);
        mSocket.on(SocketEvents.EVENT_CAPTURE_MODE_EXIT.getCommand(), mCaptureModeExitListener);
        mSocket.on(SocketEvents.EVENT_CAPTURE_MODE_SCREEN_RECEIVED.getCommand(), mCaptureModeScreenRecievedListener);
        mSocket.on(SocketEvents.EVENT_TEST_MODE_ENTER.getCommand(), mOnTestModeEnterListener);
        mSocket.on(SocketEvents.EVENT_TEST_MODE_EXIT.getCommand(), mOnTestModeExitListener);
        mSocket.on(SocketEvents.EVENT_IDENTIFY_MODE_ENTER.getCommand(), mOnIdentifyModeEnterListener);
        mSocket.on(SocketEvents.EVENT_IDENTIFY_MODE_EXIT.getCommand(), mOnIdentifyModeExitListener);
        mSocket.on(SocketEvents.EVENT_TERMINATE.getCommand(), mOnTerminateListener);
        mSocket.on(SocketEvents.EVENT_INVALID.getCommand(), mOnErrorListener);
    }


    /**
     * Adds a one time listener for the event.
     *
     * @param event    an event name.
     * @param listener the listener.
     * @return a reference to this object.
     */
    public Emitter once(String event, Emitter.Listener listener) {
        return mSocket.once(event, listener);
    }

    /**
     * Listens on the event.
     *
     * @param event    event name.
     * @param listener the listener.
     * @return a reference to this object.
     */
    public Emitter addListener(String event, Emitter.Listener listener) {
        return mSocket.on(event, listener);
    }

    /**
     * Removes the listener.
     *
     * @param event    an event name.
     * @param listener the listener.
     * @return a reference to this object.
     */
    @SuppressWarnings("unused")
    public Emitter removeListener(String event, Emitter.Listener listener) {
        return mSocket.off(event, listener);
    }

    /**
     * Removes all listeners of the specified event.
     *
     * @param event an event name.
     * @return a reference to this object.
     */
    public Emitter removeAll(String event) {
        return mSocket.off(event);
    }

    public synchronized void connect() {
            try {
                setupSocket();
            } catch (URISyntaxException e) {
                InsertLogger.e(e, "Error while trying to setup socket");
            }
            if (mSocket != null) {
                mSocket.connect();
            }
    }

    /**
     * @return True if the socket is connected, false otherwise.
     */
    @SuppressWarnings("unused")
    public boolean isConnected() {
        return mSocket.connected();
    }

    /**
     * Disconnects the socket.
     */
    public synchronized void disconnect() {

        if (mSocket != null) {
            mSocket.disconnect();
            killSocket();
        }
    }

    public void killSocket() {
        if (mSocket != null) {
            mSocket.off();
            mSocket.close();
            mSocket = null;
        }
    }
}
