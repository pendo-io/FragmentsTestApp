package sdk.pendo.io.actions;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import org.apache.commons.lang3.tuple.Pair;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.events.InsertEvent.EventActions;
import sdk.pendo.io.events.ScreenDisplayDurationManager;
import sdk.pendo.io.intelligence.ViewIntel;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.listeners.views.InsertDrawerListener;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.ActivationModel;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.network.responses.TriggerModel;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.ActivityUtils;
import sdk.pendo.io.utilities.ElementUtils;
import sdk.pendo.io.utilities.TriggerUtils;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.DISMISS_INSERT;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.HOST_APP_DEVELOPER_CALL;
import static sdk.pendo.io.actions.handlers.InsertGlobalCommandHandler.INSERT_GLOBAL_COMMAND_DEST;
import static sdk.pendo.io.constants.Constants.GeneralConsts.IRRELEVANT;
import static sdk.pendo.io.events.InsertEvent.EventActions.PREVIEW;

/**
 * Pendo's action manager.
 * <p>
 * Created by assaf on 4/30/15.
 */
public final class InsertsManager {

    private static final AtomicBoolean S_ACTIVITY_DESTROYED = new AtomicBoolean(false);

    private static volatile InsertsManager INSTANCE;

    private static Map<String, InsertAction> sInserts = new HashMap<>();
    private volatile HashSet<String> mFullyDisplayedInsertsAfterAnimation = new HashSet<>();

    private static Map<String, BehaviorSubject<Boolean>> sInsertInited = new HashMap<>();
    private static final Object INSERT_INITED_LOCK = new Object();

    static Observable<Boolean> getVisualGuideStepInitedAsObservable(String guideStepId) {
        synchronized (INSERT_INITED_LOCK) {
            if (!sInsertInited.containsKey(guideStepId)) {
                BehaviorSubject<Boolean> finishedLoadingImages = BehaviorSubject.createDefault(false);
                sInsertInited.put(guideStepId, finishedLoadingImages);
            }
            return sInsertInited.get(guideStepId);
        }
    }

    public static void setVisualGuideStepInited(String guideStepId, boolean isInited) {
        synchronized (INSERT_INITED_LOCK) {
            if (!guideStepId.isEmpty()) {
                BehaviorSubject<Boolean> finishedInitializingInsert = BehaviorSubject.createDefault(isInited);
                if (!sInsertInited.containsKey(guideStepId)) {
                    sInsertInited.put(guideStepId, finishedInitializingInsert);
                } else {
                    sInsertInited.get(guideStepId).onNext(isInited);
                }
            }
        }
    }

    static void removeVisualInsertInitedObservable(String insertId) {
        synchronized (INSERT_INITED_LOCK) {
            if (!insertId.isEmpty()) {
                BehaviorSubject<Boolean> removedItem = sInsertInited.remove(insertId);
                if (removedItem != null) {
                    removedItem.onComplete();
                }
            }
        }
    }

    private InsertsManager(@NonNull Map<String, InsertAction> inserts) {

        //Initialize the visual inserts' FSM.
    }

    public static synchronized InsertsManager getInstance()
            throws IllegalStateException {
        if (INSTANCE == null) {
            throw new IllegalStateException("Need to be instantiated first!");
        }
        return INSTANCE;
    }

    public static synchronized void init(@NonNull Map<String, InsertAction> inserts)
            throws IllegalStateException {

        if (INSTANCE == null) {
            INSTANCE = new InsertsManager(inserts);
        } else {
            InsertLogger.w("Cannot init more than once.");
            throw new IllegalStateException("InsertsManager already initiated.");
        }
    }

    public static synchronized boolean isInited() {
        return INSTANCE != null;
    }

    public static boolean isActivityDestroyed() {
        return S_ACTIVITY_DESTROYED.getAndSet(false);
    }

    public boolean wasInsertFullyDisplayedAfterAnimation(String insertId) {
        return mFullyDisplayedInsertsAfterAnimation.contains(insertId);
    }

    public void setInsertFullyDisplayedAfterAnimation(String guideId) {
        mFullyDisplayedInsertsAfterAnimation.add(guideId);
    }

    public void removeInsertFullyDisplayedAfterAnimation(String insertId) {
        mFullyDisplayedInsertsAfterAnimation.remove(insertId);
    }

    public void dismissVisibleGuides() {
        if (!isInited()) {
            throw new IllegalStateException(
                    "Pendo SDK must be initialized before calling this method.");
        }

        InsertCommandDispatcher.getInstance()
                .dispatchCommand(new InsertCommand.Builder(DISMISS_INSERT, HOST_APP_DEVELOPER_CALL)
                        .setSourceId(VisualInsert.DISMISS_VISIBLE_INSERTS)
                        .setDestinationId(INSERT_GLOBAL_COMMAND_DEST)
                        .build(), true);
    }

    /**
     * dispatches trigger commands.
     *
     * @param insertEvent   - the trigger event.
     * @param triggers      - trigger model list.
     * @param forceDispatch
     * @param parameters    - passed in case of custom event.
     */
    private void dispatchTriggerCommands(InsertEvent insertEvent,
                                         List<TriggerModel> triggers, boolean forceDispatch,
                                         @Nullable Map<String, String> parameters) {
        if (triggers == null) {
            triggers = insertEvent.getTriggers();
        }

        if (triggers != null) {
            for (TriggerModel triggerModel : triggers) {
                if (triggerModel != null) {
                    // Protecting from a preview on device scenario
                    // (which has no trigger for the insert)
                    // Dispatch the trigger's actions in case trigger is valid
                    if (!forceDispatch
                            && EventsManager.getInstance().wasTriggerDispatched(
                            triggerModel.getId())) {
                        continue;
                    }
                    triggerModel.dispatchCommands(parameters);

                    TriggerUtils.handleTriggerFlow(triggerModel);
                }
            }
        }
    }

    protected Map<String, InsertAction> getInserts() {
        return sInserts;
    }

    public static InsertAction getInsert(String insertId) {
        return sInserts.get(insertId);
    }

    @NonNull
    public List<Pair<InsertAction, TriggerModel>> getInserts(InsertEvent insertEvent,
                                                             @Nullable View rootView) {
        List<Pair<InsertAction, TriggerModel>> insertActionTriggerPairs = new ArrayList<>();

        if (insertEvent.getTriggers() != null) {
            for (TriggerModel trigger : insertEvent.getTriggers()) {
                if (trigger.satisfiesFlow()) {
                    if (TriggerUtils.satisfiesAllConditions(trigger, rootView)) {
                        for (String insertId : trigger.getInsertIds()) {
                            insertActionTriggerPairs.add(Pair.of(sInserts.get(insertId), trigger));
                        }
                    }
                }
            }
        }
        return insertActionTriggerPairs;
    }

    public void runScreenLeftTrigger(TriggerModel trigger) {
        if (ActivationManager.INSTANCE.isInited()) {
            ScreenDisplayDurationManager.getInstance()
                    .setScreenFinalDisplayDuration(trigger.getScreenId());
            List<TriggerModel> triggerList = new ArrayList<>();
            triggerList.add(trigger);
            dispatchTriggerCommands(null, triggerList, false, null);
        }
    }

}
