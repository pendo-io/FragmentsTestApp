@file:JvmName("JsonUtils")
package sdk.pendo.io.utilities

import com.google.gson.JsonArray
import com.google.gson.JsonObject


class InsertJsonException(override var message: String) : Exception(message)

@Throws(InsertJsonException::class)
fun getString(jsonObject: JsonObject, key: String): String {
    val optString = optString(jsonObject, key)
    if (optString == null) {
        throw InsertJsonException("Json Exception. Key: " + key + "doesn't exist.")
    } else {
        return optString
    }
}



@JvmOverloads
fun optString(jsonObject: JsonObject, key: String, defaultVal: String? = null): String? {
    return try {
        jsonObject.get(key).asString
    } catch (e: Exception) {
        defaultVal
    }


}

fun optBoolean(jsonObject: JsonObject, key: String, defaultVal: Boolean): Boolean {
    return try {
        jsonObject.get(key).asBoolean
    } catch (e: Exception) {
        defaultVal
    }
}

fun optJsonArray(jsonObject: JsonObject, key: String): JsonArray? {
    return try {
        jsonObject.getAsJsonArray(key)
    } catch (e: Exception) {
        null
    }
}

fun optJsonObject(jsonArray: JsonArray, index: Int): JsonObject? {
    return try {
        jsonArray.get(index).asJsonObject
    } catch (e: Exception) {
        null
    }
}







