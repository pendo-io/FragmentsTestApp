package sdk.pendo.io.reactive.filters;

import android.app.Activity;

import io.reactivex.functions.Predicate;
import sdk.pendo.io.events.ActivityModel;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.utilities.ViewHierarchyUtility;

/**
 * Filter that returns true if an Activity has a ListView inside its view hierarchy.
 * Created by itayvallach on 09/11/2016.
 */

public class HasListViewFilter implements Predicate<Object> {

    private final Activity mActivity;

    public HasListViewFilter(Activity activity) {
        mActivity = activity;
    }

    @Override
    public boolean test(Object nil) {
        if (mActivity != null) {
            ActivityModel activityModel = EventsManager.getInstance()
                    .getActivityModelByName(mActivity.getLocalClassName());

            if (activityModel != null) {
                activityModel.checkIfListViewExists(ViewHierarchyUtility.INSTANCE
                                                            .getCurrentRootView(mActivity));
                return activityModel.hasListView();

            } else {
                return false;
            }

        } else {
            return false;
        }
    }

}
