package sdk.pendo.io.analytics;

import android.support.annotation.Nullable;
import android.text.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.sdk.manager.ScreenManager;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.EXTERNAL_ENDPOINT_URL;

/**
 * This class represents the analytics data we collect and send.
 *
 * Created by assaf on 7/6/15.
 */
public class InsertAnalyticsData {

    // The analytics event.
    private final String mEvent;

    // Always present values:
    private long mTimestamp = -1;

    // Additional information:
    private final JSONObject mAdditionalInfo;

    @Nullable
    private GenericInsertAnalyticsData mGenericInsertAnalytics;

    @Nullable
    private JSONObject mAnalyticsData;

    @Nullable
    private String mEndpointUrl;

    public InsertAnalyticsData(GenericInsertAnalyticsData genericAnalytics, Tracker.TrackerInfo trackerInfo) {
        mGenericInsertAnalytics = genericAnalytics;
        mEvent = trackerInfo.getEvent();
        mAdditionalInfo = trackerInfo.getSpecificAnalytics();
        mEndpointUrl = trackerInfo.getEndpointUrl();
        mTimestamp = trackerInfo.getTimestamp();
    }

    public InsertAnalyticsData(JSONObject analyticsData, Tracker.TrackerInfo trackerInfo) {
        mAnalyticsData = analyticsData;
        mEvent = trackerInfo.getEvent();
        mAdditionalInfo = trackerInfo.getSpecificAnalytics();
        mEndpointUrl = trackerInfo.getEndpointUrl();
        mTimestamp = trackerInfo.getTimestamp();
    }

    public JSONObject convertToJSONObject() {
        JSONObject jsonObject = new JSONObject();
        try {

            if (mEvent != null && mEvent.equals(AnalyticsEvent.TRACK_EVENT.getValue())) {
                // Used for track events new API.
                // No need to put any event here as it was already pre populated.
            }

            jsonObject.put(AnalyticsProperties.TIMESTAMP, mTimestamp);

            if (mAnalyticsData != null && mAnalyticsData.toString().contains(AnalyticsProperties.RETROACTIVE_SCREEN_DATA)) {
                jsonObject.put(AnalyticsProperties.RETROACTIVE_SCREEN_ID, ScreenManager.INSTANCE.getCurrentScreenId());
            }

            if (mGenericInsertAnalytics != null) {
                // Adding generic insert analytics to the json object
                mGenericInsertAnalytics.addInsertValues(jsonObject, mEvent);
            }

            if (mAnalyticsData != null) {
                Iterator<String> keys = mAnalyticsData.keys();

                if (keys != null) {
                    while (keys.hasNext()) {
                        String key = keys.next();
                        jsonObject.put(key, mAnalyticsData.get(key));
                    }
                }
            }

            if (mAdditionalInfo != null) {
                Iterator<String> keys = mAdditionalInfo.keys();

                if (keys != null) {
                    while (keys.hasNext()) {
                        String key = keys.next();
                        jsonObject.put(key, mAdditionalInfo.get(key));
                    }
                }
            }

            if (!TextUtils.isEmpty(mEndpointUrl)) {
                jsonObject.put(EXTERNAL_ENDPOINT_URL, mEndpointUrl);
            }

            if (mEvent.equals(AnalyticsEvent.APP_SESSION_END.getValue())) {
                jsonObject.put(AnalyticsProperties.SEND_MODE, AnalyticsProperties.SEND_MODE_BUFFER);
            }

            return jsonObject;
        } catch (JSONException e) {
            InsertLogger.e(e.getMessage());
        }

        return null;
    }
}
