package sdk.pendo.io.utilities.script;

import external.sdk.pendo.io.mozilla.javascript.BaseFunction;
import external.sdk.pendo.io.mozilla.javascript.Context;
import external.sdk.pendo.io.mozilla.javascript.NativeJavaClass;
import external.sdk.pendo.io.mozilla.javascript.NativeJavaObject;
import external.sdk.pendo.io.mozilla.javascript.Scriptable;
import external.sdk.pendo.io.mozilla.javascript.ScriptableObject;
import external.sdk.pendo.io.mozilla.javascript.WrapFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import sdk.pendo.io.logging.InsertLogger;

/**
 * Pendo's sandbox wrapper for the {@link WrapFactory} class.
 * Rhino will call the methods of this class whenever it needs to wrap a value
 * resulting from a call to a Java method or an access to a Java field.
 *
 * @see external.sdk.pendo.io.mozilla.javascript.Context#setWrapFactory(WrapFactory)
 * Created by assaf on 11/6/16.
 */
class JavascriptSandboxWrapFactory extends WrapFactory {

    private final ScriptSandbox mShutter;
    private final Set<Class<?>> mReplacedClasses = new HashSet<>();

    JavascriptSandboxWrapFactory(ScriptSandbox shutter) {
        mShutter = shutter;
    }

    @Override
    public Scriptable wrapNewObject(Context cx, Scriptable scope, Object obj) {
        ensureReplacedClass(scope, obj, null);
        return super.wrapNewObject(cx, scope, obj);
    }

    @Override
    public Object wrap(Context cx, Scriptable scope, Object obj, Class<?> staticType) {
        ensureReplacedClass(scope, obj, staticType);
        return super.wrap(cx, scope, obj, staticType);
    }

    @Override
    public Scriptable wrapAsJavaObject(Context cx, Scriptable scope, Object javaObject,
                                       Class<?> staticType) {
        final Class<?> type = ensureReplacedClass(scope, javaObject, staticType);

        return new NativeJavaObject(scope, javaObject, staticType) {
            private final Map<String, Boolean> mInstanceMethodToAllowed = new HashMap<>();

            @Override
            public Object get(String name, Scriptable scope) {
                Object wrapped = super.get(name, scope);

                if (wrapped instanceof BaseFunction) {
                    String id = type.getName() + "." + name;
                    Boolean allowed = mInstanceMethodToAllowed.get(id);

                    if (allowed == null) {

                        // Check if the method is allowed.
                        allowed = mShutter.allowMethodAccess(type, javaObject, name);
                        mInstanceMethodToAllowed.put(id, allowed);
                    }

                    if (!allowed) {
                        return NOT_FOUND;
                    }
                } else {
                    // NativeJavaObject + only boxed primitive types?
                    if (!mShutter.allowFieldAccess(type, javaObject, name)) {
                        return NOT_FOUND;
                    }
                }

                return wrapped;
            }
        };
    }

    private Class<?> ensureReplacedClass(Scriptable scope, Object obj,
                                         Class<?> staticType) {

        final Class<?> type = (staticType == null && obj != null) ? obj
                .getClass() : staticType;

        if (type != null && !type.isPrimitive()
                && !type.getName().startsWith("java.")
                && mReplacedClasses.add(type)) {

            replaceJavaNativeClass(type, scope);
        }

        return type;
    }

    private void replaceJavaNativeClass(final Class<?> type, Scriptable scope) {

        Object clazz = Context.jsToJava(ScriptableObject.getProperty(scope, "Packages"),
                                        Object.class);
        Object holder = null;
        for (String part : type.getName().split("\\.")) {
            holder = clazz;
            clazz = ScriptableObject.getProperty((Scriptable) clazz, part);
        }
        NativeJavaClass nativeClass;

        nativeClass = new NativeJavaClass(scope, type) {

            @Override
            public Object get(String name, Scriptable start) {
                Object wrapped = super.get(name, start);

                if (wrapped instanceof BaseFunction) {
                    // Check if static method is allowed.
                    if (!mShutter.allowStaticMethodAccess(type, name)) {
                        return NOT_FOUND;
                    }
                } else {
                    // NativeJavaObject + only boxed primitive types?
                    if (!mShutter.allowStaticFieldAccess(type, name)) {
                        return NOT_FOUND;
                    }
                }

                return wrapped;
            }
        };

        if (holder == null) {
            InsertLogger.d("Holder is null, bailing out.");
            return;
        }

        ScriptableObject.putProperty((Scriptable) holder,
                                     type.getSimpleName(),
                                     nativeClass);

        ScriptableObject.putProperty(scope,
                                     type.getSimpleName(),
                                     nativeClass);
    }
}
