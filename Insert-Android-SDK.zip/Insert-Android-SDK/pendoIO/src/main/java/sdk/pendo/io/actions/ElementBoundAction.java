package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import sdk.pendo.io.actions.visual_manipulation.ChangeTextAction;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.constants.Constants;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.network.responses.ElementModel;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Abstract class for action that are bound to specific elements on the screen
 * (e.g. {@link },
 * {@link ChangeTextAction}).
 *
 * <pre>
 * The action must have the property:
 * <code>{
 *     "name": "element",
 *     "type": "string",
 *     "value": "{}"
 * }
 * </code>
 * </pre>
 * Created by assaf on 12/1/15.
 */
public abstract class ElementBoundAction {

    /** Relevant base properties. */
    private static final HashSet<String> PROPERTIES =
            new HashSet<>(Arrays.asList(new String[] {
                    Constants.ViewAttrsConsts.ID,
                    Constants.SpecialViewAttrsConsts.ELEMENT
            }));

    private final HashMap<String, Object> mElementBoundProperties = new HashMap<>();

    public ElementBoundAction(JsonArray properties) {
        extractProperties(properties, mElementBoundProperties, PROPERTIES);
    }

    public final String getId() {
        return (String) mElementBoundProperties.get(Constants.ViewAttrsConsts.ID);
    }

    @Nullable
    public final IdentificationData getViewIdentificationData() {

        final String elementStr = (String) mElementBoundProperties
                .get(Constants.SpecialViewAttrsConsts.ELEMENT);

        try {
            JSONObject elementJson = new JSONObject(elementStr);

            final int screenId = elementJson.optInt("screenId", -1);
            if (screenId == -1) {
                InsertLogger.w("Did not get screen id.");
                // TODO: 10/21/15 Error analytics.
                return null;
            }

            final int elementId = elementJson.optInt("elementId", -1);
            if (elementId == -1) {
                InsertLogger.w("Did not get element id.");
                // TODO: 10/21/15 Error analytics.
                return null;
            }

            String screenName = EventsManager.getInstance().getScreenNameFromId(screenId);

            if (screenName == null) {
                InsertLogger.w("Cannot find the screen name from the given ID: '"
                        + elementJson.getInt("screenId") + "'.");
                // TODO: 10/21/15 Error analytics.
                return null;
            }

            final ElementModel elementModel = EventsManager.getInstance()
                    .getElementByScreenNameAndElementId(screenName, elementId);

            if (elementModel == null) {
                InsertLogger.w("Cannot find the element for the given ID: '"
                        + elementId + "' and screen: '" + screenName + "'.");
                // TODO: 10/21/15 Error analytics.
                return null;
            }

            return elementModel.configuration.getIdentificationData();

        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }

        return null;
    }

    public static void extractProperties(@NonNull JsonArray properties,
                                         @NonNull HashMap<String, Object> elementBoundProperties,
                                         @NonNull HashSet<String> relevantProperties) {

        if (properties != null) {
            for (JsonElement property : properties) {

                if (property.isJsonObject()) {
                    final JsonObject jsonObject = property.getAsJsonObject();
                    String name = jsonObject.get(Constants.DynamicViewsConsts.NAME).getAsString();

                    if (!relevantProperties.contains(name)) {
                        continue;
                    }

                    String type = jsonObject.get(Constants.DynamicViewsConsts.TYPE).getAsString();
                    JsonElement value = jsonObject
                            .get(Constants.DynamicViewsConsts.VALUE);

                    if (Constants.SpecialViewAttrTypeConsts.JSON.equals(type)) {
                        elementBoundProperties.put(name, value.getAsJsonObject());
                    } else {
                        elementBoundProperties.put(name, value.getAsString());
                    }

                    if (elementBoundProperties.size() == relevantProperties.size()) {
                        break;
                    }
                }
            }
        }
    }

    public abstract boolean runInsert(final GenericInsertAnalyticsData iga, final View view);
}
