package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

/**
 * Created by itayvallach on 26/06/2016.
 *
 * This class represents the model of the direct link data we get on
 * a push notification
 */
public class ShowInsertLinkData {

    @SerializedName("link")
    private String mLink;

    public String getLink() {
        return mLink;
    }
}
