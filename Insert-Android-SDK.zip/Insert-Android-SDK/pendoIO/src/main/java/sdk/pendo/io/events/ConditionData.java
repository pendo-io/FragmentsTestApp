package sdk.pendo.io.events;

import android.support.annotation.Nullable;
import com.google.gson.annotations.SerializedName;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by itayvallach on 07/08/2016.
 *
 * This class represents the data of a condition which is located inside a trigger.
 */
public class ConditionData {

    @SerializedName("type")
    private String mType;

    @SerializedName("typeValue")
    private IdentificationData mTypeValue;

    @SerializedName("operator")
    private String mOperator;

    @SerializedName("parameters")
    private ConditionParam[] mParameters;

    public static final String NUMBER_VALUE = "number";
    public static final String STRING_VALUE = "string";

    public String getType() {
        return mType;
    }

    public IdentificationData getTypeValue() {
        return mTypeValue;
    }

    public String getOperator() {
        return mOperator;
    }

    public ConditionParam[] getParameters() {
        return mParameters;
    }

    public enum Operator {
        EXISTS("exists"),
        NOT_EXISTS("notExists"),


        // String operations.
        STR_EQUALS("strEquals"),
        STR_NOT_EQUALS("strNotEquals"),
        STARTS_WITH("startsWith"),
        ENDS_WITH("endsWith"),
        CONTAINS("contains"),
        NOT_CONTAINS("notContaining"),

        //Numeric operations.
        NUM_EQUALS("numEquals"),
        NUM_NOT_EQUALS("numNotEquals"),
        LESS_THAN("lessThan"),
        LESS_THAN_OR_EQUALS("lessThanOrEquals"),
        GREATER_THAN("greaterThan"),
        GREATER_THAN_OR_EQUALS("greaterThanOrEquals");

        private final String mOperator;

        private static final Map<String, Operator> LOOKUP_TABLE = new HashMap<>();

        static {
            for (Operator s : EnumSet.allOf(Operator.class)) {
                LOOKUP_TABLE.put(s.mOperator, s);
            }
        }

        Operator(String type) {
            this.mOperator = type;
        }

        public boolean equals(Operator operator) {
            return this.mOperator.equals(operator.mOperator);
        }

        @Nullable
        public static Operator get(String operator) {
            return LOOKUP_TABLE.get(operator);
        }
    }

    public enum ConditionType {
        ELEMENT_INFO(IdentificationData.SERIALIZED_NAME),
        SCRIPT("script"),
        SHARED_PREFERENCE("sharedPreferences");

        private final String mConditionType;

        private static final Map<String, ConditionType> LOOKUP_TABLE = new HashMap<>();

        static {
            for (ConditionType t : EnumSet.allOf(ConditionType.class)) {
                LOOKUP_TABLE.put(t.mConditionType, t);
            }
        }

        ConditionType(String type) {
            this.mConditionType = type;
        }

        public boolean equals(ConditionType type) {
            return this.mConditionType.equals(type.mConditionType);
        }

        @Nullable
        public static ConditionType get(String type) {
            return LOOKUP_TABLE.get(type);
        }
    }

    public class ConditionParam {

        @SerializedName("type")
        private String mType;

        @SerializedName("value")
        private String mValue;

        public String getType() {
            return mType;
        }

        public String getValue() {
            return mValue;
        }
    }
}
