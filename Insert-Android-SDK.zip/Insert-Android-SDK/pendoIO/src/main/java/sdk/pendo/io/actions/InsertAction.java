package sdk.pendo.io.actions;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import sdk.pendo.io.actions.configurations.CachingPolicy;
import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.actions.configurations.InsertGroup;
import sdk.pendo.io.actions.configurations.InsertTypeValue;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.responses.InsertModel;
import sdk.pendo.io.utilities.Utils;
import static sdk.pendo.io.network.responses.InsertModel.INSERT_ACTIONS;

/**
 * Pendo's action class.
 *
 * Created by assaf on 4/30/15.
 */
public class InsertAction implements Comparable<InsertAction> {

    public static final String INSERT_CAPPING = "capping";
    public static final String INSERT_CONFIGURATION = "configuration";
    public static final String INSERT_INSERT_DELAY = "insertDelay";

    public static final String NO_ID = "";
    private static final int THIS_ACTION = 1;
    private static final int COMPARED_TO_ACTION = -1;
    private Tracker mTracker;

    @Override
    public final int compareTo(@NonNull InsertAction anotherAction) {
        //appTweak beats all.
        if (this.getType().equals(InsertActions.APP_TWEAK)) {
            return THIS_ACTION;
        }
        if (anotherAction.getType().equals(InsertActions.APP_TWEAK)) {
            return COMPARED_TO_ACTION;
        }

        //visuals will go by multiple and priority.
        if (this.getConfiguration().isMultipleShows()
                || anotherAction.getConfiguration().isMultipleShows()) {
            if (anotherAction.getConfiguration().getPriority() <
                    this.getConfiguration().getPriority()) {
                return COMPARED_TO_ACTION;
            } else {
                return THIS_ACTION;
            }
        }

        //Now check cappings.
        if (this.isOutOfCappingForSession()){
            return COMPARED_TO_ACTION;
        }
        if (anotherAction.isOutOfCappingForSession()) {
            return THIS_ACTION;
        }

        //Now check by priority
        if (this.getConfiguration().getPriority() <
                anotherAction.getConfiguration().getPriority()) {
            return THIS_ACTION;
        } else {
            return COMPARED_TO_ACTION;
        }
    }

    @Nullable
    public final Tracker getTracker() {
        return mTracker;
    }

    public final void setTracker(Tracker tracker) {
        mTracker = tracker;
    }

    public enum InsertActions {
        TOAST("toast"),
        VISUAL("visual"),
        APP_TWEAK("appTweak");

        @SuppressWarnings("CheckStyle")
        public final String type;

        @SuppressWarnings("CheckStyle")
        private static final Map<String, InsertActions> sLookupByType = new HashMap<>();
        static {
            for (InsertActions s : EnumSet.allOf(InsertActions.class)) {
                sLookupByType.put(s.type, s);
            }
        }

        @SuppressWarnings("CheckStyle")
        InsertActions(String type) {
            this.type = type;
        }

        @SuppressWarnings("CheckStyle")
        public boolean equals(InsertActions insertAction) {
            return this.type.equals(insertAction.type);
        }

        @Nullable
        public static InsertActions get(String type) {
            return sLookupByType.get(type);
        }
    }

    private String mType;

    protected String id = NO_ID;

    InsertGroup group;

    @SerializedName(INSERT_CONFIGURATION)
    InsertActionConfiguration configuration;

    @SerializedName(INSERT_CAPPING)
    protected GuideCapping capping;

    @SerializedName(INSERT_ACTIONS)
    private List<InsertCommand> mActions;

    @SerializedName(INSERT_INSERT_DELAY)
    private InsertTypeValue mInsertDelay;

    public InsertAction(String id) {
        this.id = id;
    }

    @Nullable
    public final List<InsertCommand> getActions() {
        return mActions != null ? new LinkedList<>(mActions) : null;
    }

    protected InsertAction(String type, @Nullable InsertModel insertModel) {
        mType = type;

        if (insertModel != null) {
            this.id = insertModel.id;
            this.configuration = insertModel.configuration;
            this.group = insertModel.mGroup;
            this.capping = insertModel.capping;
            mInsertDelay = insertModel.configuration.getInsertDelay();
            try {
                JsonArray actions = insertModel.actions;
                if (actions != null) {
                    this.mActions = InsertCommand.getInsertCommands(actions);
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    }

    public final InsertActionConfiguration getConfiguration() {
        return configuration;
    }

    public final InsertGroup getInsertGroup() {
        return group;
    }

    public void setInsertGroup(InsertGroup group) {
        this.group = group;
    }

    public final InsertActions getType() {
        return InsertActions.get(mType);
    }

    public final String getId() {
        return id;
    }

    /**
     * @return the insert delay in milliseconds.
     */
    public long getInsertDelay() {

        long delay = 0;
        if (mInsertDelay != null) {
            try {
                delay = Utils.convertToTimeUnit(mInsertDelay, TimeUnit.MILLISECONDS);
            } catch (Exception ignore) {
            }
        }

        return delay > 0 ? delay : 0;
    }

    public static InsertAction insertActionFactory(InsertModel insertModel) {

        if (insertModel.configuration != null) {
            InsertActions action = InsertActions.get(insertModel.configuration.type);
            if (action != null) {
                InsertLogger.d("Pendo's type: " + action.type);
                switch (action) {
                    case TOAST:
                        return new InsertActionToast("TEST", InsertActionToast.ToastLength.LONG);
                    case VISUAL: // FIXME: 5/13/15 Change to something generic.
                        return null;
                    case APP_TWEAK:
                        return new AppTweakInsert(insertModel);
                }
            }
        }

        return null; // FIXME: 5/13/15 What to do here?
    }

    public final boolean canConsumeOne() {
        CachingPolicy cachingPolicy = configuration.getCachingPolicy();
        if (cachingPolicy != null && cachingPolicy.isEnabled()) {
            return !cachingPolicy.isExpired()
                    && (capping == null || capping.canConsumeOne());
        }

        return capping == null || capping.canConsumeOne();
    }

    public final boolean didCacheExpire() {
        final CachingPolicy cachingPolicy = configuration.getCachingPolicy();
        if (cachingPolicy == null) {
           return false;
        }
        return cachingPolicy.isEnabled() && cachingPolicy.isExpired();
    }

    public final boolean isOutOfCappingForSession() {
        if (capping != null) {
            return (capping.getConsumed() == capping.getMaxSessionImpressions());
        } else {
            //If capping null, then we are never out of capping.
            return false;
        }
    }

    @Override
    public final boolean equals(Object o) {
        return o == this || o instanceof InsertAction && id.equals(((InsertAction) o).id);
    }

    @Override
    public final int hashCode() {
        return id.hashCode(); // TODO: 11/10/15 Really? Is that the hashcode?
    }

    @Override
    public final String toString() {
        if (configuration != null) {
            String cappingString = capping != null ? capping.toString() : " ";
            String cachingString = configuration.getCachingPolicy() != null
                    ? configuration.getCachingPolicy().toString() : " ";
            return "Pendo:"
                    + " {"
                    + "[id = " + id + "]," + " "
                    + "[type = " + configuration.type + "]," + " "
                    + "[name = " + configuration.name + "]," + " "
                    + "[capping = " + cappingString + "]," + " "
                    + "[caching = " + cachingString + "]"
                    + "}";
        }
        else {
            return "Pendo:"
                    + " {"
                    + "[id = " + id + "]," + " "
                    + "[configuration = " + "NULL" + "]"
                    + "}";
        }
    }
}
