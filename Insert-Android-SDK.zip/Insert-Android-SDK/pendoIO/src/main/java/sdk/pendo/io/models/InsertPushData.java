package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

import sdk.pendo.io.actions.configurations.InsertGroup;

/**
 * Created by itayvallach on 26/06/2016.
 *
 * This class represents the model of the data that comes on Pendo's push notification.
 */
public class InsertPushData {

    public static final String MODE_TEST = "test";
    public static final String USER = "user";

    @SerializedName("mode")
    private String mMode;

    @SerializedName("insertId")
    private String mInsertId;

    @SerializedName("elementId")
    private String mElementId;

    @SerializedName("group")
    private InsertGroup mGroup;

    @SerializedName("action")
    private String mAction;

    public String getMode() {
        return mMode;
    }

    public void setMode(String mode) {
        mMode = mode;
    }

    public String getInsertId() {
        return mInsertId;
    }

    public void setInsertId(String insertId) {
        mInsertId = insertId;
    }

    public String getElementId() {
        return mElementId;
    }

    public void setElementId(String elementId) {
        mElementId = elementId;
    }

    public InsertGroup getGroup() {
        return mGroup;
    }

    public void setGroup(InsertGroup group) {
        mGroup = group;
    }

    public String getAction() {
        return mAction;
    }

    public void setAction(String action) {
        mAction = action;
    }

}
