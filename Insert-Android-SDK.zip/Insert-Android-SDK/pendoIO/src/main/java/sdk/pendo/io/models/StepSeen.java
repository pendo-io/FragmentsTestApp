package sdk.pendo.io.models;

import sdk.pendo.io.actions.GuideManager;

public final class StepSeen {
    private String mGuideId;
    private String mStepId;
    private StepLocationModel mStepLocationModel;

    public StepSeen(String guideId, String stepId, StepLocationModel stepLocationModel) {
        mGuideId = guideId;
        mStepId = stepId;
        mStepLocationModel = stepLocationModel;
    }

    public String getGuideId() {
        return mGuideId;
    }

    public void setGuideId(String guideId) {
        this.mGuideId = guideId;
    }

    public String getStepId() {
        return mStepId;
    }

    public Integer getStepIndex() {
        if (mGuideId != null) {
            GuideModel currentGuideModel = GuideManager.INSTANCE.getGuide(mGuideId);
            if (currentGuideModel != null) {
                Integer guideStepIndex = currentGuideModel.getGuideStepIndex(mStepId);
                if (guideStepIndex != null) {
                    return guideStepIndex;
                }
            }
        }
        return null;
    }

    public StepLocationModel getStepLocationModel() {
        return mStepLocationModel;
    }

}
