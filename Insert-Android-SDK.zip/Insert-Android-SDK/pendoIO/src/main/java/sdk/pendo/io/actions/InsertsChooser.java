package sdk.pendo.io.actions;

import android.util.SparseArray;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Created by tomerlevinson on 12/14/15.
 */
public final class InsertsChooser {
    private static final Object LOCK = new Object();

    private static final int FIRST_BIGGER = 1;
    private static final int SECOND_BIGGER = -1;
    private static final int PQ_INITIAL_CAPACITY = 11;

    private static volatile InsertsChooser sInstance;
    private static PriorityQueue<InsertAction> sPriorityQueue;

    private InsertsChooser() {
        sPriorityQueue = new PriorityQueue<>(PQ_INITIAL_CAPACITY, new InsertPriorityComparator());
    }

    public static void init() {
        getInstance();
    }

    public static InsertsChooser getInstance() {
        InsertsChooser result = sInstance;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = sInstance;
                if (result == null) { // 2nd check (w/ lock)
                    //noinspection CheckStyle
                    sInstance = result = new InsertsChooser();
                }
            }
        }
        return result;
    }

    void eliminateMultipleVisuals(List<String> insertIdsList) {

        // Get all Pop-up inserts with no multiple.
        List<String> noMultipleVisuals = new ArrayList<>();
        final Map<String,InsertAction> inserts = InsertsManager.getInstance().getInserts();

        for (String insertID : insertIdsList) {
            InsertAction insertAction = inserts.get(insertID);
            if (insertAction != null
                    && !insertAction.getConfiguration().isMultipleShows()
                    && !insertAction.isOutOfCappingForSession()) {
                noMultipleVisuals.add(insertID);
            }
        }

        if (noMultipleVisuals.size() > 0) {

            // Get the chosen pair to be in the queue.
            String chosenInsertId = noMultipleVisuals.get(0);
            for (int i = 1; i < noMultipleVisuals.size(); i++) {
                final InsertAction insertAction =
                        inserts.get(noMultipleVisuals.get(i));
                final InsertAction anotherAction =
                        inserts.get(chosenInsertId);

                if (insertAction != null
                        && anotherAction != null
                        && insertAction.compareTo(anotherAction) == FIRST_BIGGER) {
                    chosenInsertId = noMultipleVisuals.get(i);
                }
            }

            noMultipleVisuals.remove(chosenInsertId);
        }
        // Remove all the pairs except for the chosenPair.
        for (String insertID : noMultipleVisuals) {
            insertIdsList.remove(insertID);
        }
    }

    public List<InsertAction> chooseInserts(List<String> insertsIdList) {

        eliminateMultipleVisuals(insertsIdList);

        // Add all Inserts to the priority queue.
        for (final String insertId : insertsIdList) {
            final InsertAction insertAction = InsertsManager.getInstance().getInserts()
                    .get(insertId);

            if (insertAction == null) {
                continue;
            }

            sPriorityQueue.add(insertAction);
        }

        List<InsertAction> myPrioritisedList = new ArrayList<>();

        while (!sPriorityQueue.isEmpty()) {
            myPrioritisedList.add(sPriorityQueue.poll());
        }

        return myPrioritisedList;
    }

    private static class InsertPriorityComparator implements Comparator<InsertAction> {
        @Override
        public int compare(InsertAction x, InsertAction y) {
            if (x.compareTo(y) == FIRST_BIGGER) {
                return FIRST_BIGGER;
            } else {
                return SECOND_BIGGER;
            }
        }
    }
}

