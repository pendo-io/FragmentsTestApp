package sdk.pendo.io.logging;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import java.util.regex.Matcher;

import javax.net.ssl.SSLPeerUnverifiedException;

import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.utilities.AnalyticsUtils;

import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONFIGURATION;

/**
 * Debug logging tree.
 *
 * Created by assaf on 4/8/15.
 */
public class InsertDebugTree extends InsertLogger.DebugTree {

    public InsertDebugTree() { }

    @Override
    protected final String createStackElementTag(StackTraceElement element) {
        String className = element.getClassName();
        String methodName = element.getMethodName();
        int lineNumber = element.getLineNumber();

        Matcher m = InsertLogger.ANONYMOUS_CLASS.matcher(className);
        if (m.find()) {
            className = m.replaceAll("");
        }
        String classNameTag = className.substring(className.lastIndexOf('.') + 1);
        return "Pendo::" + classNameTag + ":" + methodName + "():"
                + Integer.toString(lineNumber) + ":";
    }

    @Override
    /** Log a debug message with optional format args. */
    public void d(String message, Object... args) {
        super.d(null, message, args);
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.DEBUG);
    }

    @Override
    /** Log a debug exception and a message with optional format args. */
    public void d(Throwable t, String message, Object... args) {
        super.d(t, message, args);
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.DEBUG,
                                                                       t.toString());
    }

    @Override
    /** Log an info message with optional format args. */
    public void i(String message, Object... args) {
        super.i(null, message, args);
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.INFO);
    }

    @Override
    /** Log an info exception and a message with optional format args. */
    public void i(Throwable t, String message, Object... args) {
        super.i(t, message, args);
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.INFO,
                                                                       t.toString());
    }

    @Override
    /** Log a warning message with optional format args. */
    public void w(String message, Object... args) {
        super.w(null, message, args);
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.WARNING);
        sendErrorReport(message);
    }

    @Override
    /** Log a warning exception and a message with optional format args. */
    public void w(Throwable t, String message, Object... args) {
        super.w(t, message, args);
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.WARNING,
                                                                       t.toString());
        sendExceptionReport(t, message);
    }

    @Override
    /** Log an error message with optional format args. */
    public void e(String message, Object... args) {
        super.e(null, message, args);
        InsertRemoteDebug.getInstance().addLogIfRemoteDebugOn(message, InsertLogger.ERROR);
        sendErrorReport(message);
    }

    @Override
    /** Log an error exception and a message with optional format args. */
    public void e(Throwable t, String message, Object... args) {
        super.e(t, message, args);
        InsertRemoteDebug.getInstance().addExceptionLogIfRemoteDebugOn(message,
                                                                       InsertLogger.ERROR,
                                                                       t.toString());
        sendExceptionReport(t, message);
    }
    private void sendErrorReport(String message) {
        if (BackendApiManager.getInstance().isAuthenticated()) {
            AnalyticsUtils.sendErrorReport(ERROR_REASON_CONFIGURATION, message);
        }
    }

    private void sendExceptionReport(@NonNull Throwable t, @Nullable String message) {
        if (t instanceof SSLPeerUnverifiedException) {
            // TODO: 9/19/16 Talk to Udi about how can we send this to the server.
            InsertLogger.d("Cannot send SSLPeerUnverifiedException to server yet.");
            return;
        }

        if (BackendApiManager.getInstance().isAuthenticated()) {
            AnalyticsUtils.sendExceptionReport(t, message);
        }
    }
}
