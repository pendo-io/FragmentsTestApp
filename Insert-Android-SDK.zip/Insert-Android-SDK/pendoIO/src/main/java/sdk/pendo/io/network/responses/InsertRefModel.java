package sdk.pendo.io.network.responses;

import android.support.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

/**
 * Created by nirsegev on 9/20/15.
 */
public final class InsertRefModel {

    @SerializedName("idRef")
    public String id;

    @SerializedName("type")
    public String type;

    /* package */ static InsertRefModel copy(@NonNull InsertRefModel insertRefModel) {
        InsertRefModel copy = new InsertRefModel();
        copy.id = insertRefModel.id;
        copy.type = insertRefModel.type;

        return copy;
    }
}
