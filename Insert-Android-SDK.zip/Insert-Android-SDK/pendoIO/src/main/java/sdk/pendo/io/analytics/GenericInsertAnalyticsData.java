package sdk.pendo.io.analytics;

import android.support.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;

import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;

/**
 * Generic Pendo analytics.
 * Used to bind analytics with insertAction and insertEvent.
 * <p/>
 * Created by assaf on 6/18/15.
 */
public final class GenericInsertAnalyticsData {

    public static final long INVALID_TIME = -1;
    public static final int GROUP_ID_DEFAULT_VALUE = 1;
    public static final int INVALID_TRIGGER_ID = -1;
    public static final String GROUP_TYPE_DEFAULT_VALUE = "user";

    public enum DismissedReason {
        TIME_OUT("Timeout"),
        STATE_CHANGED("StateChanged"),
        CLOSE_BUTTON("CloseButton"),
        SYSTEM("System"),
        APP_TERMINATION("AppTermination"),
        USER_ACTION("UserAction"),
        APP_IN_BACKGROUND("AppInBackground");

        private final String mValue;

        DismissedReason(String value) {
            mValue = value;
        }

        public String getValue() {
            return mValue;
        }
    }

    public enum NotDisplayReason {
        ERROR_REASON_CAPPING("Capping"),
        ERROR_CONTROL_GROUP("ControlGroup"),
        ERROR_REASON_CONNECTIVITY("Connectivity"),
        ERROR_REASON_IMAGE("ImageError"),
        ERROR_REASON_VIDEO("VideoError"),
        ERROR_REASON_CONFIGURATION("ConfigurationError"),
        ELEMENT_NOT_VISIBLE("ElementNotVisible"),
        ERROR_REASON_UNKNOWN("Unknown"),
        ERROR_REASON_RUN_PREVIEW_INSERT("RunPreviewInsertError"),
        ERROR_REASON_ENTER_TEST_MODE("EnterTestModeError"),
        ERROR_REASON_BACKEND("BackendError"),
        ERROR_GUIDE_ALREADY_DISPLAYED("GuideAlreadyDisplayed");

        private final String mValue;

        NotDisplayReason(String value) {
            mValue = value;
        }

        public String getValue() {
            return mValue;
        }
    }

    public enum SecurityReason {
        INVALID_SIGNATURE("InvalidSignature");

        private final String mValue;

        SecurityReason(String reason) {
            mValue = reason;
        }

        public String getValue() {
            return mValue;
        }
    }

    public enum ScriptError {
        JS_ERROR("JSError");

        private final String mValue;

        ScriptError(String reason) {
            mValue = reason;
        }

        public String getValue() {
            return mValue;
        }
    }

    private InsertAction mInsertAction = null;
    private GuideModel mGuideModel = null;

    private long mDuration = INVALID_TIME;
    @Nullable
    private String mDismissedReason;
    @Nullable
    private NotDisplayReason mNotDisplayedReason;

    private int mTriggerId = INVALID_TRIGGER_ID;

    protected GenericInsertAnalyticsData(InsertAction insertAction) {
        mInsertAction = insertAction;
    }

    protected GenericInsertAnalyticsData(GuideModel guideModel) {
        mGuideModel= guideModel;
    }

    protected InsertAction getInsertAction() {
        return mInsertAction;
    }

    protected GuideModel getGuideModel() {
        return mGuideModel;
    }

    public void setTriggerId(int triggerId) {
        mTriggerId = triggerId;
    }

    public String getInsertId() {
        return mGuideModel.getGuideId();
    }
    public GenericInsertAnalyticsData setDuration(long duration) {
        mDuration = duration;
        return this;
    }

    public GenericInsertAnalyticsData setDismissedReason(
            @Nullable DismissedReason dismissedReason) {
        if (dismissedReason == null) {
            return this;
        }

        mDismissedReason = dismissedReason.getValue();
        return this;
    }

    public GenericInsertAnalyticsData setDismissedReason(@Nullable String dismissedReason) {
        mDismissedReason = dismissedReason;
        return this;
    }

    public GenericInsertAnalyticsData setNotDisplayedReason(
            @Nullable NotDisplayReason notDisplayedReason) {
        mNotDisplayedReason = notDisplayedReason;
        return this;
    }


    public long getDuration() {
        return mDuration;
    }

    @Nullable
    private String getDismissedReason() {
        return mDismissedReason;
    }

    @Nullable
    public NotDisplayReason getNotDisplayedReason() {
        return mNotDisplayedReason;
    }

    public void addInsertValues(JSONObject json, String analyticsEvent) {
        try {
            JSONObject controlGroupJSON = new JSONObject();
            json.put(AnalyticsProperties.CONTROL_GROUP, controlGroupJSON);

            AnalyticsEvent event = AnalyticsEvent.findEvent(analyticsEvent);

            if (!AnalyticsEvent.GUIDE_RECEIVED.equals(event)) {
                //TODO: Add relevant triggeredBy
//                json.put(AnalyticsProperties.TRIGGERED_BY, insertEvent.getId());
            }
            if (AnalyticsEvent.GUIDE_DISMISSED.equals(event)) {

                String dismissedReason = getDismissedReason();
                if (dismissedReason != null) {
                    json.put(AnalyticsProperties.DISPLAY_DURATION_MILLIS, getDuration());
                    json.put(AnalyticsProperties.DISMISSED_BY, dismissedReason);
                } else {
                    InsertLogger.w("No dismiss reason given!");
                }

            } else if (AnalyticsEvent.GUIDE_NOT_DISPLAYED.equals(event)) {

                NotDisplayReason notDisplayedReason = getNotDisplayedReason();
                if (notDisplayedReason != null ) {
                    json.put(AnalyticsProperties.REASON, notDisplayedReason.getValue());
                } else {
                    InsertLogger.w("No not display reason given!");
                }
            }
        } catch (JSONException e) {
            InsertLogger.e(e.getMessage());
        }

    }
}
