package sdk.pendo.io.models;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.actions.InsertActionConfiguration.*;

public class GuideModel implements Comparable<GuideModel> {

    private static final int THIS_ACTION = 1;
    private static final int COMPARED_TO_ACTION = -1;
    private static final int FIRST_GUIDES_CHILD_INDEX = 0;
    public static final String INVALID_GUIDE_ID = "";
    public static final String PREVIEW_GUIDE_ID = "PREVIEW_GUIDE_ID";
    public static final String PREVIEW_GUIDE_STEP_ID = "PREVIEW_GUIDE_STEP_ID";
    private StepContentModel mStepContentModel = null;
    public static final String DEFAULT_GUIDE_STEP_ID = "";
    private static final String TOOLTIP_WIDGET_NAME = "Tooltip";

    private Tracker mTracker;

    @SerializedName("activations")
    private JsonArray mActivations;

    @SerializedName("priority")
    private int mPriority;

    @SerializedName("recurrence")
    private long mRecurrence;

    @SerializedName("steps")
    private JsonArray mSteps;

    @SerializedName("guideId")
    private String mGuideId;

    @SerializedName("appId")
    private String mAppId;

    @SerializedName("configuration")
    private GeneralGuidesConfiguration mGeneralGuideConfiguration;

    @SerializedName("guideName")
    private String mGuideName;

    public JsonArray getActivations() {
        return mActivations;
    }

    public void setActivations(JsonArray activations) {
        this.mActivations = activations;
    }

    public int getPriority() {
        return mPriority;
    }

    public void setPriority(int mPriority) {
        this.mPriority = mPriority;
    }

    public JsonArray getSteps() {
        return mSteps;
    }

    private void setSteps(JsonArray steps) {
        this.mSteps = steps;
    }

    public String getGuideId() {
        if (mGuideId != null) {
            return mGuideId;
        }
        return INVALID_GUIDE_ID;
    }

    public void setGuideId(String mGuideId) {
        this.mGuideId = mGuideId;
    }

    public String getAppId() {
        return mAppId;
    }

    public void setAppId(String mAppId) {
        this.mAppId = mAppId;
    }

    @Override
    public final int compareTo(@NonNull GuideModel anotherGuide) {
        // Check by priority
        if (this.getPriority() <
                anotherGuide.getPriority()) {
            return THIS_ACTION;
        } else {
            return COMPARED_TO_ACTION;
        }
    }

    @Nullable
    public final Tracker getTracker() {
        return mTracker;
    }

    public final void setTracker(Tracker tracker) {
        mTracker = tracker;
    }

    protected GuideModel(@Nullable StepGuideModel stepGuideModel) {
        if (stepGuideModel != null) {
            try {
                JSONArray stepArray = new JSONArray();
                JSONObject contentJSON = new JSONObject();
                JSONObject guideJSON = new JSONObject();
                guideJSON.put("guide", new JSONObject(Pendo.GSON.toJson(stepGuideModel, StepGuideModel.class)));
                guideJSON.put("guideId", PREVIEW_GUIDE_ID);
                guideJSON.put("guideStepId", PREVIEW_GUIDE_STEP_ID);
                contentJSON.put("content", guideJSON);
                contentJSON.put("location", new JSONObject());
                contentJSON.put("activations", new JSONArray());
                stepArray.put(0, contentJSON);
                JsonArray GSONStepArray = Pendo.GSON.fromJson(stepArray.toString(), JsonArray.class);
                this.setSteps(GSONStepArray);
                this.setGuideId(PREVIEW_GUIDE_ID);
                this.setPriority(3);
                this.setActivations(null);
                this.setGuideName("DEFAULT_NAME");
                this.setGeneralGuideConfiguration(null);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    }

    protected GuideModel(@Nullable GuideModel guideModel) {
        if (guideModel != null) {
            this.setActivations(guideModel.getActivations());
            this.setAppId(guideModel.getAppId());
            this.setGuideId(guideModel.getGuideId());
            this.setPriority(guideModel.getPriority());
            this.setSteps(guideModel.getSteps());
            this.setGuideName(guideModel.getGuideName());
            this.setGeneralGuideConfiguration(guideModel.getGeneralGuideConfiguration());

        }
    }

    @Override
    public final boolean equals(Object o) {
        return o == this || o instanceof GuideModel && getGuideId().equals(((GuideModel) o).getGuideId());
    }

    @Override
    public final int hashCode() {
        return getGuideId().hashCode(); // TODO: 11/10/15 Really? Is that the hashcode?
    }

    @Override
    public final String toString() {
        String guideId = getGuideId() != null ? getGuideId() : "";
        String appId = getAppId() != null ? getAppId() : "";
        String activation = getActivations() != null ? getActivations().toString() : "";
        String steps = getSteps() != null ? getSteps().toString() : "";
        int priority = getPriority();
        return "Guide Model:"
                + " {"
                + "[guideId = " + guideId + "]," + " "
                + "[appId = " + appId + "]," + " "
                + "[priority = " + priority + "]," + " "
                + "[activation = " + activation + "]," + " "
                + "[steps = " + steps + "]"
                + "}";
    }

    public static GuideModel guideFactory(StepGuideModel previewOnDeviceDetails) {
        return VisualInsertManager.getInstance().createVisualInsert(previewOnDeviceDetails);
    }

    /**
     * Gets the step content model of the guide.
     * @return StepContentModel of the guide.
     */
    public synchronized StepContentModel getStepContentModel(int stepIndex) {
        JsonElement guideStepsElement = getSteps();
        if (guideStepsElement != null) {
            try {
                // TODO: 06/08/19 handle multiple steps.
                JsonArray guideStepsArray = Pendo.GSON.fromJson(guideStepsElement, JsonArray.class);
                JsonObject stepAtIndexStepIndexObject = (JsonObject) guideStepsArray.get(stepIndex);
                JsonObject guideContentAtStepIndexObject = (JsonObject) stepAtIndexStepIndexObject.get(GUIDE_SCREEN_CONTENT);
                mStepContentModel = Pendo.GSON.fromJson(guideContentAtStepIndexObject, StepContentModel.class);
                return mStepContentModel;
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return null;
    }

    public synchronized StepModel getGuideStepModel(String stepId) {
        JsonElement guideStepsElement = getSteps();
        if (guideStepsElement != null) {
            try {
                JsonArray guideStepsArray = Pendo.GSON.fromJson(guideStepsElement, JsonArray.class);
                for (int i = 0; i < guideStepsArray.size(); i++) {
                    JsonObject currentGuideStep = (JsonObject) guideStepsArray.get(i);
                    StepModel currentStepModel = Pendo.GSON.fromJson(currentGuideStep, StepModel.class);
                    if (currentStepModel.getStepContentModel().getGuideStepId().equals(stepId)) {
                        return currentStepModel;
                    }
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return null;
    }

    public synchronized StepLocationModel getGuideStepLocation(String stepId) {
        JsonElement guideStepsElement = getSteps();
        if (guideStepsElement != null) {
            try {
                JsonArray guideStepsArray = Pendo.GSON.fromJson(guideStepsElement, JsonArray.class);
                for (int i = 0; i < guideStepsArray.size(); i++) {
                    JsonObject currentGuideStep = (JsonObject) guideStepsArray.get(i);
                    StepModel currentStepModel = Pendo.GSON.fromJson(currentGuideStep, StepModel.class);
                    if (currentStepModel.getStepContentModel().getGuideStepId().equals(stepId)) {
                        return currentStepModel.getStepLocationModel();
                    }
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return null;
    }

    public synchronized  Integer getGuideStepIndex(String stepId) {
        JsonArray guideStepsElement = getSteps();
        if (guideStepsElement != null) {
            try {
                JsonArray guideStepsArray = Pendo.GSON.fromJson(guideStepsElement, JsonArray.class);
                for (int i = 0; i < guideStepsArray.size(); i++) {
                    JsonObject currentGuideStep = (JsonObject) guideStepsArray.get(i);
                    StepModel currentStepModel = Pendo.GSON.fromJson(currentGuideStep, StepModel.class);
                    if (currentStepModel.getStepContentModel().getGuideStepId().equals(stepId)) {
                        return i;
                    }
                }
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return null;
    }

    public synchronized String getGuideStepId(int stepIndex) {
        StepContentModel stepContentModel = getStepContentModel(stepIndex);
        if (stepContentModel != null) {
            return stepContentModel.getGuideStepId();
        }
        return DEFAULT_GUIDE_STEP_ID;
    }

    /**
     * Returns the current StepGuideModel.
     * @return StepGuideModel model.
     */
    public StepGuideModel getGuideStepModel(int stepIndex) {
        JsonElement guideStepsElement = getSteps();
        if (guideStepsElement != null) {
            try {
                //TODO 05/08/19: handle multiple steps in the future.
                JsonArray guideStepsArray = Pendo.GSON.fromJson(guideStepsElement, JsonArray.class);
                JsonObject stepObjectAtStepIndex = (JsonObject) guideStepsArray.get(stepIndex);
                JsonObject stepContentModelAtStepIndex = (JsonObject) stepObjectAtStepIndex.get(GUIDE_SCREEN_CONTENT);
                JsonElement stepGuideModelAtStepIndex = stepContentModelAtStepIndex.get(GUIDE_SCREEN_CONTENT_GUIDE);
                return Pendo.GSON.fromJson(stepGuideModelAtStepIndex, StepGuideModel.class);
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return null;
    }

    public long getRecurrence() {
        return mRecurrence;
    }

    public void setRecurrence(long recurrence) {
        this.mRecurrence = recurrence;
    }

    public String getGuideName() {
        return mGuideName;
    }

    public GeneralGuidesConfiguration getGeneralGuideConfiguration() {
        return mGeneralGuideConfiguration;
    }

    public void setGeneralGuideConfiguration(GeneralGuidesConfiguration mGeneralGuideConfiguration) {
        this.mGeneralGuideConfiguration = mGeneralGuideConfiguration;
    }

    public void setGuideName(String mGuideName) {
        this.mGuideName = mGuideName;
    }

    public enum VisualGuideType {
        TOOLTIP(TOOLTIP_WIDGET_NAME),
        FULLSCREEN("Fullscreen");

        public final String widgetName;

        VisualGuideType(String widgetName) {
            this.widgetName = widgetName;
        }
    }

    /**
     * Under the assumption we only have two types of guides at the moment, tooltip and fullscreen
     * For a given step we return it is a tooltip if it has such widget type, and fullscreen
     * otherwise.
     * @param guideStep
     * @return matching InsertType
     */
    public VisualGuideType getStepVisualInsertType(int stepIndex) {
        try {
            StepContentModel stepContentModel = getStepContentModel(stepIndex);
            StepGuideModel stepGuideModel = stepContentModel.getStepModel();
            JsonArray stepViews = stepGuideModel.getViews();
            String widgetType = stepViews.get(0).getAsJsonObject().get("views").getAsJsonArray().get(0).getAsJsonObject().get("widget").getAsString();
            if (VisualGuideType.TOOLTIP.widgetName.equals(widgetType)) {
                return VisualGuideType.TOOLTIP;
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return VisualGuideType.FULLSCREEN;

    }
}
