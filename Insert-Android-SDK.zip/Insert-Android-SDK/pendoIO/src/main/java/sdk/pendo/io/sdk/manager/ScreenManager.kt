package sdk.pendo.io.sdk.manager

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.widget.DrawerLayout
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import io.reactivex.subjects.PublishSubject
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.analytics.AnalyticsProperties
import sdk.pendo.io.intelligence.ViewIntel
import sdk.pendo.io.listeners.ApplicationObservers
import sdk.pendo.io.listeners.views.InsertDrawerListener
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.network.killswitch.KillSwitchManager
import sdk.pendo.io.utilities.*
import java.util.*

object ScreenManager {
    private const val DRAWER_ID = "__DRAWER__"
    private const val DELIMITER = "|"
    private const val FRAGMENTS_SEPARATOR = "_F_"
    private val specialCharsRegex = Regex("[^\\dA-Za-z0-9_]")

    private const val PERSISTENT_SCREEN_MANAGER_FILE = "pendo_screen_manager"
    private const val PERSISTENT_INCLUDE_PAGE_TEXTS_KEY = "includePageViewTexts"
    private const val PERSISTENT_INCLUDE_FEATURE_TEXTS_KEY = "includeFeatureClickTexts"
    private const val PERSISTENT_INCLUDE_FEATURE_CLICK_ACCESSIBILITY_KEY = "includeFeatureClickAccessibility"
    private const val PERSISTENT_INCLUDE_PAGE_VIEW_ACCESSIBILITY_KEY = "includePageViewAccessibility"

    private const val IS_DEBUG: Boolean = false

    val screenChangedSubject: PublishSubject<String> = PublishSubject.create()
    val inScreenChangedSubject: PublishSubject<String> = PublishSubject.create()

    @Volatile
    var currentScreenData: JSONObject? = null
        private set

    private var capturedScreenData = JSONObject()

    @Volatile
    var includePageViewTexts: Boolean = false
        private set
    @Volatile
    var includeFeatureClickTexts: Boolean = false
        private set
    @Volatile

    var includePageViewAccessibility: Boolean = false
        private set
    @Volatile
    var includeFeatureClickAccessibility: Boolean = false
        private set
    @Volatile
    var disableAppAnalytics: Boolean = false

    @Volatile
    var currentScreenId: String = ""
        @Synchronized
        set(newValue) {
            when {
                newValue.isEmpty() -> {
                    InsertLogger.d("Got empty screen id - Ignoring.")
                }
                newValue != field -> { // Screen did change!
                    InsertLogger.d("Screen change: $field -> $newValue")
                    field = newValue
                    screenDidChange()
                }
                newValue == field -> { // Screen is the same
                    InsertLogger.d("Same screen change: $field")
                    screenIdDidNotChangeButScreenIdWasSet()
                }
                IS_DEBUG -> InsertLogger.d("Same screen identified again.")
            }
        }

    init {
        loadPolicy()
    }

    // TODO?
    fun start() {}

    /**
     * Sets the policy for the Retroactive feature.
     *
     * @param includePageViewTexts should we collect page texts.
     * @param includeFeatureClickTexts should we collect feature texts.
     */
    @Synchronized
    fun setPolicy(includePageViewTexts: Boolean, includeFeatureClickTexts: Boolean,
                  includePageViewAccessibility: Boolean, includeFeatureClickAccessibility: Boolean) {

        this.includePageViewTexts = includePageViewTexts
        this.includeFeatureClickTexts = includeFeatureClickTexts
        this.includeFeatureClickAccessibility = includeFeatureClickAccessibility
        this.includePageViewAccessibility = includePageViewAccessibility

        // Save to shared prefs.
        savePolicy()
    }

    /**
     * Load policy settings from shared prefs. Will be used as the default value until init request is complete.
     */
    @Synchronized
    private fun loadPolicy() {

        // Try to load shared prefs:
        val prefs = PreferencesUtils.getSharedPreferencesByFileName(PERSISTENT_SCREEN_MANAGER_FILE)
        if (prefs != null) {
            this.includePageViewTexts = prefs.getBoolean(PERSISTENT_INCLUDE_PAGE_TEXTS_KEY, false)
            this.includeFeatureClickTexts = prefs.getBoolean(PERSISTENT_INCLUDE_FEATURE_TEXTS_KEY, false)
            this.includePageViewAccessibility = prefs.getBoolean(PERSISTENT_INCLUDE_PAGE_VIEW_ACCESSIBILITY_KEY, false)
            this.includeFeatureClickAccessibility = prefs.getBoolean(PERSISTENT_INCLUDE_FEATURE_CLICK_ACCESSIBILITY_KEY, false)
        }
    }

    /**
     * Save policy settings to shared prefs. Will be used as the default value until init request is complete.
     */
    @Synchronized
    private fun savePolicy() {

        val prefs = PreferencesUtils.getSharedPreferencesByFileName(PERSISTENT_SCREEN_MANAGER_FILE)
        prefs?.edit()
                ?.putBoolean(PERSISTENT_INCLUDE_PAGE_TEXTS_KEY, this.includePageViewTexts)
                ?.putBoolean(PERSISTENT_INCLUDE_FEATURE_TEXTS_KEY, this.includeFeatureClickTexts)
                ?.putBoolean(PERSISTENT_INCLUDE_PAGE_VIEW_ACCESSIBILITY_KEY, this.includePageViewAccessibility)
                ?.putBoolean(PERSISTENT_INCLUDE_FEATURE_CLICK_ACCESSIBILITY_KEY, this.includeFeatureClickAccessibility)
                ?.apply()
    }


    fun screenDidChange() {
        // Abort if kill switch is on
        if (KillSwitchManager.isKillSwitchOn()) {
            return
        }

        if (disableAppAnalytics) {
            return
        }

        // Update current data
        currentScreenData = getScreenData(includePageViewTexts, includePageViewAccessibility)

        // Notify
        screenChangedSubject.onNext(currentScreenId)
    }


    private fun screenIdDidNotChangeButScreenIdWasSet() {
        // Abort if kill switch is on
        if (KillSwitchManager.isKillSwitchOn()) {
            return
        }

        // Notify
        inScreenChangedSubject.onNext(currentScreenId)
    }

    private fun viewIsRelevantForPageView(view: View): Boolean {

        if (view is TextView) {
            return true
        }
        if (ViewUtils.isViewATabView(view)) {
            val firstTextViewChild = ViewUtils.getFirstChildTextView(view)
            if (firstTextViewChild != null && firstTextViewChild.text != null) {
                return true
            }
        }

        //TODO: handle more classes
        return false
    }


    /*
        This callback runs for every view in the hierarchy and:
        1. Checks if it's a TextView
        2. Stores all texts as part of current screen.
        3. Manipulates the texts if needed (hash, base64, truncation, etc).
         */
    private fun findTextsOnPage(
            view: View?,
            includeText: Boolean,
            includeAccessibility: Boolean,
            discoverySet: MutableSet<View>,
            texts: SortedSet<String>
    ): SortedSet<String> {


        if (view == null || !ViewUtils.isViewInsideDisplay(view)) {
            return texts
        }

        // Nothing to collect
        if (!includeText && !includeAccessibility) {
            return texts
        }

        // If relevant view, add the retroElementInfo of the view to the array in SHA1.
        if (viewIsRelevantForPageView(view)) {
            texts.add(HashingUtils.encryptSHA1(
                    ViewHierarchyUtility.createRAElementInfoJSON(
                    ViewIntel.getViewIntelId(view, includeText, includeAccessibility)
            )))
        }

        discoverySet.add(view)

        if (view is ViewGroup) {

            val isDrawerLayout = view.isDrawerLayout()
            val isDrawerLayoutOpen =
                    isDrawerLayout && (view as DrawerLayout).isDrawerOpen(Gravity.START)

            val childCount = view.childCount

            if (childCount > 0) {
                val progression =
                        if (!isDrawerLayoutOpen) {
                            // If this is a drawer layout and it's closed, take all it's siblings but not it.
                            (0 until if (isDrawerLayout) childCount - 1 else childCount)
                        } else { // If the drawer is open, we only take the drawer layout and not it's siblings.
                            childCount - 1 downTo childCount - 1
                        }

                for (i in progression) {
                    val viewChild = view.getChildAt(i)
                    if (!discoverySet.contains(viewChild)) {
                        findTextsOnPage(viewChild, includeText, includeAccessibility, discoverySet, texts)
                    }
                }
            }
        }

        return texts
    }

    fun updateDrawerState(isDrawerOpen: Boolean) {

        // Abort if kill switch is on
        if (KillSwitchManager.isKillSwitchOn()) {
            return
        }

        val newActivities = allVisibleActivities()
        val visibleFragments = allVisibleFragments()
        newScreenIdentified(newActivities, visibleFragments, isDrawerOpen)
    }

    private fun allVisibleActivities(): TreeSet<String> {
        val newActivities = TreeSet<String>()

        ApplicationObservers.getInstance()
                .allVisibleActivities.mapTo(newActivities) { it.javaClass.simpleName }
        return newActivities
    }

    private fun allVisibleFragments(): TreeSet<String> {
        val visibleFragments = TreeSet<String>()

        when (val visibleActivity = ApplicationObservers.getInstance().currentVisibleActivity) {
            is FragmentActivity -> visibleActivity.supportFragmentManager.fragments.filter { it.isPendoVisible() }
                    .mapTo(visibleFragments) { it.javaClass.simpleName }
        }
        return visibleFragments
    }

    /**
     * This is the entry point to the process of identifying a new screen. It is
     * called when a new Activity starts and identifies the new screen by scanning for fragments and texts.
     */
    fun updateVisibleActivities() {

        // Abort if kill switch is on
        if (KillSwitchManager.isKillSwitchOn()) {
            return
        }

        val newActivities = allVisibleActivities()

        // If this Activity may have fragments, we go scan for them. Otherwise, we
        // finished identifying our new screen, containing only an Activity/s.
        when (val currentVisibleActivity = ApplicationObservers.getInstance().currentVisibleActivity) {
            is FragmentActivity -> {
                currentVisibleActivity.registerPendoListener()
                recalculateScreenIdentifier(newActivities)
            }
            else -> newScreenIdentified(
                    newActivities,
                    TreeSet()
            )
        }
    }

    /**
     * After a new Activity starts, this is called to find the Fragments hosted in it, if such exist.
     *
     * @param newActivities All the current visible Activities we received. We keep this option
     * for the very rare cases that there is more than 1 visible Activity.
     */
    internal fun recalculateScreenIdentifier(
            newActivities: TreeSet<String> = allVisibleActivities()
    ) {

        val visibleFragments = allVisibleFragments()

        newScreenIdentified(
                newActivities,
                visibleFragments
        )
    }

    /**
     * This function is called when we finish identifying all visible Activities and Fragments on
     * this screen. We then create an "id" for this screen which has the following
     * format: "Activity1|Activity2|F|Fragment1|Fragment2".
     *
     * @param newActivities the new visible activities identified for this screen.
     * @param newFragments the new visible fragments identified for this screen.
     */
    @Synchronized
    private fun newScreenIdentified(
            newActivities: TreeSet<String>,
            newFragments: TreeSet<String>,
            isDrawerOpen: Boolean = InsertDrawerListener.getIsShowingDrawerValue()
    ) {

        val newScreenId: String =
                if (isDrawerOpen) {
                    DRAWER_ID
                } else {
                    val sb = StringBuilder(TextUtils.join(DELIMITER, newActivities))
                    if (!newFragments.isEmpty()) {
                        sb.append(FRAGMENTS_SEPARATOR)
                        sb.append(TextUtils.join(DELIMITER, newFragments))
                    }
                    sb.replace(specialCharsRegex, "")
                }

        currentScreenId = newScreenId
    }

    /**
     * Get screen data with the current screen details.
     *
     * @param includeText include elements text
     * @param includeAccessibility include elements accessibility
     */
    @Synchronized
    private fun getScreenData(includeText: Boolean, includeAccessibility: Boolean): JSONObject {

        val dataJSON = JSONObject()
                .put(AnalyticsProperties.RETROACTIVE_SCREEN_ID, currentScreenId)
                .put(
                        AnalyticsProperties.RETROACTIVE_EVENT_ACTIVITIES,
                        JSONArray(allVisibleActivities())
                )
                .put(
                        AnalyticsProperties.RETROACTIVE_EVENT_FRAGMENTS,
                        JSONArray(allVisibleFragments())
                )

        if (includeText || includeAccessibility) {
            val activity = ApplicationObservers.getInstance().currentVisibleActivity
            if (activity != null) {
                dataJSON.put(
                        AnalyticsProperties.RETROACTIVE_TEXTS_ELEMENT_INFOS,
                        JSONArray(Arrays.asList(getTextsForScreen(activity, includeText, includeAccessibility)))
                )

            }
        }

        // Note: for analytics/capture data, make sure to put this in a AnalyticsProperties.RETROACTIVE_SCREEN_DATA ("retroactiveScreenData") property
        return dataJSON
    }


    /**
     * Traverses over the current screen's view hierarchy to find TextViews.
     *
     * @param activity the activity of this screen where we look for texts.
     */
    @Synchronized
    private fun getTextsForScreen(activity: Activity, includeText: Boolean, includeAccessibility: Boolean): SortedSet<String> {
        val tree = mutableSetOf<View>()
        val texts = sortedSetOf<String>()
        // Just to be sure the sets are empty
        tree.clear()
        texts.clear()
        findTextsOnPage(ViewHierarchyUtility.getCurrentRootView(activity), includeText, includeAccessibility, tree, texts)
        return texts
    }


    /**
     * Generates screen data and stores it.
     */
    fun generateAndStoreCapturedScreenData() {
        // Always collect text and accessibility during capture
        capturedScreenData = getScreenData(true, true).put(
                AnalyticsProperties.RETROACTIVE_SCREEN_ID, currentScreenId
        )
    }

    /**
     * Getter for the captured screen data.
     *
     * @return the last screen data that was captured.
     */
    fun getCapturedData(): JSONObject {
        return capturedScreenData
    }

//    /**
//     * Takes an event type and its id, and generates a proper analytics json to send to the BE.
//     *
//     * @param event the event type (ScreenView, ScreenLeft, Click...).
//     *
//     * @return a JSON representing the analytic event.
//     */
//    @Synchronized
//    private fun generateAnalyticsEventJSON(event: String): JSONObject? {
//
//        when (event) {
//            SCREEN_LEFT -> {
//                if (mLastScreenAnalytics == null) {
//                    InsertLogger.e("Trying to send screen left without screen view!")
//                    return null
//                }
//                val json = JSONObject(mLastScreenAnalytics.toString())
//                populateJSONWithCommonData(json, event)
//                json
//                        .put(AnalyticsProperties.DISPLAY_DURATION, RAScreenDisplayDurationManager.getScreenDisplayDuration())
//                        .put(
//                                AnalyticsProperties.ACTIVE_TIME, PersistenceUtils.getFullTimeIntervalledAnalyticsScreenLeft(
//                                currentScreenIdHashed.toString()
//                        )
//                        )
//
//                return json
//            }
//            else -> {
//                val dataJSON: JSONObject = JSONObject().put(AnalyticsProperties.RETROACTIVE_SCREEN_DATA, ScreenManager.currentScreenData)
//                val json = populateJSONWithCommonData(JSONObject(), event)
//                        .put(AnalyticsProperties.RETROACTIVE_EVENT_ID, currentScreenIdHashed)
//                        .put(AnalyticsProperties.RETROACTIVE_EVENT_DATA, dataJSON)
//                mLastScreenAnalytics = json
//                return json
//            }
//        }
//    }


}

/**
 * Registers to all the needed fragment lifecycle activities so we can listen to them.
 */
fun FragmentActivity.registerPendoListener() {

    this.supportFragmentManager.registerFragmentLifecycleCallbacks(object :
            FragmentManager.FragmentLifecycleCallbacks() {

        override fun onFragmentDestroyed(fm: FragmentManager?, f: Fragment?) {
            super.onFragmentDestroyed(fm, f)
            ScreenManager.recalculateScreenIdentifier()
        }

        override fun onFragmentViewCreated(
                fm: FragmentManager?,
                f: Fragment?,
                v: View?,
                savedInstanceState: Bundle?
        ) {
            super.onFragmentViewCreated(fm, f, v, savedInstanceState)
//			InsertLogger.d("Fragment ${f.toString()} is being created")
            ScreenManager.recalculateScreenIdentifier()
        }

        override fun onFragmentStarted(fm: FragmentManager?, f: Fragment?) {
            super.onFragmentStarted(fm, f)
//			InsertLogger.d("Fragment ${f.toString()} is being started")
            ScreenManager.recalculateScreenIdentifier()
        }

        override fun onFragmentResumed(fm: FragmentManager?, f: Fragment?) {
            super.onFragmentResumed(fm, f)
//			InsertLogger.d("Fragment ${f.toString()} is being resumed")
            ScreenManager.recalculateScreenIdentifier()
        }

        override fun onFragmentAttached(fm: FragmentManager?, f: Fragment?, context: Context?) {
            super.onFragmentAttached(fm, f, context)
//			InsertLogger.d("Fragment ${f.toString()} is being attached")
            ScreenManager.recalculateScreenIdentifier()
        }

        override fun onFragmentDetached(fm: FragmentManager?, f: Fragment?) {
            super.onFragmentDetached(fm, f)
//			InsertLogger.d("Fragment ${f.toString()} is being detached")
            ScreenManager.recalculateScreenIdentifier()
        }

    }, false)

}