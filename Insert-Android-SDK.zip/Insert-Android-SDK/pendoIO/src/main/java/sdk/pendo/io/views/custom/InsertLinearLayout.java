package sdk.pendo.io.views.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.Optional;
import sdk.pendo.io.views.drawables.InsertBitmapDrawable;

/**
 * Pendo's Linear Layout. Extends Android's LinearLayout for background drawing purposes.
 * Created by itayvallach on 09/10/2016.
 */

public class InsertLinearLayout extends LinearLayout implements IBackgroundRenderView {

    private String mBackgroundImageUrl, mImageFillType;
    private int mBackgroundColor, mBorderWidth, mBorderColor;
    private float[] mCornerRadii;
    private boolean mGotBackgroundColor;

    public InsertLinearLayout(Context context) {
        this(context, null);
    }

    public InsertLinearLayout(Context context, AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public InsertLinearLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setWillNotDraw(false);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public InsertLinearLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setWillNotDraw(false);
    }

    @Override
    public void setImageBackgroundURL(String url) {
        mBackgroundImageUrl = url;
    }

    @Override
    public void setBackgroundColor(int color) {
        mBackgroundColor = color;
        mGotBackgroundColor = true;
    }

    @Override
    public void setCornerRadius(float cornerRadius) {
        mCornerRadii = new float[] {cornerRadius, cornerRadius, cornerRadius,
                cornerRadius, cornerRadius, cornerRadius, cornerRadius, cornerRadius};
    }

    @Override
    public void setCornerRadii(float[] cornerRadii) {
        mCornerRadii = cornerRadii;
    }

    @Override
    public void setStrokeWidth(int strokeWidth) {
        mBorderWidth = strokeWidth;
    }

    @Override
    public void setStrokeColor(int strokeColor) {
        mBorderColor = strokeColor;
    }

    @Override
    public void setImageFillType(String fillType) {
        mImageFillType = fillType;
    }

    /**
     * This method will be used when our background is only a simple ARGB color.
     * Called when finish applying all properties for this specific view (no
     * need to wait for child views to be created).
     */
    @Override
    public void renderView() {
        if (shouldSetBackgroundColor()) {
            addExtraPaddingIfNeeded();
            GradientDrawable gd = new GradientDrawable();
            ((GradientDrawable) gd.mutate()).setColor(mBackgroundColor);

            if (mBorderWidth > 0) {
                ((GradientDrawable) gd.mutate()).setStroke(mBorderWidth, mBorderColor);
            }

            if (mCornerRadii != null) {
                ((GradientDrawable) gd.mutate()).setCornerRadii(mCornerRadii);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                setBackground(gd);
            } else {
                //noinspection deprecation
                setBackgroundDrawable(gd);
            }
        }
    }

    /**
     * Used to render the background when we have an image url as a source.
     * Called only after all child views have been created and we have the
     * correct and final dimensions needed for the background.
     */
    @Override
    public void renderBackground() {
        if (mBackgroundImageUrl != null) {
            addExtraPaddingIfNeeded();
            final View view = this;

            Observable.just(mBackgroundImageUrl)
                    .observeOn(Schedulers.io())
                    .map(new Function<String, Optional<Bitmap>>() {
                        @Override
                        public Optional<Bitmap> apply(String url) {
                            Bitmap result = null;
                            try {
                                result = VisualInsert.picasso()
                                        .load(mBackgroundImageUrl).get();
                            } catch (Exception e) {
                                InsertLogger.e(e, e.getMessage());
                            }
                            return new Optional(result);
                        }
                    })
                    .filter(new Predicate<Optional<Bitmap>>() {
                        @Override
                        public boolean test(Optional<Bitmap> bitmapOptional) throws Exception {
                            return !bitmapOptional.isEmpty();
                        }
                    })
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(InsertObserver.create(new Consumer<Optional<Bitmap>>() {
                                        @Override
                                        public void accept(Optional<Bitmap> bitmap) {

                                            float cornerRadius = (mCornerRadii != null && mCornerRadii.length > 0) ? mCornerRadii[0] : 0;
                                            InsertBitmapDrawable bitmapDrawable = new InsertBitmapDrawable(
                                                    bitmap.getValue(), view, mImageFillType, mBackgroundColor,
                                                    mBorderColor, mBorderWidth, cornerRadius);

                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                                setBackground(bitmapDrawable);
                                            } else {
                                                //noinspection deprecation
                                                setBackgroundDrawable(bitmapDrawable);
                                            }

                                        }
                                    }));
        }
    }

    /**
     * In case we have corner radius and/or border, we need to add padding to
     * the view, so child views which are close to the edges will still look good with the
     * border and/or the rounded corners.
     */
    private void addExtraPaddingIfNeeded() {
        if (mBorderWidth > 0) {
            int extraPadding = (mBorderWidth) / 3;
            setPadding(getPaddingLeft() + extraPadding,
                    getPaddingTop() + extraPadding,
                    getPaddingRight() + extraPadding,
                    getPaddingBottom() + extraPadding);
        }
    }

    /**
     * We set a color as background if we have a property
     * that needs to be set: either a color, corner radius,
     * or border.
     */
    private boolean shouldSetBackgroundColor() {
        return mGotBackgroundColor || mCornerRadii != null || mBorderWidth > 0;
    }
}