package sdk.pendo.io.logging.profiling;

import java.util.ArrayList;
import java.util.List;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.InsertProfiler;
import sdk.pendo.io.utilities.SettingsUtils;

/**
 * Holds the general app and SDK info as versions, and keys.
 */
public class GeneralInfoProfiler implements InsertProfiler {

    @Override
    public final String[] getStats() {
        List<String> logs = new ArrayList<String>();
        logs.add("App key" + ProfilingManager.PROFILER_LOG_SEPERATOR + Pendo.getAppKey());
        logs.add("API endpoint" + ProfilingManager.PROFILER_LOG_SEPERATOR + RestAPI.getApiEndpoint().toString());
        logs.add("App version" + ProfilingManager.PROFILER_LOG_SEPERATOR + AndroidUtils.getAppVersionName());
        logs.add("SDK version" + ProfilingManager.PROFILER_LOG_SEPERATOR + String.valueOf(SettingsUtils.getSDKVersion()));
        logs.add("Device ID" + ProfilingManager.PROFILER_LOG_SEPERATOR + AndroidUtils.getDeviceId());
        logs.add("Is authenticated?" + ProfilingManager.PROFILER_LOG_SEPERATOR + BackendApiManager.getInstance()
                .isAuthenticated());
        logs.add("Debug logging enabled?" + ProfilingManager.PROFILER_LOG_SEPERATOR + Pendo.isDebugLogEnabled());
        logs.add("Host app debuggable?" + ProfilingManager.PROFILER_LOG_SEPERATOR + SettingsUtils.isHostAppDebuggable());
        return logs.toArray(new String[logs.size()]);
    }

    @Override
    public void mark(String message) {

    }
}

