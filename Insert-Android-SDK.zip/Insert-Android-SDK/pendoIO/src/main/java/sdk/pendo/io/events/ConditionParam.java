package sdk.pendo.io.events;

import com.google.gson.annotations.SerializedName;

/**
 * Created by itayvallach on 12/09/2016.
 */
public class ConditionParam {

    @SerializedName("type")
    private String mType;

    @SerializedName("value")
    private String mValue;

    public String getType() {
        return mType;
    }

    public String getValue() {
        return mValue;
    }
}
