package sdk.pendo.io.actions;

import sdk.pendo.io.models.StepSeen;

public final class StepSeenManager {

    private static volatile StepSeenManager INSTANCE;
    private static final Object LOCK = new Object();
    private StepSeen mCurrentStepSeen = null;

    private StepSeenManager() {
    }

    public static synchronized StepSeenManager getInstance() {
        StepSeenManager result = INSTANCE;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = INSTANCE;
                if (result == null) { // 2nd check (w/ lock)
                    INSTANCE = result = new StepSeenManager();
                }
            }
        }
        return result;
    }

    public StepSeen getCurrentStepSeen() {
        return mCurrentStepSeen;
    }

    public Integer getCurrentStepIndex() {
        if (mCurrentStepSeen != null && mCurrentStepSeen.getStepIndex() != null) {
            return mCurrentStepSeen.getStepIndex();
        }
        return 0;
    }

    public String getCurrentStepId() {
        if (mCurrentStepSeen != null) {
            return mCurrentStepSeen.getStepId();
        }
        return null;
    }

    public String getCurrentStepGuideId() {
        if (mCurrentStepSeen != null) {
            return mCurrentStepSeen.getGuideId();
        }
        return null;
    }

    public void setCurrentStepSeen(StepSeen currentStepSeen) {
        mCurrentStepSeen = currentStepSeen;
    }
}
