package sdk.pendo.io.network.socketio.listeners;

import org.json.JSONObject;

import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * The device pairing Socket.IO listener.
 * Handles the enterPairedMode event
 * <p>
 * Created by assaf on 4/19/15.
 */
public final class PairedModeUpdateListener extends EmitterListener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got: pairedModeUpdate");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_PAIR_MODE_UPDATE, args);
        if (SocketEventFSM.getInstance().getCurrentState().equals(SocketEventFSM.States.STATE_PAIRED)) {
            JSONObject jsonObject = new JSONObject();
            SocketIOUtils.addSuccesfulToResponse(jsonObject, true);
            SocketIOUtils.emitToSocket(SocketEvents.EVENT_PAIRED_MODE_UPDATED.getCommand(), jsonObject);
        }
    }
}
