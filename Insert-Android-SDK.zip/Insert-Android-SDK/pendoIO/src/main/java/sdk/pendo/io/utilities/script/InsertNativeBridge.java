package sdk.pendo.io.utilities.script;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.actions.VisualInsertBase;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.constants.Constants;
import sdk.pendo.io.intelligence.IntelManager;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.SetupAction;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.utilities.DeviceStateUtils;
import sdk.pendo.io.utilities.PersistenceUtils;
import sdk.pendo.io.utilities.ReactiveUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.ViewHierarchyUtility;
import sdk.pendo.io.utilities.script.JavascriptRunner.InsertContext;
import sdk.pendo.io.views.custom.ViewBaseScriptBridge;

//import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.createInsertMetadataParam;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.createInsertMetadataParam;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_NOT_DISPLAYED_NO_CONNECTIVITY;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_NOT_DISPLAYED_OUT_OF_CAPPING;
import static sdk.pendo.io.actions.InsertCommandEventType.AppEventType.APP_SESSION_END;
import static sdk.pendo.io.analytics.AnalyticsProperties.REASON;
import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CAPPING;
import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONNECTIVITY;

/**
 * Pendo's script bridge to native Java.
 * <p>
 * Created by assaf on 11/8/16.
 */
@SuppressWarnings({"unused", "WeakerAccess"})
public final class InsertNativeBridge {

    private static final String DOES_NOT_EXIST_IN_CONTEXT_VALUE = "";
    private static final String EMPTY_VISITOR = "";
    private static final String EMPTY_ACCOUNT = "";

    @SuppressWarnings({"CheckStyle", "WeakerAccess"})
    public static final class InsertNativeBridgeJSFunctions {
        private InsertNativeBridgeJSFunctions() {
        }

        /**
         * A Holder JS class for the element id and element. It lazily gets the elements when needed.
         * <p>
         * function StandIn(id) {
         * this.elementId = id;
         * this.element = null;
         * <p>
         * this.getElement = function {
         * if (!this.element) {
         * this.element = Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.findElementById(this.elementId);
         * }
         * <p>
         * return this.element;
         * }
         * };
         * <p>
         * // ONLY FOR PAGER:
         * StandIn.prototype.getPageNumber = function() {
         * return this.getElement().getPageNumber();
         * }
         * <p>
         * // ONLY FOR FORM:
         * StandIn.prototype.getAnswers = function() {
         * return this.getElement().getAnswers();
         * };
         * <p>
         * <p>
         * StandIn.prototype.isValid = function() {
         * return this.getElement().isValid();
         * };
         * <p>
         * findElementById(id) {
         * return new StandIn(id);
         * }
         */
        public static final String JS_STANDIN_CONSTRUCTOR =
                jsFunctionBuilder(
                        "StandIn",
                        "id",
                        "this.elementId = id;"
                                + "this.element = null;"
                                + "this.type = null;");

        public static final String JS_STANDIN_PROTOTYPE_FUNCTION_GET_ELEMENT =
                jsAnonFunctionBuilder(
                        "StandIn.prototype.getElement",
                        "",
                        "if (!this.element) {"
                                + "this.element = Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.findElementById(this.elementId);"
                                + "this.type = this.element.getType();"
                                + "}"
                                + "return this.element;");

        public static final String JS_STANDIN_PROTOTYPE_FUNCTION_GET_TYPE =
                jsAnonFunctionBuilder(
                        "StandIn.prototype.getType",
                        "",
                        "this.getElement();"
                                + "return this.type;");

        public static final String JS_STANDIN_PROTOTYPE_FUNCTION_GET_PAGE_NUMBER =
                jsAnonFunctionBuilder(
                        "StandIn.prototype.getPageNumber",
                        "",
                        "return Number(this.getElement().getPageNumber());");

        public static final String JS_STANDIN_PROTOTYPE_FUNCTION_GET_ANSWERS =
                jsAnonFunctionBuilder(
                        "StandIn.prototype.getAnswers",
                        "",
                        "var answers = this.getElement().getAnswers();"
                                + "return JSON.parse(answers.toString());");

        public static final String JS_FUNCTION_FIND_ELEMENT_BY_ID =
                jsFunctionBuilder(
                        "findElementById",
                        "elementId",
                        "return new StandIn(elementId);");

        public static final String JS_FUNCTION_GET_FROM_CONTEXT =
                jsFunctionBuilder(
                        "getFromContext",
                        "context, parameterName",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getFromContext(context, parameterName));"
                );

        public static final String JS_FUNCTION_GET_GUIDE_STEP_ID =
                jsFunctionBuilder(
                        "getGuideStepId",
                        "context",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getGuideStepId(context));"
                );

        public static final String JS_FUNCTION_GET_DURATION_INSERT_DISMISSED =
                jsFunctionBuilder(
                        "getGuideStepDuration",
                        "context",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getGuideStepDuration(context));"
                );

        public static final String JS_FUNCTION_GET_GUIDE_STEP_ADVANCED_DURATION =
                jsFunctionBuilder(
                        "getGuideStepAdvancedDuration",
                        "context",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getGuideStepAdvancedDuration(context));"

                );

        public static final String JS_FUNCTION_GET_DURATION_SCREEN_LEFT =
                jsFunctionBuilder(
                        "getDurationScreenLeft",
                        "context",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getDurationScreenLeft(context));"
                );

        public static final String JS_FUNCTION_GET_ACTIVE_TIME_FROM_LAST_FOREGROUND =
                jsFunctionBuilder(
                        "getActiveTimeFromLastForeground",
                        "",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getActiveTimeFromLastForeground());"
                );

        public static final String JS_FUNCTION_GET_DURATION_APP_IN_BACKGROUND =
                jsFunctionBuilder(
                        "getDurationAppInBackground",
                        "",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getDurationAppInBackground());"
                );

        public static final String JS_FUNCTION_GET_ACTIVE_TIME_FOR_APP_SESSION_END =
                jsFunctionBuilder(
                        "getActiveTimeForAppSessionEnd",
                        "",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getActiveTimeForAppSessionEnd());"
                );


        public static final String JS_FUNCTION_GET_DURATION_SESSION_END =
                jsFunctionBuilder(
                        "getDurationSessionEnd",
                        "",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getDurationSessionEnd());"
                );

        public static final String JS_FUNCTION_GET_ACTIVE_TIME_SCREEN_LEFT =
                jsFunctionBuilder(
                        "getActiveTimeScreenLeft",
                        "context",
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getActiveTimeScreenLeft(context));"
                );

        public static final String JS_FUNCTION_VALIDATE_FORM =
                jsAnonFunctionBuilder(
                        "StandIn.prototype.isValid",
                        "",
                        "return this.getElement().isValid();");

        public static final String JS_FUNCTION_FIND_DISPATCH_ACTIONS =
                jsFunctionBuilder(
                        "dispatchActions",
                        "action, context",
                        "var stringAction = JSON.stringify(action);"
                                + "Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.dispatchActions(stringAction, context);");

        public static final String JS_FUNCTION_FIND_DISPATCH_TRIGGER_ACTIONS =
                jsFunctionBuilder(
                        "dispatchTriggerActions",
                        "action, context",
                        "var stringAction = JSON.stringify(action);"
                                + "Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.dispatchActions(stringAction, context);");

        public static final String JS_FUNCTION_LOG_I =
                jsFunctionBuilder(
                        "logI",
                        "msg",
                        "Packages.sdk.pendo.io.logging.InsertLogger.i(msg);");

        public static final String JS_FUNCTION_LOG_D =
                jsFunctionBuilder(
                        "logD",
                        "msg",
                        "Packages.sdk.pendo.io.logging.InsertLogger.d(msg);");

        public static final String JS_FUNCTION_GET_ORIENTATION =
                jsFunctionBuilder(
                        "getOrientation",
                        null,
                        "return String(Packages.sdk.pendo.io.utilities.script.InsertNativeBridge.getOrientation());");

        public static final String JS_FUNCTION_LOG_E =
                jsFunctionBuilder(
                        "logE",
                        "msg",
                        "Packages.sdk.pendo.io.logging.InsertLogger.e(msg);");

        private static String jsAnonFunctionBuilder(@NonNull String functionName,
                                                    @Nullable String parameters,
                                                    @Nullable String code) {
            return functionName + " = function(" + Utils.replaceIfNull(parameters) + ") {"
                    + Utils.replaceIfNull(code)
                    + "}";
        }

        private static String jsFunctionBuilder(@NonNull String functionName,
                                                @Nullable String parameters,
                                                @Nullable String code) {
            return "function " + functionName + "(" + Utils.replaceIfNull(parameters) + ") {"
                    + Utils.replaceIfNull(code)
                    + "}";
        }
    }

    private InsertNativeBridge() {
    }

    @Nullable
    public static ViewBaseScriptBridge findElementById(String elementId) {
        final Activity currentVisibleActivity = ApplicationObservers.getInstance()
                .getCurrentVisibleActivity();

        if (currentVisibleActivity != null) {
            final View view = IntelManager
                    .findViewInHierarchy(
                            ViewHierarchyUtility.INSTANCE.getCurrentRootView(currentVisibleActivity),
                            elementId);

            if (view instanceof ViewBaseScriptBridge) {
                return ((ViewBaseScriptBridge) view).getViewScriptBridge();
            }
        }

        return null;
    }

    /**
     * A getter for the orientation.
     *
     * @return the device orientation
     */
    public static String getOrientation() {
        return DeviceStateUtils.getDeviceOrientation();
    }

    /**
     * Returns the value of the key "parameterName" from the given context.
     *
     * @param context       - The context we want to question.
     * @param parameterName - The key in the context map.
     * @return the value of the key in the context.
     */
    public static String getFromContext(InsertContext context, @NonNull String parameterName) {
        String parameterValue = null;
        if (context != null) {
            parameterValue = context.get(parameterName, String.class);
        }
        if (parameterValue == null) {
            return DOES_NOT_EXIST_IN_CONTEXT_VALUE;
        }
        return parameterValue;
    }

    public static String getGuideStepId(InsertContext context) {
        String parameterValue = null;
        if (context != null) {
            parameterValue = context.get(AnalyticsProperties.GUIDE_STEP_ID, String.class);
        }
        if (parameterValue == null) {
            return DOES_NOT_EXIST_IN_CONTEXT_VALUE;
        }
        return parameterValue;
    }

    /**
     * Computes the total time from a given interval array of the following format:
     * [{"time":1500311837, "duration":5000}, {"time":1500312017, "duration":2000}]
     * By summing up the durations.
     *
     * @param intervalArray
     */
    private static Long computeIntervalsDurationFromJSONArray(JSONArray intervalArray) {
        long duration = 0;
        if (intervalArray == null) {
            return duration;
        }
        for (int i = 0; i < intervalArray.length(); i++) {
            JSONObject interval = null;
            try {
                interval = intervalArray.getJSONObject(i);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            if (interval != null) {
                long intervalDuration = 0;
                if (interval.has(AnalyticsProperties.INTERVAL_DURATION)) {
                    try {
                        intervalDuration = interval.getLong(AnalyticsProperties.INTERVAL_DURATION);
                    } catch (JSONException e) {
                        InsertLogger.e(e, e.getMessage());
                    }
                    duration += intervalDuration;
                }
            }
        }
        return duration;
    }

    /**
     * This will get the duration in milliseconds of the showing insert.
     *
     * @param context
     * @return duration of insert showing.
     */
    public static String getGuideStepDuration(InsertContext context) {
        String result = context.get(AnalyticsProperties.DISPLAY_DURATION, String.class);
        if (result == null) {
            if (context.getGuideId() != null) {
                VisualInsertBase visualInsert = VisualInsertManager.getInstance()
                        .getVisualInsert(context.getGuideId());
                if (visualInsert != null) {
                    result = String.valueOf(visualInsert.getDuration());
                }
            }
        }
        return result;
    }

    /**
     * This will get the duration in milliseconds of the dismissed step.
     *
     * @param context
     * @return duration of insert showing.
     */
    public static String getGuideStepAdvancedDuration(InsertContext context) {
        String result = context.get(AnalyticsProperties.STEP_DISPLAY_DURATION, String.class);
        if (result == null) {
            if (context.getGuideId() != null) {
                VisualInsertBase visualInsert = VisualInsertManager.getInstance()
                        .getVisualInsert(context.getGuideId());
                if (visualInsert != null) {
                    result = String.valueOf(visualInsert.getDuration());
                }
            }
        }
        return result;
    }

    /**
     * Returns the json array of times of the screen visibility until left.
     * The following format is used:
     * [{"time":1500311837, "duration":5000}, {"time":1500312017, "duration":2000}]
     *
     * @param context
     * @return json array string of intervals.
     */
    public static String getActiveTimeScreenLeft(InsertContext context) {
        if (context.getScreenId() != null) {
            return PersistenceUtils.getFullTimeIntervalledAnalyticsScreenLeft(
                    context.getScreenId()).toString();
        }
        return new JSONArray().toString();
    }

    /**
     * Get the duration of the time from when we first saw the screen until it has been left.
     * by summing up the duration in all of its intervals, which are of the following format:
     * [{"time":1500311837, "duration":5000}, {"time":1500312017, "duration":2000}]
     *
     * @param context
     * @return duration of screen left
     */
    public static String getDurationScreenLeft(InsertContext context) {
        int defaultDuration = 0;
        JSONArray intervalArray = PersistenceUtils.getFullTimeIntervalledAnalyticsScreenLeft(
                context.getScreenId());
        if (intervalArray != null && intervalArray.length() > 0) {
            return Long.toString(computeIntervalsDurationFromJSONArray(intervalArray));
        }
        return String.valueOf(defaultDuration);
    }

    /**
     * Returns the json of the last interval between appInForeground/AppSessionStart
     * and appInBackground.
     * The json will be of the following format:
     * {"time":1500311837, "duration":5000}
     *
     * @return json string of interval.
     */
    public static String getActiveTimeFromLastForeground() {
        String foregroundIntervalString = PersistenceUtils.getLastIntervalledAnalyticsForAppInBackground();
        JSONObject lastTimeInForegroundJSON = null;
        JSONArray lastTimeInForegroundJsonArray = new JSONArray();
        if (foregroundIntervalString == null) {
            return lastTimeInForegroundJsonArray.toString();
        }
        try {
            lastTimeInForegroundJSON = new JSONObject(foregroundIntervalString);
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
        if (lastTimeInForegroundJSON != null) {
            lastTimeInForegroundJsonArray.put(lastTimeInForegroundJSON);
        }
        return lastTimeInForegroundJsonArray.toString();
    }

    /**
     * Return the duration in millis of the last interval of the app in foreground.
     *
     * @return duration in millis of the aforementioned.
     */
    public static String getDurationAppInBackground() {
        int defaultDuration = 0;
        String lastIntervalString = PersistenceUtils.getLastIntervalledAnalyticsForAppInBackground();
        if (lastIntervalString == null) {
            return Integer.toString(defaultDuration);
        }
        JSONObject lastIntervalJSONObject = null;
        long duration = 0;
        try {
            lastIntervalJSONObject = new JSONObject(lastIntervalString);
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }

        if (lastIntervalJSONObject != null && lastIntervalJSONObject.has(AnalyticsProperties.INTERVAL_DURATION)) {
            try {
                duration = lastIntervalJSONObject.getLong(AnalyticsProperties.INTERVAL_DURATION);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return Long.toString(duration);
    }

    public static String getDurationSessionEnd() {
        //In ms.
        int appSessionDuration = Integer.parseInt(PersistenceUtils.getAppSessionDuration());
        return Long.toString(TimeUnit.SECONDS.toMillis(appSessionDuration));
    }

    /**
     * Get the active time intervals of the app.
     * The intervals will be in this format:
     * [{"time":1500311837, "duration":5000}, {"time":1500312017, "duration":2000}]
     *
     * @return json array string of time intervals.
     */
    public static String getActiveTimeForAppSessionEnd() {
        return PersistenceUtils.getFullTimeIntervalledAnalyticsAppSessionEnd().toString();
    }

    /**
     * Adds visitor id and account id info to analytics.
     *
     * @param commandList
     */
    private static void addVisitorAccountInfo(List<InsertCommand> commandList) {
        // Get persisted visitor and account id. In case we called initSDK with visitor and account,
        // these variables will reflect the initSDK supplied account and visitor.
        // In any other case they will reflect the stored account and visitor id.
        String visitorId = PersistenceUtils.getPersistedVisitorId();
        String accountId = PersistenceUtils.getPersistedAccountId();
        for (InsertCommand command : commandList) {
            String commandEventTypeString = command.getEventType().eventType;
            // On every app session end, get the visitor and account from a property on Pendo IDEV-13424
            if (APP_SESSION_END.eventType.equals(commandEventTypeString)) {
                visitorId = Pendo.getPersistedVisitorId();
                if (visitorId == null) {
                    visitorId = EMPTY_VISITOR;
                }
                accountId = Pendo.getPersistedAccountId();
                if (accountId == null) {
                    accountId = EMPTY_ACCOUNT;
                }
            }

            // In case we have an account send it, otherwise tell backend to run anonymous.
            if (accountId != null) {
                command.addParameter(new InsertCommandsEventBus.Parameter(SetupAction.ACCOUNT_ID, Constants.GeneralConsts.TYPE_STRING, accountId));
            } else {
                command.addParameter(new InsertCommandsEventBus.Parameter(SetupAction.ACCOUNT_ID, Constants.GeneralConsts.TYPE_STRING, EMPTY_ACCOUNT));
            }
            // In case we have an visitor send it, otherwise tell backend to run anonymous.
            if (visitorId != null) {
                command.addParameter(new InsertCommandsEventBus.Parameter(SetupAction.VISITOR_ID, Constants.GeneralConsts.TYPE_STRING, visitorId));
            } else {
                command.addParameter(new InsertCommandsEventBus.Parameter(SetupAction.VISITOR_ID, Constants.GeneralConsts.TYPE_STRING, EMPTY_VISITOR));
            }
        }
    }

    /**
     * Dispatches the given command iff it matches the {@link InsertCommandEventType}.
     *
     * @param commands the {@link InsertCommand}s to dispatch in JSON string format.
     */
    public static void dispatchActions(@NonNull final String commands, final InsertContext context) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                try {
                    List<InsertCommand> commandList;
                    JsonParser parser = new JsonParser();
                    JsonElement commandsJsonElement = parser.parse(commands);
                    if (commandsJsonElement.isJsonArray()) {
                        commandList = InsertCommand.getInsertCommands(commandsJsonElement.getAsJsonArray());
                    } else {
                        commandList = InsertCommand.commandFactory(commandsJsonElement.getAsJsonObject());
                    }
                    if (!commandList.isEmpty()) {
                        if (context != null) {
                            List<InsertCommand> filteredCommandList = new ArrayList<>();
                            // Filter "piped" commands according to correct Reason.

                            for (InsertCommand command : commandList) {
                                if (ERROR_REASON_CAPPING.getValue().equals(context.get(REASON, String.class))) {
                                    if (command.getEventType().equals(GUIDE_NOT_DISPLAYED_OUT_OF_CAPPING)) {
                                        filteredCommandList.add(command);
                                        break;
                                    }
                                }
                                if (ERROR_REASON_CONNECTIVITY.getValue().equals(context.get(REASON, String.class))) {
                                    if (command.getEventType().equals(GUIDE_NOT_DISPLAYED_NO_CONNECTIVITY)) {
                                        filteredCommandList.add(command);
                                        break;
                                    }
                                }
                            }

                            if (!filteredCommandList.isEmpty()) {
                                commandList = filteredCommandList;
                            }
                            for (InsertCommand command : commandList) {
                                final String insertId = context.getGuideId();

                                if (insertId != null) {
                                    command.addParameter(createInsertMetadataParam(insertId));
                                }
                            }
                        }

                        InsertCommandDispatcher.getInstance().dispatchCommands(commandList,
                                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY, true);
                    }
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        });
    }
}
