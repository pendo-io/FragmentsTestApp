package sdk.pendo.io.reactive.filters;

import io.reactivex.functions.Predicate;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.events.EventsManager;

/**
 * Filter that returns true when receiving a name of an activity that has view manipulation inserts.
 * Created by itayvallach on 09/11/2016.
 */

public class HasViewManipulationsFilter implements Predicate<Object> {

    private final String mActivityName;

    public HasViewManipulationsFilter(String activityName) {
        mActivityName = activityName;
    }

    @Override
    public boolean test(Object nil) {
        return mActivityName != null &&
                ActivationManager.INSTANCE.isInited();
//                && EventsManager.getInstance()
//                        .hasViewManipulationsForActivity(mActivityName);
    }

}
