package sdk.pendo.io.network.socketio.configuration;

import java.net.URI;

public enum SocketServerEndpoint {
    PRODUCTION("https://websockets.mobile.pendo.io"),
    CUSTOM("");

    private URI mUri;

    SocketServerEndpoint(String url){
        mUri = URI.create(url);
    }

    public URI getUrl() {
        return mUri;
    }


    /**
     * Sets the Socket endpoint uri
     * @param uri
     * @return the APIEndpoint with the url inside
     */
    public SocketServerEndpoint setUrl(URI uri) {
        mUri = uri;
        return this;
    }

}
