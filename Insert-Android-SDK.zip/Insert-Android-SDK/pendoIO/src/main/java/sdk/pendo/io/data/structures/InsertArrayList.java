package sdk.pendo.io.data.structures;

import android.annotation.TargetApi;
import android.os.Build;
import android.view.View;
import android.view.ViewTreeObserver;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import sdk.pendo.io.events.PassiveTriggersListener;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.GlobalLayoutDebouncer;
import sdk.pendo.io.utilities.ViewHierarchyUtility;

/**
 * A class that replaces the {@link ArrayList} of the {@link android.view.WindowManager} mRoots.
 *
 * Created by assaf on 11/16/16.
 */
public final class InsertArrayList<E> extends ArrayList<E> {

    private static final String CLASS_VIEW_ROOT_IMPL = "ViewRootImpl";
    private static final String FIELD_NAME_M_ATTACH_INFO = "mAttachInfo";
    private static final String FIELD_NAME_M_TREE_OBSERVER = "mTreeObserver";
    private static final String FIELD_NAME_M_VIEW = "mView";

    private HashMap<E, ViewTreeObserver.OnGlobalLayoutListener> mOnGlobalLayoutListeners =
            new HashMap<>();

    @Override
    public boolean add(final E viewToAdd) {

        // If the view being added is a ViewRootImpl,
        // set OnGlobalLayoutListener on the mView inside of it.
        if (viewToAdd.getClass().getSimpleName().equals(CLASS_VIEW_ROOT_IMPL)) {

            try {
                Field field_mAttachInfo =
                        viewToAdd.getClass().getDeclaredField(FIELD_NAME_M_ATTACH_INFO);
                field_mAttachInfo.setAccessible(true);
                final Object mAttachInfo = field_mAttachInfo.get(viewToAdd);

                Field field_mTreeObserver =
                        mAttachInfo.getClass().getDeclaredField(FIELD_NAME_M_TREE_OBSERVER);
                field_mTreeObserver.setAccessible(true);
                final ViewTreeObserver mTreeObserver =
                        (ViewTreeObserver) field_mTreeObserver.get(mAttachInfo);

                final ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener
                        = new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {

                        try {
                            Field field_mView =
                                    viewToAdd.getClass().getDeclaredField(FIELD_NAME_M_VIEW);
                            field_mView.setAccessible(true);
                            final View mView = (View) field_mView.get(viewToAdd);

                            final Observable<Object> debouncer = GlobalLayoutDebouncer.getInstance()
                                    .getDebouncer(mView);
                            debouncer.subscribe(InsertObserver.create(
                                    new Consumer<Object>() {
                                @Override
                                public void accept(Object nill) {
                                    ViewHierarchyUtility.INSTANCE.addListenersToViewHierarchy(mView);
                                    PassiveTriggersListener.INSTANCE.activityStateChange();
                                }
                            }));

                            // Do once first.
                            ViewHierarchyUtility.INSTANCE.addListenersToViewHierarchy(mView);

                            PassiveTriggersListener.INSTANCE.activityStateChange();


                            Field field_mAttachInfo =
                                    viewToAdd.getClass().getDeclaredField(FIELD_NAME_M_ATTACH_INFO);
                            field_mAttachInfo.setAccessible(true);
                            final Object mAttachInfo = field_mAttachInfo.get(viewToAdd);

                            Field field_mTreeObserver =
                                    mAttachInfo.getClass().getDeclaredField(FIELD_NAME_M_TREE_OBSERVER);
                            field_mTreeObserver.setAccessible(true);
                            final ViewTreeObserver mTreeObserver =
                                    (ViewTreeObserver) field_mTreeObserver.get(mAttachInfo);

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                mTreeObserver.removeOnGlobalLayoutListener(this);
                            } else {
                                mTreeObserver.removeGlobalOnLayoutListener(this);
                            }

                            InsertLogger.d("Added listener.");
                        } catch (Exception e) {
                            InsertLogger.e(e, e.getMessage());
                        }
                    }
                };

                mTreeObserver.addOnGlobalLayoutListener(onGlobalLayoutListener);

//                mOnGlobalLayoutListeners.put(viewToAdd, onGlobalLayoutListener);
                InsertLogger.d("Added listener.");
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
            return super.add(viewToAdd);
        }

        return false;
    }

    @Override
    public void add(int index, E object) {
        super.add(index, object);
    }

    @Override
    public boolean addAll(Collection<? extends E> collection) {
        return super.addAll(collection);
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> collection) {
        return super.addAll(index, collection);
    }

    @Override
    public E remove(int index) {
        final E removed = super.remove(index);

//        if (removed.getClass().getSimpleName().equals(CLASS_VIEW_ROOT_IMPL)) {
//
//            try {
//                Field field_mAttachInfo =
//                        removed.getClass().getDeclaredField(FIELD_NAME_M_ATTACH_INFO);
//                field_mAttachInfo.setAccessible(true);
//                final Object mAttachInfo = field_mAttachInfo.get(removed);
//
//                Field field_mTreeObserver =
//                        mAttachInfo.getClass().getDeclaredField(FIELD_NAME_M_TREE_OBSERVER);
//                field_mTreeObserver.setAccessible(true);
//                final ViewTreeObserver mTreeObserver =
//                        (ViewTreeObserver) field_mTreeObserver.get(mAttachInfo);
//
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//                    removeJellyBeanOnGlobalLayoutListener(mTreeObserver, removed);
//                } else {
//                    removeIceCreamSandwichOnGlobalLayoutListener(mTreeObserver, removed);
//                }
//
//                InsertLogger.d("Removed listener!");
//
//            } catch (Exception e) {
//                InsertLogger.e(e, e.getMessage());
//            }
//        }

        return removed;
    }

    @Override
    public boolean remove(Object object) {
        return super.remove(object);
    }

    @Override
    protected void removeRange(int fromIndex, int toIndex) {
        super.removeRange(fromIndex, toIndex);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void removeJellyBeanOnGlobalLayoutListener(ViewTreeObserver viewTreeObserver, E o) {
        viewTreeObserver.removeOnGlobalLayoutListener(mOnGlobalLayoutListeners.remove(o));
    }


    @SuppressWarnings("deprecation")
    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    private void removeIceCreamSandwichOnGlobalLayoutListener(ViewTreeObserver viewTreeObserver, E o) {
        viewTreeObserver.removeGlobalOnLayoutListener(mOnGlobalLayoutListeners.remove(o));
    }
}
