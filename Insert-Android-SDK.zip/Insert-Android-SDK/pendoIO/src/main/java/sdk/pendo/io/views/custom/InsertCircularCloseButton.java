package sdk.pendo.io.views.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.view.View;

import org.apache.commons.lang3.tuple.Pair;

import java.util.List;

import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandEventType.UserEventType;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.views.custom.ActionableBlock.OnSubmitAction.CLOSE;

/**
 * Pendo's close button view.
 */
public final class InsertCircularCloseButton extends View
        implements ActionableBlock, InsertCustomView, View.OnClickListener {
    private Paint mXPaint;
    private Paint mCircleStrokePaint;
    private Paint mCirclePaint;
    private int mXColor;
    private int mCircleStrokeColor;
    private int mCircleColor;
    private float mXWidth;
    private float mCircleWidth;

    private String mActionParam;

    public InsertCircularCloseButton(Context context) {
        this(context, null);
    }

    public InsertCircularCloseButton(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public InsertCircularCloseButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {

        InsertContentDescriptionManager.getInstance().setContentDescription(this,
                getContext().getString(R.string.insert_close_button_accessibility_description), null);
        setBackgroundColor(Color.TRANSPARENT);
        setOnClickListener(this);

        // Load attributes
        final TypedArray a = getContext().obtainStyledAttributes(
                attrs, R.styleable.InsertCircularCloseButton, defStyle, 0);

        mXColor = a.getColor(
                R.styleable.InsertCircularCloseButton_insertXColor,
                Color.BLACK);
        mCircleStrokeColor = a.getColor(
                R.styleable.InsertCircularCloseButton_insertFrameColor,
                Color.BLACK);
        mCircleColor = a.getColor(
                R.styleable.InsertCircularCloseButton_insertCircleColor,
                Color.WHITE);

        mXWidth = a.getDimension(
                R.styleable.InsertCircularCloseButton_insertXWidth,
                getResources().getDimension(R.dimen.circle_close_button_width));
        mCircleWidth = a.getDimension(
                R.styleable.InsertCircularCloseButton_insertFrameWidth,
                getResources().getDimension(R.dimen.circle_close_button_width));

        mXPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCircleStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mXPaint.setColor(mXColor);
        mCircleStrokePaint.setColor(mCircleStrokeColor);
        mCirclePaint.setColor(mCircleColor);
        mXPaint.setStyle(Paint.Style.STROKE);
        mCircleStrokePaint.setStyle(Paint.Style.STROKE);
        mCirclePaint.setStyle(Paint.Style.FILL);
        mXPaint.setStrokeWidth(mXWidth);
        mCircleStrokePaint.setStrokeWidth(mCircleWidth);

        a.recycle();
    }

    @SuppressWarnings("CheckStyle")
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, getHeight() / 3.0f, mCirclePaint);
        canvas.drawCircle(getWidth() / 2.0f, getHeight() / 2.0f, getHeight() / 3.0f, mCircleStrokePaint);
        canvas.drawLine(getWidth() / 3.0f, getHeight() / 3.0f, 2 * getWidth() / 3.0f, 2 * getHeight() / 3.0f, mXPaint);
        canvas.drawLine(getWidth() / 3.0f, 2 * getWidth() / 3.0f, 2 * getWidth() / 3.0f, getHeight() / 3.0f, mXPaint);
    }

    @Override
    public void setActionParam(String actionParam) {

        mActionParam = actionParam;
    }

    @Override
    public String getActionParam() {
        return mActionParam;
    }

    @NonNull
    @Override
    public CharSequence getElementId() {
        return getContentDescription();
    }

    public void setXColor(int color) {
        mXColor = color;
        mXPaint.setColor(mXColor);
    }

    public void setXWidth(int xWidth) {
        mXWidth = xWidth;
        mXPaint.setStrokeWidth(mXWidth);
    }

    @Override
    public void setStrokeWidth(int frameWidth) {
        mCircleWidth = frameWidth;
        mCircleStrokePaint.setStrokeWidth(mCircleWidth);
    }

    @Override
    public void setStrokeColor(int color) {
        mCircleStrokeColor = color;
        mCircleStrokePaint.setColor(mCircleStrokeColor);
    }

    public void setCircleColor(int color) {
        mCircleColor = color;
        mCirclePaint.setColor(mCircleColor);
    }

    @Override
    public Pair<OnSubmitAction, String> getOnSubmit() {
        // Default is close.
        return Pair.of(CLOSE, null);
    }

    private List<InsertCommand> mCommands = null;
    @Override
    public void setActions(List<InsertCommand> commands) {

        if (commands == null || commands.isEmpty()) {
            InsertLogger.d("No commands.");
            return;
        }

        mCommands = commands;
    }

    @Override
    public void onClick(View v) {

        if (mCommands == null || mCommands.isEmpty()) {
            InsertLogger.d("No commands.");
            return;
        }
        JavascriptRunner.InsertContext.addBasicParamsToInsertCommands(mCommands);
        InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, UserEventType.TAP_ON, true);
    }

    @Override
    public void setOnSubmit(String onSubmit) {
    }

    @Override
    public void renderView() {
        invalidate();
    }

    @Override
    public void setCornerRadius(float cornerRadius) {}

    @Override
    public void setCornerRadii(float[] cornerRadii) {}
}
