package sdk.pendo.io.reactive.observers;

import android.support.annotation.NonNull;

import java.security.cert.CertPathValidatorException;
import java.util.NoSuchElementException;

import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.Observable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.observers.DisposableObserver;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.utilities.AnalyticsUtils;

/**
 * Implements default Observer behaviour and can get any action from clients. this is done to make
 * sure we have a onError implementation so the errors will be contained in RX error handling rather
 * than through unhandled exception Created by nirsegev on 7/16/15.
 */
public final class InsertObserver<T> extends DisposableObserver<T> {

    private Consumer<? super T> mOnNext;
    private Consumer<Throwable> mOnError;
    private Action mOnComplete;

    private InsertObserver(final Consumer<? super T> onNext,
                           final Consumer<Throwable> onError,
                           final Action onComplete) {

        mOnNext = onNext;
        mOnError = onError;
        mOnComplete = onComplete;
    }

    @Override
    public void onComplete() {
        if (mOnComplete != null) {
            try {
                mOnComplete.run();
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    }

    @Override
    public void onError(Throwable e) {
        if (shouldReportException(e)) {
            AnalyticsUtils.sendExceptionReport(e);
        }
        if (mOnError != null) {
            try {
                mOnError.accept(e);
            } catch (Exception e1) {
                InsertLogger.e(e1, e1.getMessage());
            }
        }
    }

    public static boolean shouldReportException(Throwable e) {
        return !(e instanceof NoSuchElementException)
                && !(e instanceof CertPathValidatorException);
    }

    @Override
    public void onNext(T t) {
        try {
            mOnNext.accept(t);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    public static final class Builder<T> {
        private Consumer<Throwable> mOnError = null;
        private Action mOnComplete = null;
        private Consumer<? super T> mOnNext = null;

        Builder<T> addOnNextAction(final Consumer<? super T> onNext) {
            mOnNext = onNext;
            return this;
        }

        Builder<T> addOnErrorAction(final Consumer<Throwable> onError) {
            mOnError = onError;
            return this;
        }

        Builder<T> addOnCompleteAction(final Action onComplete) {
            mOnComplete = onComplete;
            return this;
        }

        InsertObserver<T> build() {
            return new InsertObserver<>(mOnNext, mOnError, mOnComplete);
        }
    }

    /**
     * Creates an {@link InsertObserver} with a callback to handle
     * the items the {@link Observable} emits.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onNext
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     *
     * @return a {@link InsertObserver} with a callback for {@link Observer#onNext(T)}.
     *
     * @throws IllegalArgumentException
     *             if {@code onNext} is null
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     */
    @SuppressWarnings("SSBasedInspection")
    @NonNull
    public static <T> InsertObserver<T> create(@NonNull final Consumer<T> onNext) {
        //noinspection ConstantConditions
        if (onNext == null) {
            throw new IllegalArgumentException("onNext can not be null");
        }

        return new InsertObserver.Builder<T>()
                .addOnNextAction(onNext)
                .addOnErrorAction(new InsertOnErrorHandler())
                .build();
    }

    /**
     * Creates an {@link InsertObserver} with callbacks to handle
     * the items the {@link Observable} emits and any error notification it issues.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onNext
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     * @param onError
     *             the {@code Consumer<Throwable>} you have designed
     *             to accept any error notification from the Observable.
     *
     * @return a {@link InsertObserver} with a callbacks for {@link Observer#onNext(T)}
     * and {@link Observer#onError(Throwable)}.
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     *
     * @throws IllegalArgumentException
     *             if {@code onNext} is null, or
     *             if {@code onError} is null
     */
    @NonNull
    public static <T> InsertObserver<T> create(@NonNull final Consumer<T> onNext,
                                               @NonNull final Consumer<Throwable> onError) {
        //noinspection ConstantConditions
        if (onNext == null) {
            throw new IllegalArgumentException("onNext can not be null");
        }
        //noinspection ConstantConditions
        if (onError == null) {
            throw new IllegalArgumentException("onError can not be null");
        }

        return new InsertObserver.Builder<T>()
                .addOnNextAction(onNext)
                .addOnErrorAction(onError)
                .build();
    }

    /**
     * Creates an {@link InsertObserver} with callbacks to handle
     * the items the {@link Observable} emits and any error notification or
     * completion notification it issues.
     * <dl>
     *  <dt><b>Scheduler:</b></dt>
     *  <dd>{@code subscribe} does not operate by default on a particular {@link Scheduler}.</dd>
     * </dl>
     *
     * @param onNext
     *             the {@code Consumer<T>} you have designed to accept emissions from the Observable.
     * @param onError
     *             the {@code Consumer<Throwable>} you have designed
     *             to accept any error notification from the Observable.
     * @param onComplete
     *             the {@code Action} you have designed
     *             to accept a completion notification from the Observable.
     *
     * @return a {@link InsertObserver} with a callbacks for {@link Observer#onNext(T)},
     * {@link Observer#onError(Throwable)} and {@link Observer#onComplete()}.
     *
     * @throws IllegalArgumentException
     *             if {@code onNext} is null, or
     *             if {@code onError} is null, or
     *             if {@code onComplete} is null
     *
     * @see <a href="http://reactivex.io/documentation/operators/subscribe.html">
     *     ReactiveX operators documentation: Subscribe</a>
     */
    @NonNull
    public static <T> InsertObserver<T> create(@NonNull final Consumer<T> onNext,
                                               @NonNull final Consumer<Throwable> onError,
                                               @NonNull final Action onComplete) {

        //noinspection ConstantConditions
        if (onNext == null) {
            throw new IllegalArgumentException("onNext can not be null");
        }
        //noinspection ConstantConditions
        if (onError == null) {
            throw new IllegalArgumentException("onError can not be null");
        }
        //noinspection ConstantConditions
        if (onComplete == null) {
            throw new IllegalArgumentException("onComplete can not be null");
        }

        return new InsertObserver.Builder<T>()
                .addOnNextAction(onNext)
                .addOnErrorAction(onError)
                .addOnCompleteAction(onComplete)
                .build();
    }
}
