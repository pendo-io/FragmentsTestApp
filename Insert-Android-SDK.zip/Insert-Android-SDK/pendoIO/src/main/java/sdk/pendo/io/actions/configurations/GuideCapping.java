package sdk.pendo.io.actions.configurations;

import com.google.gson.annotations.SerializedName;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pendo's capping.
 * <p/>
 * Created by assaf on 6/14/15.
 */
public final class GuideCapping {

    private static final String INSERT_CAPPING_CONSUMED = "consumed";
    public static final String INSERT_CAPPING_MAX_SESSION_IMPRESSIONS = "maxSessionImpressions";

    @SerializedName(INSERT_CAPPING_MAX_SESSION_IMPRESSIONS)
    private volatile int mMaxSessionImpressions = -1;

    private transient volatile AtomicInteger mConsumed = new AtomicInteger(0);

    /* package */
    public synchronized int getMaxSessionImpressions() {
        return mMaxSessionImpressions;
    }

    public synchronized void setConsumed(int consumed) {
        mConsumed.set(consumed);
    }

    public synchronized boolean canConsumeOne() {
        // In case the max session capping is not set, we treat it as always
        return mMaxSessionImpressions == -1 || mConsumed.get() < mMaxSessionImpressions;

    }

    public synchronized boolean consumeOne() {
        // In case the max session capping is not set, we treat it as always
        if (mMaxSessionImpressions == -1) {
            return true;
        }

        if (mConsumed.get() < mMaxSessionImpressions) {
            mConsumed.getAndIncrement();
            return true;
        }

        return false;
    }

    public synchronized int getConsumed() {
        return mConsumed.get();
    }

    @Override
    public synchronized String toString() {
        return "{"
                + INSERT_CAPPING_MAX_SESSION_IMPRESSIONS + " = " + mMaxSessionImpressions + ", "
                + INSERT_CAPPING_CONSUMED + " = " + mConsumed + ", "
                + "}";
    }
}
