package sdk.pendo.io.utilities;

import android.content.Context;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Created by nirsegev on 4/14/16.
 */
public class FileUtils {

    public static final String CANNOT_CREATE_CACHE_FILE = "Cannot create cache file";

    @Nullable
    public static String getStoredFileAsString(String fileName) {
        final Context context = Pendo.getApplicationContext();
        final File filesDir = context.getFilesDir();
        final File cacheFile = new File(filesDir, fileName);

        if (!cacheFile.exists()) {
            return null;
        }

        final StringBuilder string = new StringBuilder();
        final FileInputStream fis;
        try {
            fis = context.openFileInput(fileName);
        } catch (FileNotFoundException e) {
            InsertLogger.e(e, e.getMessage());
            return null;
        }

        InputStreamReader isr = new InputStreamReader(fis, Charset.forName(ENCODING_UTF_8));
        try {
            BufferedReader bufferedReader = new BufferedReader(isr);

            String readString = bufferedReader.readLine();
            while (readString != null) {
                string.append(readString);
                readString = bufferedReader.readLine();
            }

            bufferedReader.close();

        } catch (IOException e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            try {
                fis.close();
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }

            try {
                isr.close();
            } catch (IOException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

        if (TextUtils.isEmpty(string.toString())) {
            InsertLogger.i("No stored information");
            return null;
        }
        return string.toString();
    }

    public static void createFileFromByteArray(byte[] bytesArray, String cacheFileName) {
        FileOutputStream fos = null;
        final Context context = Pendo
                .getApplicationContext();

        try {
            createCacheFile(context, cacheFileName);

            fos = context.openFileOutput(cacheFileName, Context.MODE_PRIVATE);

            fos.write(bytesArray);
            fos.flush();

        } catch (IOException e) {
            InsertLogger.e(e, e.getMessage());
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }
    }

    /**
     * Creates the cache file if it doesn't {@link File#exists()} yet and returns it.
     *
     * @param context the application's context.
     * @return the cache {@link File}.
     * @throws IOException if it's not possible to create the file.
     */
    public static File createCacheFile(Context context, String fileName) throws IOException {
        final File filesDir = context.getFilesDir();
        final File cacheFile = new File(filesDir, fileName);

        if (!cacheFile.exists() && !cacheFile.createNewFile()) {
            throw new IOException(CANNOT_CREATE_CACHE_FILE);
        }

        return cacheFile;
    }

    public static synchronized boolean deleteFile(String fileName) {
        try {
            final File cacheFile = createCacheFile(Pendo.getApplicationContext(), fileName);
            final boolean deletedCacheFile = cacheFile != null && cacheFile.delete();

            if (deletedCacheFile) {
                InsertLogger.i("Deleted cache file.");
            } else {
                InsertLogger.w("Could not delete the cache file!");
            }

            return deletedCacheFile;
        } catch (IOException e) {
            InsertLogger.e(e, "Could not delete the cache file!");
            return false;
        }
    }
}
