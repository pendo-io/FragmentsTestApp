package sdk.pendo.io.utilities;

/**
 * This class represents an object which may contain a null value inside it. We use it
 * in RxJava 2 where we cannot call onNext() with an explicit null.
 * @param <M>
 */
data class Optional<M>(val value : M?) {

    val isEmpty = (value == null)
}

