package sdk.pendo.io.reactive.observers;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.ViewTreeObserver;

import com.trello.rxlifecycle3.android.ActivityEvent;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.commons.lang3.tuple.Pair;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function3;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.activities.InsertVisualActivity;
import sdk.pendo.io.activities.PendoGateActivity;
import sdk.pendo.io.cache.GuideCacheManager;
import sdk.pendo.io.events.DirectLinkEventManager;
import sdk.pendo.io.events.PassiveTriggersListener;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.GlobalLayoutDebouncer;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.utilities.Optional;
import sdk.pendo.io.utilities.ViewHierarchyUtility;
import sdk.pendo.io.views.listener.FloatingListenerButton;

/**
 * Created by nirsegev on 7/15/15.
 */
public final class InsertApplicationObservers {

    private Disposable mFlowStateSubscription;
    private Disposable mActivityOnResumeAndEventsManagerInitedSubscription;
    private InsertMaybeObserver mActivityFirstOnCreateSubscription;
    private Disposable mDirectLinkSubscription;
    private Disposable mActivityOnPauseSubscription;
    private Disposable mActivityGeneralOnCreateSubscription;
    private Disposable mPairingFloatingButtonSubscription;
    private InsertMaybeObserver mFirstActivityOnCreateSubscription;
    private ViewTreeObserver.OnScrollChangedListener mScrollChangedListener;
    private final static Object mFlowStateLock = new Object();

    public void reset() {
        if (mActivityOnResumeAndEventsManagerInitedSubscription != null) {
            mActivityOnResumeAndEventsManagerInitedSubscription.dispose();
            mActivityOnResumeAndEventsManagerInitedSubscription = null;
        }
        if (mActivityOnPauseSubscription != null) {
            mActivityOnPauseSubscription.dispose();
            mActivityOnPauseSubscription = null;
        }
        if (mActivityGeneralOnCreateSubscription != null) {
            mActivityGeneralOnCreateSubscription.dispose();
            mActivityGeneralOnCreateSubscription = null;
        }
        if (mActivityFirstOnCreateSubscription != null) {
            mActivityFirstOnCreateSubscription = null;
        }
        if (mDirectLinkSubscription != null) {
            mDirectLinkSubscription.dispose();
            mDirectLinkSubscription = null;
        }
        if (mPairingFloatingButtonSubscription != null) {
            mPairingFloatingButtonSubscription.dispose();
            mPairingFloatingButtonSubscription = null;
        }
        if (mFirstActivityOnCreateSubscription != null) {
            mFirstActivityOnCreateSubscription = null;
        }
        if (mFlowStateSubscription != null) {
            mFlowStateSubscription.dispose();
            mFlowStateSubscription = null;
        }

        mScrollChangedListener = null;
    }

    public InsertApplicationObservers(Observable<ActivityEvent> activityOnResumeObservable,
                                      Observable<ActivityEvent> activityOnPauseObservable,
                                      Observable<ActivityEvent> activityOnCreatedObservable) {

        mActivityOnResumeAndEventsManagerInitedSubscription = Observable.combineLatest(
                activityOnResumeObservable, ActivationManager.INSTANCE.isInitedObservable(),
                new BiFunction<ActivityEvent, Boolean, Boolean>() {
                    @Override
                    public Boolean apply(ActivityEvent onResumeObservable, Boolean inited) {
                        return inited && onResumeObservable.equals(ActivityEvent.RESUME);
                    }
                })
                .subscribeWith(InsertObserver.create(
                        new InsertActivityOnResumeAndEventsManagerInitedAction()));

        mActivityOnPauseSubscription = activityOnPauseObservable.subscribeWith(
                InsertObserver.create(new InsertActivityOnPauseAction()));

        mActivityGeneralOnCreateSubscription = activityOnCreatedObservable.subscribeWith(
                InsertObserver.create(new InsertActivityGeneralOnCreateAction()));

        // On the first Activity onCreate() we show only one guide according to the following priority:
        // 1. Direct-Link guide (if exists)
        // 2. AppLaunch guide (if exists)
        // 3. No guide.
        mActivityFirstOnCreateSubscription = Observable.zip(DirectLinkEventManager.getInstance().
                        getDirectLinkDataAsObservable(),
                ActivationManager.INSTANCE.isInitedObservable().filter(new Predicate<Boolean>() {
                    @Override
                    public boolean test(Boolean inited) {
                        return inited;
                    }
                }), RestAPI.getNetworkInitedObservable().filter(new Predicate<Boolean>() {
                    @Override
                    public boolean test(Boolean inited) {
                        return inited;
                    }
                }), new Function3<Optional<Pair<Integer, String>>, Boolean, Boolean, Pair<Integer, String>>() {
                    @Override
                    public Pair<Integer, String> apply(Optional<Pair<Integer, String>> directLinkData,
                                                       Boolean eventsInited,
                                                       Boolean networkInited) {
                        return directLinkData.getValue();
                    }
                }).firstElement().subscribeWith(
                InsertMaybeObserver.create(new InsertActivityFirstOnCreateAction()));

        mDirectLinkSubscription = activityOnResumeObservable
                .filter(new Predicate<ActivityEvent>() {
                    @Override
                    public boolean test(ActivityEvent activityEvent) {
                        // We show direct-link only if event manager was inited
                        // AND we either have network or we are paired.
                        return ActivationManager.INSTANCE.isInited() &&
                                (!SocketEventFSM.getInstance().isNotPairedMode() || RestAPI.getNetworkInited());
                    }
                }).subscribeWith(InsertObserver.create(new InsertDirectLinkAction()));

        mPairingFloatingButtonSubscription = Observable.mergeArray(activityOnResumeObservable,
                SocketEventFSM.isInPairedModeObservable(),
                SocketEventFSM.isInTestModeObservable(),
                SocketEventFSM.isInCaptureModeObservable(),
                SocketEventFSM.isSocketConnectedObservable(),
                SocketEventFSM.isInIdentificationModeObservable(),
                ActivationManager.INSTANCE.isInitedObservable())
                .delaySubscription(500, TimeUnit.MILLISECONDS)
                .subscribeWith(InsertObserver.create(new InsertPairingFloatingButtonAction()));

        mFlowStateSubscription = Observable.merge(
                ApplicationFlowManager.getInstance().getAppFlowChanges(),
                ActivationManager.INSTANCE.isInitedObservable())
                .filter(new Predicate<Object>() {
                    @Override
                    public boolean test(Object ignore) throws Exception {
                        return ActivationManager.INSTANCE.isInited();
                    }
                })
                .subscribeWith(InsertObserver.create(new InsertFlowStateAction()));

        // On the first Activity's onCreate we start loading all Inserts, unless there's a
        // flag to ignore it. Currently flag to ignore is used in Corodova apps since we miss
        // the first Activity's onCreate and there are no more Activities.
        if (Pendo.getPendoOptions() == null || !Pendo.getPendoOptions().getIgnoreFirstOnCreate()) {
            mFirstActivityOnCreateSubscription = activityOnCreatedObservable
                    .firstElement()
                    .subscribeWith(InsertMaybeObserver.create(new InsertFirstActivityOnCreateAction()));
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void removeJellyBeanOnGlobalLayoutListener(ViewTreeObserver viewTreeObserver) {
//        viewTreeObserver.removeOnGlobalLayoutListener(mOnGlobalLayoutListener);
//        viewTreeObserver.removeOnGlobalLayoutListener(mOnGlobalLayoutElementViewListener);
        viewTreeObserver.removeOnScrollChangedListener(mScrollChangedListener);
    }


    @SuppressWarnings("deprecation")
    @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    private void removeIceCreamSandwichOnGlobalLayoutListener(ViewTreeObserver viewTreeObserver) {
//        viewTreeObserver.removeGlobalOnLayoutListener(mOnGlobalLayoutListener);
//        viewTreeObserver.removeGlobalOnLayoutListener(mOnGlobalLayoutElementViewListener);
        viewTreeObserver.removeOnScrollChangedListener(mScrollChangedListener);
    }

    private class InsertFlowStateAction implements Consumer<Object> {
        private StopWatch mLastChangeStopWatch = new StopWatch();
        private long mStartTime = System.currentTimeMillis();


        // holds the current flow state
        private AppFlowState mCurrentState = AppFlowState.IN_FOREGROUND;
        private final AtomicBoolean mFirstTimeSinceLaunch = new AtomicBoolean(true);

        @Override
        public void accept(Object object) {
            // RX is not thread safe
            // Could be a situation where we go to background, reach just before we start the watch and then go back to foreground.
            // On foreground flow start the watch and then go back to background flow and start the watch again.
            synchronized (mFlowStateLock) {
                AppFlowState appFlowState = ApplicationFlowManager.getInstance().getAppFlowState();

                // In case we are in foreground for the first time
                // we should send app session started analytics.
                // No need to send it in case we're after switchVisitor,
                // as we handle it there already.
                if (appFlowState == AppFlowState.IN_FOREGROUND && mFirstTimeSinceLaunch.getAndSet(
                        false)) {

                    /**
                     * Those analytics should not be sent in case of a new visitor.
                     * When we have a new visitor switched, we already take care of this sending ourselves.
                     * In any case, we will get to this if in case the application is in foreground and it's
                     * the first time since launch.
                     */
                    if (!Pendo.getIsSwitchVisitorValue()) {
                        AnalyticsUtils.sendAppSessionStartedAnalytics();
                    }

                    if (mLastChangeStopWatch.isStopped()) {
                        mLastChangeStopWatch.reset();
                    }

                    if (!mLastChangeStopWatch.isStarted()) {
                        mLastChangeStopWatch.start();
                    }
                    mStartTime = System.currentTimeMillis();
                    return;
                }


                if (appFlowState != mCurrentState && ActivationManager.INSTANCE.isInited()) {
                    mCurrentState = appFlowState;

                    // App flow changed, let's notify with analytics stop watch and send time.
                    long timeSinceChange = mLastChangeStopWatch.getTime();
                    mLastChangeStopWatch.reset();

                    // In case the user returned to foreground and sessionTimeout is given,
                    // check if we need to re-init against the backend
                    // AND send app session start analytics.
                    // There's no need to send these analytics in case we're after switchVisitor.
                    int sessionTimeout = Pendo.getSessionTimeout();
                    if (appFlowState == AppFlowState.IN_FOREGROUND && sessionTimeout > 0) {

                        // App in foreground and got session timeout configuration.
                        if (TimeUnit.MILLISECONDS.toSeconds(timeSinceChange) > sessionTimeout) {

                            // App is in foreground and time since state change is greater than
                            // session timeout so we re-init inserts.
                            AnalyticsUtils.sendAppSessionStartedAnalytics();
                            BackendApiManager.getInstance().startBackendInitialization(true /* Force init */);

                            if (mLastChangeStopWatch.isStopped()) {
                                mLastChangeStopWatch.reset();
                            }

                            if (!mLastChangeStopWatch.isStarted()) {
                                mLastChangeStopWatch.start();
                            }
                            mStartTime = System.currentTimeMillis();

                            // When we send app session start analytics
                            // we should not send foreground indication.
                            return;
                        }
                    }

                    AnalyticsUtils.sendAppInForegroundBackgroundAnalytics(appFlowState, timeSinceChange,
                            mStartTime);

                    // Starting the stop watch so the next app flow change
                    // will have the duration from now.
                    if (mLastChangeStopWatch.isStopped()) {
                        mLastChangeStopWatch.reset();
                    }
                    if (!mLastChangeStopWatch.isStarted()) {
                        mLastChangeStopWatch.start();
                    }
                    mStartTime = System.currentTimeMillis();
                }
            }
        }
    }

    private class InsertActivityOnResumeAndEventsManagerInitedAction implements Consumer<Boolean> {

        @Override
        public void accept(Boolean inited) {
            final Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
            if (activity == null) {
                InsertLogger.d(
                        "InsertActivityOnResumeAndEventsManagerInitedAction received null activity");
                return;
            }

            if (!inited) {
                // Events manager is not fully initiated we should not perform any work
                InsertLogger.d("Events manager is not initiated and we got a 'onResume' event.");
                return;
            }

            // EventsManager.getInstance().resetSensitiveStates(activity.getLocalClassName());


            // If the Gate Activity/Visual Activity is starting, don't add the capture view and listeners.
            if (activity instanceof PendoGateActivity || activity instanceof InsertVisualActivity) {
                InsertLogger.i(activity.getClass().getSimpleName() + " started.");
                return;
            }

            if (!BackendApiManager.getInstance().isAuthenticated()) {
                return;
            }

            ScreenManager.INSTANCE.updateVisibleActivities();

            final View view = activity.getWindow().getDecorView().getRootView();

            // EventsManager.getInstance().handleFlowTriggersIfNeeded(view);

            final ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener =
                    new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            } else {
                                view.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                            }

                            ViewHierarchyUtility.INSTANCE.addListenersToViewHierarchy(view);
                            PassiveTriggersListener.INSTANCE.activityStateChange();
                        }
                    };

            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    onGlobalLayoutListener.onGlobalLayout();
                }
            });

            final Observable<Object> debouncer = GlobalLayoutDebouncer.getInstance()
                    .getDebouncer(view);

            debouncer.subscribeOn(AndroidSchedulers.mainThread())
                    .subscribe(InsertObserver.create(new Consumer<Object>() {
                        @Override
                        public void accept(Object nill) {
                            ViewHierarchyUtility.INSTANCE.addListenersToViewHierarchy(view);
                            PassiveTriggersListener.INSTANCE.activityStateChange();
                        }
                    }));

            mScrollChangedListener = new ViewTreeObserver.OnScrollChangedListener() {
                @Override
                public void onScrollChanged() {
                    PassiveTriggersListener.INSTANCE.activityStateChange();
                }
            };

            final ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            viewTreeObserver.addOnGlobalLayoutListener(onGlobalLayoutListener);
            viewTreeObserver.addOnScrollChangedListener(mScrollChangedListener);
        }
    }

    private class InsertActivityFirstOnCreateAction implements Consumer<Pair<Integer, String>> {

        @Override
        public void accept(Pair<Integer, String> triggerInsertPair) {
            BackendApiManager.setInitProcessComplete(true);
        }
    }

    /**
     * Launches direct link insert if exists.
     */
    private class InsertDirectLinkAction implements Consumer<Object> {

        @Override
        public void accept(Object o) {
            Pair<Integer, String> triggerInsertPair = DirectLinkEventManager.getInstance().getDirectLinkData();
            if (triggerInsertPair != null) {
                String guideId = triggerInsertPair.getRight();
                if (guideId != null) {
                    // We showed the Pendo by direct link, now remove it so it won't show again.
                    DirectLinkEventManager.getInstance().removeLastDirectLinkData();
                }
            }
        }
    }

    private class InsertActivityOnPauseAction implements Consumer<Object> {

        @Override
        public void accept(Object o) {
            Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();

            if (activity == null) {
                InsertLogger.d("Activity is null.");
                return;
            }

            FloatingListenerButton.Builder.removeActiveInstances();
            if (!BackendApiManager.getInstance().isAuthenticated() && !GuideCacheManager.isCacheLoaded()) {
                return;
            }
            final View view = activity.getWindow().getDecorView().getRootView();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                removeJellyBeanOnGlobalLayoutListener(view.getViewTreeObserver());
            } else {
                removeIceCreamSandwichOnGlobalLayoutListener(view.getViewTreeObserver());
            }

        }
    }

    private class InsertActivityGeneralOnCreateAction implements Consumer<Object> {

        @Override
        public void accept(Object o) {

            //FIXME: We only update the current visible activity when we reach onResume(), so
            //FIXME: we probably don't get the activity we want here.
            final Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();

            // Check if there are event for this activity.
            if (activity != null && ActivationManager.INSTANCE.isInited()) {
//                InsertLogger.d("Got events? " + Boolean.toString(EventsManager.getInstance().
//                        hasElementsWithEventsForActivity(activity.getLocalClassName())));
            } else {
                InsertLogger.d("Events aren't ready.");
            }
        }
    }

    private class InsertPairingFloatingButtonAction implements Consumer<Object> {
        @Override
        public void accept(Object object) {
            Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
            if (activity != null && !GuideUtils.isInsertActivity(activity.getLocalClassName())) {
                FloatingListenerButton.Builder.removeActiveInstances();
                if (SocketIOUtils.getSessionToken() != null &&
                        !SocketEventFSM.getInstance().isNotPairedMode()) {
                    new FloatingListenerButton.Builder().create();
                }
            }
        }
    }

    private class InsertFirstActivityOnCreateAction implements Consumer<Object> {
        @Override
        public void accept(Object object) {
            // TODO: don't force new init in the future when we support caching of guides.
            GuideUtils.startLoadingInserts(true, false);
        }
    }

}
