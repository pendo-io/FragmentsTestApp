package sdk.pendo.io.logging.profiling;

import com.squareup.picasso.StatsSnapshot;
import java.util.ArrayList;
import java.util.List;
import sdk.pendo.io.actions.VisualInsert;
import sdk.pendo.io.utilities.InsertProfiler;

/**
 * Holds the data usage and cache profiling data.
 */
public class DataProfiler implements InsertProfiler {

    @Override
    public final String[] getStats() {
        StatsSnapshot picassoStats = VisualInsert.getPicassoStats();
        List<String> logs = new ArrayList<String>();
        logs.add("Downloaded images;" + picassoStats.downloadCount);
        logs.add("Total Decoded size;" + picassoStats.totalOriginalBitmapSize);
        logs.add("Decoded images count;" + picassoStats.originalBitmapCount);
        logs.add("Cache hits;" + picassoStats.cacheHits);
        logs.add("Cache miss;" + picassoStats.cacheMisses);
        return logs.toArray(new String[logs.size()]);
    }

    @Override
    public void mark(String message) {

    }
}
