package sdk.pendo.io.events;

import android.support.annotation.CheckResult;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import org.apache.commons.lang3.tuple.Pair;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.data.structures.HashMapListValues;
import sdk.pendo.io.intelligence.ViewIntel;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.responses.ElementModel;
import sdk.pendo.io.network.responses.ScreenModel;
import sdk.pendo.io.network.responses.TriggerModel;
import sdk.pendo.io.utilities.PredicateUtils;
import sdk.pendo.io.utilities.Utils;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;
import static sdk.pendo.io.events.InsertEvent.EventActions;

/**
 * This class holds all the activity's states and elements.
 *
 * Created by assaf on 11/19/15.
 */
public final class ActivityModel {
    // TODO: 11/19/15 Rename the class and decide what package it should be inside of.

    @NonNull
    private final String mActivityName;

    /** Stores state sensitive the screens related to this activity. */
    private final List<ScreenModel> mStateSensitiveScreens;

    /** Stores a mapping from of elements to their state sensitive events. */
    private final HashMapListValues<ElementModel, InsertEvent> mStateSensitiveElementsToInserts;

    /** Stores a Collection of elements not connected to events, triggers or inserts. */
    private final List<ElementModel> mNotActiveElements;

    @Nullable
    /** Stores all the elements that has an {@link EventActions#ELEMENT_VIEW} event. */
    private HashMapListValues<ElementModel, InsertEvent> mElementViewMap;

    @Nullable
    /** Stores all the elements that has A/B testing {@link InsertAction}. */
    private HashMapListValues<ElementModel, InsertEvent> mViewManipulationMap;

    @Nullable
    /** Stores all the text that needs to be modified in this activity. */
    private HashSet<String> mTextModificationStrings;

    private boolean mHasElements = false;
    private boolean mHasElementsWithEvents = false;
    private boolean mHasViewManipulations = false;
    private boolean mHasListView = false;

    public ActivityModel(@NonNull String activityName) {
        mActivityName = activityName;
        mStateSensitiveScreens = new LinkedList<>();
        mStateSensitiveElementsToInserts = new HashMapListValues<>();
        mNotActiveElements = new LinkedList<>();
    }

    /**
     * @return the activity's name.
     */
    @NonNull
    public String getActivityName() {
        return mActivityName;
    }

    /**
     * Adds a screen to this activity.
     * <p>
     * The method parses the screen's elements and element's events and holds a mapping from
     * elements to the elements' events.
     *
     * @param screen the {@link ScreenModel} to add to this activity.
     *
     * @return true if the screen was added, false otherwise.
     */
    @CheckResult
    public synchronized boolean addScreen(@NonNull ScreenModel screen) {

        // Don't process or add a screen already in the list.
        if (hasScreen(screen)) {
            return false;
        }

        // Boolean to state whether this screen has state sensitive elements.
        // States false and only if there is a sensitive event changes to true.
        boolean sensitive = false;

        // For all element in the screen, go over all of its' events,
        // if the event is state sensitive add it to the mStateSensitiveElementsToInserts map
        final List<ElementModel> elementModels = preProcessAllElements(screen);
        if (elementModels.size() > 0) {
            mHasElements = true;
        }
        for (ElementModel screenElement : elementModels) {

            if (screenElement.events != null) {
                for (InsertEvent elementEvent : screenElement.events) {
                    elementEvent.getConfiguration().setScreenId(screen.id);

                    String eventAction = elementEvent.getConfiguration().getAction();

                    if (eventAction.equals(EventActions.ELEMENT_VIEW_INTERNAL.action)) {
                        mHasViewManipulations = true;
                        addElementToViewManipulationList(screenElement, elementEvent);
                        break;
                    }

                    mHasElementsWithEvents = true;

                    if (elementEvent.getConfiguration().isStateSensitive()) {
                        mStateSensitiveElementsToInserts.add(screenElement, elementEvent);
                        sensitive = true; // Changes only to true once there is a sensitive event.
                    }

                    if (EventActions.ELEMENT_VIEW.equals(eventAction)) {
                        addElementToElementViewList(screenElement, elementEvent);
                    }
                }
            } else {
                if (!EventsManager.NAME_ELEMENT_ANY.equals(screenElement.name)) {
                    mNotActiveElements.add(screenElement);
                }
            }
        }

        if (sensitive) {
            mStateSensitiveScreens.add(screen);
        }

        return true;
    }

    /**
     * Getter for the state sensitive screens.
     *
     * @return - A list of the screens.
     */
    public List<ScreenModel> getStateSensitiveScreens() {
        return mStateSensitiveScreens;
    }

    /**
     * Clear the old screen model list and add the new one.
     * @param screenModels - the screen models to add.
     */
    public void setStateSensitiveScreens(List<ScreenModel> screenModels) {
        mStateSensitiveScreens.clear();
        mStateSensitiveScreens.addAll(screenModels);
    }
    /**
     * Pre-process the {@link ScreenModel} to extract all it's {@link ElementModel}s and generate
     * copies of {@link ElementModel}s according to their {@link TriggerModel}'s predicate.
     * <p>
     * SO if there is multiple {@link TriggerModel}s for an {@link ElementModel} we will end up with
     * just as much copies as triggers.
     *
     * @param screenModel The {@link ScreenModel} to process.
     *
     * @return new list of {@link ElementModel} that includes all the pre-process changes.
     */
    @NonNull
    private synchronized List<ElementModel> preProcessAllElements(ScreenModel screenModel) {
        ArrayList<ElementModel> retList = new ArrayList<>();

        for (ElementModel element : screenModel.elements) {

            if (EventsManager.NAME_ELEMENT_ANY.equals(element.name)) {
                retList.add(element);
                continue;
            }

            if (element.events != null) {
                for (InsertEvent elementEvent : element.events) {

                    final List<Pair<InsertAction, TriggerModel>> pairs =
                            InsertsManager.getInstance().getInserts(elementEvent, (View) null);

                    if (pairs == null || pairs.isEmpty()) {

                        final List<TriggerModel> triggers = elementEvent.getTriggers();
                        if (triggers != null && !triggers.isEmpty()) {
                            retList.add(element);
                        }

                        break;
                    }

                    for (Pair<InsertAction, TriggerModel> pair : pairs) {
                        if (pair != null) {
                            final TriggerModel trigger = pair.getRight();
                            String predicate = trigger.getConfiguration().getPredicate();

                            if (predicate != null) {
                                ElementModel elem = ElementModel.copyElement(element, predicate);
                                retList.add(elem);
                            } else { // This shouldn't happen according to Udi.
                                retList.add(element);
                            }
                        }
                    }
                }
            } else {
                // no events but still can be no active elements
                retList.add(element);
            }
        }

        return retList;
    }

    @NonNull
    synchronized List<Pair<InsertEvent, TriggerModel>>
    findSensitiveScreenEvents(final View view) {
        LinkedList<Pair<InsertEvent, TriggerModel>> result = new LinkedList<>();
        for (ScreenModel screen : mStateSensitiveScreens) {
            result.addAll(screen.getScreenViewEventsForCurrentState(view));
        }

        // If the current state doesn't match any trigger, reset all triggers that were
        // already triggered so we will trigger them again if there WILL be a match
        // in the current activity.
        if (result.isEmpty()) {
            resetAllStates();
        }

        return result;
    }

    @Nullable
    public synchronized ScreenModel findSensitiveScreenModelByScreenId(final int screenId) {
        if (screenId < 0) {
            return null;
        }
        for (ScreenModel screen : mStateSensitiveScreens) {
            if (screen.id == screenId) {
                return screen;
            }
        }
        return null;
    }

    /**
     * Checks if this activity has the given {@link ScreenModel}.
     *
     * @param screen the screen to check if the activity has it.
     *
     * @return true if the screen is not null and the activity has it, false otherwise.
     */
    public boolean hasScreen(ScreenModel screen) {
        return screen != null
                && mStateSensitiveScreens.contains(screen);
    }

    /**
     * @return true if this activity has {@link ElementModel}, false otherwise.
     */
    public boolean hasElements() {
        return mHasElements;
    }

    /**
     * @return true if this activity has {@link ElementModel}, false otherwise.
     */
    public boolean hasElementsWithEvents() {
        return mHasElementsWithEvents;
    }

    /**
     * @return true if this activity has A/B testing {@link InsertAction}.
     */
    public boolean hasViewManipulations() {
        return mHasViewManipulations;
    }

    /**
     * @return true if this activity has a {@link android.widget.ListView}.
     */
    public boolean hasListView() {
        return mHasListView;
    }

    /**
     * Traverses through the view hierarchy looking for a ListView, and updates
     * the mHasListView field accordingly.
     * @param view - the view we use as a root when traversing the hierarchy.
     */
    public void checkIfListViewExists(View view) {
        if (view instanceof ListView) {
            mHasListView = true;
        }

        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); ++i) {
                checkIfListViewExists(((ViewGroup) view).getChildAt(i));
            }
        }
    }

    /**
     * @return all the {@link ElementModel}s of this activity.
     */
    @NonNull
    public List<ElementModel> getAllElements() {

        final Set<ElementModel> sensitiveElements = mStateSensitiveElementsToInserts.keySet();

        LinkedList<ElementModel> retList = new LinkedList<>();
        retList.addAll(sensitiveElements);
        retList.addAll(mNotActiveElements);

        return retList;
    }

    /**
     * Returns the {@link ElementModel} with the given element id.
     *
     * @param elementId the element's id.
     *
     * @return the {@link ElementModel} with the given element id or null if not found.
     */
    @Nullable
    public ElementModel getElement(int elementId) {

        // Look for the element in the sensitive list.
        for (ElementModel element : mStateSensitiveElementsToInserts.keySet()) {
            if (element.id == elementId) {
                return element;
            }
        }

        // Look for the element in the not active elements list.
        for (ElementModel element : mNotActiveElements) {
            if (element.id == elementId) {
                return element;
            }
        }

        InsertLogger.d("Element with id '" + elementId + "' not found.");
        return null;
    }

    /**
     * Returns the {@link ElementModel} that matches the given {@link IdentificationData}
     * from the view manipulation list.
     *
     * @param identificationData the element's {@link IdentificationData}.
     *
     * @return the {@link ElementModel} that matches the given
     * {@link IdentificationData} or null if not found.
     */
    @Nullable
    public List<InsertEvent> getVisualManipulationElement(
            @NonNull IdentificationData identificationData) {

        if (!hasViewManipulations() || mViewManipulationMap == null) {
            InsertLogger.i("No view manipulations.");
            return null;
        }

        // Look for the element in the insensitive list.
        for (Map.Entry<ElementModel, List<InsertEvent>> entry : mViewManipulationMap.entrySet()) {
            ElementModel element = entry.getKey();
            boolean isElementAny = EventsManager.NAME_ELEMENT_ANY.equals(element.name);

            if (!isElementAny) {
                if (compareElement(identificationData, element, true)) {
                    return entry.getValue();
                }
            }
        }

        InsertLogger.d("Nothing found.");
        return null;
    }

    @Nullable
    public HashSet<String> getTextModificationStrings() {
        if (mTextModificationStrings == null) {
//            InsertLogger.d("Test - No text modifications.");
            return null;
        }

        return new HashSet<>(mTextModificationStrings);
    }

    /**
     * Returns the {@link ElementModel} that matches the given {@link IdentificationData}.
     *
     * @param identificationData the element's {@link IdentificationData}.
     *
     * @return the {@link ElementModel} that matches the given
     * {@link IdentificationData} or null if not found.
     */
    @Nullable
    public ElementModel getElement(@Nullable IdentificationData identificationData) {
        List<ElementModel> sensitiveElements = getElementsFromCollection(identificationData, mStateSensitiveElementsToInserts, true);
        if (sensitiveElements.size() > 0) {
            return sensitiveElements.get(0);
        }

        if (identificationData != null) {
            List<ElementModel> notActiveElements = getElementsFromCollection(identificationData, mNotActiveElements, true);
            if (notActiveElements.size() > 0) {
                return notActiveElements.get(0);
            }

            InsertLogger.d("Element with identification data '" + identificationData
                    .toString() + "' not found.");
        } else {
            InsertLogger.d("Element with identification data 'null' not found.");
        }
        return null;
    }

    private List<ElementModel> getElementsFromCollection(@Nullable IdentificationData identificationData, HashMapListValues<ElementModel, InsertEvent> collection, boolean stopOnFirst) {
        List<ElementModel> elements = new ArrayList<>();
        // Look for the element in the insensitive list.
        for (ElementModel element : collection.keySet()) {
            if (addElementIfNeeded(identificationData, stopOnFirst, elements, element)) {
                break;
            }
        }
        return elements;
    }

    private List<ElementModel> getElementsFromCollection(@Nullable IdentificationData identificationData, List<ElementModel> collection, boolean stopOnFirst) {
        List<ElementModel> elements = new ArrayList<>();
        // Look for the element in the insensitive list.
        for (ElementModel element : collection) {
            if (addElementIfNeeded(identificationData, stopOnFirst, elements, element)) {
                break;
            }
        }
        return elements;
    }

    private boolean addElementIfNeeded(@Nullable IdentificationData identificationData,
                                       boolean stopOnFirst,
                                       List<ElementModel> elements,
                                       ElementModel element) {
        boolean isElementAny = EventsManager.NAME_ELEMENT_ANY.equals(element.name);

        if (identificationData == null && isElementAny) {
            if (stopOnFirst) {
                elements.add(element);
                return true;
            }

        } else if (identificationData != null && !isElementAny) {
            if (compareElement(identificationData, element, false)) {
                elements.add(element);
                if (stopOnFirst) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Returns the list of {@link ElementModel} that matches the given {@link IdentificationData}.
     *
     * @param identificationData the element's {@link IdentificationData}.
     *
     * @return the list of {@link ElementModel} that matches the given
     * {@link IdentificationData} or empty list if not found
     */
    public List<ElementModel> getAllElements(@Nullable IdentificationData identificationData) {
        List<ElementModel> elements = new ArrayList<>();
        elements.addAll(getElementsFromCollection(identificationData, mStateSensitiveElementsToInserts, false));
        elements.addAll(getElementsFromCollection(identificationData, mNotActiveElements, false));
        return elements;
    }

    /**
     * Compared the identification data between desired element and suggested one. in case there is
     * a root view, the method will return true only if the current screen state is identical to the
     * one described in the element
     *
     * @param identificationData
     * @param element
     * @param viewManipulation whether this element should be treated for view manipulation.
     *
     * @return
     */
    private Boolean compareElement(@Nullable IdentificationData identificationData,
                                   ElementModel element,
                                   boolean viewManipulation) {
        return ViewIntel.compareIdentificationData(
                element.configuration.getIdentificationData(), identificationData, viewManipulation, null)
                .getLeft();
    }


    @Nullable // FIXME: 12/3/15 Javadoc
    public HashMapListValues<ElementModel, InsertEvent> getElementViewMap() {
        try {
            Utils.requireNonNull(mElementViewMap);
            final Object clonedMap = mElementViewMap.clone();
            if (clonedMap instanceof HashMapListValues)  {
                //noinspection unchecked
                return (HashMapListValues<ElementModel, InsertEvent>) clonedMap;
            }
        } catch (Exception ignore) { }

        return null;
    }

    @Nullable // FIXME: 12/3/15 Javadoc
    public HashMapListValues<ElementModel, InsertEvent> getViewManipulationMap() {
        try {
            Utils.requireNonNull(mViewManipulationMap);
            final Object clonedMap = mViewManipulationMap.clone();
            if (clonedMap instanceof HashMapListValues)  {
                //noinspection unchecked
                return (HashMapListValues<ElementModel, InsertEvent>) clonedMap;
            }
        } catch (Exception ignore) { }

        return null;
    }

    @Override
    public boolean equals(Object o) {

        if (o == this) {
            return true;
        } else if (o instanceof ActivityModel) {
            return mActivityName.equals(((ActivityModel) o).mActivityName);
        }

        return false;
    }

    @Override
    public int hashCode() {
        return mActivityName.hashCode();
    }

    private synchronized void addElementToElementViewList(ElementModel element, InsertEvent event) {

        try {
            Utils.requireNonNull(mElementViewMap);
        } catch (Exception e) {
            mElementViewMap = new HashMapListValues<>();
        }

        mElementViewMap.add(element, event);
    }

    private synchronized void addElementToViewManipulationList(ElementModel element,
                                                               InsertEvent event) {

        try {
            Utils.requireNonNull(mViewManipulationMap);
        } catch (Exception e) {
            mViewManipulationMap = new HashMapListValues<>();
        }

        mViewManipulationMap.add(element, event);
    }

    /**
     * Resets the showing state of all the sensitive screen states for this activity.
     */
    public synchronized void resetAllStates() {
        for (ScreenModel stateSensitiveScreen : mStateSensitiveScreens) {
            if (stateSensitiveScreen.elements != null) {
                for (ElementModel element : stateSensitiveScreen.elements) {
                    if (element.events != null) {
                        for (InsertEvent event : element.events) {
                            if (event.getTriggers() != null) {
                                for (TriggerModel triggerModel : event.getTriggers()) {
                                    triggerModel.resetDispatchCommands();
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
