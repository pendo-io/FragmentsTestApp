package sdk.pendo.io.network;

import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by tomerlevinson on 4/10/16.
 *
 * This class is used to store a single parameter for a SetupAction.
 *      {
 *          "name": "ParamName",
 *          "value": "ParamValue",
 *          "type": "ParamType"
 *      }
 *
 */
public class SetupParamModel {
    private String mName;
    private String mValue;
    private Class<?> mTypeOfValue;

    public SetupParamModel(String name, String type, String value){
        mName = name;
        mValue = value;
        try {
            mTypeOfValue = Class.forName(type);
        } catch (ClassNotFoundException e) {
            //Fallback
            mTypeOfValue  = String.class;
            InsertLogger.d("Class "+ type + " not found in SetupParamModel.");
        }
    }


    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getValue() {
        return mValue;
    }

    public void setValue(String value) {
        mValue = value;
    }

    public Class<?> getTypeOfValue() {
        return mTypeOfValue;
    }

    public void setTypeOfValue(Class<?> typeOfValue) {
        mTypeOfValue = typeOfValue;
    }
}