package sdk.pendo.io.actions;

/**
 * An interface for getting callbacks from the visual insert regarding its lifecycle
 * Created by nirsegev on 5/31/16.
 */
public interface VisualInsertLifecycleListener {
    void onCreate(VisualInsertBase visualInsert);
    void onDestroy(String visualInsertId);
}
