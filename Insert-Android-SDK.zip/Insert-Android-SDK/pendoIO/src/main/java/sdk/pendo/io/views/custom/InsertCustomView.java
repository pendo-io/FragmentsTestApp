package sdk.pendo.io.views.custom;

/**
 * An interface for allowing our custom views to be rendered only once -
 * when we finish applying all properties from the backend
 * Created by itayvallach on 06/06/2016.
 */
public interface InsertCustomView {

    void renderView();

    void setCornerRadius(float cornerRadius);

    void setCornerRadii(float[] cornerRadii);

    void setStrokeWidth(int strokeWidth);

    void setStrokeColor(int strokeColor);

}
