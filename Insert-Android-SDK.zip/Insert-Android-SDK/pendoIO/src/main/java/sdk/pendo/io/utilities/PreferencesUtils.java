package sdk.pendo.io.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.List;
import java.util.Set;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.events.TriggerPreference;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by nirsegev on 8/12/15.
 *
 * Utilities to store, update, and retrieve data from the device's SharedPreferences.
 */
public class PreferencesUtils {

    private static final Object LOCK = new Object();

    public static boolean isConditionalPreferencesValid(List<TriggerPreference> preferences) {
            if (preferences != null) {
                return PreferencesUtils.checkValuesForAllEvents(preferences);
            } else {
                // the conditions are valid as Vacuous truth
                return true;
            }
    }

    /**
     * Store a boolean in the shared preferences.
     * @param preferencesFileName - name of the file in the shared preferences to be stored at.
     * @param key - name of key
     * @param value - value of key
     * @param override - override existing value
     */
    public static void storeBoolean(String preferencesFileName, String key, boolean value, boolean override) {
        synchronized (LOCK) {
            SharedPreferences sharedPrefs = getSharedPreferencesByFileName(preferencesFileName);
            if (sharedPrefs != null) {
                if (override || !sharedPrefs.contains(key)) {
                    sharedPrefs.edit().putBoolean(key, value).apply();
                }
            }
        }
    }

    /**
     * Retrieve the current stored boolean inside the given preferences file.
     * @param preferencesFileName - file in question
     * @param key - key of the value to be retrieved.
     * @return boolean value of stored boolean.
     */
    public static boolean retrieveStoredBoolean(String preferencesFileName, String key) {
        synchronized (LOCK) {
            return getSharedPreferencesByFileName(preferencesFileName).getBoolean(key, false);
        }
    }

    private static boolean checkValuesForAllEvents(List<TriggerPreference> eventPreferences) {

        SharedPreferences defaultSharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(Pendo.getApplicationContext());
        for (TriggerPreference eventPreference : eventPreferences) {
            String valueType = eventPreference.getValueType();
            TriggerPreference.EventPreferenceValueType eventPreferenceValueType =
                    TriggerPreference.EventPreferenceValueType.getTypeForString(valueType);

            try {

                // Get the preference according to its type
                switch (eventPreferenceValueType) {
                    case BOOLEAN:
                        Boolean sharedPreferencesBooleanValue =
                                defaultSharedPreferences.getBoolean(
                                        eventPreference.getName(),
                                        Boolean.valueOf(eventPreference.defaultValue())
                                );

                        // TODO: 8/16/15 Remove log.
                        if (checkFalse(
                                sharedPreferencesBooleanValue,
                                eventPreference.getOperator(),
                                Boolean.valueOf(eventPreference.getValue())
                                )) {
                            return false;
                        }
                        break;
                    case STRING:
                        String sharedPreferencesStringValue =
                                defaultSharedPreferences.getString(
                                        eventPreference.getName(),
                                        eventPreference.defaultValue()
                                );
                        if (checkFalse(
                                sharedPreferencesStringValue,
                                eventPreference.getOperator(),
                                eventPreference.getValue())) {
                            return false;
                        }
                        break;
                    case NUMBER:
                        @SuppressWarnings("ConstantConditions")
                        Integer sharedPreferencesIntegerValue =
                                defaultSharedPreferences.getInt(
                                        eventPreference.getName(),
                                        Integer.parseInt(eventPreference.defaultValue())
                                );
                        //noinspection ConstantConditions
                        if (checkFalse(
                                sharedPreferencesIntegerValue,
                                eventPreference.getOperator(),
                                Integer.valueOf(eventPreference.getValue())
                                )) {
                            return false;
                        }
                        break;
                }
            } catch (Exception e) {

                // In case of an error we are reporting to the server
                // and marking the condition as not true.
                InsertLogger.e(e, e.getMessage());
                return false;
            }

        }
        return true;
    }

    private static <T> boolean checkFalse(T sharedPreferencesIntegerValue,
                                          String operator, T eventValue) {
        TriggerPreference.EventPreferenceOperator operatorType =
                TriggerPreference.EventPreferenceOperator.getTypeByString(operator);
        return !operatorType.compare(sharedPreferencesIntegerValue, eventValue);
    }

    /**
     * Retrieves a SharedPreference instance by the input file name.
     * If such instance doesn't exist, it will be created (with the desired file name)
     * after editions will be committed to this instance.
     * @param fileName
     * @return shared preferences for specific fileName, or null if insert application context
     *          is null.
     */
    public static SharedPreferences getSharedPreferencesByFileName(String fileName) {
        Context insertApplicationContext = Pendo.getApplicationContext();
        synchronized (LOCK) {
            if (insertApplicationContext != null) {
                return insertApplicationContext
                        .getSharedPreferences(fileName, Context.MODE_PRIVATE);
            }
            return null;
        }
    }

    /**
     * Stores a string inside SharedPreferences where the value is a String.
     * @param preferencesFileName
     * @param key
     * @param value
     * @param override - parameter to indicate if we should override the value in case the key already exists.
     */
    public static void storeString(String preferencesFileName, String key, String value, boolean override) {
        synchronized (LOCK) {
            SharedPreferences sharedPrefs = getSharedPreferencesByFileName(preferencesFileName);
            if (sharedPrefs != null) {
                if (override || !sharedPrefs.contains(key)) {
                    sharedPrefs.edit().putString(key, value).commit();
                }
            }
        }
    }

    /**
     * Stores a int value inside SharedPreferences.
     * @param preferencesFileName
     * @param key
     * @param value
     */
    public static void storeInt(String preferencesFileName, String key, int value) {
        synchronized (LOCK) {
            SharedPreferences sharedPrefs = getSharedPreferencesByFileName(preferencesFileName);
            if (sharedPrefs != null) {
                sharedPrefs.edit().putInt(key, value).commit();
            }
        }
    }

    /**
     * Stores a key-value pair inside SharedPreferences where the value is a String Set.
     * @param preferencesFileName
     * @param key
     * @param value
     * @param override - parameter to indicate if we should override the value in case the key already exists.
     */
    public static void storeStringSet(String preferencesFileName, String key, Set<String> value, boolean override) {
        synchronized (LOCK) {
            SharedPreferences sharedPrefs = getSharedPreferencesByFileName(preferencesFileName);
            if (sharedPrefs != null) {
                if (override || !sharedPrefs.contains(key)) {
                    sharedPrefs.edit().putStringSet(key, value).apply();
                }
            }
        }
    }

    /**
     * Retrieves a String Set from SharedPreferences that was stored by the input key.
     * @param preferencesFileName
     * @param key - the key which value is the String Set we wish to retrieve.
     * @return
     */
    public static Set<String> retrieveStoredStringSet(String preferencesFileName, String key) {
        synchronized (LOCK) {
            SharedPreferences sharedPreferencesFile = getSharedPreferencesByFileName(preferencesFileName);
            if (sharedPreferencesFile != null) {
                return sharedPreferencesFile.getStringSet(key, null);
            }
            return null;
        }
    }

    /**
     * Deletes data from SharedPreferences
     * @param preferencesFileName
     * @param key - the key of the data we wish to delete.
     */
    public static void deleteStoredDataByKey(String preferencesFileName, String key) {
        synchronized (LOCK) {
            if (key != null) {
                SharedPreferences sharedPreferences = getSharedPreferencesByFileName(preferencesFileName);
                if (sharedPreferences != null) {
                    sharedPreferences
                            .edit()
                            .remove(key)
                            .apply();
                }
            }
        }
    }

    /**
     * Clears the contents of preferencesFileName.
     * @param preferencesFileName
     */
    public static void clearStoredData(String preferencesFileName) {
        synchronized (LOCK) {
            SharedPreferences sharedPreferences = getSharedPreferencesByFileName(preferencesFileName);
            if (sharedPreferences != null) {
                sharedPreferences
                        .edit()
                        .clear()
                        .apply();
            }
        }
    }
}
