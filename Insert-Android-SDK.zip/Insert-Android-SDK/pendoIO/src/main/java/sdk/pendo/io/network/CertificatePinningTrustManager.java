package sdk.pendo.io.network;

import android.support.annotation.NonNull;
import android.util.Pair;

import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import external.sdk.pendo.io.okhttp3.CertificatePinner;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.SettingsUtils;
import sdk.pendo.io.utilities.Utils;

/**
 * This {@link X509TrustManager} only verify the public key SHA256 hash with a given SHA256 hash.
 *
 * Created by assaf on 4/24/16.
 */
public final class CertificatePinningTrustManager implements X509TrustManager {

    private static final CertificatePinner CERTIFICATE_PINNER_DEFAULT =
            getBaseCertificatePinnerBuilder().build();
    private static CertificatePinner DEBUG_relaxedCertificatePinner;

    public static CertificatePinner getCertificatePinner() {

        if (DEBUG_relaxedCertificatePinner != null && SettingsUtils.isHostAppDebuggable()) {
            return DEBUG_relaxedCertificatePinner;
        } else {
            return CERTIFICATE_PINNER_DEFAULT;
        }
    }

    private final String mHostName;
    private final CertificatePinner mCertificatePinner;
    private TrustManager[] mTrustManagers;

    /**
     * @return the base {@link okhttp3.CertificatePinner.Builder} with *.insert.io certificate
     * already pinned.
     */
    @SuppressWarnings({"CheckStyle", "SpellCheckingInspection"})
    public static CertificatePinner.Builder getBaseCertificatePinnerBuilder() {
        return new CertificatePinner.Builder()
            .add("us.device2.mobile.pendo.io", "sha256/fWYo+NcnBzYJw7m92bN8Xfsw+BQe8g2YNprKIWfmhyA=")
            .add("eu.device2.mobile.pendo.io", "sha256/aVvbmJ5yeKlF7IFrYEgh2ECv/ac2g8F0tZtHQU7eQXs=")
            .add("us.data2.mobile.pendo.io", "sha256/0XcGQ+ICbQonKXF3Lygo+/LQ7grb8s6KYWQ/BUXgEL8=")
            .add("eu.data2.mobile.pendo.io", "sha256/XDE5lb8aL5BOF20NYFc9dqiUJwN0b6Qh0aekLeHVYY4");
    }

    public static void setAdditionalDebugPins(List<Pair<String,String>> additionalDebugPins) {
        Builder b = new Builder();
        for (Pair<String, String> additionalDebugPin : additionalDebugPins) {
            b.add(additionalDebugPin.first, additionalDebugPin.second);
        }

        DEBUG_relaxedCertificatePinner = b.getPinner();
    }

    @SuppressWarnings("unused")
    public static final class Builder {
        private String mHostname;

        /** The base certificate pinner already pins *.insert.io certificate with SHA-256. */
        private final CertificatePinner.Builder mCertificatePinnerBuilder =
                getBaseCertificatePinnerBuilder();

        public Builder setHostname(String hostname) {
            mHostname = hostname;
            return this;
        }

        /**
         * Pins certificates for {@code pattern}.
         *
         * @param pattern lower-case host name or wildcard pattern such as {@code *.example.com}.
         * @param pins SHA-256 or SHA-1 hashes.
         * Each pin is a hash of a certificate's Subject Public Key Info,
         * base64-encoded and prefixed with either {@code sha256/} or {@code sha1/}.
         */
        public Builder add(String pattern, String... pins) {
            mCertificatePinnerBuilder.add(pattern, pins);
            return this;
        }

        public CertificatePinner getPinner() {
            return mCertificatePinnerBuilder.build();
        }

        public CertificatePinningTrustManager build() {
            return new CertificatePinningTrustManager(mHostname, mCertificatePinnerBuilder.build());
        }
    }

    private CertificatePinningTrustManager(@NonNull String hostname,
                                           @NonNull CertificatePinner certificatePinner) {

        Utils.requireArgumentNotEmpty(hostname, "hostname = null");
        Utils.requireArgumentNonNull(certificatePinner, "certificatePinner = null");

        mHostName = hostname;
        mCertificatePinner = certificatePinner;

        try {
            final TrustManagerFactory trustManagerFactory = TrustManagerFactory
                    .getInstance(TrustManagerFactory.getDefaultAlgorithm());

            trustManagerFactory.init((KeyStore) null);

            mTrustManagers = trustManagerFactory.getTrustManagers();

            if (mTrustManagers != null) {
                InsertLogger.d("Number of TrustManagers: " + mTrustManagers.length);
            } else {
                InsertLogger.d("No TrustManagers.");
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType)
            throws CertificateException {

        if (mTrustManagers != null) {
            for (TrustManager trustManager : mTrustManagers) {
                if (trustManager instanceof X509TrustManager) {
                    ((X509TrustManager) trustManager).checkClientTrusted(chain, authType);
                }
            }
        }
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType)
            throws CertificateException {

//        InsertLogger.d("Test - testing chain: " + Arrays.toString(chain));
        if (mTrustManagers != null) {
            for (TrustManager trustManager : mTrustManagers) {
                if (trustManager instanceof X509TrustManager) {
                    ((X509TrustManager) trustManager).checkServerTrusted(chain, authType);
                }
            }
        }

        try {
            mCertificatePinner.check(mHostName, Arrays.<Certificate>asList(chain));
        } catch (SSLPeerUnverifiedException e) {
            InsertLogger.e(e, "Hostname = '" + mHostName + "', "
                    + "TrustManagers = '" + Arrays.toString(mTrustManagers) + "', "
                    + "Authentication Type = '" + authType + "', "
                    + "Chain = '" + Arrays.toString(chain) + "', "
                    + "Message = '" + e.getMessage() + "'.");
            throw new CertificateException(e);
        }
//        InsertLogger.d("Test - All good!");
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {

        ArrayList<X509Certificate> acceptedIssuers = new ArrayList<>();
        if (mTrustManagers != null) {
            for (TrustManager trustManager : mTrustManagers) {
                if (trustManager instanceof X509TrustManager) {
                    final X509Certificate[] issuers = ((X509TrustManager) trustManager)
                            .getAcceptedIssuers();

                    Collections.addAll(acceptedIssuers, issuers);
                }
            }
        }
        return acceptedIssuers.toArray(new X509Certificate[acceptedIssuers.size()]);
    }

    public static SSLContext getSslContext(String hostName) throws NoSuchAlgorithmException,
            KeyManagementException {

        SSLContext sslContext = SSLContext.getInstance("TLS");

        final CertificatePinningTrustManager certificatePinningTrustManager =
                new CertificatePinningTrustManager(hostName, getCertificatePinner());

        sslContext.init(null, new TrustManager[] {certificatePinningTrustManager}, null);

        return sslContext;
    }
}
