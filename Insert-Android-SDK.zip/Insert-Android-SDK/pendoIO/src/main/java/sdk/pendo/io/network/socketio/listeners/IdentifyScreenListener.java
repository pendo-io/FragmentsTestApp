package sdk.pendo.io.network.socketio.listeners;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.async.CaptureScreenTask;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Listen on {@link external.sdk.pendo.io.socket.SocketEvents#EVENT_IDENTIFY_SCREEN}.
 */
public class IdentifyScreenListener implements  Emitter.Listener, CaptureScreenTask.CaptureScreenListener {
    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got identifyScreen");
    }

    @Override
    public void onPreCaptureScreen() {

    }

    @Override
    public void onScreenCaptured() {

    }
}
