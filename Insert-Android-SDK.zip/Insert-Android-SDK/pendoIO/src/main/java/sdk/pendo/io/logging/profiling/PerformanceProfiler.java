package sdk.pendo.io.logging.profiling;

import java.text.SimpleDateFormat;
import java.util.Arrays;

import sdk.pendo.io.utilities.FixedStack;
import sdk.pendo.io.utilities.InsertProfiler;

/**
 * Holds the profiling data for performance tracking.
 */
public class PerformanceProfiler implements InsertProfiler {

    private SimpleDateFormat mDateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
    private FixedStack<String> mLogs = new FixedStack<>();

    public final void mark(String message) {
        mLogs.push(getCurrentTime() + ProfilingManager.PROFILER_LOG_SEPERATOR + message);
    }

    @Override
    public final String[] getStats() {
        Object[] logsArray = mLogs.toArray();
        return Arrays.copyOf(logsArray, logsArray.length, String[].class);
    }

    public final String getCurrentTime() {

        return mDateFormat.format(System.currentTimeMillis());
    }
}

