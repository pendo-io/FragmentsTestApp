package sdk.pendo.io.information.collectors.device

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONException
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.add
import java.util.*

/**
 * Collect battery information.

 * Created by assaf on 4/14/15.
 */
internal class BatteryStatus : Collector() {

    override fun collectData(json: JSONObject) {

        // Add battery status.
        addBatteryStatus(json)
    }

    /**
     * Adds the current battery status to the JSON.

     * @param info The JSON to receive the battery status JSON.
     */
    private fun addBatteryStatus(info: JSONObject) {
        val iFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = application!!.registerReceiver(null, iFilter)

        if (batteryStatus != null) {
            val battery = JSONObject()

            val health = batteryStatus.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
            try {
                battery.add(DeviceInfoConstants.BatteryStatus.STATUS, batteryHealth(health))
            } catch (e: JSONException) {
                InsertLogger.e(e, "${e.message}")
            }

            val level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val batteryPct = level / scale.toFloat()

            battery.add(DeviceInfoConstants.BatteryStatus.LEVEL,
                    String.format(Locale.US, "%.2f%%", batteryPct * 100))

            // Are we charging / charged?
            val status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

            if (isCharging) {
                battery.add(DeviceInfoConstants.BatteryStatus.STATUS, "charging")

                // How are we charging?
                val chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)

                battery.add(DeviceInfoConstants.BatteryStatus.POWER_SOURCE, batteryPowerSource(chargePlug))
            } else {
                battery.add(DeviceInfoConstants.BatteryStatus.STATUS, "discharging")
            }

            info.add(DeviceInfoConstants.BatteryStatus.BATTERYSTATUS, battery)
        }
    }

    private fun batteryPowerSource(chargePlug: Int): String {

        when (chargePlug) {
            BatteryManager.BATTERY_PLUGGED_USB -> return "USB"
            BatteryManager.BATTERY_PLUGGED_AC -> return "AC"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> return "WIRELESS"
            else -> return "UNDEFINED"
        }
    }

    private fun batteryHealth(health: Int): String {
        when (health) {
            BatteryManager.BATTERY_HEALTH_UNKNOWN -> return "UNKNOWN"
            BatteryManager.BATTERY_HEALTH_GOOD -> return "GOOD"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> return "OVERHEAT"
            BatteryManager.BATTERY_HEALTH_DEAD -> return "DEAD"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> return "OVER_VOLTAGE"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> return "UNSPECIFIED_FAILURE"
            BatteryManager.BATTERY_HEALTH_COLD -> return "COLD"
            else -> return "UNDEFINED"
        }
    }
}
