package sdk.pendo.io.actions

import sdk.pendo.io.models.*

object GuidesConfigurationManager {
    private var mThrottlingConfiguration: ThrottlingConfigurationModel? = null
    private var mLastStepSeenConfiguration: LastStepSeenConfigurationModel? = null
    private var mLocalLastSeenTime: Long? = null
    const val DEFAULT_THROTTLING_TIME_MINUTES = 5


    @Synchronized
    fun setThrottlingConfiguration(throttlingConfigurationModel: ThrottlingConfigurationModel) {
        mThrottlingConfiguration = throttlingConfigurationModel
    }

    @Synchronized
    fun setLastStepSeenConfigurationModel(lastStepSeenConfigurationModel: LastStepSeenConfigurationModel) {
        mLastStepSeenConfiguration = lastStepSeenConfigurationModel
        val guideId: String? = mLastStepSeenConfiguration?.guideId
        val guideStepId: String? = mLastStepSeenConfiguration?.guideStepId
        var stepLocationModel: StepLocationModel? = null
        if (guideId != null) {
            stepLocationModel = GuideManager.getGuide(guideId)?.getGuideStepLocation(guideStepId)
        }
        if (guideId != null && guideStepId != null) {
            StepSeenManager.getInstance().currentStepSeen = StepSeen(guideId, guideStepId, stepLocationModel)
        }
    }

    @Synchronized
    fun getIsThrottlingEnabled(): Boolean? {
        return mThrottlingConfiguration?.isEnabled
    }

    @Synchronized
    fun getThrottlingIntervalMS(): Int {
        if (mThrottlingConfiguration != null) {
            val throttlingInterval = mThrottlingConfiguration!!.interval
            val resultInSeconds = when (mThrottlingConfiguration!!.unit.toLowerCase()) {
                "second" -> throttlingInterval
                "minute" -> 60 * throttlingInterval
                "hour" -> 3600 * throttlingInterval
                "day" -> 86400 * throttlingInterval
                // Default to minutes
                else -> 60 * throttlingInterval
            }
            return resultInSeconds * 1000
        }
        return DEFAULT_THROTTLING_TIME_MINUTES * 1000
    }

    @Synchronized
    fun getLastSeenTimeMS(): Long? {
        if (mLocalLastSeenTime != null) {
            return mLocalLastSeenTime
        }
        if (mLastStepSeenConfiguration != null) {
            return mLastStepSeenConfiguration?.time
        }
        return null
    }

    @Synchronized
    fun setLastSeenTimeMS(lastSeenTime: Long) {
        mLocalLastSeenTime = lastSeenTime
    }
}
