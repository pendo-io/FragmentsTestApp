package sdk.pendo.io.reactive.filters;


import com.trello.rxlifecycle3.android.ActivityEvent;

import io.reactivex.functions.Predicate;

/**
 * Created by nirsegev on 7/15/15.
 */
public final class LifeCycleFilter implements Predicate<Object> {
    private ActivityEvent mEventToFilter;

    public LifeCycleFilter(ActivityEvent eventToFilter) {
        mEventToFilter = eventToFilter;
    }

    @Override
    public boolean test(Object o) {
        ActivityEvent event = (ActivityEvent) o;
        if (event != null && event.equals(mEventToFilter)) {
            return true;
        }
        return false;
    }
}
