package sdk.pendo.io.fonts;

import android.support.annotation.Nullable;

import com.joanzapata.iconify.Icon;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * Lists all usable {@link Icon}s of the Pendo IconFontFamily.
 */
public enum InsertIoIcons implements Icon {
    icon_mic('\ub000'),
    icon_mute('\ub001'),
    icon_volume_up('\ub002'),
    icon_volume_off('\ub003'),
    icon_resize_full_alt('\ub100'),
    icon_right_open('\ub200'),
    icon_left_open('\ub201'),
    icon_left_circled2('\ub202'),
    icon_right_circled2('\ub203'),
    icon_angle_left('\ub204'),
    icon_angle_right('\ub205'),
    icon_angle_circled_right('\ub206'),
    icon_angle_circled_left('\ub207'),
    icon_angle_double_left('\ub208'),
    icon_angle_double_right('\ub209'),
    icon_right_big('\ub210'),
    icon_left_big('\ub211'),
    icon_right_circled('\ub212'),
    icon_left_circled('\ub213'),
    icon_arrows_cw('\ub300'),
    icon_play('\ub400'),
    icon_stop('\ub401'),
    icon_pause('\ub402'),
    icon_to_end('\ub405'),
    icon_to_end_alt('\ub406'),
    icon_to_start('\ub407'),
    icon_to_start_alt('\ub408'),
    icon_fast_fw('\ub409'),
    icon_fast_bw('\ub410'),
    icon_youtube_play('\ub411'),
    icon_award('\ub500'),
    icon_off('\ub600'),
    icon_cc_visa('\ub700'),
    icon_cc_mastercard('\ub701'),
    icon_cc_discover('\ub702'),
    icon_cc_amex('\ub703'),
    icon_cc_paypal('\ub704'),
    icon_cc_stripe('\ub705'),
    icon_android('\ub800'),
    icon_apple('\ub801'),
    icon_retweet('\uc000'),
    icon_comment('\uc100'),
    icon_comment_empty('\uc101'),
    icon_bell('\uc200'),
    icon_bell_alt('\uc201'),
    icon_attention_alt('\uc300'),
    icon_attention('\uc301'),
    icon_attention_circled('\uc302'),
    icon_trash('\uc400'),
    icon_trash_empty('\uc401'),
    icon_phone('\uc500'),
    icon_phone_squared('\uc501'),
    icon_menu('\uc600'),
    icon_cog('\uc601'),
    icon_wrench('\uc602'),
    icon_list_bullet('\uc603'),
    icon_ellipsis('\uc604'),
    icon_basket('\uc700'),
    icon_cart_plus('\uc701'),
    icon_cart_arrow_down('\uc702'),
    icon_calendar('\uc800'),
    icon_calendar_empty('\uc801'),
    icon_login('\uc900'),
    icon_logout('\uc901'),
    icon_lock('\ud000'),
    icon_lock_open_alt('\ud001'),
    icon_pin('\ud100'),
    icon_eye('\ud200'),
    icon_eye_off('\ud201'),
    icon_tag('\ud300'),
    icon_thumbs_up('\ud400'),
    icon_thumbs_down('\ud401'),
    icon_thumbs_up_alt('\ud402'),
    icon_thumbs_down_alt('\ud403'),
    icon_angellist('\ud404'),
    icon_download_cloud('\ud500'),
    icon_upload_cloud('\ud501'),
    icon_pencil('\ud600'),
    icon_edit('\ud601'),
    icon_print('\ud700'),
    icon_ok('\ue001'),
    icon_ok_circled('\ue002'),
    icon_ok_circled2('\ue003'),
    icon_ok_squared('\ue004'),
    icon_check_empty('\ue005'),
    icon_check('\ue006'),
    icon_toggle_off('\ue007'),
    icon_toggle_on('\ue008'),
    icon_circle('\ue009'),
    icon_circle_empty('\ue010'),
    icon_circle_thin('\ue011'),
    icon_dot_circled('\ue012'),
    icon_blank('\ue013'),
    icon_ok_circled_1('\ue014'),
    icon_ok_1('\ue015'),
    icon_ok_outline('\ue016'),
    icon_ok_2('\ue017'),
    icon_check_outline('\ue018'),
    icon_check_1('\ue019'),
    icon_ok_3('\ue020'),
    icon_check_empty_1('\ue021'),
    icon_check_2('\ue022'),
    icon_ok_circle('\ue023'),
    icon_star('\ue100'),
    icon_star_empty('\ue101'),
    icon_star_half('\ue102'),
    icon_star_half_alt('\ue103'),
    icon_cancel('\ue200'),
    icon_cancel_circled('\ue201'),
    icon_cancel_circled2('\ue202'),
    icon_minus('\ue203'),
    icon_minus_circled('\ue204'),
    icon_minus_squared('\ue205'),
    icon_minus_squared_alt('\ue206'),
    icon_plus('\ue300'),
    icon_plus_circled('\ue301'),
    icon_plus_squared('\ue302'),
    icon_plus_squared_alt('\ue303'),
    icon_help('\ue400'),
    icon_help_circled('\ue401'),
    icon_info_circled('\ue500'),
    icon_info('\ue501'),
    icon_smile('\ue600'),
    icon_frown('\ue601'),
    icon_meh('\ue602'),
    icon_emo_happy('\ue603'),
    icon_emo_wink('\ue604'),
    icon_emo_unhappy('\ue605'),
    icon_emo_sleep('\ue606'),
    icon_emo_thumbsup('\ue607'),
    icon_emo_surprised('\ue608'),
    icon_emo_angry('\ue609'),
    icon_spin6('\ue700'),
    icon_spin5('\ue701'),
    icon_spin4('\ue702'),
    icon_spin3('\ue703'),
    icon_spin2('\ue704'),
    icon_spin1('\ue705'),
    icon_facebook('\ue800'),
    icon_facebook_official('\ue802'),
    icon_google('\ue803'),
    icon_gplus('\ue804'),
    icon_gplus_squared('\ue805'),
    icon_linkedin_squared('\ue806'),
    icon_linkedin('\ue807'),
    icon_tumblr('\ue808'),
    icon_tumblr_squared('\ue809'),
    icon_facebook_squared('\ue80a'),
    icon_twitter_squared('\ue810'),
    icon_twitter('\ue811'),
    icon_youtube('\ue812'),
    icon_youtube_squared('\ue813'),
    icon_dropbox('\ue814'),
    icon_gittip('\ue891'),
    icon_paypal('\ue897'),
    icon_music('\ue900'),
    icon_search('\uf000'),
    icon_mail('\uf100'),
    icon_mail_alt('\uf101'),
    icon_mail_squared('\uf102'),
    icon_heart('\uf200'),
    icon_heart_empty('\uf201'),
    icon_video('\uf300'),
    icon_picture('\uf400'),
    icon_camera('\uf500'),
    icon_home('\uf600'),
    icon_link('\uf700'),
    icon_link_ext('\uf800'),
    icon_link_ext_alt('\uf801'),
    icon_forward('\uf802'),
    icon_export('\uf803'),
    icon_export_alt('\uf804'),
    icon_share('\uf805'),
    icon_share_squared('\uf806'),
    icon_paper_plane('\uf807'),
    icon_paper_plane_empty('\uf809'),
    icon_attach('\uf900');

    final char mCharacter;

    InsertIoIcons(char character) {
        mCharacter = character;
    }

    @Override
    public String key() {
        return name().replace('_', '-');
    }

    @Override
    public char character() {
        return mCharacter;
    }

    private static final Map<Character, InsertIoIcons> LOOKUP_TABLE = new HashMap<>();

    @Nullable
    public static synchronized InsertIoIcons findIcon(Character c) {

        if (LOOKUP_TABLE.isEmpty()) {
            for (InsertIoIcons icon : EnumSet.allOf(InsertIoIcons.class)) {
                LOOKUP_TABLE.put(icon.mCharacter, icon);
            }
        }

        return LOOKUP_TABLE.get(c);
    }
}
