package sdk.pendo.io.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import sdk.pendo.io.R;

/**
 * Created by tomerlevinson on 10/28/15.
 */
public class ErrorDialog extends DialogFragment {

    static private Dialog mDialog = null;
    static final private int TRANSPARENT_COLOR = R.color.colorTransparent;
    private final static String IMAGE_ID_TAG = "imageID";
    private final static String LAYOUT_ID_TAG = "layoutID";
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    /*
     *  Getter function for last non-null dialog.
     *  When a new dialog fragment is instanstiated, the dialog is null,
     *  therefore we need to save the last non-null dialog.
     */
    public Dialog getLastDialog(){
        return mDialog;
    }

    @Override
    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance())
            getDialog().setDismissMessage(null);
        super.onDestroyView();
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        int layoutID = R.layout.capture_fail;
        int imageID = R.id.imageViewFail;
        if (getArguments() != null) {
            layoutID = getArguments().getInt(LAYOUT_ID_TAG);
            imageID = getArguments().getInt(IMAGE_ID_TAG);
        }
        setRetainInstance(true);
        setCancelable(true);
        mDialog = new Dialog(getActivity());
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(layoutID);
        ImageView image = (ImageView) mDialog.findViewById(imageID);
        View dialogView = (View) image.getParent();
        dialogView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });
        final Window window = mDialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        window.setBackgroundDrawable(new ColorDrawable(getResources().getColor(TRANSPARENT_COLOR)));
        return mDialog;
    }

    public static ErrorDialog newInstance(int layoutID, int imageID) {
        ErrorDialog errorDialog = new ErrorDialog();
        // Supply num input as an argument.
        Bundle args = new Bundle();
        args.putInt(LAYOUT_ID_TAG, layoutID);
        args.putInt(IMAGE_ID_TAG, imageID);
        errorDialog.setArguments(args);

        return errorDialog;
    }

}
