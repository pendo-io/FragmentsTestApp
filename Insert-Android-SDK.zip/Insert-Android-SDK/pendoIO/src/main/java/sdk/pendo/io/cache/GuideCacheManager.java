package sdk.pendo.io.cache;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;

import com.google.gson.JsonSyntaxException;

import org.jose4j.jwt.consumer.InvalidJwtException;

import java.nio.charset.Charset;
import java.util.concurrent.atomic.AtomicBoolean;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.models.InitModel;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.FileUtils;
import sdk.pendo.io.utilities.SettingsUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Disk cache manager.
 * <p/>
 * Created by assaf on 11/10/15.
 */
public final class GuideCacheManager {
    public static final String CACHE_FILE_NAME = "io_pendo_cache";
    public static final String PAIRING_CACHE_FILE_NAME = "pairing_pendo_cache";
    private static volatile GuideCacheManager INSTANCE;
    private static volatile AtomicBoolean sCacheLoaded = new AtomicBoolean(false);

    private GuideCacheManager() {
    }

    public static synchronized GuideCacheManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GuideCacheManager();
        }

        return INSTANCE;
    }

    /**
     * Loads the cached inserts from the given file name,
     * initialize the InsertsManager and EventsManager
     * @param fileName the file name from which to read the cache
     */
    public synchronized InitModel loadCachedInsertAndEvents(String fileName) {
        boolean loadingFromUserCache = false;
        InitModel initModel = null;
        String cacheString = FileUtils.getStoredFileAsString(fileName);
        if (TextUtils.isEmpty(cacheString)) {
            return null;
        }

        try {
            final CacheModel cacheModel =
                    Pendo.GSON.fromJson(cacheString, CacheModel.class);

            final String sdkVersion = cacheModel.getSdkVersion();
            final String appVersion = cacheModel.getAppVersion();

            InsertLogger.d("Cache: SDK version = '" + sdkVersion
                    + "' App version = '" + appVersion + "'.");

            if (appVersion == null || !appVersion.equals(getCurrentAppVersion())
                    || !sdkVersion.equals(SettingsUtils.getSDKVersion())) {
                InsertLogger.d("Cannot load cache,"
                        + " missing app version or mismatch or sdk version mismatch.");
                return null;
            }

            String initModelStr = cacheModel.getInitModel();
            try {
                if (fileName.equals(CACHE_FILE_NAME)) {
                    initModelStr  = JsonWebTokenValidator.INSTANCE.validate(initModelStr);
                    loadingFromUserCache = true;
                }
                initModel = Pendo.GSON.fromJson(initModelStr, InitModel.class);
                if (initModel != null && !initModel.getGuideList().isEmpty()) {
                    InsertLogger.d("loaded inserts from cache, num of inserts : " + initModel.getGuideList().size());
                    //TODO: Add cachable - noncachable to guides to see if we cache it or not.
                    if (initModel.getInitConfiguration() == null) {
                        return null;
                    }
                    initModel.init(loadingFromUserCache);
                }
            } catch (InvalidJwtException e) {
                InsertLogger.e(e, "Failed to load cache, not valid.");
                AnalyticsUtils.sendJwtSecurityException(initModelStr, "cache", e.getMessage());
            }
            sCacheLoaded.set(true);
        } catch (JsonSyntaxException e) {
            InsertLogger.e(e, e.getMessage());
        } catch (PackageManager.NameNotFoundException e) {
            InsertLogger.e(e, "Cannot get current version, not loading cache.");
        }
        return initModel;
    }

    public synchronized void storeCachedGuide(String guideModel, String fileName) {
        try {
            Utils.requireNonNull(guideModel);
            String sdkVersion = SettingsUtils.getSDKVersion();

            CacheModel cacheModel = new CacheModel(sdkVersion, getCurrentAppVersion(), guideModel);

            final String cacheModelJson = Pendo.GSON.toJson(cacheModel);
            FileUtils.createFileFromByteArray(cacheModelJson.getBytes(Charset.forName(ENCODING_UTF_8)), fileName);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    public synchronized void storeCachedInsertAndEvents(String initModel, String fileName) {

        try {
            Utils.requireNonNull(initModel);
            String sdkVersion = SettingsUtils.getSDKVersion();

            CacheModel cacheModel = new CacheModel(sdkVersion, getCurrentAppVersion(), initModel);

            final String cacheModelJson = Pendo.GSON.toJson(cacheModel);
            FileUtils.createFileFromByteArray(cacheModelJson.getBytes(Charset.forName(ENCODING_UTF_8)), fileName);
        } catch (PackageManager.NameNotFoundException ignore) {
        }

    }

    private String getCurrentAppVersion() throws PackageManager.NameNotFoundException {
        final String packageName = Pendo.getApplicationContext()
                .getApplicationInfo().packageName;
        final PackageInfo packageInfo = Pendo.getApplicationContext().getPackageManager()
                .getPackageInfo(packageName, 0);

        return packageInfo.versionName + ":" + packageInfo.versionCode;
    }

    public static boolean isCacheLoaded() {
        return sCacheLoaded.get();
    }

    public void deleteCache() {
        FileUtils.deleteFile(CACHE_FILE_NAME);
    }
}
