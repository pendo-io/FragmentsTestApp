package sdk.pendo.io.models;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;

/**
 * Describes the guide content for a single Step.
 * https://pendo-io.atlassian.net/wiki/spaces/ENG/pages/373293493/New+Guide+Activation+Model+Retroactive+SDK
 */
public class StepGuideModel {

    @SerializedName("views")
    private JsonArray mViews;

    @SerializedName("widget")
    private String mWidget;

    @SerializedName("id")
    private String mId;

    @SerializedName("configuration")
    private GuideConfigurationModel mConfiguration;

    @SerializedName("actions")
    private JsonArray mActions;

    @SerializedName("properties")
    private JsonArray mProperties;

    public JsonArray getViews() {
        return mViews;
    }

    public void setViews(JsonArray mViews) {
        this.mViews = mViews;
    }

    public String getWidget() {
        return mWidget;
    }

    public void setWidget(String mWidget) {
        this.mWidget = mWidget;
    }

    public String getId() {
        return mId;
    }

    public void setId(String mId) {
        this.mId = mId;
    }

    public GuideConfigurationModel getConfiguration() {
        return mConfiguration;
    }

    public void setConfiguration(GuideConfigurationModel mConfiguration) {
        this.mConfiguration = mConfiguration;
    }

    public JsonArray getActions() {
        return mActions;
    }

    public void setActions(JsonArray mActions) {
        this.mActions = mActions;
    }

    public JsonArray getProperties() {
        return mProperties;
    }

    public void setProperties(JsonArray mProperties) {
        this.mProperties = mProperties;
    }
}
