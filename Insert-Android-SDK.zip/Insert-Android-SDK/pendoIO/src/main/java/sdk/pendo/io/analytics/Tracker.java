package sdk.pendo.io.analytics;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import org.json.JSONObject;

import io.reactivex.functions.Consumer;
import io.reactivex.subjects.PublishSubject;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Analytics tracker interface.
 *
 * Created by assaf on 6/16/15.
 */
public class Tracker {

    public final class TrackerInfo {
        private final String mEvent;
        private final JSONObject mSpecificAnalytics;
        private final long mTimestamp;
        private final String mEndpointUrl;

        public TrackerInfo(String event, JSONObject specificAnalytics, String endpointUrl) {
            mEvent = event;
            mSpecificAnalytics = specificAnalytics;
            mTimestamp = System.currentTimeMillis();
            mEndpointUrl = endpointUrl;
        }

        protected String getEvent() {
            return mEvent;
        }

        protected JSONObject getSpecificAnalytics() {
            return mSpecificAnalytics;
        }

        protected long getTimestamp() {
            return mTimestamp;
        }

        protected String getEndpointUrl() {
            return mEndpointUrl;
        }
    }

    private final PublishSubject<TrackerInfo> mTrackerInfoPublisher;

    @Nullable
    private final GenericInsertAnalyticsData mInsertGenericAnalytics;

    @Nullable
    private JSONObject mAnalyticsData;

    protected Tracker() {
        mTrackerInfoPublisher = PublishSubject.create();
        mInsertGenericAnalytics = null;
        mAnalyticsData = null;

        mTrackerInfoPublisher.subscribe(InsertObserver.create(new Consumer<TrackerInfo>() {
            @Override
            public void accept(TrackerInfo trackerInfo) {
                InsertLogger.d("Sending analytics.");
                InsertAnalyticsData analyticsData =
                        new InsertAnalyticsData(mInsertGenericAnalytics, trackerInfo);
                InsertAnalytics.getInstance().setupAndSubscribe(analyticsData);
            }
        }));
    }

    protected Tracker(@Nullable GenericInsertAnalyticsData insertGenericAnalytics) {
        mTrackerInfoPublisher = PublishSubject.create();
        mInsertGenericAnalytics = insertGenericAnalytics;
        mAnalyticsData = null;

        if (mInsertGenericAnalytics != null) {
            mInsertGenericAnalytics.getGuideModel().setTracker(this);
        }

        mTrackerInfoPublisher.subscribe(InsertObserver.create(new Consumer<TrackerInfo>() {
            @Override
            public void accept(TrackerInfo trackerInfo) {
                InsertLogger.d("Sending analytics.");
                InsertAnalyticsData analyticsData =
                        new InsertAnalyticsData(mInsertGenericAnalytics, trackerInfo);
                InsertAnalytics.getInstance().setupAndSubscribe(analyticsData);
            }
        }));
    }

    protected Tracker(@Nullable JSONObject analyticsData) {
        mTrackerInfoPublisher = PublishSubject.create();
        mInsertGenericAnalytics = null;
        mAnalyticsData = analyticsData;

        mTrackerInfoPublisher.subscribe(InsertObserver.create(new Consumer<TrackerInfo>() {
            @Override
            public void accept(TrackerInfo trackerInfo) {
                InsertLogger.d("Sending analytics.");
                InsertAnalyticsData analyticsData =
                        new InsertAnalyticsData(mAnalyticsData, trackerInfo);
                InsertAnalytics.getInstance().setupAndSubscribe(analyticsData);
            }
        }));
    }

    public void send(@NonNull String event, @Nullable JSONObject specificAnalytics, @Nullable String endPointUrl) {
        TrackerInfo trackerInfo = new TrackerInfo(event, specificAnalytics, endPointUrl);
        mTrackerInfoPublisher.onNext(trackerInfo);
    }

    @Nullable
    public GenericInsertAnalyticsData getGenericAnalytics() { return mInsertGenericAnalytics; }

    @Nullable
    public JSONObject getAnalyticsData() {
        return mAnalyticsData;
    }

    public void setAnalyticsData(@Nullable JSONObject mAnalyticsData) {
        this.mAnalyticsData = mAnalyticsData;
    }
}
