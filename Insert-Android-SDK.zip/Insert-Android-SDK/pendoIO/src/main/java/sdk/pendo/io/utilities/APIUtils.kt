package sdk.pendo.io.utilities

import android.util.Log
import android.util.Pair

import org.jose4j.jwt.consumer.InvalidJwtException
import org.json.JSONException
import org.json.JSONObject

import java.io.IOException
import java.net.HttpURLConnection
import java.nio.charset.Charset
import java.nio.charset.UnsupportedCharsetException

import external.sdk.pendo.io.okhttp3.RequestBody
import external.sdk.pendo.io.okhttp3.ResponseBody
import sdk.pendo.io.Pendo
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.network.responses.converters.gson.InsertGsonRequestBodyConverter
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator

import sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_BACKEND
import sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8

/**
 * Handling API tasks, such as parsing and logging backend responses.
 */
object APIUtils {

	// Backend error response constants:
	private const val BACKEND_ERROR_RESPONSE_ERROR_ID = "errorId"
	private const val BACKEND_ERROR_RESPONSE_ERROR_MESSAGE = "errorMessage"
	private const val UNKNOWN = 999

	fun getRequestBody(content: String): RequestBody {
		return RequestBody.create(InsertGsonRequestBodyConverter.JSON_MEDIA_TYPE, content)
	}

	/**
	 * Parses API error to get the error id and error message
	 *
	 * @param responseBody
	 * @return Pair of errorId, errorMessage
	 */
	private fun parseAPIError(responseBody: String?): Pair<Int, String>? {
		val json: JSONObject
		try {
			json = JSONObject(responseBody)
			if (json.has(BACKEND_ERROR_RESPONSE_ERROR_ID) && json.has(BACKEND_ERROR_RESPONSE_ERROR_MESSAGE)) {
				val errorMessage = json.getString(BACKEND_ERROR_RESPONSE_ERROR_MESSAGE)
				return Pair(json.getInt(BACKEND_ERROR_RESPONSE_ERROR_ID), errorMessage)
			}
		} catch (e: JSONException) {
			InsertLogger.d(e, e.message + " JSON: " + responseBody)
		}

		return null
	}

//	private fun toastBackendErrorIfNeeded(
//		code: Int,
//		message: String,
//		response: String?
//	) {
//		//        if (Pendo.isDebugLogEnabled() && (code == HttpURLConnection.HTTP_INTERNAL_ERROR)) {
//		//            toast(message, response);
//		//        }
//	}

//	private fun toast(message: String, response: String) {
//		Handler(Looper.getMainLooper())
//			.post {
//				Toast.makeText(
//					Pendo.getApplicationContext(),
//					"Error from backend: "
//							+ message + " " + response, Toast.LENGTH_LONG
//				)
//					.show()
//			}
//	}

	/**
	 * Logging a backend error and toasting it if needed
	 *
	 * @param code
	 * @param message
	 * @param body
	 */
	fun logBackendError(code: Int, message: String, body: String?) {
		internalLogBackendError(code, message, body ?: "")
	}

	/**
	 * Logging a backend error and toasting it if needed
	 *
	 * @param error
	 * @param statusCode
	 */
	fun logBackendError(error: ResponseBody, statusCode: Int) {
		try {
			val body = JsonWebTokenValidator.validate(APIUtils.getResponseBodyAsString(error))
			if (body != null) {
				InsertLogger.d("Retrofit backend error: $body")
			}

			internalLogBackendError(statusCode, null, body)
		} catch (e: IOException) {
			InsertLogger.e(e, e.message)
		} catch (e: InvalidJwtException) {
			InsertLogger.e(e, e.message)
		}

	}

	private fun internalLogBackendError(code: Int, message: String?, body: String?) {
//		toastBackendErrorIfNeeded(code, message.orEmpty(), body)
		handleBackendErrorIfNeeded(code, message.orEmpty(), body)
	}

	private fun handleBackendErrorIfNeeded(code: Int, message: String, responseBody: String?) {
		if (code == HttpURLConnection.HTTP_INTERNAL_ERROR) {
			val errorDetails = parseAPIError(responseBody)
			if (errorDetails != null) {
				Log.e(Pendo.TAG, message + " " + errorDetails.second)
				if (errorDetails.first == UNKNOWN) {
					AnalyticsUtils.sendErrorReport(
						ERROR_REASON_BACKEND,
						"Backend returned unexpected error "
								+ message + responseBody
					)
				}
			}
		}
	}

	/**
	 * Checking whether the response holds an unexpected backend error
	 * @param responseBody
	 * @return
	 */
	fun isUnexpectedAPIError(responseBody: String?): Boolean {
		val error: Pair<Int, String>?
		val errorMessage: String
		if (responseBody != null) {
			errorMessage = responseBody
			error = parseAPIError(errorMessage)
			if (error != null) {
				return error.first == UNKNOWN
			}
		}
		return false
	}

	fun logSocketError(errorString: String) {
		//toast(errorString, "");
		InsertLogger.d("Socket Error: $errorString")
	}

	/**
	 * Since calling string() on a ResponseBody consumes it (can only be called once),
	 * this method returns the ResponseBody as a string without calling string().
	 * @param responseBody the ResponseBody instance we want to get as a String.
	 * @return a string representation of the ResponseBody.
	 * @throws IOException
	 */
	@Throws(IOException::class)
	fun getResponseBodyAsString(responseBody: ResponseBody?): String {
		var result = ""
		if (responseBody != null) {
			val source = responseBody.source()
			source.request(java.lang.Long.MAX_VALUE) // Buffer the entire body.
			val buffer = source.buffer()
			val contentType = responseBody.contentType()
			if (contentType != null) {
				try {
					val charset = contentType.charset(Charset.forName(ENCODING_UTF_8))
					if (responseBody.contentLength() != 0L) {
						result = buffer.clone().readString(charset)
					}
				} catch (e: UnsupportedCharsetException) {
					InsertLogger.d("Couldn't decode the response body; charset is likely malformed.")
				}

			}
		}
		return result
	}
}
