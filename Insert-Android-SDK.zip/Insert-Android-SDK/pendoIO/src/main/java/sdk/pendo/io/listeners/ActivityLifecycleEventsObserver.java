package sdk.pendo.io.listeners;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import com.trello.rxlifecycle3.android.ActivityEvent;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import sdk.pendo.io.activities.InsertVisualActivity;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.reactive.observers.InsertObserver;

/**
 * A singleton {@link android.app.Activity} lifecycle observer that emits events to it's listeners.
 * <p/>
 * Created by assaf on 2/2/16.
 */
public final class ActivityLifecycleEventsObserver {

    private static final int FRAGMENT_CHANGE_INTERVAL = 250;
    private static volatile ActivityLifecycleEventsObserver INSTANCE;

    @SuppressWarnings("CheckStyle")
    private static volatile BehaviorSubject<ActivityAndLifecycle> mActivityLifecycleEventsObserver = BehaviorSubject.create();

    private ActivityLifecycleEventsObserver() {
    }

    public static synchronized ActivityLifecycleEventsObserver getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ActivityLifecycleEventsObserver();
        }

        return INSTANCE;
    }

    /** package */ void notifyListeners(Activity activity, ActivityEvent lifecycleEvent) {

        if (activity instanceof InsertVisualActivity) {
            InsertLogger.i("Not notifying about " + activity.getLocalClassName());
            return;
        }

        ActivityAndLifecycle activityAndLifecycle =
                ActivityAndLifecycle.activityAndLifecycleFactory(activity, lifecycleEvent);

        mActivityLifecycleEventsObserver.onNext(activityAndLifecycle);
    }

    /**
     * Notifies the given {@link Observer} iff the given {@link Activity} received the given
     * {@link ActivityEvent}.
     *
     * @param activity the {@link Activity} to filter by.
     * @param lifecycleEvent the {@link ActivityEvent} to filter by.
     * @param consumer the consumer to subscribe.
     *
     * @return a {@link Disposable} reference with which the {@link Observer}
     * can stop receiving items before the Observable has completed.
     */
    public Disposable subscribeActivityLifeEventObserver(
            @NonNull Activity activity,
            @NonNull ActivityEvent lifecycleEvent,
            @NonNull Consumer<ActivityEvent> consumer) {

        final ActivityAndLifecycle activityAndLifecycle =
                ActivityAndLifecycle.activityAndLifecycleFactory(activity, lifecycleEvent);

        return mActivityLifecycleEventsObserver
                .filter(new Predicate<ActivityAndLifecycle>() {
                    @Override
                    public boolean test(ActivityAndLifecycle activityAndLifecycleEvent) {

                        return activityAndLifecycleEvent.equals(activityAndLifecycle);
                    }
                })
                .map(new Function<ActivityAndLifecycle, ActivityEvent>() {
                    @Override
                    public ActivityEvent apply(
                            ActivityAndLifecycle activityAndLifecycle) {
                        return activityAndLifecycle.mLifecycleEvent;
                    }
                })
                .subscribe(consumer);

    }

    /**
     * Notifies the given {@link Observer} iff <b>ANY</b> {@link Activity} excluding the given one
     * received the given {@link ActivityEvent}, or if the current visible fragment has changed
     * (is no longer 'currentFragment').
     *
     * @param activity the {@link Activity} to filter by.
     * @param lifecycleEvent the {@link ActivityEvent} to filter by.
     * @param currentFragment the {@link Fragment} that is currently visible (or null if there's no such).
     * @param consumer the consumer to subscribe.
     *
     * @return a {@link Disposable} reference with which the {@link Observer}
     * can stop receiving items before the Observable has completed.
     */

    @SuppressLint("RestrictedApi")
    public Disposable subscribeAnyButActivityLifeEventObserverOrFragmentChange(
            @NonNull final Activity activity,
            @NonNull final ActivityEvent lifecycleEvent,
            @Nullable final String currentFragment,
            @NonNull Consumer<ActivityEvent> consumer) {

        final BehaviorSubject fragmentChangeObservable = BehaviorSubject.create();

        if (activity instanceof FragmentActivity && currentFragment != null) {
            final AtomicBoolean fragmentChanged = new AtomicBoolean(false);
            
            InsertLogger.d("Current Fragment =  " + currentFragment);

            Observable.interval(FRAGMENT_CHANGE_INTERVAL, TimeUnit.MILLISECONDS, Schedulers.computation())
                    .takeWhile(new Predicate<Long>() { // Run every 250ms and stop when Fragment changes.
                        @Override
                        public boolean test(Long aLong) {
                            return !fragmentChanged.get();
                        }
                    })
                    .subscribe(InsertObserver.create(new Consumer<Long>() {
                        @Override
                        public void accept(Long ignore) {
                            for (Fragment fragment : ((FragmentActivity) activity).getSupportFragmentManager().getFragments()) {
                                if (fragment != null && fragment.isVisible() && fragment.isMenuVisible()
                                        && !fragment.getClass().getSimpleName().equals(currentFragment)) {
                                    InsertLogger.d("New Fragment =  " + fragment.getClass().getSimpleName());
                                    fragmentChangeObservable.onNext(lifecycleEvent);
                                    fragmentChanged.set(true);
                                    break;
                                }
                            }
                        }
                    }));
        }

        final ActivityAndLifecycle activityAndLifecycle =
                ActivityAndLifecycle.activityAndLifecycleFactory(activity, lifecycleEvent);

        return mActivityLifecycleEventsObserver
                .filter(new Predicate<ActivityAndLifecycle>() {
                    @Override
                    public boolean test(ActivityAndLifecycle activityAndLifecycleEvent) {

                        return activityAndLifecycleEvent
                                .lifeEventEqualsAndActivityNotEquals(activityAndLifecycle);
                    }
                })
                .map(new Function<ActivityAndLifecycle, ActivityEvent>() {
                    @Override
                    public ActivityEvent apply(
                            ActivityAndLifecycle activityAndLifecycle) {
                        return activityAndLifecycle.mLifecycleEvent;
                    }
                })
                .mergeWith(fragmentChangeObservable)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(consumer, new InsertOnErrorHandler());
    }

    @SuppressWarnings("CheckStyle")
    private static final class ActivityAndLifecycle {
        final int mActivityId;
        final ActivityEvent mLifecycleEvent;


        private ActivityAndLifecycle(int activityId, ActivityEvent lifecycleEvent) {
            mActivityId = activityId;
            mLifecycleEvent = lifecycleEvent;
        }

        /**
         * Returns true iff the given object have the same {@link ActivityEvent} but differ
         * in the {@link Activity} AND it's not InsertVisualActivity.
         *
         * @param o the object to compare this instance with.
         *
         * @return True iff the given object have the same {@link ActivityEvent} but differ
         * in the {@link Activity}.
         */
        public boolean lifeEventEqualsAndActivityNotEquals(Object o) {

            return !equals(o)
                    && (o instanceof ActivityAndLifecycle)
                    && ((ActivityAndLifecycle) o).mActivityId != InsertVisualActivity.ID
                    && mActivityId != ((ActivityAndLifecycle) o).mActivityId
                    && mLifecycleEvent.equals(((ActivityAndLifecycle) o).mLifecycleEvent);

        }

        @Override
        public boolean equals(Object o) {

            if (o == this) {
                return true;
            } else if (!(o instanceof ActivityAndLifecycle)) {
                return false;
            }


            return mActivityId == ((ActivityAndLifecycle) o).mActivityId
                    && mLifecycleEvent.equals(((ActivityAndLifecycle) o).mLifecycleEvent);
        }

        @Override
        public int hashCode() {
            return (mActivityId * 37) + (mLifecycleEvent.hashCode() * 23);
        }

        private static ActivityAndLifecycle activityAndLifecycleFactory(
                Activity activity, ActivityEvent lifecycleEvent) {
            final int activityId = getActivityId(activity);
            return new ActivityAndLifecycle(activityId, lifecycleEvent);
        }

        private static int getActivityId(Activity activity) {
            if (activity instanceof InsertVisualActivity) {
                return InsertVisualActivity.ID;
            }

            return activity.getLocalClassName().hashCode();
        }
    }
}
