package sdk.pendo.io.utilities.script;

import android.support.annotation.Nullable;

import external.sdk.pendo.io.mozilla.javascript.Context;
import external.sdk.pendo.io.mozilla.javascript.ContextFactory;
import external.sdk.pendo.io.mozilla.javascript.Function;
import external.sdk.pendo.io.mozilla.javascript.Scriptable;
import external.sdk.pendo.io.mozilla.javascript.ScriptableObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.StepSeenManager;
import sdk.pendo.io.actions.VisualInsertBase;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.StepContentModel;
import sdk.pendo.io.utilities.ResourceUtils;
import sdk.pendo.io.utilities.SettingsUtils;
import sdk.pendo.io.utilities.script.JavascriptSandboxContextFactory.InsertIoJSContext;

import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_FIND_DISPATCH_ACTIONS;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_FIND_DISPATCH_TRIGGER_ACTIONS;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_FIND_ELEMENT_BY_ID;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_DURATION_INSERT_DISMISSED;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_DURATION_SCREEN_LEFT;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_ACTIVE_TIME_FROM_LAST_FOREGROUND;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_ACTIVE_TIME_FOR_APP_SESSION_END;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_DURATION_APP_IN_BACKGROUND;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_ACTIVE_TIME_SCREEN_LEFT;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_DURATION_SESSION_END;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_FROM_CONTEXT;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_GUIDE_STEP_ID;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_GET_ORIENTATION;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_LOG_D;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_LOG_E;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_LOG_I;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_FUNCTION_VALIDATE_FORM;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_STANDIN_CONSTRUCTOR;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_STANDIN_PROTOTYPE_FUNCTION_GET_ANSWERS;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_STANDIN_PROTOTYPE_FUNCTION_GET_ELEMENT;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_STANDIN_PROTOTYPE_FUNCTION_GET_PAGE_NUMBER;
import static sdk.pendo.io.utilities.script.InsertNativeBridge.InsertNativeBridgeJSFunctions.JS_STANDIN_PROTOTYPE_FUNCTION_GET_TYPE;

/**
 * Runs JavaScript.
 * <p>
 * Created by tomerlevinson on 3/31/16.
 */
public final class JavascriptRunner {

    // @formatter:off
    public static final String SCRIPT_NAME                      = "script";
    public static final String JAVA_SCRIPT_TYPE                 = "javascript";
    public static final String JAVA_SCRIPT_RUNNER_DESTINATION   = "JavaScriptRunner";
    private static final String MAIN_FUNCTION_NAME              = "guideRun";
    // @formatter:on

    private static String sDeviceLocal = ResourceUtils.getCurrentUserPreferenceOnLocale();

    public static final class InsertContext {

        private final Map<String, Object> mContextMap = new HashMap<>();

        public InsertContext() {
            if (sDeviceLocal.equals(ResourceUtils.EMPTY_DEVICE_LOCAL)) {
                sDeviceLocal = ResourceUtils.getCurrentUserPreferenceOnLocale();
            }
            mContextMap.put("locale", sDeviceLocal);
            mContextMap.put("sdkVersion", SettingsUtils.getSDKVersion());
        }

        public InsertContext(String guideId) {
            this();
            mContextMap.put("guideId", guideId);
        }

        @Nullable
        public <T> T get(String key, Class<T> type) {
            if (mContextMap.containsKey(key)) {
                return type.cast(mContextMap.get(key));
            }
            return null;
        }

        public void set(String key, String value) {
            mContextMap.put(key, value);
        }

        public String getGuideId() {
            return get(AnalyticsProperties.GUIDE_ID, String.class);
        }

        public String getScreenId() {
            return get(AnalyticsProperties.SCREEN_ID, String.class);
        }

        /**
         * Adds basic context parameters to the context of insert commands lacking them.
         *
         * @param insertCommands - the insert commands in question.
         */
        public static void addBasicParamsToInsertCommands(List<InsertCommand> insertCommands) {
            for (InsertCommand insertCommand : insertCommands) {
                JavascriptRunner.InsertContext guideContext = insertCommand.getContext();
                if (guideContext != null
                        && guideContext.getGuideId() != null) {
                    String guideId = guideContext.getGuideId();
                    GuideModel guideModel = GuideManager.INSTANCE.getGuide(guideId);
                    if (guideModel != null) {
                        VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(guideId);
                        if  (visualInsert != null) {
                            guideContext.set(AnalyticsProperties.SEEN_REASON, visualInsert.getActivatedBy());
                        }
                        StepContentModel stepContentModel = guideModel.getStepContentModel(StepSeenManager.getInstance().getCurrentStepIndex());
                        if (stepContentModel != null && stepContentModel.getGuideStepId() != null) {
                            guideContext.set(AnalyticsProperties.GUIDE_STEP_ID, stepContentModel.getGuideStepId());
                        }
                    }
                    VisualInsertBase insert = ((VisualInsertBase) GuideManager.INSTANCE.getGuide(guideId));
                    if (insert != null) {
                        long displayDuration = insert.getDuration();
                        if (guideContext.get(AnalyticsProperties.DISPLAY_DURATION,
                                String.class) == null) {
                            guideContext.set(AnalyticsProperties.DISPLAY_DURATION,
                                    Long.toString(displayDuration));
                        }
                        if (guideContext.get(AnalyticsProperties.GUIDE_ID,
                                String.class) == null) {
                            guideContext.set(AnalyticsProperties.GUIDE_ID,
                                    guideId);
                        }
                        if (guideContext.get(AnalyticsProperties.VISITOR_ID_CAMELCASE, String.class) == null) {
                            guideContext.set(AnalyticsProperties.VISITOR_ID_CAMELCASE, Pendo.getVisitorId());
                        }
                        if (guideContext.get(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, String.class) == null) {
                            guideContext.set(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, Pendo.getAccountId());
                        }

                    }
                } else {
                    guideContext = new JavascriptRunner.InsertContext();
                    insertCommand.setContext(guideContext);
                }
            }
        }
    }

    private JavascriptRunner() {
    }

    static {
        // Initialize GlobalFactory with custom factory
        ContextFactory.initGlobal(
                new JavascriptSandboxContextFactory(JavascriptSandboxImpl.getInstance()));
    }

    /**
     * Sets the sandbox mode to every script sandbox implementation.
     *
     * @param options the insert's options.
     */
    public static void setSandboxMode(Pendo.PendoOptions options) {

        // IMPORTANT: Add all new sandboxes here.
        JavascriptSandboxImpl.getInstance().setSandboxModeAndWhitelist(options);
    }


    public static void log(String msg) {
        InsertLogger.i("RHINO_LOG", msg);
    }

    public static Object runCode(String javascriptCode, Class<?> resultClsType) {
        return runCode(javascriptCode, resultClsType, null);
    }

    public static Object runCode(String javascriptCode, Class<?> resultClsType,
                                 InsertContext context) {

        // Every Rhino VM begins with the enter()
        // This Context is not Android's Context
//        if (resultClsType == String.class) {
//            // Do string related code here.
//        }
        try {
            InsertIoJSContext rhino =
                    (InsertIoJSContext) JavascriptSandboxContextFactory.getGlobal().enterContext();

            // Turn off optimization to make Rhino Android compatible
            rhino.setOptimizationLevel(-1);


            Scriptable scope = rhino.initStandardObjects();
            Object[] functionParams = new Object[]{context};

            // This line set the javaContext variable in JavaScript
            ScriptableObject.putProperty(scope, "javaContext",
                    Context.javaToJS(Pendo.getApplicationContext(), scope));
            ScriptableObject.putProperty(scope, "javaLoader", Context.javaToJS(
                    Pendo.class.getClassLoader(), scope));

            // Add our base functions.
            addAllBaseJSFunctions(rhino, scope);

            // Note the forth argument is 1, which means the JavaScript source has
            // been compressed to only one line using something like YUI.
            rhino.evaluateString(scope, javascriptCode, "MAIN_SERVER_SCRIPT", 1, null);
            Object functionToInvoke = scope.get(MAIN_FUNCTION_NAME, scope);
            if (functionToInvoke instanceof Function) {
                Object invocationJSResult =
                        ((Function) functionToInvoke).call(rhino, scope, scope, functionParams);
                Object javaResult = Context.jsToJava(invocationJSResult, Object.class);
                return resultClsType.cast(javaResult);
            }

        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());

        } finally {
            Context.exit();
        }
        return null;
    }

    private static void addAllBaseJSFunctions(
            InsertIoJSContext rhino, Scriptable scope) {

        // Add the stand in for the elements.
        rhino.evaluateString(scope, JS_STANDIN_CONSTRUCTOR,
                "JS_STANDIN_CONSTRUCTOR", 1, null);
        rhino.evaluateString(scope, JS_STANDIN_PROTOTYPE_FUNCTION_GET_ELEMENT,
                "JS_STANDIN_PROTOTYPE_FUNCTION_GET_ELEMENT", 1, null);
        rhino.evaluateString(scope, JS_STANDIN_PROTOTYPE_FUNCTION_GET_TYPE,
                "JS_STANDIN_PROTOTYPE_FUNCTION_GET_TYPE", 1, null);
        rhino.evaluateString(scope, JS_STANDIN_PROTOTYPE_FUNCTION_GET_PAGE_NUMBER,
                "JS_STANDIN_PROTOTYPE_FUNCTION_GET_PAGE_NUMBER", 1, null);
        rhino.evaluateString(scope, JS_STANDIN_PROTOTYPE_FUNCTION_GET_ANSWERS,
                "JS_STANDIN_PROTOTYPE_FUNCTION_GET_ANSWERS", 1, null);

        // Add find element by id for the JS to be able to look for elements by their ID.
        rhino.evaluateString(scope, JS_FUNCTION_FIND_ELEMENT_BY_ID,
                "JS_FUNCTION_FIND_ELEMENT_BY_ID", 1, null);

        // Add dispatch action for the JS to be able to run actions in the SDK.
        rhino.evaluateString(scope, JS_FUNCTION_FIND_DISPATCH_ACTIONS,
                "JS_FUNCTION_FIND_DISPATCH_ACTIONS", 1, null);

        // For iOS compatability.
        rhino.evaluateString(scope, JS_FUNCTION_FIND_DISPATCH_TRIGGER_ACTIONS,
                "JS_FUNCTION_FIND_DISPATCH_TRIGGER_ACTIONS", 1, null);

        // Add get from context function.
        rhino.evaluateString(scope, JS_FUNCTION_GET_FROM_CONTEXT,
                "JS_FUNCTION_GET_FROM_CONTEXT", 1, null);

        rhino.evaluateString(scope, JS_FUNCTION_GET_GUIDE_STEP_ID,
                "JS_FUNCTION_GET_GUIDE_STEP_ID", 1, null);

        // Get duration of insert dismissed.
        rhino.evaluateString(scope, JS_FUNCTION_GET_DURATION_INSERT_DISMISSED,
                "JS_FUNCTION_GET_DURATION_INSERT_DISMISSED", 1, null);

        //Get duration of screen left
        rhino.evaluateString(scope, JS_FUNCTION_GET_DURATION_SCREEN_LEFT,
                "JS_FUNCTION_GET_DURATION_SCREEN_LEFT", 1, null);

        // Get active time from last foreground or sessionStart.
        rhino.evaluateString(scope, JS_FUNCTION_GET_ACTIVE_TIME_FROM_LAST_FOREGROUND,
                "JS_FUNCTION_GET_ACTIVE_TIME_FROM_LAST_FOREGROUND", 1, null);

        // Get the app in background duration.
        rhino.evaluateString(scope, JS_FUNCTION_GET_DURATION_APP_IN_BACKGROUND,
                "JS_FUNCTION_GET_DURATION_APP_IN_BACKGROUND", 1, null);

        // Get active time for app session end.
        rhino.evaluateString(scope, JS_FUNCTION_GET_ACTIVE_TIME_FOR_APP_SESSION_END,
                "JS_FUNCTION_GET_ACTIVE_TIME_FOR_APP_SESSION_END", 1, null);

        // Get duration session end.
        rhino.evaluateString(scope, JS_FUNCTION_GET_DURATION_SESSION_END,
                "JS_FUNCTION_GET_DURATION_SESSION_END", 1, null);
        // Get active time of screen left.
        rhino.evaluateString(scope, JS_FUNCTION_GET_ACTIVE_TIME_SCREEN_LEFT,
                "JS_FUNCTION_GET_ACTIVE_TIME_SCREEN_LEFT", 1, null);

        // Validate form function.
        rhino.evaluateString(scope, JS_FUNCTION_VALIDATE_FORM,
                "JS_FUNCTION_VALIDATE_FORM", 1, null);

        // Add getOrienation function.
        rhino.evaluateString(scope, JS_FUNCTION_GET_ORIENTATION,
                "JS_FUNCTION_GET_ORIENTATION", 1, null);

        // Add loggers:
        rhino.evaluateString(scope, JS_FUNCTION_LOG_I, "JS_FUNCTION_LOG_I", 1, null);
        rhino.evaluateString(scope, JS_FUNCTION_LOG_D, "JS_FUNCTION_LOG_D", 1, null);
        rhino.evaluateString(scope, JS_FUNCTION_LOG_E, "JS_FUNCTION_LOG_E", 1, null);
    }
}
