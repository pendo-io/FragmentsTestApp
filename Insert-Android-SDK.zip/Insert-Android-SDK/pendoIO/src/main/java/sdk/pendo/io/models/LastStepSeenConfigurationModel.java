package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

public class LastStepSeenConfigurationModel {
    @SerializedName("guideId")
    private String mGuideId;

    @SerializedName("guideStepId")
    private String mGuideStepId;

    @SerializedName("time")
    private long mTime;

    public long getTime() {
        return mTime;
    }

    public void setTime(long time) {
        this.mTime = time;
    }

    public String getGuideStepId() {
        return mGuideStepId;
    }

    public String getGuideId() {
        return mGuideId;
    }
}