package sdk.pendo.io.information.collectors.application

import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.add

/**
 * Collect information about the application's permissions.

 * Created by assaf on 4/14/15.
 */
internal class Permissions : Collector() {

    override fun collectData(json: JSONObject) {

        // Add the permissions that were requested by the package.
        addPermissions(json)
    }

    /**
     * Adds all the permission the application is using to the JSON.

     * @param info The JSON object to receive the permissions array.
     */
    private fun addPermissions(info: JSONObject) {
        try {
            val permissions = application!!.packageManager.getPackageInfo(packageName,
                    PackageManager.GET_PERMISSIONS)

            // The <uses-permission> under the <manifest>.
            val requestedPermissions = permissions.requestedPermissions
            if (requestedPermissions != null) {
                val permissionArray = JSONArray()

                for (permission in requestedPermissions) {
                    permissionArray.add(permission)
                }

                info.add("permissions", permissionArray)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            InsertLogger.e(e, "Failed to get permissions.")
        }

    }
}
