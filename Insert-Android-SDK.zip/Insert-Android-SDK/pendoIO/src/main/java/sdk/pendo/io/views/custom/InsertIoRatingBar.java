package sdk.pendo.io.views.custom;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.joanzapata.iconify.Icon;
import com.joanzapata.iconify.IconDrawable;

import org.json.JSONException;

import java.util.List;

import external.sdk.pendo.io.dynamicview.DynamicProperty;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.fonts.InsertIoIcons;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.FontUtils;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.ViewUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;
import sdk.pendo.io.views.third_party.FlexboxLayout;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts.createInsertMetadataParams;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_SELECTION_CHANGED;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_VALID;

/**
 * Pendo IO custom RatingBar view.
 * <p/>
 * Created by assaf on 6/29/16.
 */
@SuppressLint("ViewConstructor")
public final class InsertIoRatingBar extends FlexboxLayout implements View.OnClickListener {

    private static final int DEFAULT_NUM_OF_STEPS = 5;
    private static final int DEFAULT_TEXT_SIZE = 12;
    private static final String HINT_LOCATION_BELOW = "below";

    private final String mInsertId;
    private final int mNumOfSteps;
    private final List<InsertCommand> mCommands;

    private int mRating = 0;
    private StepButton[] mStepViews;

    /**
     * Pendo's rating bar view. Using {@link FlexboxLayout} to layout the rating 'steps'.
     *
     * @param context    the context.
     * @param jsonObject the view JSON object we get from the backend
     *                   (properties and commands are needed).
     * @param insertId   the insert id of the insert this view is related to.
     * @throws JSONException if the value doesn't exist or is not a {@code JSONObject}.
     */
    @SuppressWarnings("ConstantConditions")
    public InsertIoRatingBar(@NonNull Context context, @NonNull JsonObject jsonObject, String insertId)
            throws JSONException {
        super(context);

        InsertContentDescriptionManager.getInstance().setContentDescription(this,
                getContext().getString(
                        R.string.insert_rating_bar_access_desc), null);
        setupFlexboxLayout();

        mInsertId = insertId;

        int steps = -1;
        int iconSize = ViewUtils.convertDpToPx(FontUtils.DEFAULT_FONT_ICON_SIZE);
        int textSize = ViewUtils.convertSpToPx(DEFAULT_TEXT_SIZE);
        int textColor = Color.WHITE;
        DynamicProperty textStyle = null;
        String fontFamily = null;
        String iconFontFamily = null;
        String selectedIcon = null;
        String unselectedIcon = null;
        int selectedIconColor = Color.WHITE;
        int unselectedIconColor = Color.WHITE;
        String minValueHintText = null;
        String maxValueHintText = null;
        String hintLocation = HINT_LOCATION_BELOW;

        final JsonArray actions =
                JsonUtils.optJsonArray(jsonObject, InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);
        final JavascriptRunner.InsertContext insertContext =
                new JavascriptRunner.InsertContext(mInsertId);
        mCommands = InsertCommand.getInsertCommandsWithParameters(
                actions,
                createInsertMetadataParams(mInsertId),
                insertContext);

        final JsonArray props = JsonUtils.optJsonArray(
                jsonObject, InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);

        if (props != null) {
            for (int i = 0; i < props.size(); i++) {

                DynamicProperty prop = new DynamicProperty(props.get(i).getAsJsonObject());
                if (DynamicProperty.NAME.STEPS.equals(prop.name)) {
                    steps = prop.getValueInt();
                } else if (DynamicProperty.NAME.ICONSIZE.equals(prop.name)) {
                    iconSize = prop.getValueInt();
                } else if (DynamicProperty.NAME.TEXTSIZE.equals(prop.name)) {
                    textSize = prop.getValueInt();
                } else if (DynamicProperty.NAME.TEXTCOLOR.equals(prop.name)) {
                    textColor = prop.getValueColor();
                } else if (DynamicProperty.NAME.FONTFAMILY.equals(prop.name)) {
                    fontFamily = prop.getValueString();
                } else if (DynamicProperty.NAME.TEXTSTYLE.equals(prop.name)) {
                    textStyle = prop;
                } else if (DynamicProperty.NAME.ICONFONTFAMILY.equals(prop.name)) {
                    iconFontFamily = prop.getValueString();
                } else if (DynamicProperty.NAME.SELECTEDICON.equals(prop.name)) {
                    selectedIcon = prop.getValueString();
                } else if (DynamicProperty.NAME.UNSELECTEDICON.equals(prop.name)) {
                    unselectedIcon = prop.getValueString();
                } else if (DynamicProperty.NAME.SELECTEDICONCOLOR.equals(prop.name)) {
                    selectedIconColor = prop.getValueColor();
                } else if (DynamicProperty.NAME.UNSELECTEDICONCOLOR.equals(prop.name)) {
                    unselectedIconColor = prop.getValueColor();
                } else if (DynamicProperty.NAME.MINVALUEHINTTEXT.equals(prop.name)) {
                    minValueHintText = prop.getValueString();
                } else if (DynamicProperty.NAME.MAXVALUEHINTTEXT.equals(prop.name)) {
                    maxValueHintText = prop.getValueString();
                } else if (DynamicProperty.NAME.HINTLOCATION.equals(prop.name)) {
                    hintLocation = prop.getValueString();
                }
            }
        }

        // Set the number of steps in the rating bar.
        if (steps <= 0) {
            InsertLogger.d("Number of steps is: '" + steps
                    + "', defaulting to default: '" + DEFAULT_NUM_OF_STEPS + "'.");
            mNumOfSteps = DEFAULT_NUM_OF_STEPS;
        } else {
            mNumOfSteps = steps;
        }

        // Get the selected and unselected icons.
        Icon iconifySelected =
                FontUtils.getIcon(FontUtils.getChar(selectedIcon),
                        iconFontFamily,
                        InsertIoIcons.icon_star);
        Icon iconifyUnselected =
                FontUtils.getIcon(FontUtils.getChar(unselectedIcon),
                        iconFontFamily,
                        InsertIoIcons.icon_star_empty);

        // Create the icon drawables.
        final IconDrawable iconSelected =
                FontUtils.createIconDrawable(context, iconSize,
                        selectedIconColor, iconifySelected);

        final IconDrawable iconUnselected =
                FontUtils.createIconDrawable(context, iconSize,
                        unselectedIconColor, iconifyUnselected);

        // Create the minimum and maximum TextViews.
        TextView minValueText = createStepTextView(context, textSize,
                textColor, fontFamily,
                textStyle, minValueHintText);
        TextView maxValueText = createStepTextView(context, textSize,
                textColor, fontFamily,
                textStyle, maxValueHintText);

        //noinspection CheckStyle
        setupStepViews(iconSelected, iconUnselected, minValueText, maxValueText,
                StepButton.hintLocation(hintLocation));
    }

    /**
     * Sets the current rating.
     *
     * @param rating the rating (must be positive).
     */
    public void setRating(int rating) {

        if (rating == -1) {
            return;
        }

        mRating = rating;
        refreshSteps();
    }

    /**
     * @return the current rating (0 if no rating).
     */
    public int getRating() {
        return mRating;
    }

    /**
     * @return the current rating zero-based (-1 if no rating).
     */
    public int getAnalyticsRating() {
        return mRating - 1;
    }

    @Override
    public void onClick(View v) {
        if (v instanceof StepButton) {
            StepButton step = (StepButton) v;

            mRating = step.mPosition + 1;
            InsertContentDescriptionManager.getInstance().setContentDescription(
                    v, "Rating selected '" + mRating + "' out of '" + mNumOfSteps + "'.", null);
            if (mCommands != null) {
                InsertCommandDispatcher.getInstance().dispatchCommands(mCommands,
                        ON_SELECTION_CHANGED, true);

                InsertCommandDispatcher.getInstance().dispatchCommands(mCommands,
                        ON_VALID, true);
            }

            refreshSteps();
        }
    }

    /**
     * Goes over the steps, sets the right icon for each of then and set the content description
     * for the selected step to be something meaningful.
     */
    private void refreshSteps() {
        for (int position = 0; position < mStepViews.length; position++) {

            if (mRating == position + 1) {
                final String contentDescription = "Rating selected '" + mRating
                        + "' out of '" + mNumOfSteps + "'.";
                InsertContentDescriptionManager.getInstance().setContentDescription(
                        mStepViews[position], contentDescription, contentDescription);
            } else {
                mStepViews[position].setContentDescription(null);
                final String contentDescription = "Click to select rating '" + (position + 1)
                        + "' out of '" + mNumOfSteps + "'.";
                InsertContentDescriptionManager.getInstance().setContentDescription(
                        mStepViews[position], contentDescription, contentDescription);
            }

            if (position < mRating) {
                mStepViews[position].check(true);
            } else {
                mStepViews[position].check(false);
            }
        }
    }

    /**
     * Setup:
     * Flexbox layout:
     * {@link FlexboxLayout.FlexDirection},
     * {@link FlexboxLayout.FlexWrap},
     * {@link FlexboxLayout.JustifyContent}
     * <p/>
     * Flexbox items:
     * {@link FlexboxLayout.AlignItems},
     * {@link AlignContent}.
     */
    private void setupFlexboxLayout() {
        // Flex layout:
        setFlexDirection(FLEX_DIRECTION_ROW);
        setFlexWrap(FLEX_WRAP_NOWRAP);
        setJustifyContent(JUSTIFY_CONTENT_CENTER);

        // Flex items:
        setAlignItems(ALIGN_ITEMS_STRETCH);
        setAlignContent(ALIGN_CONTENT_CENTER);
    }

    /**
     * Setup the step views and adds them to the layout.
     *
     * @param selectedIcon     the icon for the selected state.
     * @param unselectedIcon   the icon for the unselected state.
     * @param minValueHintText the {@code TextView} of the minimum hint text.
     * @param maxValueHintText the {@code TextView} of the maximum hint text.
     * @param hintLocation     indicates where the hint text will be located, below or above the star.
     */
    private void setupStepViews(IconDrawable selectedIcon, IconDrawable unselectedIcon,
                                TextView minValueHintText, TextView maxValueHintText,
                                int hintLocation) {

        mStepViews = new StepButton[mNumOfSteps];
        for (int position = 0; position < mNumOfSteps; position++) {
            StepButton step = new StepButton(getContext(),
                    position,
                    selectedIcon,
                    unselectedIcon,
                    (position == 0 ? minValueHintText
                            : (position == mNumOfSteps - 1
                            ? maxValueHintText : null)),
                    hintLocation,
                    mNumOfSteps);
            mStepViews[position] = step;
            final String contentDescription = "Click to select rating '" + (position + 1)
                    + "' out of '" + mNumOfSteps + "'"
                    + (position == 0 ? minValueHintText.getText()
                    : (position == mNumOfSteps - 1
                    ? " " + maxValueHintText.getText() : ""))
                    + ".";
            InsertContentDescriptionManager.getInstance().setContentDescription(
                    mStepViews[position], contentDescription, contentDescription);

            step.setLayoutParams(
                    createDefaultLayoutParams(selectedIcon.getIntrinsicWidth(),
                            ViewGroup.LayoutParams.MATCH_PARENT));
            step.setOnClickListener(this);

            addView(step);
        }
    }

    /**
     * Creates a new {@link FlexboxLayout.LayoutParams} based on the stored default values in the
     * SharedPreferences.
     *
     * @param width  the width of the view.
     * @param height the height of the view.
     * @return a {@link FlexboxLayout.LayoutParams} instance
     */
    private static FlexboxLayout.LayoutParams createDefaultLayoutParams(int width, int height) {
        FlexboxLayout.LayoutParams lp =
                new FlexboxLayout.LayoutParams(width, height);
        lp.order = 1;
        lp.flexGrow = 1.0f;
        lp.flexShrink = 0.0f;
//        int flexBasisPercent = -1;
//        flexBasisPercent == -1 ? -1 : (float) (flexBasisPercent / 100.0);
        lp.flexBasisPercent = -1;
        return lp;
    }

    /**
     * Helper method that creates the {@link TextView} for the hint text.
     *
     * @param context       the context.
     * @param textSize      the text size in pixels.
     * @param textColor     the text color.
     * @param fontFamily    the font family.
     * @param textStyle     the text style.
     * @param valueHintText the text itself.
     * @return the {@link TextView} for the hint text.
     */
    private static TextView createStepTextView(Context context, int textSize, int textColor,
                                               String fontFamily, DynamicProperty textStyle,
                                               String valueHintText) {
        TextView valueText = new TextView(context);
        valueText.setText(valueHintText);
        InsertContentDescriptionManager.getInstance().setContentDescription(valueText,
                valueHintText, null);
        valueText.setTextColor(textColor);
        valueText.setSingleLine(false);
        valueText.setHorizontallyScrolling(false);
        valueText.setGravity(Gravity.CENTER);
        valueText.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);

        String receivedFontFamily = FontUtils.
                chooseAndSetFontFromArray(fontFamily, textStyle, valueText);
        if (receivedFontFamily == null) {
            FontUtils.checkIfExternalAndLoad(fontFamily, valueText);
        }

        return valueText;
    }

    @SuppressLint("ViewConstructor")
    private static final class StepButton extends LinearLayout {

        private static final int HINT_LOCATION_BELOW = 0;
        private static final int HINT_LOCATION_ABOVE = 1;

        private final int mPosition;
        private final int mNumberOfSteps;
        private final IconDrawable mSelectedIcon;
        private final IconDrawable mUnselectedIcon;

        @NonNull
        private final ImageView mStepIcon;

        @Nullable
        private final TextView mStepText;

        private boolean mChecked;

        StepButton(Context context,
                   int position,
                   @NonNull IconDrawable selectedIcon,
                   @NonNull IconDrawable unselectedIcon,
                   @Nullable TextView stepText,
                   int hintLocation,
                   int numberOfSteps) {

            super(context);
            setId(Utils.generateViewId());
            mPosition = position;
            mSelectedIcon = selectedIcon;
            mUnselectedIcon = unselectedIcon;
            mNumberOfSteps = numberOfSteps;


            mStepText = stepText;
            mStepIcon = new ImageView(context);
            mStepIcon.setImageDrawable(mUnselectedIcon);

            if (mStepText != null) {
                if (hintLocation == HINT_LOCATION_BELOW) {
                    addView(mStepIcon);
                    addView(mStepText);
                } else {
                    addView(mStepText);
                    addView(mStepIcon);
                }
            } else {
                addView(mStepIcon);
            }

            setOrientation(LinearLayout.VERTICAL);
            setGravity((hintLocation == HINT_LOCATION_BELOW
                    ? Gravity.TOP : Gravity.BOTTOM) | Gravity.CENTER_HORIZONTAL);
        }

        private static int hintLocation(String hintLocation) {
            return InsertIoRatingBar.HINT_LOCATION_BELOW.equals(hintLocation)
                    ? HINT_LOCATION_BELOW : HINT_LOCATION_ABOVE;
        }

        /**
         * Check or un-check the step.
         *
         * @param check whether the step is checked or not.
         */
        public synchronized void check(boolean check) {

            if (isChecked() == check) {
                return;
            }

            if (check) {
                mStepIcon.setImageDrawable(mSelectedIcon);
            } else {
                mStepIcon.setImageDrawable(mUnselectedIcon);
            }
            InsertContentDescriptionManager.getInstance().setContentDescription(mStepIcon,
                    "Click to change selection of rating to "
                            + (mPosition + 1) + " out of " + mNumberOfSteps, null);
            mChecked = check;
        }

        public synchronized boolean isChecked() {
            return mChecked;
        }
    }
}
