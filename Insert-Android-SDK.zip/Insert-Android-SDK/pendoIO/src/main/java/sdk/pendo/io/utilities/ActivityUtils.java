
package sdk.pendo.io.utilities;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.trello.rxlifecycle3.android.ActivityEvent;

import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.InsertPreparationManager;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;

import static sdk.pendo.io.models.GuideModel.DEFAULT_GUIDE_STEP_ID;


/**
 * Created by nirsegev on 3/28/16.
 */
public final class ActivityUtils {
    private ActivityUtils() {
    }

    @Nullable
    public static Activity getActivity(@Nullable Context context) {
        if (context == null) {
            return null;
        } else if (context instanceof Activity) {
            return (Activity) context;
        } else if (context instanceof ContextWrapper) {
            return getActivity(((ContextWrapper) context).getBaseContext());
        }
        return null;
    }

    /**
     * Starts an activity after receiving an activity which had lifecycles events such as onResume,
     * osStart, etc.. Unsubscribed automatically on onPause.
     *
     * IMPORTANT - The Activity observable is mandatory here to make sure we have an instance of a created activity,
     * because on app-launch/direct-links events there's a risk for a race condition where we'll try to
     * run an insert before we have the activity instance.
     *
     * @param intent
     */
    public static void startActivityFromBoundActivity(@NonNull final Intent intent, final String insertId, Integer stepIndex, Boolean isPreviewGuide) {
        Maybe<Activity> activityObservable = null;
        if (Pendo.getPendoOptions().getIsInitedFromActivity()) {
            activityObservable = Observable.just(ApplicationObservers.getInstance().getCurrentVisibleActivity()).firstElement();
        } else {
            activityObservable =
                    ApplicationObservers.getInstance()
                            .getActivitiesUntilLifecycleEventObservable(ActivityEvent.PAUSE)
                            .firstElement();
        }
        GuideModel guideModel;
        if (isPreviewGuide) {
            guideModel = SocketEventFSM.getInstance().getPreviewInsert();
        } else {
            guideModel = GuideManager.INSTANCE.getGuide(insertId);
        }
        assert guideModel != null;
        String firstGuideStepId = guideModel.getGuideStepId(stepIndex);
        if (!firstGuideStepId.equals(DEFAULT_GUIDE_STEP_ID) && InsertPreparationManager.getInstance().getHasImages(firstGuideStepId)) {
            final Maybe<Activity> obsrvActivity = activityObservable;
            final Maybe<Boolean> obsrvImages = InsertPreparationManager
                    .getInstance()
                    .getImagesLoadedAsObservable(
                            firstGuideStepId)
                    .filter(new Predicate<Boolean>() {
                        @Override
                        public boolean test(Boolean imagesLoaded) {
                            // Will continue if one of the two happens,
                            // Either the images have loaded or the time expired for tap on.
                            return imagesLoaded;

                        }
                    })
                    .firstElement();

            activityObservable = Maybe.zip(
                    obsrvActivity,
                    obsrvImages,
                    new BiFunction<Activity, Boolean, Activity>() {
                        @Override
                        public Activity apply(Activity activity, Boolean aBoolean) {
                            return activity;
                        }
                    });
        }

        //No images to load for the insert, just start once we have the activity.
        activityObservable.subscribe(
                InsertMaybeObserver.create(new Consumer<Activity>() {
                    @Override
                    public void accept(Activity activity) {
                        activity.startActivity(intent);
                    }
                }));
    }
    
    /**
     * Starts an activity immediately on current valid activity.
     *
     * @param intent
     */
    public static void startActivityImmediate(@NonNull final Intent intent) {
        Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
        if (currentActivity != null && !currentActivity.isFinishing()) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    if (!currentActivity.isDestroyed()) {
                        currentActivity.startActivity(intent);
                    }
                } else {
                    // isDestroyed api is not supported, just start the activity
                    currentActivity.startActivity(intent);
                }
            } catch (ActivityNotFoundException e) {
                currentActivity.startActivity(intent);
            }
        }
    }
}
