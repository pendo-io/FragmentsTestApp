package sdk.pendo.io.listeners.views;

import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;

import org.json.JSONObject;

import java.util.ArrayList;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.VisualAnimationManager;
import sdk.pendo.io.reactive.InsertOnErrorHandler;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.sdk.manager.AnalyticsManager;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.ViewHierarchyUtility;

/**
 * Custom {@link AdapterView.OnItemClickListener} that also holds reference to multiple
 * {@link AdapterView.OnItemClickListener} for a view.
 *
 * Created by assaf on 5/14/15.
 */ 
public final class InsertOnItemClickListener implements AdapterView.OnItemClickListener {

    private ArrayList<AdapterView.OnItemClickListener> mOnItemClickListener = new ArrayList<>();

    private Disposable mSubscription = null;

    public boolean addListener(AdapterView.OnItemClickListener onItemClickListener) {
        return mOnItemClickListener.add(onItemClickListener);
    }

    @Override
    public void onItemClick(final AdapterView<?> parent, final View view,
                            final int position, final long id) {

        InsertLogger.d("Got item clicked! position: '" + position + "', id: '" + id + "'.");
        String runningInsert = InsertAction.NO_ID;
        boolean activityDestroyed = true;
        try {
            JSONObject elementInfoRA = ViewHierarchyUtility.INSTANCE.createRAElementInfoJSON(view, ScreenManager.INSTANCE.getIncludeFeatureClickTexts(), ScreenManager.INSTANCE.getIncludeFeatureClickAccessibility());
            AnalyticsManager.INSTANCE.handleClickEvent(elementInfoRA);
            activityDestroyed = InsertsManager.isActivityDestroyed();
            if (!activityDestroyed) {
                runningInsert = ActivationManager.INSTANCE.handleClick(elementInfoRA);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

        String insertId = InsertAction.NO_ID;

        // Proceed with onClicks only if visual wasn't shown or our activity was destroyed.
        if (activityDestroyed || runningInsert.equals(InsertAction.NO_ID)) {
            for (AdapterView.OnItemClickListener onItemClickListener : mOnItemClickListener) {
                onItemClickListener.onItemClick(parent, view, position, id);
            }
        } else if (mSubscription == null) {
            try {
                // Listens to the ether to be notified when something wants to notify the listeners
                // that they need to do something because the insert was closed.
                // e.g. Like perform the button click.
                mSubscription = InsertCommandsEventBus.getInstance()
                        .getCommandEventBus()
                        .compose(VisualAnimationManager.waitForAnimationDoneAndNotifyClose(
                                insertId)).firstElement()
                        .subscribe(new Consumer<InsertCommand>() {
                            @Override
                            public void accept(InsertCommand insertCommand) throws Exception {
                                InsertLogger.d(insertCommand.toString());
                                for (AdapterView.OnItemClickListener onItemClickListener
                                        : mOnItemClickListener) {
                                    onItemClickListener.onItemClick(parent, view, position,
                                            id);
                                }
                                if (mSubscription != null) {
                                    mSubscription = null;
                                }
                            }
                        }, new InsertOnErrorHandler()
                        );
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
    }
}
