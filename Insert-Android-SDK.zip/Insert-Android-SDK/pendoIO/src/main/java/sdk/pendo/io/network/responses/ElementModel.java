package sdk.pendo.io.network.responses;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.events.InsertEvent.EventActions;

/**
 * Model representation for the Element model received from the backend.
 *
 * Created by assaf on 5/13/15.
 */
public final class ElementModel {

    @SerializedName("id")
    public int id;

    @SerializedName("screenId")
    public int screenId;

    @SerializedName("name")
    public String name;

    @SerializedName("configuration")
    public ElementConfigurationModel configuration;

    @SerializedName("events")
    @Nullable
    public List<InsertEvent> events;

    public static ElementModel copyElement(ElementModel elementModel, @Nullable String predicate) {

        ElementModel copiedElement = new ElementModel();

        copiedElement.id = elementModel.id;
        copiedElement.screenId = elementModel.screenId;
        copiedElement.name = elementModel.name;
        copiedElement.configuration = ElementConfigurationModel
                .copyElementConfigurationModel(elementModel.configuration);

        if (elementModel.events != null) {
            copiedElement.events = new ArrayList<>(elementModel.events);
        }

        return copiedElement;
    }

    @Override
    public int hashCode() {
        int hash;
        if (configuration.getIdentificationData() != null) {
           hash = 17 * id + configuration.getIdentificationData().hashCode();
        } else {
            hash = 17 * id;
        }
        return hash;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof ElementModel)) {
            return false;
        } else if (o == this) {
            return true;
        }

        final ElementModel model = (ElementModel) o;
        boolean equal = false;
        equal = id == model.id;
        if (equal && configuration.getIdentificationData() != null && model.configuration.getIdentificationData() != null) {
                equal =  configuration.getIdentificationData().equals(model.configuration.getIdentificationData());
        }
        return equal;
    }

    public boolean hasEventsForAction(@NonNull EventActions eventActions) {

        try {
            Utils.requireNonNull(events);
            for (InsertEvent event : events) {
                if (eventActions.equals(event.getConfiguration().getAction())) {
                    return true;
                }
            }
        } catch (Exception ignore) {
        }

        return false;
    }

    public boolean hasScreenStateSensitiveEvents() {

        try {
            Utils.requireNonNull(events);
            for (InsertEvent event : events) {
                if (event.getConfiguration().isStateSensitive() || EventActions.ELEMENT_VIEW.equals(event.getConfiguration().getAction())) {
                    return true;
                }
            }
        } catch (Exception ignore) {
        }

        return false;
    }
}
