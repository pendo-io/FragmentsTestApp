package sdk.pendo.io.exceptions

/**
 * Pendo's exception for dynamic view errors.
 *
 * Updated by Oren Dayan 21/1/20
 */
class DynamicViewException(message: String) : Exception(message)