package sdk.pendo.io.network.socketio.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.concurrent.atomic.AtomicBoolean;
import io.reactivex.functions.Consumer;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.cache.GuideCacheManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.InitModel;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.interfaces.RestAPI;
import sdk.pendo.io.network.socketio.SocketIOManager;
import sdk.pendo.io.network.socketio.configuration.IdentifyScreenData;
import sdk.pendo.io.network.socketio.configuration.IdentifyScreenDetails;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ScreenManager;
import sdk.pendo.io.utilities.InsertEndpointUtil;
import sdk.pendo.io.utilities.ResourceUtils;

import static sdk.pendo.io.network.socketio.SocketIOManager.VERSION_2;
import static sdk.pendo.io.network.socketio.SocketIOManager.VERSION_PARAM;

/**
 * Socket IO Utility class.
 *
 * Created by assaf on 4/27/15.
 */
public final class SocketIOUtils {
    public static final String SESSION_TOKEN = "sessionToken";
    public static final String PROPERTY_VERIFIED_ELEMENTS_MAP = "verifiedElements";
    public static final String PROPERTY_DEVICE_NAME = "deviceName";
    public static final String PROPERTY_IMAGE = "image";
    public static final String PEROPERTY_IMAGE_HEIGHT = "image_height";
    public static final String PROPERTY_IMAGE_WIDTH = "image_width";
    public static final String PROPERTY_TREE = "tree";
    public static final String PROPERTY_RA_DATA = "retroactiveScreenData";
    private static final String CONNECTION_ERROR = "Connection error";
    private static Uri sSOCKET_ENDPOINT = InsertEndpointUtil.INSTANCE.getProductionSocketUri();
    private static String sSId;
    private static AtomicBoolean sEnteredFromGateActivity = new AtomicBoolean(false);
    public static final String CONNECTION_ERROR_UNAUTHORIZED_ACCESSTOKEN = "Unauthorized. Invalid access token.";
    public static final String CONNECTION_ERROR_UNAUTHORIZED_SESSIONTOKEN = "Unauthorized. Invalid session token";
    private static final AtomicBoolean DO_ONCE = new AtomicBoolean(true);

    public SocketIOUtils() {

    }
    public static void addSuccesfulToResponse(JSONObject data, boolean isSuccessful) {
        try {
            data.put(SocketEvents.EVENT_SUCCESS, isSuccessful);
        } catch (JSONException ignore) {
        }

    }

    public static int getServerPort() {
        return sSOCKET_ENDPOINT.getPort();
    }

    public static void setCustomServerEnpdpoint(Uri endpoint) {
        if (endpoint != null) {
            sSOCKET_ENDPOINT = endpoint;
        }
    }

    /**
     * Setter for whether we entered from the gateActivity.
     * @param enteredFromGateActivity
     */
    public static void setEnteredFromGateActivity(boolean enteredFromGateActivity) {
        sEnteredFromGateActivity.set(enteredFromGateActivity);
    }

    /**
     * Gets whether we were started from gate activity.
     * This method gets and sets to false in order to reset its value.
     * @return whether we entered from gate activity
     */
    public static boolean getAndResetEnteredFromGateActivity() {
        return sEnteredFromGateActivity.getAndSet(false);
    }

    public static Uri getServerURI() {
        return sSOCKET_ENDPOINT;
    }

    public static void setSessionDetails(String dataString) {
        if (!TextUtils.isEmpty(dataString)) {
            Uri uri = Uri.parse(dataString);
            if (uri == null) {
                InsertLogger.e("Can't read QR code data");
            } else {
                String sessionToken = uri.getQueryParameter(SESSION_TOKEN);
                InsertLogger.d("got this sessionId: " + sessionToken);

                if (!TextUtils.isEmpty(sessionToken)) {
                    saveSessionToken(sessionToken);
                }

                // For testing if there are ip and port use those as the server url
                String sid = uri.getQueryParameter("sid");
                if (!TextUtils.isEmpty(sid)) {
                    sSId = sid;
                    InsertLogger.d("got this sid: " + sSId);
                }
            }
        }
    }

    public static void removeSessionDetails() {
        saveSessionToken(null);
    }

    public static String getSid() {
        return sSId;
    }

    private static final class Constants {

        protected static final String SOCKET_INFO = "socketInfo";
    }


    private static void saveSessionToken(String sessionToken) {
        InsertLogger.d("save session token: " + sessionToken);
        SharedPreferences.Editor editor = Pendo.getApplicationContext()
                .getSharedPreferences(Constants.SOCKET_INFO, Context.MODE_PRIVATE).edit();

        editor.putString(SocketIOManager.SOCKET_QUERY_PARAM_SESSION_TOKEN, sessionToken);
        editor.apply();
    }

    public static String getSessionToken() {
        return Pendo.getApplicationContext()
                .getSharedPreferences(Constants.SOCKET_INFO, Context.MODE_PRIVATE)
                .getString(SocketIOManager.SOCKET_QUERY_PARAM_SESSION_TOKEN, null);
    }

    public static void handleMarketerDeviceInit(boolean shouldSkipFirstToken, final boolean shouldExecuteSetup) {
        BackendApiManager.getInstance().startDeviceAuth();
        Consumer<String> consumer = new Consumer<String>() {

            @Override
            public void accept(String s) {
                if (!TextUtils.isEmpty(s)) {
                    InsertLogger.d("tries to connect to socket");
                    SocketIOManager.getInstance().connect();
                    
                    // If access token validity expired, no need to execute setup
                    // all over again, just new access token.
                    if (shouldExecuteSetup) {
                        BackendApiManager.getInstance().executeSetupFromBackend();
                    }
                }
            }
        };
        if (shouldSkipFirstToken) {
            RestAPI.getAccessTokenObservable().skip(1).subscribe(InsertObserver.create(consumer));
        } else {
            RestAPI.getAccessTokenObservable().firstElement().subscribe(InsertMaybeObserver.create(consumer));
        }
    }

    /**
     * Loads the pairing cache inserts (inserts that were cached during old pairing)
     * and try to run application launched inserts in case there are
     */
    public static void loadCachedPairingInsertsAndRun() {
        // When session token exists (it's a marketer device) we first load the pairing cached inserts
        // and try to launch an application launch insert
        InitModel initModel = GuideCacheManager.getInstance().loadCachedInsertAndEvents(GuideCacheManager.PAIRING_CACHE_FILE_NAME);
        if (initModel != null) {
            SocketEventFSM.updateGuideNames(initModel.getGuideList());
        }
    }

    public static boolean handleUnauthorizedConnectionIfNeeded(Object[] args) {
        if (args != null && args.length > 0 && args[0] instanceof String) {
            String errorString = (String) args[0];
            if (!TextUtils.isEmpty(errorString) && StringUtils.containsIgnoreCase(errorString, CONNECTION_ERROR_UNAUTHORIZED_ACCESSTOKEN)) {
                // Device received access token unauthorized, try to get a new access token and reconnect
                    SocketIOUtils.handleMarketerDeviceInit(true, false);
                    return true;
            } else if (!TextUtils.isEmpty(errorString) && StringUtils.containsIgnoreCase(errorString, CONNECTION_ERROR_UNAUTHORIZED_SESSIONTOKEN)) {
                // Device received session token unauthorized, delete the session token from storage and kill socket
                SocketIOUtils.removeSessionDetails();
                terminateAndKillSocket();
                BackendApiManager.getInstance().startBackendInitialization(true);
                return true;
            } else if (!TextUtils.isEmpty(errorString) && StringUtils.containsIgnoreCase(errorString, CONNECTION_ERROR)) {
                // In case the socket is not currently connected and we get a connection error,
                // we load the inserts from pairing cache
                if (!SocketEventFSM.isSocketConnected() && DO_ONCE.getAndSet(false)) {
                    SocketIOUtils.loadCachedPairingInsertsAndRun();
                }
            }
        }
        return false;
    }

    private static void terminateAndKillSocket() {
        SocketIOManager.getInstance().terminateSession();
        SocketIOManager.getInstance().disconnect();
        SocketIOManager.getInstance().killSocket();
    }

    /**
     * Utility method for wrapping the JSON object with another JSON like so:
     * <pre>
     * {
     *   "data" : data
     * }
     * </pre>
     *
     * @param data The data to wrap.
     * @return The wrapped data.
     * @throws JSONException
     */
    private static JSONObject wrapData(JSONObject data) throws JSONException {

        JSONObject retVal = new JSONObject();
        retVal.put("data", data);
        return retVal;
    }

    /**
     * Emits the command/event to the socket , adds the initiatorId and wraps the json data in "data": root
     * @param command the command to send
     * @param data the addition data json to send
     */
    public static void emitToSocket(String command, JSONObject data) {
        try {
            // FIXME NOT TO BE left here after we have a new mock socket server: Adding the sId for testing purpose
            JSONObject jsonObject = SocketIOUtils
                    .wrapData(data);
            if (!TextUtils.isEmpty(sSId)) {
             jsonObject.put("sid", sSId);
            }
            jsonObject.put(VERSION_PARAM, VERSION_2); // notifying backend this is the new pairing mode
            SocketIOManager.getInstance().emit(command, jsonObject);
            InsertLogger.d("SocketIO device sent: " + command);
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    public static void sendCapturedScreen(
            SocketEvents eventToSend,
            JSONArray viewHierarchy,
            Bitmap bitmap,
            JSONArray oldStateViewNewStateViewMap)
            throws JSONException {

        JSONObject data = generateScreenCaptureData(viewHierarchy, bitmap, oldStateViewNewStateViewMap);
        SocketIOUtils.emitToSocket(eventToSend.getCommand(), data);
    }

    @NonNull
    private static JSONObject generateScreenCaptureData(JSONArray viewHierarchy,
                                                        Bitmap bitmap,
                                                        JSONArray oldStateViewNewStateViewMap
    ) throws JSONException {
        JSONObject data = new JSONObject();
        data.put(PROPERTY_DEVICE_NAME, Build.MANUFACTURER + " - " + Build.MODEL);
        data.put(PROPERTY_IMAGE, ResourceUtils.getBase64StringFromBitmap(bitmap));
        data.put(PEROPERTY_IMAGE_HEIGHT, bitmap.getHeight());
        data.put(PROPERTY_IMAGE_WIDTH, bitmap.getWidth());
        data.put(PROPERTY_TREE, viewHierarchy);
        data.put(PROPERTY_RA_DATA, ScreenManager.INSTANCE.getCapturedData());
        if (oldStateViewNewStateViewMap != null) {
            data.put(PROPERTY_VERIFIED_ELEMENTS_MAP, oldStateViewNewStateViewMap);
            InsertLogger.d(PROPERTY_VERIFIED_ELEMENTS_MAP + oldStateViewNewStateViewMap.toString());
        }
        return data;
    }

    public static IdentifyScreenData fetchOldScreenDetails(String oldScreenJson) {
        IdentifyScreenDetails identifyScreenDetails = null;
        if (oldScreenJson != null) {
            InsertLogger.d("socket recieved screen to identify: " + oldScreenJson);
            identifyScreenDetails = Pendo.GSON.fromJson(oldScreenJson,
                    IdentifyScreenDetails.class);
        }
        if (SocketEventFSM.getInstance().isIdentifyMode()) {
            if (identifyScreenDetails == null){
                InsertLogger.d("socket got non valid screen details to identify");
            } else {
                // sending the capture screen compared with the old state views
                return identifyScreenDetails.data;
            }
        }
        return null;
    }

}
