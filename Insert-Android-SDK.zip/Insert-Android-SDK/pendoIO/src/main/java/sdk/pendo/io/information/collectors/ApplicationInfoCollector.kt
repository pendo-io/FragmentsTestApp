package sdk.pendo.io.information.collectors

import org.json.JSONObject
import sdk.pendo.io.information.collectors.application.ApplicationInfo
import sdk.pendo.io.information.collectors.application.Permissions
import sdk.pendo.io.utilities.add

/**
 * Utility class to generate information about the application.

 * Created by assaf on 4/2/15.
 */
internal class ApplicationInfoCollector : Collector() {

    // All active application collectors:
    private val mApplicationInfoCollectors = arrayOf(
            Permissions(),
            ApplicationInfo())
    //            new Activities(),
    //            new ContentProviders(),
    //            new Receivers(),
    //            new Services(),

    override fun collectData(json: JSONObject) {
        json.add("app_info", applicationInfo)
    }

    private // Iterate over all the collectors and collect their data.
    val applicationInfo: JSONObject
        get() {

            val info = JSONObject()
            for (collector in mApplicationInfoCollectors) {
                collector.addInformation(info)
            }

            return info
        }

    private object Holder {
        val INSTANCE = ApplicationInfoCollector()
    }

    companion object {
        val instance: ApplicationInfoCollector by lazy { Holder.INSTANCE }
    }
}
