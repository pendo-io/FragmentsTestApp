package sdk.pendo.io.logging;

import android.support.annotation.NonNull;
import android.support.annotation.StringDef;
import android.util.Log;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.utilities.ReactiveUtils;

import static java.util.Collections.unmodifiableList;

/** Pendo's logging based on Timber. */
@SuppressWarnings("unused")
public final class InsertLogger {

    static final int MAX_LOG_LENGTH = 4000;
    static final int CALL_STACK_INDEX = 7;
    static final Pattern ANONYMOUS_CLASS = Pattern.compile("(\\$\\d+)+$");

    static final String VERBOSE = "V";
    static final String INFO = "I";
    static final String DEBUG = "D";
    static final String WARNING = "W";
    static final String ERROR = "E";
    static final String ASSERT = "A";

    @StringDef({VERBOSE, INFO, DEBUG, WARNING, ERROR, ASSERT})
    @Retention(RetentionPolicy.SOURCE)
    public @interface LogLevel { }

    /** Log a verbose message with optional format args. */
    public static void v(@NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.v(message, args);
            }
        });
    }

    /** Log a verbose exception and a message with optional format args. */
    public static void v(final Throwable t, @NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.v(t, message, args);
            }
        });
    }

    /** Log a verbose exception. */
    public static void v(final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.v(t);
            }
        });
    }

    /** Log a debug message with optional format args. */
    public static void d(@NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.d(message, args);
            }
        });
    }

    /** Log a debug exception and a message with optional format args. */
    public static void d(final Throwable t, final @NonNull String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.d(t, message, args);
            }
        });
    }

    /** Log a debug exception. */
    public static void d(final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.d(t);
            }
        });
    }


    /** Log an info message with optional format args. */
    public static void i(@NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.i(message, args);
            }
        });
    }

    /** Log an info exception and a message with optional format args. */
    public static void i(final Throwable t, @NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.i(t, message, args);
            }
        });
    }

    /** Log an info exception. */
    public static void i(final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.i(t);
            }
        });
    }

    /** Log a warning message with optional format args. */
    public static void w(@NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.w(message, args);
            }
        });
    }


    /** Log a warning exception and a message with optional format args. */
    public static void w(final Throwable t, @NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.w(t, message, args);
            }
        });
    }

    /** Log a warning exception. */
    public static void w(final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.w(t);
            }
        });
    }

    /** Log an error message with optional format args. */
    public static void e(@NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.e(message, args);
            }
        });
    }


    /** Log an error exception and a message with optional format args. */
    public static void e(final Throwable t, final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.e(t, message, args);
            }
        });
    }

    /** Log an error exception. */
    public static void e(final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.e(t);
            }
        });
    }

    /** Log an assert message with optional format args. */
    public static void wtf(@NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.wtf(message, args);
            }
        });
    }


    /** Log an assert exception and a message with optional format args. */
    public static void wtf(final Throwable t, @NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.wtf(t, message, args);
            }
        });
    }

    /** Log an assert exception. */
    public static void wtf(final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.wtf(t);
            }
        });
    }

    /** Log at {@code priority} a message with optional format args. */
    public static void log(final int priority, @NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.log(priority, message, args);
            }
        });
    }

    /** Log at {@code priority} an exception and a message with optional format args. */
    public static void log(final int priority, final Throwable t, @NonNull final String message, final Object... args) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.log(priority, t, message, args);
            }
        });
    }

    /** Log at {@code priority} an exception. */
    public static void log(final int priority, final Throwable t) {
        ReactiveUtils.schedule(new ApiAction() {
            @Override
            protected void execute() {
                TREE_OF_SOULS.log(priority, t);
            }
        });
    }

    /**
     * A view into InsertLogger's planted trees as a tree itself.
     * This can be used for injecting a logger instance
     * rather than using static methods or to facilitate testing.
     */
    public static Tree asTree() {
        return TREE_OF_SOULS;
    }

    /** Set a one-time tag for use on the next logging call. */
    public static Tree tag(String tag) {
        Tree[] forest = sForestAsArray;
        //noinspection ForLoopReplaceableByForEach
        for (int i = 0, count = forest.length; i < count; i++) {
            forest[i].mExplicitTag.set(tag);
        }
        return TREE_OF_SOULS;
    }

    /** Add a new logging tree. */
    public static void plant(Tree tree) {
        if (tree == null) {
            throw new NullPointerException("tree == null");
        }
        if (tree == TREE_OF_SOULS) {
            throw new IllegalArgumentException("Cannot plant InsertLogger into itself.");
        }
        synchronized (FOREST) {
            FOREST.add(tree);
            sForestAsArray = FOREST.toArray(new Tree[FOREST.size()]);
        }
    }

    /** Adds new logging trees. */
    public static void plant(Tree... trees) {
        if (trees == null) {
            throw new NullPointerException("trees == null");
        }
        for (Tree tree : trees) {
            if (tree == null) {
                throw new NullPointerException("trees contains null");
            }
            if (tree == TREE_OF_SOULS) {
                throw new IllegalArgumentException("Cannot plant InsertLogger into itself.");
            }
        }
        synchronized (FOREST) {
            Collections.addAll(FOREST, trees);
            sForestAsArray = FOREST.toArray(new Tree[FOREST.size()]);
        }
    }

    /** Remove a planted tree. */
    public static void uproot(Tree tree) {
        synchronized (FOREST) {
            if (!FOREST.remove(tree)) {
                throw new IllegalArgumentException("Cannot uproot tree which is not planted: "
                                                           + tree);
            }
            sForestAsArray = FOREST.toArray(new Tree[FOREST.size()]);
        }
    }

    /** Remove all planted trees. */
    public static void uprootAll() {
        synchronized (FOREST) {
            FOREST.clear();
            sForestAsArray = TREE_ARRAY_EMPTY;
        }
    }

    /** Return a copy of all planted {@linkplain Tree trees}. */
    public static List<Tree> forest() {
        synchronized (FOREST) {
            return unmodifiableList(new ArrayList<>(FOREST));
        }
    }

    public static int treeCount() {
        synchronized (FOREST) {
            return FOREST.size();
        }
    }

    @LogLevel
    private static String logLevelIntToString(int level) throws IllegalArgumentException {
        switch (level) {
            case Log.VERBOSE:
                return VERBOSE;
            case Log.DEBUG:
                return DEBUG;
            case Log.INFO:
                return INFO;
            case Log.WARN:
                return WARNING;
            case Log.ERROR:
                return ERROR;
            case Log.ASSERT:
                return ASSERT;
        }

        throw new IllegalArgumentException("Level: " + level + " is not supported");
    }

    private static final Tree[] TREE_ARRAY_EMPTY = new Tree[0];
    // Both fields guarded by 'FOREST'.
    private static final List<Tree> FOREST = new ArrayList<>();
    private static volatile Tree[] sForestAsArray = TREE_ARRAY_EMPTY;

    /** A {@link Tree} that delegates to all planted trees in the {@linkplain #FOREST forest}. */
    @SuppressWarnings("ForLoopReplaceableByForEach")
    private static final Tree TREE_OF_SOULS = new Tree() {
        @Override public void v(String message, Object... args) {
            logger(VERBOSE, message, args);
        }

        @Override public void v(Throwable t, String message, Object... args) {
            logger(VERBOSE, t, message, args);
        }

        @Override public void v(Throwable t) {
            logger(VERBOSE, t);
        }

        @Override public void d(String message, Object... args) {
            logger(DEBUG, message, args);
        }

        @Override public void d(Throwable t, String message, Object... args) {
            logger(DEBUG, t, message, args);
        }

        @Override public void d(Throwable t) {
            logger(DEBUG, t);
        }

        @Override public void i(String message, Object... args) {
            logger(INFO, message, args);
        }

        @Override public void i(Throwable t, String message, Object... args) {
            logger(INFO, t, message, args);
        }

        @Override public void i(Throwable t) {
            logger(INFO, t);
        }

        @Override public void w(String message, Object... args) {
            logger(WARNING, message, args);
        }

        @Override public void w(Throwable t, String message, Object... args) {
            logger(WARNING, t, message, args);
        }

        @Override public void w(Throwable t) {
            logger(WARNING, t);
        }

        @Override public void e(String message, Object... args) {
            logger(ERROR, message, args);
        }

        @Override public void e(Throwable t, String message, Object... args) {
            logger(ERROR, t, message, args);
        }

        @Override public void e(Throwable t) {
            logger(ERROR, t);
        }

        @Override public void wtf(String message, Object... args) {
            logger(ASSERT, message, args);
        }

        @Override public void wtf(Throwable t, String message, Object... args) {
            logger(ASSERT, t, message, args);
        }

        @Override public void wtf(Throwable t) {
            logger(ASSERT, t);
        }

        @Override public void log(int priority, String message, Object... args) {
            try {
                final String level = logLevelIntToString(priority);
                logger(level, message, args);
            } catch (Exception ignore) {
            }
        }

        @Override public void log(int priority, Throwable t, String message, Object... args) {
            try {
                final String level = logLevelIntToString(priority);
                logger(level, t, message, args);
            } catch (Exception ignore) {
            }
        }

        @Override public void log(int priority, Throwable t) {
            try {
                final String level = logLevelIntToString(priority);
                logger(level, t);
            } catch (Exception ignore) {
            }
        }

        private void logger(@LogLevel String level, String message, Object... args) {
            Tree[] forest = sForestAsArray;
            for (int i = 0, count = forest.length; i < count; i++) {
                switch (level) {
                    case VERBOSE:
                        forest[i].v(message, args);
                        break;
                    case INFO:
                        forest[i].i(message, args);
                        break;
                    case DEBUG:
                        forest[i].d(message, args);
                        break;
                    case WARNING:
                        forest[i].w(message, args);
                        break;
                    case ERROR:
                        forest[i].e(message, args);
                        break;
                    case ASSERT:
                        forest[i].wtf(message, args);
                        break;
                    default:
                        // TODO: 8/29/16 Throw?
                        break;
                }
            }
        }

        private void logger(@LogLevel String level, Throwable t) {
            Tree[] forest = sForestAsArray;
            for (int i = 0, count = forest.length; i < count; i++) {
                switch (level) {
                    case VERBOSE:
                        forest[i].v(t);
                        break;
                    case INFO:
                        forest[i].i(t);
                        break;
                    case DEBUG:
                        forest[i].d(t);
                        break;
                    case WARNING:
                        forest[i].w(t);
                        break;
                    case ERROR:
                        forest[i].e(t);
                        break;
                    case ASSERT:
                        forest[i].wtf(t);
                        break;
                    default:
                        // TODO: 8/29/16 Throw?
                        break;
                }
            }
        }

        private void logger(@LogLevel String level, Throwable t, String message, Object... args) {
            Tree[] forest = sForestAsArray;
            for (int i = 0, count = forest.length; i < count; i++) {
                switch (level) {
                    case VERBOSE:
                        forest[i].v(t, message, args);
                        break;
                    case INFO:
                        forest[i].i(t, message, args);
                        break;
                    case DEBUG:
                        forest[i].d(t, message, args);
                        break;
                    case WARNING:
                        forest[i].w(t, message, args);
                        break;
                    case ERROR:
                        forest[i].e(t, message, args);
                        break;
                    case ASSERT:
                        forest[i].wtf(t, message, args);
                        break;
                    default:
                        // TODO: 8/29/16 Throw?
                        break;
                }
            }
        }

        @Override protected void log(int priority, String tag, String message, Throwable t) {
            throw new AssertionError("Missing override for log method.");
        }
    };

    private InsertLogger() {
        throw new AssertionError("No instances.");
    }

    /** A facade for handling logging calls.
     * Install instances via {@link #plant InsertLogger.plant()}. */
    @SuppressWarnings("CheckStyle")
    public abstract static class Tree {
        public static final int INITIAL_STRING_WRITER_SIZE = 256;
        private final ThreadLocal<String> mExplicitTag = new ThreadLocal<>();

        String getTag() {
            String tag = mExplicitTag.get();
            if (tag != null) {
                mExplicitTag.remove();
            }
            return tag;
        }

        /** Log a verbose message with optional format args. */
        public void v(String message, Object... args) {
            prepareLog(Log.VERBOSE, null, message, args);
        }

        /** Log a verbose exception and a message with optional format args. */
        public void v(Throwable t, String message, Object... args) {
            prepareLog(Log.VERBOSE, t, message, args);
        }

        /** Log a verbose exception. */
        public void v(Throwable t) {
            prepareLog(Log.VERBOSE, t, null);
        }

        /** Log a debug message with optional format args. */
        public void d(String message, Object... args) {
            prepareLog(Log.DEBUG, null, message, args);
        }

        /** Log a debug exception and a message with optional format args. */
        public void d(Throwable t, String message, Object... args) {
            prepareLog(Log.DEBUG, t, message, args);
        }

        /** Log a debug exception. */
        public void d(Throwable t) {
            prepareLog(Log.DEBUG, t, null);
        }

        /** Log an info message with optional format args. */
        public void i(String message, Object... args) {
            prepareLog(Log.INFO, null, message, args);
        }

        /** Log an info exception and a message with optional format args. */
        public void i(Throwable t, String message, Object... args) {
            prepareLog(Log.INFO, t, message, args);
        }

        /** Log an info exception. */
        public void i(Throwable t) {
            prepareLog(Log.INFO, t, null);
        }

        /** Log a warning message with optional format args. */
        public void w(String message, Object... args) {
            prepareLog(Log.WARN, null, message, args);
        }

        /** Log a warning exception and a message with optional format args. */
        public void w(Throwable t, String message, Object... args) {
            prepareLog(Log.WARN, t, message, args);
        }

        /** Log a warning exception. */
        public void w(Throwable t) {
            prepareLog(Log.WARN, t, null);
        }

        /** Log an error message with optional format args. */
        public void e(String message, Object... args) {
            prepareLog(Log.ERROR, null, message, args);
        }

        /** Log an error exception and a message with optional format args. */
        public void e(Throwable t, String message, Object... args) {
            prepareLog(Log.ERROR, t, message, args);
        }

        /** Log an error exception. */
        public void e(Throwable t) {
            prepareLog(Log.ERROR, t, null);
        }

        /** Log an assert message with optional format args. */
        public void wtf(String message, Object... args) {
            prepareLog(Log.ASSERT, null, message, args);
        }

        /** Log an assert exception and a message with optional format args. */
        public void wtf(Throwable t, String message, Object... args) {
            prepareLog(Log.ASSERT, t, message, args);
        }

        /** Log an assert exception. */
        public void wtf(Throwable t) {
            prepareLog(Log.ASSERT, t, null);
        }

        /** Log at {@code priority} a message with optional format args. */
        public void log(int priority, String message, Object... args) {
            prepareLog(priority, null, message, args);
        }

        /** Log at {@code priority} an exception and a message with optional format args. */
        public void log(int priority, Throwable t, String message, Object... args) {
            prepareLog(priority, t, message, args);
        }

        /** Log at {@code priority} an exception. */
        public void log(int priority, Throwable t) {
            prepareLog(priority, t, null);
        }

        /** Return whether a message at {@code priority} should be logged. */
        protected boolean isLoggable(int priority) {

            // TODO: 8/28/16 Add ability to set log level in manifest.
            return true;
        }

        private void prepareLog(int priority, Throwable t, String message, Object... args) {
            // Consume tag even when message is not loggable
            // so that next message is correctly tagged.
            String tag = getTag();

            if (!isLoggable(priority)) {
                return;
            }
            if (message != null && message.length() == 0) {
                message = null;
            }
            if (message == null) {
                if (t == null) {
                    return; // Swallow message if it's null and there's no throwable.
                }
                message = getStackTraceString(t);
            } else {
                if (args.length > 0) {
                    message = String.format(message, args);
                }
                if (t != null) {
                    message += "\n" + getStackTraceString(t);
                }
            }

            log(priority, tag, message, t);
        }

        private String getStackTraceString(Throwable t) {
            // Don't replace this with Log.getStackTraceString() - it hides
            // UnknownHostException, which is not what we want.
            StringWriter sw = new StringWriter(INITIAL_STRING_WRITER_SIZE);
            PrintWriter pw = new PrintWriter(sw, false);
            t.printStackTrace(pw);
            pw.flush();
            return sw.toString();
        }

        /**
         * Write a log message to its destination. Called for all level-specific methods by default.
         *
         * @param priority Log level. See {@link Log} for constants.
         * @param tag Explicit or inferred tag. May be {@code null}.
         * @param message Formatted log message. May be {@code null},
         *        but then {@code t} will not be.
         * @param t Accompanying exceptions. May be {@code null},
         *        but then {@code message} will not be.
         */
        protected abstract void log(int priority, String tag, String message, Throwable t);
    }

    /** A {@link Tree Tree} for debug builds.
     * Automatically infers the tag from the calling class. */
    @SuppressWarnings("CheckStyle")
    public static class DebugTree extends Tree {

        /**
         * Extract the tag which should be used for the message from the {@code element}.
         * By default this will use the class name without any anonymous class suffixes
         * (e.g., {@code Foo$1} becomes {@code Foo}).
         * <p>
         * Note: This will not be called if a {@linkplain #tag(String) manual tag} was specified.
         */
        protected String createStackElementTag(StackTraceElement element) {
            String tag = element.getClassName();
            Matcher m = ANONYMOUS_CLASS.matcher(tag);
            if (m.find()) {
                tag = m.replaceAll("");
            }
            return tag.substring(tag.lastIndexOf('.') + 1);
        }

        @Override
        final String getTag() {
            String tag = super.getTag();
            if (tag != null) {
                return tag;
            }

            // DO NOT switch this to Thread.getCurrentThread().getStackTrace(). The test will pass
            // because Robolectric runs them on the JVM but on Android the elements are different.
            StackTraceElement[] stackTrace = new Throwable().getStackTrace();
            if (stackTrace.length <= CALL_STACK_INDEX) {
                throw new IllegalStateException(
                        "Synthetic stacktrace didn't have enough elements:"
                                + " are you using proguard?");
            }
            return createStackElementTag(stackTrace[CALL_STACK_INDEX]);
        }

        /**
         * Break up {@code message} into maximum-length chunks (if needed) and send to either
         * {@link Log#println(int, String, String) Log.println()} or
         * {@link Log#wtf(String, String) Log.wtf()} for logging.
         *
         * {@inheritDoc}
         */
        @Override
        protected void log(int priority, String tag, String message, Throwable t) {
            if (message.length() < MAX_LOG_LENGTH) {
                if (priority == Log.ASSERT) {
                    Log.wtf(tag, message);
                } else {
                    Log.println(priority, tag, message);
                }
                return;
            }

            // Split by line, then ensure each line can fit into Log's maximum length.
            for (int i = 0, length = message.length(); i < length; i++) {
                int newline = message.indexOf('\n', i);
                newline = newline != -1 ? newline : length;
                do {
                    int end = Math.min(newline, i + MAX_LOG_LENGTH);
                    String part = message.substring(i, end);
                    if (priority == Log.ASSERT) {
                        Log.wtf(tag, part);
                    } else {
                        Log.println(priority, tag, part);
                    }
                    i = end;
                } while (i < newline);
            }
        }
    }
}
