package sdk.pendo.io.information.collectors.application

import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.ResourceUtils
import sdk.pendo.io.utilities.add

/**
 * Collect information about the application's services.

 * Created by assaf on 4/14/15.
 */
internal class Services : Collector() {

    override fun collectData(json: JSONObject) {

        // Add the application's services.
        addServices(json)
    }

    /**
     * Adds information about the application's services to the JSON.

     * @param info The JSON to receiver the information about the application's services.
     */
    private fun addServices(info: JSONObject) {
        try {
            val appServices = application!!.packageManager.getPackageInfo(packageName,
                    PackageManager.GET_SERVICES)

            val services = appServices.services
            if (services != null) {
                val serviceArray = JSONArray()

                for (service in services) {
                    val serviceJSON = JSONObject()
                    serviceJSON.add("service_enabled", service.enabled)
                    serviceJSON.add("service_exported", service.exported)
                    serviceJSON.add("service_icon", service.icon)
                    serviceJSON.add("service_label", ResourceUtils.getStringFromResource(service.labelRes) ?: "??")
                    serviceJSON.add("service_name", service.name)
                    serviceJSON.add("service_permission", service.permission)
                    serviceJSON.add("service_process", service.processName)

                    val flags = service.flags
                    val flagsArray = JSONArray()

                    if (0 != flags and ServiceInfo.FLAG_STOP_WITH_TASK) {
                        flagsArray.add("FLAG_STOP_WITH_TASK")
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        if (0 != flags and ServiceInfo.FLAG_ISOLATED_PROCESS) {
                            flagsArray.add("FLAG_STOP_WITH_TASK")
                        }
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                        if (0 != flags and ServiceInfo.FLAG_SINGLE_USER) {
                            flagsArray.add("FLAG_STOP_WITH_TASK")
                        }
                    }

                    serviceJSON.add("service_flags", flagsArray)

                    serviceArray.add(serviceJSON)
                }

                info.add("services", serviceArray)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            InsertLogger.e(e, "Failed to get services.")
        }

    }
}
