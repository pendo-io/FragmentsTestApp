@file:JvmName("RAUtils")

package sdk.pendo.io.utilities

import android.annotation.SuppressLint
import android.support.v4.app.Fragment
import java.util.AbstractCollection as UtilAbstractCollection

/**
 * @return true whether this fragment is currently visible. False otherwise.
 */
@SuppressLint("RestrictedApi")
internal fun Fragment.isPendoVisible(): Boolean {
	return this.isVisible && this.isMenuVisible && !this.isDetached && !this.isRemoving
}

/**
 * Takes a "regular" (legacy) predicate and transforms it to RAPredicate.
 * Currently, it just truncates the actual text part from it.
 *
 * @param predicate The predicate we want to transform to RAPredicate.
 *
 * @return the RAPredicate after the transformation.
 */
fun toRAPredicate(predicate: String): String {
	val startIndexOfText = predicate.indexOf(PredicateUtils.TEXT_PREFIX)
	return if (startIndexOfText == -1) predicate else predicate.substring(0, startIndexOfText)
}
