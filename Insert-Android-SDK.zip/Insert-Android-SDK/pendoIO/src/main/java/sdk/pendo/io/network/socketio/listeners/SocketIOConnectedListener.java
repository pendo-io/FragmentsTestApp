package sdk.pendo.io.network.socketio.listeners;

import org.json.JSONObject;
import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

public final class SocketIOConnectedListener implements Emitter.Listener {

    public static final String DUMMY_SOCKET_EVENT = "dummySocketEvent";

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got Connected");
        SocketIOUtils.emitToSocket(DUMMY_SOCKET_EVENT, new JSONObject());
        SocketEventFSM.getInstance().updateSocketConnectedObservable(true);
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_SOCKET_CONNECTED, args);
    }
}
