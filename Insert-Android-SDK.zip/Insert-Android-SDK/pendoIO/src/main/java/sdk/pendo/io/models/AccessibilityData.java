package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;
import android.util.Base64;

import java.nio.charset.Charset;

import sdk.pendo.io.actions.StepSeenManager;
import sdk.pendo.io.utilities.PredicateUtils;
import sdk.pendo.io.utilities.Utils;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Accessibility data of a view, used for views identification (element info).
 *
 * Created by Barak on 9/12/18.
 */
public final class AccessibilityData {

    public static final String ACCESSIBILITY_CONTENT_DESCRIPTION = "label";

    @SerializedName(ACCESSIBILITY_CONTENT_DESCRIPTION)
    private String contentDescription;

    public String getContentDescription() {
        return contentDescription;
    }

    public void setContentDescription(String contentDescription) {
        this.contentDescription = contentDescription;
    }

    /**
     * @param contentDescription content description of the view.
     */
    public AccessibilityData(String contentDescription) {
        if (contentDescription != null && contentDescription.length() > 0) {
            this.contentDescription = Base64.encodeToString(Utils.truncateStringToLength(contentDescription).toString().getBytes(Charset.forName(ENCODING_UTF_8)), PredicateUtils.BASE64_FLAGS);
        }
    }
}
