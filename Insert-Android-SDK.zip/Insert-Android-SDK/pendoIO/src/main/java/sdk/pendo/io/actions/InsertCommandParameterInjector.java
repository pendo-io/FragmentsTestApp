package sdk.pendo.io.actions;

import com.google.gson.JsonArray;

import java.util.ArrayList;
import java.util.List;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.StepContentModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.utilities.PersistenceUtils;
import sdk.pendo.io.utilities.ReactiveUtils;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_DISMISSED_STATE_CHANGED;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_DISMISSED_TIMEOUT;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_DISMISSED_USER_ACTION;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_DISPLAYED;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_NOT_DISPLAYED_NO_CONNECTIVITY;
import static sdk.pendo.io.actions.InsertCommandEventType.AnalyticsEventType.GUIDE_NOT_DISPLAYED_OUT_OF_CAPPING;
import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CAPPING;
import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONNECTIVITY;
import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;

/**
 * Created by tomerlevinson on 9/28/16.
 * Used to inject parameters into actions & handle insert analytics events.
 */
public final class InsertCommandParameterInjector {

    private static volatile InsertCommandParameterInjector INSTANCE;

    private InsertCommandParameterInjector() {
    }

    public static synchronized InsertCommandParameterInjector getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InsertCommandParameterInjector();
        }
        return INSTANCE;
    }

    public void addGenericParamsInjectAndDispatch(
            final GuideModel guideModel,
            final String analyticsActionEventType,
            final List<InsertCommandsEventBus.Parameter> specificInjectionParameters) {

        final JsonArray stepGuideModel = guideModel.getSteps();

        if (stepGuideModel != null && GuideManager.INSTANCE.getGuideActions() != null && SocketEventFSM.getInstance().isNotPairedMode()) {
            ReactiveUtils.schedule(new ApiAction() {
                @Override
                protected void execute() {
                    List<InsertCommand> insertCommandList = GuideManager.INSTANCE.getGuideActions();
                    ArrayList<InsertCommand> chosenCommandsByActionEventType = new ArrayList<>();
                    // Check which commands are suitable for the specific event type we received.
                    // And put them inside the chosenCommandsByActionEventType array.
                    for (InsertCommand insertCommand : insertCommandList) {
                        if (insertCommand.getEventType().eventType.equals(analyticsActionEventType)) {
                            chosenCommandsByActionEventType.add(insertCommand);
                        }
                    }
                    for (InsertCommand chosenCommand : chosenCommandsByActionEventType) {

                        // 1) Add insertContext to each command.
                        JavascriptRunner.InsertContext insertContext = new JavascriptRunner.InsertContext(guideModel.getGuideId());
                        // 2) Add generic params to insertContext. (Maybe extract list of needed params for specific action from special parameter for it?)
                        //      2.1) Create control group JSON.
                        insertContext.set(AnalyticsProperties.GUIDE_ID, guideModel.getGuideId());
                        StepContentModel stepContentModel = guideModel.getStepContentModel(StepSeenManager.getInstance().getCurrentStepIndex());
                        if (stepContentModel != null && stepContentModel.getGuideStepId() != null) {
                            insertContext.set(AnalyticsProperties.GUIDE_STEP_ID, stepContentModel.getGuideStepId());
                        }
                        VisualInsertBase visualInsert = VisualInsertManager.getInstance().getVisualInsert(guideModel.getGuideId());
                        if (visualInsert != null) {
                            String guideActivatedBy = visualInsert.getActivatedBy();
                            if (guideActivatedBy != null) {
                                insertContext.set(AnalyticsProperties.SEEN_REASON, guideActivatedBy);
                            }
                        }
                        insertContext.set(AnalyticsProperties.ACCOUNT_ID_CAMELCASE, Pendo.getAccountId());
                        insertContext.set(AnalyticsProperties.VISITOR_ID_CAMELCASE, Pendo.getVisitorId());
                        // 3) Add specific params to insertContext.
                        if (specificInjectionParameters != null) {
                            for (InsertCommandsEventBus.Parameter specificParameter : specificInjectionParameters) {
                                insertContext.set(specificParameter.getParameterName(), specificParameter.getParameterValue());
                            }
                        }
                        // 4) Set context for specific commands.
                        chosenCommand.setContext(insertContext);
                    }
                    // Dispatch the commands
                    InsertCommandDispatcher.getInstance().dispatchCommands(chosenCommandsByActionEventType,
                            InsertCommandEventType.getEventType(analyticsActionEventType), false);
                }
            });
        }
    }

    /**
     * Handler for no connectivity analytics.
     *
     * @param insertId
     * @param insertEvent
     */
    public void handleInsertNoConnectivityAnalytics(String insertId) {
        GuideModel guideModel = GuideManager.INSTANCE.getGuide(insertId);
        ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.NOT_DISPLAYED_REASON,
                TYPE_STRING,
                ERROR_REASON_CONNECTIVITY.getValue()));
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.REASON,
                TYPE_STRING,
                ERROR_REASON_CONNECTIVITY.getValue()));
        if (VisualInsertManager.getInstance().getVisualInsert(insertId) != null) {
            specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.SEEN_REASON,
                    TYPE_STRING,
                    VisualInsertManager.getInstance().getVisualInsert(insertId).getActivatedBy()));
        }
        if (guideModel != null) {
            addGenericParamsInjectAndDispatch(guideModel,
                    GUIDE_NOT_DISPLAYED_NO_CONNECTIVITY.eventType, specificParams);
        }

    }

    /**
     * Handler for insert displayed analytics.
     *
     * @param insertId
     * @param insertEvent
     */
    public void handleInsertDisplayedAnalytics(final String insertId, boolean isVisualInsert, final String activatedBy) {
        if (!isVisualInsert || InsertsManager.getInstance().wasInsertFullyDisplayedAfterAnimation(insertId)) {
            ReactiveUtils.schedule(new ApiAction() {
                @Override
                protected void execute() {
                    GuideModel guideModel = GuideManager.INSTANCE.getGuide(insertId);
                    ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
                    specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.SEEN_REASON,
                            TYPE_STRING,
                            activatedBy));
                    if (guideModel != null) {
                        addGenericParamsInjectAndDispatch(guideModel,
                                GUIDE_DISPLAYED.eventType, specificParams);

                        PersistenceUtils.persistInsertDisplayedAnalytics(insertId, 0);
                    }
                }
            });
        }
    }

    /**
     * Handler for insert timed out analytics.
     *
     * @param insertId
     * @param insertEvent
     * @param displayDuration
     */
    public void handleInsertTimeoutAnalytics(String insertId,
                                             long displayDuration) {
        GuideModel guideModel = GuideManager.INSTANCE.getGuide(insertId);
        ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
        specificParams.add(
                new InsertCommandsEventBus.Parameter(AnalyticsProperties.DISPLAY_DURATION_MILLIS,
                        "number",
                        Long.toString(displayDuration)));
        specificParams.add(
                new InsertCommandsEventBus.Parameter(AnalyticsProperties.DISPLAY_DURATION,
                        "number",
                        Long.toString(displayDuration)));
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.REASON,
                TYPE_STRING,
                GenericInsertAnalyticsData.DismissedReason.TIME_OUT.getValue()));
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.NOT_DISPLAYED_REASON,
                TYPE_STRING,
                GenericInsertAnalyticsData.DismissedReason.TIME_OUT.getValue()));

        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.DISMISSED_BY,
                TYPE_STRING,
                GenericInsertAnalyticsData.DismissedReason.TIME_OUT.getValue()));
        if (VisualInsertManager.getInstance().getVisualInsert(insertId) != null) {
            specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.SEEN_REASON,
                    TYPE_STRING,
                    VisualInsertManager.getInstance().getVisualInsert(insertId).getActivatedBy()));
        }
        if (guideModel != null) {
            addGenericParamsInjectAndDispatch(guideModel, GUIDE_DISMISSED_TIMEOUT.eventType,
                    specificParams);
        }

        PersistenceUtils.removeStoredInsertDisplayedAnalytics(insertId);
    }

    /**
     * Handler for insert capped out analytics.
     *
     * @param insertAction
     * @param insertEvent
     */
    public void handleInsertCappedOutAnalytics(GuideModel guideModel) {
        // In case there is capping limitation and we cannot consume one impression
        // we are only sending the analytics without showing the insert.
        ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.NOT_DISPLAYED_REASON,
                TYPE_STRING,
                ERROR_REASON_CAPPING.getValue()));
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.REASON,
                TYPE_STRING,
                ERROR_REASON_CAPPING.getValue()));
        addGenericParamsInjectAndDispatch(guideModel,
                GUIDE_NOT_DISPLAYED_OUT_OF_CAPPING.eventType, specificParams);
    }

    /**
     * Handler for insert dismissed analytics, due to user action.
     *
     * @param insertId
     * @param insertEvent
     * @param displayDuration
     */
    public void handleInsertUserActionAnalytics(String insertId,
                                                long displayDuration) {
        GuideModel guideModel = GuideManager.INSTANCE.getGuide(insertId);
        ArrayList<InsertCommandsEventBus.Parameter> specificParams = new ArrayList<>();
        specificParams.add(
                new InsertCommandsEventBus.Parameter(AnalyticsProperties.DISPLAY_DURATION_MILLIS,
                        "number",
                        Long.toString(displayDuration)));
        specificParams.add(
                new InsertCommandsEventBus.Parameter(AnalyticsProperties.DISPLAY_DURATION,
                        "number",
                        Long.toString(displayDuration)));
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.REASON,
                TYPE_STRING,
                GenericInsertAnalyticsData.DismissedReason.USER_ACTION.getValue()));
        specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.DISMISSED_BY,
                TYPE_STRING,
                GenericInsertAnalyticsData.DismissedReason.USER_ACTION.getValue()));
        if (VisualInsertManager.getInstance().getVisualInsert(insertId) != null) {
            specificParams.add(new InsertCommandsEventBus.Parameter(AnalyticsProperties.SEEN_REASON,
                    TYPE_STRING,
                    VisualInsertManager.getInstance().getVisualInsert(insertId).getActivatedBy()));
        }
        if (guideModel != null) {
            addGenericParamsInjectAndDispatch(guideModel, GUIDE_DISMISSED_USER_ACTION.eventType,
                    specificParams);
        }

        PersistenceUtils.removeStoredInsertDisplayedAnalytics(insertId);
    }

}
