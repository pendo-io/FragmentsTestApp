package sdk.pendo.io.network.socketio.state.machines;

import android.app.Activity;
import android.app.Dialog;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;

import org.jose4j.jwt.consumer.InvalidJwtException;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import external.sdk.pendo.io.statemachine.EasyFlow;
import external.sdk.pendo.io.statemachine.EventEnum;
import external.sdk.pendo.io.statemachine.StateEnum;
import external.sdk.pendo.io.statemachine.StatefulContext;
import external.sdk.pendo.io.statemachine.call.ContextHandler;
import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertPreparationManager;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.StepSeenManager;
import sdk.pendo.io.actions.configurations.GuideCapping;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.cache.GuideCacheManager;
import sdk.pendo.io.dialogs.ProgressDialog;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.InitModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.network.responses.validators.JsonWebTokenValidator;
import sdk.pendo.io.network.socketio.configuration.IdentifyScreenData;
import sdk.pendo.io.network.socketio.configuration.TestModeDetails;
import sdk.pendo.io.network.socketio.utilities.SocketDialogUtils;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.views.listener.FloatingListenerButton;

import static external.sdk.pendo.io.statemachine.FlowBuilder.from;
import static external.sdk.pendo.io.statemachine.FlowBuilder.on;
import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason;

/**
 * FSM for the Socket.IO with the backend/frontend.
 * <p>
 * Created by tomerlevinson on 11/4/15.
 */
public final class SocketEventFSM {

    /*********************************
     * FSM specific definitions.
     *********************************/
    private static volatile SocketEventFSM sInstance;
    private static final Object LOCK = new Object();
    private FlowContext mFlowContext;
    private EasyFlow<FlowContext> mFlow;
    private Handler mSendingTimeoutHandler = new Handler(Looper.getMainLooper());
    private Runnable mSendingTimeoutRunnable = null;
    private static final int SEND_IMAGE_TIMEOUT = 20000;
    //    private static final int PAIRING_TIMEOUT_INTERVAL = 15000;
    private static final String NEW_LINE_SEPERATOR = "\n";
    private static BehaviorSubject<Boolean> sIsInCaptureModeObservable = BehaviorSubject.create();
    private static BehaviorSubject<Boolean> sIsInPairedModeObservable = BehaviorSubject.create();
    private static BehaviorSubject<Boolean> sIsInTestModeObservable = BehaviorSubject.create();
    private static BehaviorSubject<Boolean> sIsSocketConnectedObservable = BehaviorSubject.create();
    private static BehaviorSubject<Boolean> sIsInIdentificationModeObservable = BehaviorSubject.create();
    private StepGuideModel mPreviewInsert;
    private InsertEvent mPreviewEvent;
    private static String sInsertNames;
    private IdentifyScreenData mIdentifyScreenData;
    private static Map<String, GuideCapping> sInsertIdCappingArray = new HashMap<>();

    public void setInitialState() {
        mFlowContext.setState(States.STATE_NOT_PAIRED);
    }


    /*********************************
     * FSM States - nodes.
     *********************************/
    public enum States implements StateEnum {
        STATE_NOT_PAIRED,
        STATE_PAIRED,
        STATE_CAPTURE_MODE,
        STATE_PREVIEW,
        STATE_TEST_MODE,
        STATE_IDENTIFY_MODE
    }

    /*********************************
     * FSM events - vertices.
     *********************************/
    public enum Events implements EventEnum {
        EVENT_SOCKET_CONNECTED,
        EVENT_SOCKET_DISCONNECTED,
        EVENT_PAIR_MODE_UPDATE,
        EVENT_CAPTURE_MODE_ENTER,
        EVENT_CAPTURE_MODE_EXIT,
        EVENT_CAPTURE_MODE_SCREEN_CAPTURED,
        EVENT_CAPTURE_MODE_SCREEN_RECEIVED,
        EVENT_PREVIEW_ON_DEVICE,
        EVENT_PREVIEW_DISPLAYED,
        EVENT_TEST_MODE_ENTER,
        EVENT_TEST_MODE_EXIT,
        EVENT_IDENTIFY_MODE_ENTER,
        EVENT_IDENTIFY_MODE_EXIT,
        EVENT_IDENTIFY_SCREEN,
        EVENT_RESET_STATE
    }

    public IdentifyScreenData getIdentifyScreenData() {
        return mIdentifyScreenData;
    }

    public void setIdentifyScreenData(IdentifyScreenData identifyScreenData) {
        mIdentifyScreenData = identifyScreenData;
    }

    public static synchronized Observable<Boolean> isInCaptureModeObservable() {
        return sIsInCaptureModeObservable;
    }


    public static synchronized Observable<Boolean> isInPairedModeObservable() {
        return sIsInPairedModeObservable;
    }

    public static synchronized Observable<Boolean> isInTestModeObservable() {
        return sIsInTestModeObservable;
    }

    public static synchronized Observable<Boolean> isSocketConnectedObservable() {
        return sIsSocketConnectedObservable;
    }

    public static synchronized Observable<Boolean> isInIdentificationModeObservable() {
        return sIsInIdentificationModeObservable;
    }

    public static synchronized void updateSocketConnectedObservable(Boolean value) {
        sIsSocketConnectedObservable.onNext(value);
    }

    public static synchronized Boolean isSocketConnected() {
        return sIsSocketConnectedObservable.hasValue()
                && sIsSocketConnectedObservable.getValue();
    }

    private SocketEventFSM() {
        initFSM();
    }

    private void initFSM() {
        defineFSMTransitions();
        bindFlow();
        mFlowContext = new FlowContext();
        mFlowContext.setState(States.STATE_NOT_PAIRED);
        mFlow.start(true, mFlowContext);
    }

    public static SocketEventFSM getInstance() {
        SocketEventFSM result = sInstance;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = sInstance;
                if (result == null) { // 2nd check (w/ lock)
                    sInstance = result = new SocketEventFSM();
                }
            }
        }
        return result;
    }

    public GuideModel getPreviewInsert() {
        return GuideModel.guideFactory(mPreviewInsert);
    }

    public InsertEvent getPreviewEvent() {
        return mPreviewEvent;
    }


    public static String getInsertNames() {
        return sInsertNames;
    }

    public boolean isTestMode() {
        return mFlowContext.getState().equals(States.STATE_TEST_MODE);
    }

    public boolean isPairedMode() {
        return mFlowContext.getState().equals(States.STATE_PAIRED);
    }

    public boolean isNotPairedMode() {
        return mFlowContext.getState().equals(States.STATE_NOT_PAIRED);
    }

    public boolean isCaptureMode() {
        return mFlowContext.getState().equals(States.STATE_CAPTURE_MODE);
    }

    public boolean isIdentifyMode() {
        return mFlowContext.getState().equals(States.STATE_IDENTIFY_MODE);
    }

    /*********************************
     * FSM Context.
     *********************************/
    private static class FlowContext extends StatefulContext {
        private Object mArgs;

        public Object getArgs() {
            return mArgs;
        }
    }

    public final class SingleThreadExecutor implements Executor {
        @Override
        public void execute(Runnable r) {
            r.run();
        }
    }

    /*********************************
     * FSM flow initialization.
     *********************************/
    @SuppressWarnings("CheckStyle")
    private void defineFSMTransitions() {
        if (mFlow != null) {
            return;
        }
        /* **********************************************************
         * from(BEGIN_STATE).transit(on(VERTEX).to(NEXT_STATE))
         * The following FSM is of the aforementioned manner.
         * We move from the beginner state upon an event(a vertex),
         * to the next state, and so forth.
         ********************************************************** */
        mFlow = from(States.STATE_NOT_PAIRED).transit(
                //Mobile is now paired, let's continue.
                on(Events.EVENT_SOCKET_CONNECTED).to(States.STATE_PAIRED).
                        transit(
                                //We are entering capture mode flow.
                                on(Events.EVENT_CAPTURE_MODE_ENTER).to(States.STATE_CAPTURE_MODE)
                                        .transit(
                                                on(Events.EVENT_CAPTURE_MODE_EXIT).to(States.STATE_PAIRED),
                                                on(Events.EVENT_PAIR_MODE_UPDATE).to(States.STATE_CAPTURE_MODE),
                                                on(Events.EVENT_SOCKET_DISCONNECTED).to(States.STATE_PAIRED),
                                                on(Events.EVENT_RESET_STATE).to(States.STATE_PAIRED),
                                                on(Events.EVENT_CAPTURE_MODE_SCREEN_RECEIVED).to(States.STATE_CAPTURE_MODE),
                                                on(Events.EVENT_CAPTURE_MODE_SCREEN_CAPTURED).to(States.STATE_CAPTURE_MODE)),
                                //We are entering preview on device flow.
                                on(Events.EVENT_PREVIEW_ON_DEVICE).to(States.STATE_PREVIEW)
                                        .transit(
                                                //Go back to being paired, after we're done.
                                                on(Events.EVENT_PREVIEW_DISPLAYED).to(States.STATE_PAIRED)),
                                on(Events.EVENT_PAIR_MODE_UPDATE).to(States.STATE_PREVIEW),
                                //We are entering test mode flow.
                                on(Events.EVENT_TEST_MODE_ENTER).to(States.STATE_TEST_MODE)
                                        .transit(
                                                on(Events.EVENT_TEST_MODE_EXIT).to(States.STATE_PAIRED),
                                                on(Events.EVENT_RESET_STATE).to(States.STATE_PAIRED)),
                                on(Events.EVENT_PAIR_MODE_UPDATE).to(States.STATE_TEST_MODE),
                                //We are entering identify mode flow.
                                on(Events.EVENT_IDENTIFY_MODE_ENTER).to(States.STATE_IDENTIFY_MODE)
                                        .transit(
                                                on(Events.EVENT_IDENTIFY_SCREEN).to(States.STATE_IDENTIFY_MODE),
                                                on(Events.EVENT_IDENTIFY_MODE_EXIT).to(States.STATE_PAIRED),
                                                on(Events.EVENT_SOCKET_DISCONNECTED).to(States.STATE_PAIRED),
                                                on(Events.EVENT_RESET_STATE).to(States.STATE_PAIRED)),
                                on(Events.EVENT_PAIR_MODE_UPDATE).to(States.STATE_IDENTIFY_MODE),
                                on(Events.EVENT_PAIR_MODE_UPDATE).to(States.STATE_PAIRED)
                        )).executor(new SingleThreadExecutor());

    }


    @SuppressWarnings("CheckStyle")
    private void bindFlow() {

        /* ********************************
         * FSM bind states to behaviour.
         ******************************** */
        mFlow.whenEnter(States.STATE_NOT_PAIRED, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                InsertLogger.d("StateFSM - Mobile not paired");
                sIsInPairedModeObservable.onNext(false);
            }
        });
        mFlow.whenEnter(States.STATE_PAIRED, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                try {
                    InsertLogger.d("StateFSM - Entered Paired mode");
                    if (Events.EVENT_PAIR_MODE_UPDATE.equals(context.getLastEvent())) {
                        InsertLogger.d("StateFSM - last event was update pair mode");
                        initGuidesFromArgs((FlowContext) context, true);
                        return;
                    }
                    if (Events.EVENT_TEST_MODE_EXIT.equals(context.getLastEvent())) {
                        InsertLogger.d("StateFSM - last event was test mode exit, loading inserts from cache...");

                        //While we were in test mode we cached all inserts so we would only have the one specific insert
                        //we wish to test. Now that we exited test mode we want to load back all the inserts we cached.
                        InitModel loadedInitModel = GuideCacheManager.getInstance().loadCachedInsertAndEvents(GuideCacheManager.PAIRING_CACHE_FILE_NAME);
                        if (loadedInitModel != null) {
                            updateGuideNames(loadedInitModel.getGuideList());
                        }
                        return;
                    }
                    InsertLogger.d("StateFSM - Mobile is now paired");
                    sIsInPairedModeObservable.onNext(true);
                    initGuidesFromArgs((FlowContext) context, true);
                } catch (Exception e) {
                    InsertLogger.e(e.getMessage());
                }
            }
        });

        mFlow.whenEnter(States.STATE_CAPTURE_MODE, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                try {
                    InsertLogger.d("StateFSM - Entered capture mode.");
                    if (Events.EVENT_CAPTURE_MODE_SCREEN_CAPTURED.equals(context.getLastEvent())) {
                        InsertLogger.d("StateFSM - last event was screen captured.");
                        mSendingTimeoutRunnable = new Runnable() {
                            @Override
                            public void run() {
                                InsertLogger.d("StateFSM - showing capture fail dialog");
                                SocketDialogUtils.showCaptureFailDialog();
                            }
                        };
                        mSendingTimeoutHandler.postDelayed(mSendingTimeoutRunnable,
                                SEND_IMAGE_TIMEOUT);
                        return;
                    } else if (Events.EVENT_CAPTURE_MODE_SCREEN_RECEIVED.equals(context.getLastEvent())) {
                        InsertLogger.d("StateFSM - last event was screen received.");
                        // UI notify it was recieved the screen , let's update the user it was successfull
                        if (mSendingTimeoutHandler != null && mSendingTimeoutRunnable != null) {
                            mSendingTimeoutHandler.removeCallbacks(mSendingTimeoutRunnable);

                        }
                        SocketDialogUtils.showCaptureSuccessDialog();
                        return;
                    } else if (Events.EVENT_PAIR_MODE_UPDATE.equals(context.getLastEvent())) {
                        handlePairModeUpdate((FlowContext) context);
                        return;
                    }
                    sIsInCaptureModeObservable.onNext(true);
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }


            }
        });
        mFlow.whenLeave(States.STATE_CAPTURE_MODE, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                try {
                    sIsInCaptureModeObservable.onNext(false);
                    // When leaving the capture mode make sure the sending image dialog and timeout handlers are OFF.
                    resetCaptureHandlers(context);
                    InsertLogger.d("StateFSM - Leaving capture mode.");
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }

            private void resetCaptureHandlers(StatefulContext context) {
                try {
                    if (mSendingTimeoutHandler != null && mSendingTimeoutRunnable != null) {
                        mSendingTimeoutHandler.removeCallbacks(mSendingTimeoutRunnable);
                    }
                    ProgressDialog dialogFragment = FloatingListenerButton.getDialogFragment();
                    if (dialogFragment != null) {
                        Dialog sendingImageDialog = dialogFragment
                                .getLastDialog();
                        if (sendingImageDialog != null &&
                                sendingImageDialog.isShowing() &&
                                !context.getLastEvent().equals(Events.EVENT_CAPTURE_MODE_SCREEN_RECEIVED) &&
                                !context.getLastEvent().equals(Events.EVENT_CAPTURE_MODE_SCREEN_CAPTURED)) {
                            InsertLogger.d("StateFSM - dismissing dialog");
                            sendingImageDialog.dismiss();
                        }
                    }
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        });
        mFlow.whenEnter(States.STATE_PREVIEW, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                try {
                    if (Events.EVENT_PAIR_MODE_UPDATE.equals(context.getLastEvent())) {
                        handlePairModeUpdate((FlowContext) context);
                        return;
                    }
                    InsertLogger.d("StateFSM - UI requests preview on device.");
                    runPreview((FlowContext) context);
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        });
        mFlow.whenEnter(States.STATE_TEST_MODE, new ContextHandler<StatefulContext>() {
            @Override
            public void call(final StatefulContext context) {
                try {
                    InsertLogger.d("StateFSM - Mobile in test mode.");

                    if (Events.EVENT_PAIR_MODE_UPDATE.equals(context.getLastEvent())) {
                        handlePairModeUpdate((FlowContext) context);
                        return;
                    }
                    if (VisualInsertManager.getInstance().isAnyInsertShowing()) {
                        InsertsManager.getInstance().dismissVisibleGuides();
                    }
                    sIsInTestModeObservable.onNext(true);
                    try {
                        VisualInsertManager.getInstance().getIsFullScreenInsertShowingObservable().filter(new Predicate<Boolean>() {
                            @Override
                            public boolean test(Boolean isFullScreenInsertShowing) {
                                return !isFullScreenInsertShowing;
                            }
                        }).firstElement().subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                            @Override
                            public void accept(Boolean aBoolean) {
                                initGuidesFromArgs((FlowContext) context, false);
                            }
                        }));
                    } catch (Exception e) {
                        AnalyticsUtils.sendErrorReport(
                                NotDisplayReason.ERROR_REASON_ENTER_TEST_MODE,
                                e.getMessage());
                    }
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        });
        mFlow.whenLeave(States.STATE_TEST_MODE, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                try {
                    StepSeenManager.getInstance().setCurrentStepSeen(null);
                    sIsInTestModeObservable.onNext(false);
                    InsertLogger.d("StateFSM - Leaving test mode mode.");
                    InitModel initModel = new InitModel();
                    // emptying  all the data structures (inserts, events, etc..)
                    initModel.init();
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        });
        mFlow.whenEnter(States.STATE_IDENTIFY_MODE, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                InsertLogger.d("StateFSM - Mobile in identify mode");
                if (Events.EVENT_PAIR_MODE_UPDATE.equals(context.getLastEvent())) {
                    handlePairModeUpdate((FlowContext) context);
                    return;
                }
                sIsInIdentificationModeObservable.onNext(true);

            }
        });
        mFlow.whenLeave(States.STATE_IDENTIFY_MODE, new ContextHandler<StatefulContext>() {
            @Override
            public void call(StatefulContext context) {
                sIsInIdentificationModeObservable.onNext(false);
            }
        });


    }

    /**
     * When pairedModeUpdate is being sent during Capture/Preview/Test/Identify mode,
     * We should update cached inserts only
     *
     * @param context containing the arguments received for the state machine.
     */
    private void handlePairModeUpdate(FlowContext context) {

        String json = context.mArgs.toString();

        if (!TextUtils.isEmpty(json)) {
            InsertLogger.i("StateFSM -  saving update mode init model to cache");
            TestModeDetails testDetailsFromServer = Pendo.GSON.fromJson(json,
                    TestModeDetails.class);
            InitModel initModel = new InitModel(testDetailsFromServer.data);
            storeInitModelToCache(initModel);
        }
    }

    /**
     * Update the guides' name to be used in the pairing dialog active inserts
     *
     * @param guideModels the list of guides which are used to fetch the names
     */
    public static void updateGuideNames(List<GuideModel> guideModels) {
        sInsertNames = "";
        StringBuilder builder = new StringBuilder();
        for (GuideModel guideModel : guideModels) {
            String guideName = guideModel.getGuideName();
            if (guideName != null) {
                builder.append(guideModel.getGuideName());
            } else {
                builder.append(guideModel.getGuideId());
            }
            builder.append(NEW_LINE_SEPERATOR);
        }
        sInsertNames = builder.toString();
    }

    /**
     * Runs preview on device with a given state machine context
     *
     * @param context
     */
    private void runPreview(FlowContext context) {
        Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();

        if (currentActivity == null) {
            InsertLogger.e("Activity is null! Not displaying preview.");
            AnalyticsUtils.sendErrorReport(
                    NotDisplayReason.ERROR_REASON_RUN_PREVIEW_INSERT,
                    "Activity is null! Not displaying preview.");
            move(Events.EVENT_PREVIEW_DISPLAYED);
            return;
        }

        String json = null;
        if (context.mArgs instanceof JSONObject) {
            try {
                json = ((JSONObject) context.mArgs).get("data").toString();
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

        if (json == null) {
            return;
        }
        mPreviewInsert = Pendo.GSON.fromJson(json,
                StepGuideModel.class);
        mPreviewEvent = GuideUtils.generatePreviewEventFromInitModel();
        if (!InsertsManager.isInited()) {
            Map<String, InsertAction> guideMap = new HashMap<>();
            String guideId = mPreviewInsert.getId();
            if (guideId != null) {
                guideMap.put(guideId, new InsertAction(guideId));
            }
            InsertsManager.init(guideMap);
        }
        InsertPreparationManager.getInstance().prepareGuideImages(mPreviewInsert.getViews(), GuideModel.PREVIEW_GUIDE_STEP_ID);
        ArrayList<String> imagesToDownload = InsertPreparationManager.getInstance().getImages(
                mPreviewInsert.getViews());
        InsertPreparationManager.getInstance().fetchImages(GuideModel.PREVIEW_GUIDE_STEP_ID, imagesToDownload);
        currentActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    GuideManager.INSTANCE.showPreview();
                } catch (Exception e) {
                    AnalyticsUtils.sendErrorReport(
                            NotDisplayReason.ERROR_REASON_RUN_PREVIEW_INSERT,
                            e.getMessage());
                }
                move(Events.EVENT_PREVIEW_DISPLAYED);
            }
        });
    }

    private void initGuidesFromArgs(FlowContext context, boolean saveToCache) {
        // Extract active insert names.
        if (context.mArgs == null) {
            return;
        }
        String json = context.mArgs.toString();
        InsertLogger.d("StateFSM - Got json from socket: " + json);

        if (!TextUtils.isEmpty(json)) {
            TestModeDetails testDetailsFromServer = Pendo.GSON.fromJson(json, TestModeDetails.class);
            if (shouldFetchInsertsFromSocketData(testDetailsFromServer)) {
                GuideModel guideModel = testDetailsFromServer.data;
                if (guideModel != null) {
                    updateGuideNames(Collections.singletonList(guideModel));
                    InitModel initModel = new InitModel(guideModel);
                    if (saveToCache) {
                        InsertLogger.d("Saving inserts from socket to cache, num of inserts: " + initModel.getGuideList().size());
                        storeInitModelToCache(initModel);
                    }
                    initModel.init();
                    if (!InsertsManager.isInited()) {
                        Map<String, InsertAction> guideMap = new HashMap<>();
                        InsertsManager.init(guideMap);
                    }
                } else {
                    InsertLogger.i("init model is null");
                }
            }
        }
    }

    private void storeInitModelToCache(InitModel initModel) {
        GuideCacheManager.getInstance()
                .storeCachedGuide(Pendo.GSON.toJson(initModel), GuideCacheManager.PAIRING_CACHE_FILE_NAME);
    }

    private Map<String, GuideCapping> getInsertIdCappingMap() {
        return sInsertIdCappingArray;
    }

    private boolean shouldFetchInsertsFromSocketData(TestModeDetails testDetailsFromServer) {
        return testDetailsFromServer != null && testDetailsFromServer.data != null;
    }

    /*********************************
     * FSM get current state.
     *********************************/
    public StateEnum getCurrentState() {
        return mFlowContext.getState();
    }

    /*********************************
     * FSM move between states.
     *********************************/
    public boolean move(EventEnum event, Object... args) {
        synchronized (LOCK) {
            InsertLogger.i("Flow: " + mFlow.toString() + " Current: " + getCurrentState() + " Event: " + event
                    .name());
            mFlowContext.mArgs = null;
            if (args != null && args.length > 0) {
                JSONObject message = null;
                try {
                    message = (JSONObject) args[0];
                    mFlowContext.mArgs = getValidatedJWTData(message);
                } catch (InvalidJwtException e) {
                    JSONObject data = message.optJSONObject("data");
                    // Check for the case where the data is allowed to be empty if not signed.
                    if (data != null && data.length() == 0) {
                        mFlowContext.mArgs = message;
                    } else {
                        InsertLogger.e("JWT is not valid data = '" + data + "'.");
                    }
                } catch (Exception e) {
                    InsertLogger.i("Invalid event: " + event.name() + " message: '" + args[0] + "'.");
                }
            }
            return mFlow.safeTrigger(event, mFlowContext);
        }
    }

    public static JSONObject getValidatedJWTData(JSONObject response) throws InvalidJwtException {
        String jwtData = response.optString("data");
        if (jwtData == null) {
            throw new InvalidJwtException("Socket did not get data = '" + response + "'.");
        }

        try {

            // Get the data from the response.
            String validatedData = JsonWebTokenValidator.INSTANCE.validate(jwtData);

            // Validate the JWT value from it.
            if (validatedData == null) {
                throw new InvalidJwtException("Socket cannot validate data = '" + jwtData + "'.");
            }

            // Set it to a new JSONObject and return it.
            JSONObject copyOfData = new JSONObject(response.toString());
            copyOfData.put("data", new JSONObject(validatedData));
            return copyOfData;

        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }

        throw new InvalidJwtException("Something went wrong, response = '" + response + "'.");
    }

}
