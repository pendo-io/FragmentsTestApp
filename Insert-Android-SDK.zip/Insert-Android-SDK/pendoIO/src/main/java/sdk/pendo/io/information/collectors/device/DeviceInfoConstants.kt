package sdk.pendo.io.information.collectors.device

/**
 * AnalyticsProperties that represents the way the GetAuthToken Info JSON should look like.

 * Created by assaf on 5/3/15.
 */
internal class DeviceInfoConstants private constructor() {
    object BatteryStatus {
        val BATTERYSTATUS = "batteryStatus" // {
        val STATUS = "status" //: "charging",
        val LEVEL = "level" //: "78.00%",
        val POWER_SOURCE = "power_source" //: "USB"
        // },
    }

//    protected object Display {
//        protected val DISPLAY = "display" //: {
//        protected val DISPLAY_NAME = "display" //: "LMY47D",
//        protected val WIDTH = "width" //: 1080,
//        protected val HEIGHT = "height" //: 1920,
//        protected val DESNSITY = "density" //: 480,
//        protected val SIZE = "size" //: 4.59,
//        // },
//    }

    /** [optional]  */
    object Network {
        val NETWORK = "network" //: {
        val NET_TYPE = "net_type" //: "..."
        val NET_ROAMING = "net_roaming" //: true | false,

        /** [optional]  */
        val WIFI_MAC = "wifi_MAC" //: "AA:BB:CC:DD:EE:FF",
        //        /** [optional] */
        //        protected final static String MOBILE_SUB_TYPE = "mobile_sub_type"; //: "3G, 2G, 4G ....."
        // },
    }

    object Sim {
        val SIM = "sim" //: {
        val COUNTRY_ISO = "country_iso" //: "il",
        val OPERATOR = "operator" //: "SOME_NUMBER",
        val OPERATOR_NAME = "operator_name" //: "OPERATOR"
        // }
    }

    companion object {

        // {
        val DEVICE_ID = "deviceId" //: "DeviceID",
        val ID_TYPE = "idType" //: "UUID",
        val LOCALE = "locale" //: "en_US",
        val INSTALLED_APPS = "installedApps" //: ["com.google.android.youtube", ...],
        val OS = "os" //: "Android",
        val OS_VERSION = "osVersion" //: 22,
        val BRAND = "brand" //: "google",
        val MANUFACTURER = "manufacturer" //: "LGE",
        val MODEL = "model" //: "Nexus 5",
        val BOARD = "board" //: "hammerhead",
        val FEATURES = "features" //: ["android.hardware.sensor.proximity", ...],
        val TYPE = "type" //: "smartphone",
    }
    // }
}
