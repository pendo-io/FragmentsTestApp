package sdk.pendo.io.data.structures;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * {@link HashMap} that store key that points to a {@link LinkedList} of values.
 *
 * Created by assaf on 11/16/15.
 */
public final class HashMapListValues<K, V> extends HashMap<K, List<V>> {

    /**
     * The value is inserted into the list mapped to the key. If the key is not in the map yet
     * a new {@link LinkedList} will be created on behalf of the caller and the value will be added
     * to the list. The key will map to that list.
     *
     * @param key
     *            the key.
     * @param value
     *            the value.
     */
    public void add(K key, V value) {
        List<V> values = getValues(key);

        if (value != null) {
            values.add(value);
        }
    }

    @Override
    public boolean containsValue(Object value) {

        /** Use super for checking for a {@link List} */
        if (value instanceof List) {
            return super.containsValue(value);


        } else {
            final Collection<List<V>> allValues = values();

            for (List<V> valuesList : allValues) {
                for (V v : valuesList) {
                    if (v.equals(value)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private List<V> getValues(K key) {
        List<V> values = get(key);

        if (values == null) {
            values = new LinkedList<>();
            put(key, values);
        }

        return values;
    }
}
