package sdk.pendo.io.network.responses;

import android.view.View;
import com.google.gson.annotations.SerializedName;

import org.apache.commons.lang3.tuple.Pair;

import java.util.LinkedList;
import java.util.List;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.events.InsertEvent.EventActions;
import sdk.pendo.io.events.ScreenDisplayDurationManager;
import sdk.pendo.io.utilities.TriggerUtils;

/**
 * Class to represent the screen model received from the backend.
 *
 * Created by assaf on 5/13/15.
 */
public final class ScreenModel {

    public int id;

    @SerializedName("elements")
    public List<ElementModel> elements;

    @SerializedName("screenIdentificationData")
    public ScreenIdentificationData screenIdentificationData;

    public synchronized LinkedList<Pair<InsertEvent, TriggerModel>> getScreenViewEventsForCurrentState(View root) {
        LinkedList<Pair<InsertEvent, TriggerModel>> result = new LinkedList<>();
        if (elements != null) {
            for (ElementModel element : elements) {
                if (element.events != null) {
                    for (InsertEvent event : element.events) {
                        String eventAction = event.getConfiguration().getAction();
                        if (isProperEventAction(eventAction)) {
                            if (event.getTriggers() != null) {
                                for (TriggerModel trigger : event.getTriggers()) {
                                    if (trigger.satisfiesFlow()) {
                                        if (TriggerUtils.satisfiesAllConditions(trigger, root)) {
                                            result.add(Pair.of(event, trigger));
                                            handleScreenDisplayDuration(eventAction);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return result;
    }

    public void handleScreenDisplayDuration(String eventAction) {
        if (eventAction.equals(EventActions.SCREEN_LEFT.action)) {
            ScreenDisplayDurationManager.getInstance().setScreenFinalDisplayDuration(id);
            // Must be Screen View Event, start display timer if hasn't been started yet.
        } else if (!ScreenDisplayDurationManager.getInstance().isScreenCurrentlyShowing(id)) {
            ScreenDisplayDurationManager.getInstance().setScreenDisplayStartTime(id, System.currentTimeMillis());
        }
    }

    private boolean isProperEventAction(String eventAction) {
        return eventAction.equals(EventActions.SCREEN_VIEW.action)
                || eventAction.equals(EventActions.SCREEN_LEFT.action);
    }
}
