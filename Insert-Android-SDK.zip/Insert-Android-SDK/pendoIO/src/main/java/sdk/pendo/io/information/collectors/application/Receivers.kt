package sdk.pendo.io.information.collectors.application

import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.utilities.ResourceUtils
import sdk.pendo.io.utilities.add

/**
 * Collect information about the application's receivers.

 * Created by assaf on 4/14/15.
 */
internal class Receivers : Collector() {

    override fun collectData(json: JSONObject) {

        // Add the application's receivers.
        addReceivers(json)
    }

    /**
     * Adds information about the application's receivers to the JSON.

     * @param info The JSON to receive the information about the application's receivers.
     */
    private fun addReceivers(info: JSONObject) {
        try {
            val appReceivers = application!!.packageManager.getPackageInfo(packageName,
                    PackageManager.GET_RECEIVERS)

            val receivers = appReceivers.receivers
            if (receivers != null) {
                val receiverArray = JSONArray()

                for (receiver in receivers) {
                    val receiverJSON = JSONObject()
                    receiverJSON.add("receiver_enabled", receiver.enabled)
                    receiverJSON.add("receiver_exported", receiver.exported)
                    receiverJSON.add("receiver_icon", receiver.icon)
                    receiverJSON.add("receiver_label", ResourceUtils.getStringFromResource(receiver.labelRes) ?: "??")
                    receiverJSON.add("receiver_name", receiver.name)
                    receiverJSON.add("receiver_permission", receiver.permission)
                    receiverJSON.add("receiver_process", receiver.processName)

                    receiverArray.add(receiverJSON)
                }

                info.add("receivers", receiverArray)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            InsertLogger.e(e, "Failed to get receivers.")
        }

    }
}
