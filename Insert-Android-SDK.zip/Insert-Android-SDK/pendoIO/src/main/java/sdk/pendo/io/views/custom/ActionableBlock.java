package sdk.pendo.io.views.custom;

import android.support.annotation.NonNull;
import android.view.View;

import org.apache.commons.lang3.tuple.Pair;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.constants.Constants;

/**
 * Defines a block which can perform an action inside a visual insert
 * <p/>
 * Created by nirsegev on 8/3/15.
 */
public interface ActionableBlock extends View.OnClickListener {

    String getActionParam();

    void setActionParam(String actionParam);

    @NonNull
    CharSequence getElementId();

    void setOnSubmit(String valueString);

    Pair<OnSubmitAction, String> getOnSubmit();

    void setActions(List<InsertCommand> commands);

    // TODO: 4/6/16 Remove when the toast for submit will be an action.
    enum OnSubmitAction {
        CLOSE(Constants.ViewAttrsConsts.ON_SUBMIT_CLOSE),
        CHANGE_SCREEN(Constants.ViewAttrsConsts.ON_SUBMIT_CHANGE_SCREEN);

        private final String mOnSubmitAction;

        OnSubmitAction(String onSubmitAction) {
            mOnSubmitAction = onSubmitAction;
        }

        String getOnSubmitActionName() {
            return mOnSubmitAction;
        }

        private static final String CHANGE_SCREEN_PTRN =
                "^" + Constants.ViewAttrsConsts.ON_SUBMIT_CHANGE_SCREEN + "\\('(.*)'\\)$";
        private static final Pattern CHANGE_SCREEN_PTRN_MCHR = Pattern.compile(CHANGE_SCREEN_PTRN);
        static String getChangeScreenId(String onSubmitAction)
            throws IllegalStateException {

            if (onSubmitAction == null) {
                throw new IllegalStateException("Given null submit action.");
            }

            final Matcher matcher = CHANGE_SCREEN_PTRN_MCHR.matcher(onSubmitAction);
            if (!matcher.matches()) {
                throw new IllegalStateException("Given submit action '"
                        + onSubmitAction + "' Doesn't match the regex.");
            }

            return matcher.group(1);
        }
    }
}
