package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

/**
 * A wrapper for each Step in the steps array.
 * https://pendo-io.atlassian.net/wiki/spaces/ENG/pages/368672843/New+Guide+activation+model
 */
public class StepContentModel {

    @SerializedName("guideId")
    private String mGuideId;

    @SerializedName("guideStepId")
    private String mGuideStepId;

    @SerializedName("guide")
    private StepGuideModel mStepGuideModel;

    public StepGuideModel getStepModel() {
        return mStepGuideModel;
    }

    public void setStepModel(StepGuideModel stepGuideModel) {
        this.mStepGuideModel = stepGuideModel;
    }

    public String getGuideId() {
        return mGuideId;
    }

    public void setGuideId(String guideId) {
        this.mGuideId = guideId;
    }

    public String getGuideStepId() {
        return mGuideStepId;
    }
}
