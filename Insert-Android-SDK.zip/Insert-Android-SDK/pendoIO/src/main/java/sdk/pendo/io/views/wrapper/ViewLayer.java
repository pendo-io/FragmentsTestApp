package sdk.pendo.io.views.wrapper;

import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;

import java.util.HashSet;
import java.util.NavigableMap;
import java.util.PriorityQueue;
import java.util.TreeMap;

import sdk.pendo.io.utilities.ViewUtils;

/**
 * Wrapper class for views to hold the view's layer level along with the view. This adds the
 * artificial z-index of the view inside it's view hierarchy.
 * <p/>
 * Created by assaf on 11/11/15.
 */
public final class ViewLayer extends ViewWrapperBase implements Comparable<ViewLayer> {

    private int mLevel;

    public ViewLayer(View view, int level) {
        super(view);
        set(level);
    }

    private void set(int level) {
        mLevel = level;
    }

    public void set(View view, int level) {
        super.set(view);
        mLevel = level;
    }

    public int getLevel() {
        return mLevel;
    }

    @Override
    public int compareTo(@NonNull ViewLayer another) {

        final int anotherLevel = another.getLevel();

        if (mLevel < anotherLevel) {
            return 1;
        }

        if (anotherLevel < mLevel) {
            return -1;
        }

        return 0;
    }

    public static final class HierarchyBuilder {

        /**
         * Builds a {@link PriorityQueue<ViewLayer>} starting from the root {@link View}.
         *
         * @param root the {@link View} to start from.
         *
         * @return a {@link PriorityQueue<ViewLayer>}.
         */
        public synchronized PriorityQueue<ViewLayer> buildViewLayerPriorityQueue(View root) {

            return buildViewLayerPriorityQueue(root, false);
        }

        /**
         * Builds a {@link PriorityQueue<ViewLayer>} starting from the root {@link View}.
         *
         * @param root the {@link View} to start from.
         * @param onlyInDisplay indicates whether to look for views only inside the display.
         *
         * @return a {@link PriorityQueue<ViewLayer>}.
         */
        public synchronized PriorityQueue<ViewLayer> buildViewLayerPriorityQueue(
                View root,
                boolean onlyInDisplay) {

            PriorityQueue<ViewLayer> priorityQ = new PriorityQueue<>();

            rBuildViewLayerPriorityQueue(root, new HashSet<View>(), onlyInDisplay, priorityQ, 0);

            return priorityQ;
        }

        private synchronized void rBuildViewLayerPriorityQueue(View view,
                                                  HashSet<View> discoverySet,
                                                  boolean onlyInDisplay,
                                                  PriorityQueue<ViewLayer> oPriorityQueue,
                                                  int level) {

            boolean addView = true;
            if (view.getVisibility() != View.VISIBLE
                    || (onlyInDisplay && !ViewUtils.isViewInsideDisplay(view))) {
                addView = false;
            }

            if (addView) {
                oPriorityQueue.add(new ViewLayer(view, level));
            }
            discoverySet.add(view);

            if (view instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) view;

                int childCount = vg.getChildCount();

                if (childCount > 0) {

                    for (int i = 0; i < childCount; i++) {

                        View viewChild = vg.getChildAt(i);
                        if (!discoverySet.contains(viewChild)) {
                            rBuildViewLayerPriorityQueue(
                                    viewChild,
                                    discoverySet,
                                    onlyInDisplay,
                                    oPriorityQueue,
                                    level + 1);
                        }
                    }
                }
            }
        }
    }

    public static class Utils {

        public static NavigableMap<Integer, Integer>
                generateLevelElementCount(final PriorityQueue<ViewLayer> pQ) {

            PriorityQueue<ViewLayer> priorityQ = new PriorityQueue<>();

            for (ViewLayer v : pQ) {
                priorityQ.add(v);
            }

            TreeMap<Integer, Integer> retMap = new TreeMap<>();

            while (!priorityQ.isEmpty()) {
                final int level = priorityQ.poll().getLevel();

                if (retMap.containsKey(level)) {
                    final Integer count = retMap.get(level);
                    retMap.put(level, count + 1);
                } else {
                    retMap.put(level, 1);
                }
            }

            return retMap.descendingMap();
        }

        public static int getTopLevel(final PriorityQueue<ViewLayer> pQ) {

            try {
                return pQ.peek().getLevel();
            } catch (Exception e) {
                return -1;
            }
        }

        public static int viewCountAtLevel(final PriorityQueue<ViewLayer> pQ, final int level) {
            return generateLevelElementCount(pQ).get(level);
        }

        public static int viewCountToDepth(final PriorityQueue<ViewLayer> pQ, final int depth) {
            final NavigableMap<Integer, Integer> elementCount = generateLevelElementCount(pQ);
            final int topLevel = getTopLevel(pQ);
            final int lowestLevel = topLevel - depth;

            int retVal = 0;
            for (int level = topLevel; level > lowestLevel; level--) {
                retVal += elementCount.get(level);
            }

            return retVal;
        }

        public static int viewCountToDepth(final NavigableMap<Integer, Integer> elementCount,
                                           final int topLevel,
                                           final int depth) {
            final int lowestLevel = topLevel - depth;

            int retVal = 0;
            for (int level = topLevel; level > lowestLevel; level--) {
                retVal += elementCount.get(level);
            }

            return retVal;
        }
    }
}
