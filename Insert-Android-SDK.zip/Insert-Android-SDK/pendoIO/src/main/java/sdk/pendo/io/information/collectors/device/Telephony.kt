package sdk.pendo.io.information.collectors.device

import android.content.Context
import android.telephony.TelephonyManager
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.utilities.add

/**
 * Collect information about the telephone.
 * Created by assaf on 4/14/15.
 */
internal class Telephony : Collector() {

    override fun collectData(json: JSONObject) {

        // Add device type and if mobile also SIM info (if available).
        addTelephonyInfo(json)
    }

    /**
     * Adds JSON with all of the device telephony info (if available).
     *
     * @param info The JSONObject to receive the device telephony info.
     */
    private fun addTelephonyInfo(info: JSONObject) {
        val telephony = application!!.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        if (telephony.phoneType == TelephonyManager.PHONE_TYPE_NONE) {
            info.add(DeviceInfoConstants.TYPE, "Tablet")
        } else {
            info.add(DeviceInfoConstants.TYPE, "Smartphone")
            if (telephony.simState == TelephonyManager.SIM_STATE_READY) {

                info.add(DeviceInfoConstants.Sim.SIM, getSIMInfo(telephony))
            } else {
                info.add(DeviceInfoConstants.Sim.SIM, "UNAVAILABLE")
            }
        }
    }

    /**
     * Returns a JSON object representing the SIM's information.
     *
     * @param telephony A non-null TelephonyManager.
     *
     * @return A JSON object representation with information about the SIM.
     */
    private fun getSIMInfo(telephony: TelephonyManager): JSONObject {
        val simJSON = JSONObject()
        simJSON.add(DeviceInfoConstants.Sim.COUNTRY_ISO, telephony.simCountryIso)
        simJSON.add(DeviceInfoConstants.Sim.OPERATOR, telephony.simOperator)
        simJSON.add(DeviceInfoConstants.Sim.OPERATOR_NAME, telephony.simOperatorName)
        return simJSON
    }
}
