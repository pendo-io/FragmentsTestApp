package sdk.pendo.io.utilities;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.actions.AppCommandHandler;
import sdk.pendo.io.actions.GuideManager;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.configurations.InsertGroup;
import sdk.pendo.io.analytics.AnalyticsEvent;
import sdk.pendo.io.analytics.AnalyticsProperties;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData.ScriptError;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData.SecurityReason;
import sdk.pendo.io.analytics.InsertAnalytics;
import sdk.pendo.io.analytics.Tracker;
import sdk.pendo.io.cache.GuideCacheManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.models.GuideModel;
import sdk.pendo.io.models.InsertPushData;
import sdk.pendo.io.models.StepContentModel;
import sdk.pendo.io.models.StepGuideModel;
import sdk.pendo.io.network.BackendApiManager;
import sdk.pendo.io.network.SetupManager;
import sdk.pendo.io.network.interfaces.ApiAction;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;

import static sdk.pendo.io.analytics.GenericInsertAnalyticsData.NotDisplayReason;
import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;

/**
 * Created by nirsegev on 7/13/15.
 */
public final class AnalyticsUtils {

    // @formatter:off
    public static final String KEY_SDK                      = "SDK";
    public static final String KEY_OS_SDK_VERSION           = "OsSdkVersion";
    public static final String KEY_BRAND                    = "Brand";
    public static final String KEY_MANUFACTURER             = "Manufacturer";
    public static final String KEY_MODEL                    = "Model";
    public static final String KEY_BOARD                    = "Board";
    public static final String KEY_BOOTLOADER               = "Bootloader";
    public static final String KEY_DEVICE_PRODUCT_NAME      = "DeviceProductName";
    public static final String KEY_INDUSTRIAL_DESIGN_NAME   = "IndustrialDesignName";

    private static final String IMAGE_SOURCES_DELIMITER      = ",";
    private static final String ADDITIONAL_DATA_SOURCES_LIST = "sourcesList";
    // @formatter:on

    // Call getDeviceInfo to get this field.
    private static JSONObject sDeviceInfo;

    private AnalyticsUtils() {
    }

    @Nullable
    private static synchronized JSONObject getDeviceInfo() {
        if (sDeviceInfo == null) {
            sDeviceInfo = new JSONObject();
            try {
                sDeviceInfo.put(KEY_SDK, Build.VERSION.RELEASE);
                sDeviceInfo.put(KEY_OS_SDK_VERSION, String.valueOf(Build.VERSION.SDK_INT));
                sDeviceInfo.put(KEY_BRAND, Build.BRAND);
                sDeviceInfo.put(KEY_MANUFACTURER, Build.MANUFACTURER);
                sDeviceInfo.put(KEY_MODEL, Build.MODEL);
                sDeviceInfo.put(KEY_BOARD, Build.BOARD);
                sDeviceInfo.put(KEY_BOOTLOADER, Build.BOOTLOADER);
                sDeviceInfo.put(KEY_DEVICE_PRODUCT_NAME, Build.PRODUCT);
                sDeviceInfo.put(KEY_INDUSTRIAL_DESIGN_NAME, Build.DEVICE);
            } catch (JSONException ignore) {
                // Reset the device info if some info wasn't received.
                sDeviceInfo = null;
            }
        }

        return sDeviceInfo;
    }


    public static void sendExceptionReport(Throwable e) {
        sendExceptionReport(e, null);
    }

    public static void sendExceptionReport(@NonNull Throwable e, @Nullable String message) {
        JSONObject errorInfoJson = new JSONObject();
        JSONObject jsonString;
        try {
            String errorMessage;
            final String eMessage = e.getMessage();
            if (message != null && !message.equals(eMessage)) {
                errorMessage = "Dev log = '" + message + "', " +
                        "stacktrace message = '" + eMessage + "'.";
            } else {
                errorMessage = "Stacktrace message = '" + eMessage + "'.";
            }

            final JSONObject deviceInfo = getDeviceInfo();
            if (deviceInfo != null) {
                errorInfoJson.put(AnalyticsProperties.DEVICE_INFO, deviceInfo);
            }

            errorInfoJson.put(AnalyticsProperties.EXCEPTION_TYPE, e.getClass().getCanonicalName());
            errorInfoJson.put(AnalyticsProperties.ERROR_MESSAGE, errorMessage);
            errorInfoJson.put(AnalyticsProperties.STACK_TRACE,
                    Utils.stacktraceToString(e.getStackTrace()));

            jsonString = generateErrorJson(AnalyticsEvent.SDK_EXCEPTION, null, errorInfoJson);
            BackendApiManager.getInstance().sendErrorReport(jsonString.toString());
        } catch (Exception cantSend) {
            InsertLogger.d("Error while generating / sending error event" + cantSend.getMessage());
        }
    }

    public static void sendErrorReportImageLoadingFailed(String insertId, List<String> sources) {
        JSONObject json = new JSONObject();
        try {
            StringBuilder sourcesListStringBuilder = new StringBuilder();
            for (int i = 0; i < sources.size(); i++) {
                sourcesListStringBuilder.append(sources.get(i));
                if (i != sources.size() - 1) {
                    sourcesListStringBuilder.append(IMAGE_SOURCES_DELIMITER);
                }
            }
            json.put(AnalyticsProperties.GUIDE_ID, insertId);
            json.put(AnalyticsProperties.TIMESTAMP, System.currentTimeMillis());
            json.put(AnalyticsProperties.REASON, NotDisplayReason.ERROR_REASON_IMAGE);
            json.put(ADDITIONAL_DATA_SOURCES_LIST, sourcesListStringBuilder.toString());

            BackendApiManager.getInstance().sendErrorReport(json.toString());
        } catch (Exception e1) {
            InsertLogger.e("Error while generating / sending error event" + e1.getMessage());
        }

    }

    public static void sendErrorReport(NotDisplayReason errorReason, String error) {

        try {
            JSONObject errorInfo = new JSONObject();
            errorInfo.put(AnalyticsProperties.ERROR_MESSAGE, error);
            sendErrorReport(errorReason, errorInfo);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    public static void sendJwtSecurityException(String signedData, String source,
                                                String exceptionMessage) {

        JSONObject json = new JSONObject();
        try {
            json.put(AnalyticsProperties.SIGNED_DATA, signedData);
            json.put(AnalyticsProperties.SOURCE, source);
            json.put(AnalyticsProperties.EXCEPTION_MESSAGE, exceptionMessage);
            sendSecurityException(SecurityReason.INVALID_SIGNATURE, json);
        } catch (Exception e) {
            InsertLogger.e("Error while generating security exception: " + e.getMessage());
        }
    }

    public static void sendSecurityException(SecurityReason reason, JSONObject additionalInfo) {

        JSONObject json = new JSONObject();
        try {
            json.put(AnalyticsProperties.EVENT, AnalyticsEvent.SECURITY_EXCEPTION.getValue());
            json.put(AnalyticsProperties.TIMESTAMP, System.currentTimeMillis());
            if (reason != null) {
                json.put(AnalyticsProperties.REASON, reason.getValue());
            }

            if (additionalInfo != null) {
                Iterator<String> keys = additionalInfo.keys();

                while (keys != null && keys.hasNext()) {
                    String key = keys.next();
                    json.put(key, additionalInfo.get(key));
                }
            }
        } catch (Exception e1) {
            InsertLogger.e("Error while generating / sending error event" + e1.getMessage());
        }
        BackendApiManager.getInstance().sendErrorReport(json.toString());
    }

    public static void sendErrorReport(NotDisplayReason errorReason, JSONObject additionalInfo) {
        JSONObject jsonString = generateErrorJson(AnalyticsEvent.SDK_ERROR, errorReason,
                additionalInfo);

        BackendApiManager.getInstance().sendErrorReport(jsonString.toString());
    }

    public static void sendScriptableError(ScriptError scriptError,
                                           String errorMsg) {


        try {
            JSONObject additionalInfo = new JSONObject();

            additionalInfo.put(AnalyticsProperties.ERROR_MESSAGE, errorMsg);

            JSONObject jsonString = generateErrorJson(AnalyticsEvent.SDK_ERROR,
                    null,
                    additionalInfo);

            jsonString.put(AnalyticsProperties.REASON, scriptError.getValue());
            BackendApiManager.getInstance().sendErrorReport(jsonString.toString());
        } catch (JSONException e) {
            InsertLogger.e("Error while generating / sending error event" + e.getMessage());
        }
    }

    private static JSONObject generateErrorJson(AnalyticsEvent eventType,
                                                NotDisplayReason errorReason,
                                                JSONObject additionalInfo) {

        if (NotDisplayReason.ERROR_REASON_CONFIGURATION.equals(errorReason)) {
            InsertLogger.i("Deleting cache file due to configuration error.");
            GuideCacheManager.getInstance().deleteCache();
        }

        JSONObject json = new JSONObject();
        try {
            json.put(AnalyticsProperties.EVENT, eventType.getValue());
            json.put(AnalyticsProperties.TIMESTAMP, System.currentTimeMillis());
            if (errorReason != null) {
                json.put(AnalyticsProperties.REASON, errorReason.getValue());
            }

            if (additionalInfo != null) {
                Iterator<String> keys = additionalInfo.keys();

                while (keys != null && keys.hasNext()) {
                    String key = keys.next();
                    json.put(key, additionalInfo.get(key));
                }
            }
        } catch (Exception e1) {
            InsertLogger.e("Error while generating / sending error event" + e1.getMessage());
        }
        return json;
    }

    public static void sendInsertNotDisplayedAnalyticsEvent(Tracker tracker,
                                                            NotDisplayReason errorReason,
                                                            JSONObject additionalInfo) {
        final GenericInsertAnalyticsData genericAnalytics = tracker.getGenericAnalytics();

        if (genericAnalytics != null) {
            genericAnalytics.setNotDisplayedReason(errorReason);
        } else {
            InsertLogger.w("Generics analytics is null!");
        }
        tracker.send(AnalyticsEvent.GUIDE_NOT_DISPLAYED.getValue(), additionalInfo, null);
        sendErrorReport(errorReason, additionalInfo);
    }

    public static void sendGenericAnalytics(Tracker tracker, AnalyticsEvent event,
                                            String endpointUrl) {
        tracker.send(event.getValue(), null, endpointUrl);
        if (event == AnalyticsEvent.GUIDE_DISMISSED) {
            JSONObject analyticsData = tracker.getAnalyticsData();
            if (analyticsData != null && analyticsData.has(AnalyticsProperties.GUIDE_ID)) {
                try {
                    PersistenceUtils.removeStoredInsertDisplayedAnalytics(
                            tracker.getAnalyticsData().getString(AnalyticsProperties.GUIDE_ID));
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }
    }

    public static void sendInsertDismissedAnalytics(Tracker tracker, long duration, String reason,
                                                    String endpointUrl, JSONObject additionalInfo) {
        GenericInsertAnalyticsData genericAnalytics = tracker.getGenericAnalytics();
        if (genericAnalytics != null &&
                InsertsManager.getInstance().wasInsertFullyDisplayedAfterAnimation(genericAnalytics.getInsertId())) {
            InsertsManager.getInstance().removeInsertFullyDisplayedAfterAnimation(genericAnalytics.getInsertId());
            genericAnalytics.setDuration(duration);
            genericAnalytics.setDismissedReason(reason);
            tracker.send(AnalyticsEvent.GUIDE_DISMISSED.getValue(), additionalInfo, endpointUrl);
            PersistenceUtils.removeStoredInsertDisplayedAnalytics(String.valueOf(genericAnalytics.getInsertId()));
        }
    }

    public static void sendInsertDismissedAppTerminationAnalytics(String guideId, String displayDuration) {
        JSONObject json = new JSONObject();
        try {
            JSONObject propsJSON = new JSONObject();
            GuideModel guideModel = GuideManager.INSTANCE.getGuide(guideId);
            if (guideModel != null) {
                //TODO: MS check correct step content model
                StepContentModel stepContentModel = guideModel.getStepContentModel(0);
                if (stepContentModel != null) {
                    propsJSON.put(AnalyticsProperties.GUIDE_STEP_ID, stepContentModel.getGuideStepId());
                }
            }
            propsJSON.put(AnalyticsProperties.ORIENTATION, DeviceStateUtils.getDeviceOrientation());
            propsJSON.put(AnalyticsProperties.LANGUAGE, ResourceUtils.getCurrentUserPreferenceOnLocale());
            propsJSON.put(AnalyticsProperties.GUIDE_ID, guideId);
            propsJSON.put(AnalyticsProperties.DISMISS_REASON, GenericInsertAnalyticsData.DismissedReason.APP_TERMINATION.getValue());
            json.put(AnalyticsProperties.PROPS_JSON_KEY, propsJSON);
            json.put(AnalyticsProperties.GUIDE_ID, guideId)
                    .put(AnalyticsProperties.VERSION, SettingsUtils.getSDKVersion())
                    .put(AnalyticsProperties.DISPLAY_DURATION,
                            displayDuration)
                    .put(AnalyticsProperties.TYPE,
                            AnalyticsEvent.GUIDE_DISMISSED.getValue())
                    .put(AnalyticsProperties.SEND_MODE,
                            AnalyticsProperties.SEND_MODE_BUFFER);
        } catch (JSONException e) {
            InsertLogger.e(e, "Can't generate additional info json");
        }

        InsertAnalytics.newTracker().send(AnalyticsEvent.GUIDE_DISMISSED.getValue(), json, null);
    }

    public static void sendActionClickedAnalytics(Tracker tracker, AnalyticsEvent event,
                                                  long duration, JSONObject additionalInfo) {
        GenericInsertAnalyticsData genericAnalytics = tracker.getGenericAnalytics();
        if (genericAnalytics != null) {
            genericAnalytics.setDuration(duration);
            tracker.send(event.getValue(), additionalInfo, null);
        }
    }

    /**
     * Send app session started analytics.
     */
    public static void sendAppSessionStartedAnalytics() {
        if (SocketEventFSM.getInstance().isNotPairedMode()) { // No need to send if device is paired
                    ActivationManager.INSTANCE.isInitedObservable()
                            .filter(new Predicate<Boolean>() {
                                @Override
                                public boolean test(Boolean isInited) {
                                    return isInited;
                                }
                            }).firstElement()
                            .observeOn(Schedulers.io())
                    .subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                        @Override
                        public void accept(Boolean isFinishedInitActions) {
                            AppCommandHandler.getInstance().addParamsAndDispatch(
                                    InsertCommandEventType.AppEventType.APP_SESSION_START, new LinkedList<InsertCommandsEventBus.Parameter>(), null, null);
                        }
                    }));
        } else {
            InsertLogger.d("Device is paired, no need to send AppSessionStart/End");
            SetupManager.getInstance().setIsFinishedSendingPersistedAnalytics(true);
        }
    }

    /**
     * Send app session end analytics.
     */
    public static void sendAppSessionEndedAnalytics(final String visitorId, final String accountId) {
        if (SocketEventFSM.getInstance().isNotPairedMode()) { // No need to send if device is paired
            ReactiveUtils.schedule(new ApiAction() {
                @Override
                protected void execute() {
                    String sessionTime = PersistenceUtils.handleAppSessionDurationAnalyticsRecovery();
                    if (!sessionTime.equals(PersistenceUtils.APP_SESSION_DURATION_FIRST_TIME_DURATION)) {
                        AppCommandHandler.getInstance().addParamsAndDispatch(
                                InsertCommandEventType.AppEventType.APP_SESSION_END, new LinkedList<InsertCommandsEventBus.Parameter>(), visitorId, accountId);
                    }
                }
            });
        }
    }

    public static void sendAppInForegroundBackgroundAnalytics(
            final ApplicationFlowManager.AppFlowState appFlowState,
            final long timeSinceChange,
            final long startTime) {
        if (SocketEventFSM.getInstance().isNotPairedMode()) { // No need to send if device is paired
            final List<InsertCommandsEventBus.Parameter> additionalParams = new LinkedList<>();
            additionalParams.add(
                    new InsertCommandsEventBus.Parameter(AnalyticsProperties.APP_STATE_DURATION,
                            TYPE_STRING,
                            String.valueOf(TimeUnit.MILLISECONDS.toSeconds(timeSinceChange))));

            AppCommandHandler.getInstance().getIsAppCommandsSetSubject()
                    .filter((new Predicate<Boolean>() {
                        @Override
                        public boolean test(Boolean isAppCommandsSet) {
                            return isAppCommandsSet;
                        }
                    })).firstElement()
                    .observeOn(Schedulers.io())
                    .subscribe(InsertMaybeObserver.create(new Consumer<Boolean>() {
                        @Override
                        public void accept(Boolean ignore) {
                            if (appFlowState == ApplicationFlowManager.AppFlowState.IN_BACKGROUND) {
                                PersistenceUtils.persistAppInBackgroundIntervalledAnalytics(startTime, timeSinceChange);
                                AppCommandHandler.getInstance().addParamsAndDispatch(
                                        InsertCommandEventType.AppEventType.APP_IN_BACKGROUND, additionalParams, null, null);
                            } else {
                                AppCommandHandler.getInstance().addParamsAndDispatch(
                                        InsertCommandEventType.AppEventType.APP_IN_FOREGROUND, additionalParams, null, null);
                            }
                        }
                    }));
        }
    }

    public static void sendPushAnalytics(InsertPushData pushData, AnalyticsEvent analyticsEvent)
            throws JSONException {
        InsertAction insertAction = new InsertAction(pushData.getInsertId());
        JSONObject additionalAnalytics = null;

        insertAction.setInsertGroup(pushData.getGroup());
        GenericInsertAnalyticsData iga = InsertAnalytics.getInstance().
                newInsertGenericAnalytics(insertAction);
        Tracker tracker = InsertAnalytics.newTracker(iga);

        if (analyticsEvent == AnalyticsEvent.INSERT_ELEMENT_CLICKED) {
            additionalAnalytics = new JSONObject();
            additionalAnalytics.put(AnalyticsProperties.ELEMENT_ID, pushData.getElementId());
            additionalAnalytics.put(AnalyticsProperties.ACTION_TYPE,
                    pushData.getAction() != null ? pushData.getAction() : "");
        }
        tracker.send(analyticsEvent.getValue(), additionalAnalytics, null);
    }

    public static void sendAnalytics(AnalyticsEvent event, Tracker tracker,
                                     HashMap<String, Object> additionalInfo) {
        JSONObject o = new JSONObject(additionalInfo);

        if (tracker != null) {
            tracker.send(event.getValue(), o, null);
        } else {
            InsertLogger.w("Cannot send analytics, tracker is null!");
        }
    }

    public static void addVideoAdditionalInfo(HashMap<String, Object> additionalInfo,
                                              String elementId,
                                              boolean isPlaying,
                                              boolean isPlayerExists,
                                              long playtime,
                                              long videoLength) {
        try {
            additionalInfo.put(AnalyticsProperties.ELEMENT_ID, elementId);
            int orientation = ResourceUtils.getResources().getConfiguration().orientation;
            additionalInfo.put(AnalyticsProperties.ORIENTATION,
                    ResourceUtils.orientationToString(orientation));

            if (!isPlaying) {
                additionalInfo.put(AnalyticsProperties.PLAY_DURATION_MILLIS, playtime);
            }

            if (isPlayerExists) {
                additionalInfo.put(AnalyticsProperties.VIDEO_LENGTH_MILLIS,
                        videoLength);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }
}
