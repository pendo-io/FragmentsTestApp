package sdk.pendo.io.events

import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.PublishSubject
import sdk.pendo.io.actions.ActivationManager
import sdk.pendo.io.constants.Constants.GeneralConsts.IRRELEVANT
import sdk.pendo.io.listeners.ApplicationObservers
import sdk.pendo.io.reactive.observers.InsertObserver
import sdk.pendo.io.sdk.manager.ApplicationFlowManager
import sdk.pendo.io.sdk.manager.ScreenManager
import java.util.concurrent.TimeUnit

/**
 * Listener to activity and view changes.
 *
 * Created by assaf on 12/15/15.
 */
object PassiveTriggersListener {

	private const val VIEW_LAYER_DEBOUNCE_TIMEOUT = 250
	private val mViewIntersectionSubject: PublishSubject<Any> = PublishSubject.create()

//	private val mActivityStateSubject: PublishSubject<Activity> = PublishSubject.create()

	init {

		// Listen to the activity state changes.
		listenToActivityStateChanges()
	}

	@Synchronized
	fun activityStateChange() {
		mViewIntersectionSubject.onNext(IRRELEVANT)
	}

	private fun listenToActivityStateChanges() {

		mViewIntersectionSubject
			.observeOn(Schedulers.computation())
			// The Debounce operator filters out items emitted by the source Observable
			// that are rapidly followed by another emitted item.
			// http://reactivex.io/documentation/operators/debounce.html
			.debounce(VIEW_LAYER_DEBOUNCE_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
			.mergeWith(ApplicationObservers.getInstance().activityOnCreateObservable)
			.filter {
				(ActivationManager.isInited()
						&& !ApplicationFlowManager.getInstance().isInBackground
						&& ApplicationObservers.getInstance().currentVisibleActivity != null)
			}
			.retry()
			.subscribe(InsertObserver.create {

				// Call and check if any fragments changed.
				ScreenManager.recalculateScreenIdentifier()

				// Update other listeners.
//				val visibleActivity = ApplicationObservers.getInstance().currentVisibleActivity
//				if (visibleActivity != null) {
//					mActivityStateSubject.onNext(visibleActivity)
//				}
			})
	}
}