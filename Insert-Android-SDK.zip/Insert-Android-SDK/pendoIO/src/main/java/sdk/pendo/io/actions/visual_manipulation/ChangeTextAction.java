package sdk.pendo.io.actions.visual_manipulation;

import android.app.Activity;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.google.gson.JsonArray;

import org.apache.commons.lang3.tuple.Pair;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

import external.sdk.pendo.io.yoyo.Techniques;
import external.sdk.pendo.io.yoyo.YoYo;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.actions.AppTweakInterface;
import sdk.pendo.io.actions.ElementBoundAction;
import sdk.pendo.io.actions.InsertCommandParameterInjector;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.constants.Constants;
import sdk.pendo.io.intelligence.IntelManager;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.utilities.ViewUtils;

import static sdk.pendo.io.actions.VisualInsertBase.DEFAULT_ACTIVATED_BY;

/**
 * A/B testing insert action for changing the element's text.
 * <p/>
 * Created by assaf on 12/1/15.
 */
public final class ChangeTextAction extends ElementBoundAction implements AppTweakInterface {

    private static final HashSet<String> CHANGE_TEXT_PROPERTIES =
            new HashSet<>(Arrays.asList(new String[]{
                    Constants.ViewAttrsConsts.TEXT,
                    Constants.ViewAttrsConsts.BACKGROUND,
                    Constants.ViewAttrsConsts.ANIMATION,
                    Constants.ViewAttrsConsts.DURATION
            }));

    private Pair<WeakReference<TextView>, CharSequence> mTestModeOriginalTextView;

    public static final String CHANGE_TEXT_WIDGET_NAME = "pendo.io.ChangeText";
    public static final String HIGHLIGHTER_WIDGET_NAME = "pendo.io.Highlighter";
    public static final String HAS_ANIMATED = "Animated";
    public static final String BACKGROUND_CHANGED_INDICATOR = "    ";

    private final HashMap<String, Object> mChangeTextProperties = new HashMap<>();

    public ChangeTextAction(JsonArray properties) {
        super(properties);

        extractProperties(properties, mChangeTextProperties, CHANGE_TEXT_PROPERTIES);
    }

    public static final Object LOCK = new Object();

    private void saveAndRestoreTextInTestMode(final TextView tv, final CharSequence oldText) {
        if (SocketEventFSM.getInstance().isTestMode() && tv != null && oldText != null) {

            mTestModeOriginalTextView = Pair.of(new WeakReference<>(tv), oldText);

            // In case we're in test mode, subscribe to original text setting when
            // we exit test mode.
            SocketEventFSM.isInTestModeObservable()
                    .skip(1)
                    .filter(new Predicate<Boolean>() {
                        @Override
                        public boolean test(Boolean isInTestMode) {
                            return !isInTestMode;
                        }
                    }).subscribe(new Observer<Boolean>() {

                @Override
                public void onNext(Boolean aBoolean) {
                    if (mTestModeOriginalTextView != null) {
                        final CharSequence oldText = mTestModeOriginalTextView.getRight();
                        WeakReference<TextView> weakOriginalTextView = mTestModeOriginalTextView.getLeft();
                        TextView originalTextView = null;

                        if (weakOriginalTextView != null) {
                            originalTextView = weakOriginalTextView.get();
                        }

                        final TextView finalTextView = originalTextView;
                        if (finalTextView != null) {
                            Activity activity = ApplicationObservers.getInstance().getCurrentVisibleActivity();
                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    finalTextView.setText(oldText);

                                    CharSequence contentDescription = finalTextView.getContentDescription();

                                    if (contentDescription != null && contentDescription.toString()
                                            .endsWith(BACKGROUND_CHANGED_INDICATOR)) {
                                        finalTextView.setBackgroundColor(Color.TRANSPARENT);
                                        finalTextView.setTag(null);
                                    }
                                }
                            });


                            mTestModeOriginalTextView = null;
                            onComplete();
                        }
                    }
                }

                @Override
                public void onSubscribe(Disposable disposable) {
                }
                
                @Override
                public void onComplete() {
                }

                @Override
                public void onError(Throwable e) {
                }
            });
        }
    }


    @Override
    public boolean runInsert(final GenericInsertAnalyticsData iga, final View view) {

        final Activity currentActivity = ApplicationObservers.getInstance().getCurrentVisibleActivity();

        if (view == null) {
            return false;
        }

        synchronized (LOCK) {

            TextView changeText = null;
            if (!(view instanceof TextView)) {
                View found = IntelManager.findViewInHierarchy(view, TextView.class);

                if (found != null) {
                    changeText = (TextView) found;
                }
            } else {
                changeText = (TextView) view;
            }

            if (changeText != null) {

                // Tell the RecyclerView not to recycle this view so our change
                // won't appear on other cells in the list.
                ViewUtils.setIsRecyclableView(changeText, false);

                final TextView finalChangeText = changeText;
                final CharSequence oldText = finalChangeText.getText();

                // In case we're in test mode, subscribe to original text setting when
                // we get back to paired mode.
                saveAndRestoreTextInTestMode(finalChangeText, oldText);
                currentActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (shouldChangeText(finalChangeText)) {
                            finalChangeText.setText(getText());
                            InsertContentDescriptionManager.getInstance().setContentDescription(
                                    finalChangeText, getText(),
                                    null);
                        }

                        if (shouldChangeBackground()) {
                            finalChangeText.setBackgroundColor(getBackground());
                            CharSequence currentContentDescription = finalChangeText.getContentDescription();
                            String newContentDescription = currentContentDescription == null ?
                                    BACKGROUND_CHANGED_INDICATOR : currentContentDescription + BACKGROUND_CHANGED_INDICATOR;
                            InsertContentDescriptionManager.getInstance()
                                    .setContentDescription(finalChangeText, newContentDescription,
                                            newContentDescription);
                        }

                        if (shouldAnimate(finalChangeText)) {
                            YoYo.with(Techniques.valueOf(getAnimation())).duration(
                                    getDuration()).playOn(finalChangeText);
                            finalChangeText.setTag(HAS_ANIMATED);
                        }
                    }
                });

                InsertCommandParameterInjector.getInstance().
                        handleInsertDisplayedAnalytics(iga.getInsertId(), false, DEFAULT_ACTIVATED_BY);
            }
        }
        return true;
    }

    public TweakMode getInsertType() {
        return TweakMode.CHANGE_TEXT;
    }

    public String getText() {
        return (String) mChangeTextProperties.get(Constants.ViewAttrsConsts.TEXT);
    }

    @Nullable
    public Integer getBackground() {
        return Color.parseColor(
                (String) mChangeTextProperties.get(Constants.ViewAttrsConsts.BACKGROUND));
    }

    @Nullable
    public String getAnimation() {
        return (String) mChangeTextProperties.get(Constants.ViewAttrsConsts.ANIMATION);
    }

    public Integer getDuration() {
        return Integer.valueOf(
                (String) mChangeTextProperties.get(Constants.ViewAttrsConsts.DURATION));
    }

    private boolean shouldChangeText(TextView textView) {
        boolean result = false;
        final CharSequence currentText = textView.getText();
        final String newText = getText();

        if (newText == null) {
            result = false;

        } else if (currentText == null) {
            result = true;

        } else if (!currentText.toString().equals(newText)) {
            result = true;
        }

        return result;
    }

    private boolean shouldChangeBackground() {
        return !TextUtils.isEmpty(
                (String) mChangeTextProperties.get(Constants.ViewAttrsConsts.BACKGROUND));
    }

    private boolean shouldAnimate(TextView textView) {
        return !TextUtils.isEmpty(getAnimation()) && !HAS_ANIMATED.equals(textView.getTag());
    }
}