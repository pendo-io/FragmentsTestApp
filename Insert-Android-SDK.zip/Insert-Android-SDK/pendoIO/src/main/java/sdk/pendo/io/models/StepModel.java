package sdk.pendo.io.models;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

/**
 * This class depicts a single step and it's contents.
 * {
 *     "guides" : [
 *          {
 *              recurrence: xyz,
 *              guideId: abc,
 *              configuration: {},
 *              ...,
 *              steps: [
 *                  {
 *                     "content": {},
 *                     "location": {}
 *                  }
 *              ]
 *          },
 *          ...
 *     ]
 * }
 */
public class StepModel {
    @SerializedName("content")
    private StepContentModel mStepContentModel;

    @SerializedName("location")
    private StepLocationModel mStepLocationModel;

    @SerializedName("activations")
    private JsonArray mStepActivations;

    public StepContentModel getStepContentModel() {
        return mStepContentModel;
    }

    public StepLocationModel getStepLocationModel() {
        return mStepLocationModel;
    }

    public JsonArray getStepActivations() {
        return mStepActivations;
    }
}
