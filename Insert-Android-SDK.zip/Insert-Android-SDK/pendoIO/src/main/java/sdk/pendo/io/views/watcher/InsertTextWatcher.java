package sdk.pendo.io.views.watcher;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.commons.lang3.tuple.Pair;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.actions.AppTweakInsert;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.data.structures.ConcurrentWeakIdentityHashMap;
import sdk.pendo.io.events.EventsManager;
import sdk.pendo.io.events.IdentificationData;
import sdk.pendo.io.events.InsertEvent;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.responses.TriggerModel;
import sdk.pendo.io.utilities.PredicateUtils;

import static sdk.pendo.io.intelligence.ViewIntel.getViewIntelId;
import static sdk.pendo.io.actions.visual_manipulation.ChangeTextAction.BACKGROUND_CHANGED_INDICATOR;

/**
 * Watcher for text changes and if needed, changes the text.
 * <p/>
 * Created by assaf on 2/21/16.
 */
public final class InsertTextWatcher implements TextWatcher {

    private static final int INITIAL_CAPACITY = 11;

    private final WeakReference<TextView> mView;
    private AtomicBoolean mShouldChangeText = new AtomicBoolean(false);
    private AtomicBoolean mIsEditing = new AtomicBoolean(false);
    private String mOldText = null;
    private String mNewText = null;

    // Stores the history for a TextView inside a specific activity.
    private static ConcurrentWeakIdentityHashMap<TextView, Pair<String, List<String>>> sChangedTextList =
            new ConcurrentWeakIdentityHashMap<>();
    private static ConcurrentHashMap<String, String> sPredicateToNewString =
            new ConcurrentHashMap<>(INITIAL_CAPACITY);

    public InsertTextWatcher(TextView view) {
        mView = new WeakReference<>(view);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//        InsertLogger.d("Test - beforeTextChanged(" + textWatcherIdString() + "): called with: "
//                + "s = [" + s + "], start = ["
//                + start + "], count = [" + count + "], after = ["
//                + after + "], mShouldChangeText = [" + mShouldChangeText.get() + "]");
    }

    @SuppressLint("NewApi")
    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
//        InsertLogger.d("Test - onTextChanged(" + textWatcherIdString() + "): called with: "
//                + "s = [" + s + "], start = ["
//                + start + "], before = [" + before + "], count = ["
//                + count + "], mShouldChangeText = [" + mShouldChangeText.get() + "]");

        try {
            if (mOldText == null) {
                mOldText = s.toString();
            }

            final String textViewString = s.toString();
            if (mIsEditing.get() || textViewString.equals(mNewText)) {
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):mIsEditing = [" + mIsEditing.get() + "] mNewText = [" + mNewText + "]");
                return;
            }

            TextView textView = mView.get();
            if (textView == null) {
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):null TextView.");
                return;
            }

            if (!ActivationManager.INSTANCE.isInited()) {
                return;
            }

//        if (!TextUtils.isEmpty(mOldText) && !mIsEditing.get()
//                && mShouldChangeText.get() && mOldText.equals(textViewString)) {
//            textView.removeTextChangedListener(this);
//            textView.setText(mNewText);
//            textView.addTextChangedListener(this);
//            return;
//        }

            final String localClassName = ApplicationObservers.getInstance().getCurrentActivityName();
            if (!ActivationManager.INSTANCE.hasViewManipulationsForActivity(localClassName)) {
                return;
            }

            final HashSet<String> textModificationStrings = ActivationManager.INSTANCE
                    .getTextModificationStrings(localClassName);

            if (shouldRevertTextBackground(textView, textModificationStrings)) {
                textView.setBackgroundColor(Color.TRANSPARENT);
            }

            // Check if we have text changes for the current activity.
            if (textModificationStrings == null || !textModificationStrings.contains(textViewString)) {
                return;
            }

            // isAttachedToWindow() is available from KITKAT, if the SDK is lower that KITKAT
            // treat it just as isAttachedToWindow() == true.
            // If the SDK is KITKAT and up, check isAttachedToWindow().
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT || textView.isAttachedToWindow()) {

                boolean changed = changeText(localClassName, textView, null);

                if (changed) {
//                InsertLogger.d("Text changed.");
                    return;
                }

//            ArrayList<View> outViews = new ArrayList<>();
//            final View currentRootView = ApplicationObservers.getInstance().getCurrentActivityRootView();
//
//            if (currentRootView != null) {
//                currentRootView
//                        .findViewsWithText(outViews, textViewString, View.FIND_VIEWS_WITH_TEXT);
//            }
//
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):outViews size: " + outViews.size());
//
//            if (outViews.isEmpty()) {
//                InsertLogger.d("Test - (" + textWatcherIdString() + "):Didn't find '" + textViewString + "' waiting and looking again.");
//            } else {
//                for (View outView : outViews) {
//                    changeText(localClassName, (TextView) outView, null);
//                }
//            }

            } else {
                textView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                    @Override
                    public void onViewAttachedToWindow(View v) {
//                    InsertLogger.d("Attached to window.");
                        changeText(localClassName, (TextView) v, null);
                    }

                    @Override
                    public void onViewDetachedFromWindow(View v) {
//                    InsertLogger.d("Detached from window.");
                        v.removeOnAttachStateChangeListener(this);
                    }
                });
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void afterTextChanged(final Editable s) {
//        InsertLogger.d("Test - afterTextChanged(" + textWatcherIdString() + "): called with: " + "s = ["
//                + s + "], mShouldChangeText = [" + mShouldChangeText.get() + "]");
        try {
            final String textViewString = s.toString();
            if (mIsEditing.get() || textViewString.equals(mNewText)) {
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):mIsEditing = [" + mIsEditing.get() + "] mNewText = [" + mNewText + "]");
                return;
            }

            TextView textView = mView.get();
            if (textView == null) {
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):null TextView.");
                return;
            }

            if (!ActivationManager.INSTANCE.isInited()) {
                return;
            }

//        final String tvPred = getTextViewPredicate(textView);
//        final String newText = getNewText(tvPred);
//        if (newText != null && !mIsEditing.get()) {
//            textView.removeTextChangedListener(this);
//            s.clear();
//            s.append(newText);
//            textView.addTextChangedListener(this);
//            return;
//        }

            final String localClassName = ApplicationObservers.getInstance().getCurrentActivityName();
            if (!ActivationManager.INSTANCE.hasViewManipulationsForActivity(localClassName)) {
                return;
            }

            final HashSet<String> textModificationStrings = ActivationManager.INSTANCE
                    .getTextModificationStrings(localClassName);

            if (textModificationStrings == null || !textModificationStrings.contains(textViewString)) {
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):No need to look for this text: " + textViewString);
                return;
            }

            // isAttachedToWindow() is available from KITKAT, if the SDK is lower that KITKAT
            // treat it just as isAttachedToWindow() == true.
            // If the SDK is KITKAT and up, check isAttachedToWindow().
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT || textView.isAttachedToWindow()) {

                boolean changed = changeText(localClassName, textView, null);

                if (changed) {
//                InsertLogger.d("Text changed.");
                    return;
                }

//            ArrayList<View> outViews = new ArrayList<>();
//            final View currentRootView = ApplicationObservers.getInstance().getCurrentActivityRootView();
//
//            if (currentRootView != null) {
//                currentRootView
//                        .findViewsWithText(outViews, textViewString, View.FIND_VIEWS_WITH_TEXT);
//            }
//
//            InsertLogger.d("Test - (" + textWatcherIdString() + "):outViews size: " + outViews.size());
//
//            if (outViews.isEmpty()) {
//                InsertLogger.d("Test - (" + textWatcherIdString() + "):Didn't find '" + textViewString + "' waiting and looking again.");
//            } else {
//                for (View outView : outViews) {
//                    changeText(localClassName, (TextView) outView, null);
//                }
//            }

            } else {
                textView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                    @Override
                    public void onViewAttachedToWindow(View v) {
//                    InsertLogger.d("Attached to window.");
                        changeText(localClassName, (TextView) v, s);
                    }

                    @Override
                    public void onViewDetachedFromWindow(View v) {
//                    InsertLogger.d("Detached from window.");
                        v.removeOnAttachStateChangeListener(this);
                    }
                });
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    private boolean changeText(String localClassName, TextView textView, Editable s) {

        try {
            if (mIsEditing.getAndSet(true)) {
//                InsertLogger.d("Test - (" + textWatcherIdString() + "):Not changing the text: " + textView.getText());
                return false;
            }

//            InsertLogger.d("Test - (" + textWatcherIdString() + "):Changing text: " + textView.getText());

            final String oldString = textView.getText().toString();
            final String tvPred = getTextViewPredicate(textView);
            final String newText = getNewText(tvPred);
            if (s != null && newText != null && !mIsEditing.get()) {
                textView.removeTextChangedListener(this);
                s.clear();
                s.append(newText);
                textView.addTextChangedListener(this);
                return true;
            }
            // Old code, not collecting texts and accessibility
            final IdentificationData viewIntelId = getViewIntelId(textView, false, false);
            List<InsertEvent> events = null;
            if (ActivationManager.INSTANCE.isInited()) {
                events = ActivationManager.INSTANCE
                        .getViewManipulationElement(localClassName, viewIntelId);
            }

            if (events != null) {
                for (InsertEvent event : events) {
                    final List<Pair<InsertAction, TriggerModel>> inserts = InsertsManager
                            .getInstance().getInserts(event, null);

                    if (!inserts.isEmpty()) {
                        Pair<InsertAction, TriggerModel> insert = inserts.get(0);
                        final InsertAction insertAction = insert.getLeft();
                        final String pred = getTextViewPredicate(textView);
                        mShouldChangeText.set(true);
                        mNewText = ((AppTweakInsert) insertAction).getText();

                        if (mNewText != null) {
                            sPredicateToNewString.put(pred, mNewText);

                            if (s != null) {
                                textView.removeTextChangedListener(this);
                                s.clear();
                                s.append(mNewText);
                                textView.addTextChangedListener(this);
                            }
                        }

                        // Store the history for the text view.
                        if (sChangedTextList != null && localClassName != null) {
                            if (sChangedTextList.containsKey(textView)) {
                                if (localClassName.equals(
                                        sChangedTextList.get(textView).getLeft())) {
                                    List<String> historyList = sChangedTextList.get(
                                            textView).getRight();
                                    historyList.add(mNewText);
                                }
                            } else {
                                List<String> newHistory = new ArrayList<>();
                                newHistory.add(oldString);
                                newHistory.add(mNewText);
                                sChangedTextList.put(textView,
                                        Pair.of(localClassName, newHistory));
                            }
                        }

                    }
                }
            }

        } finally {
            mIsEditing.set(false);
        }

        return false;
    }

    private String textWatcherIdString() {
        final TextView textView = mView.get();

        return "{this = [" + hashCode() + "], TextView = ["
                + (textView == null ? "null" : textView.hashCode()) + "]}";
    }

    @Nullable
    private static String getNewText(String pred) {

        final String[] predicateSplit = pred.split(":");

        if (predicateSplit.length != 2) {
            return null;
        }

        final String activityName = predicateSplit[0];
        final String predicateSuffix = predicateSplit[1];

        for (Map.Entry<String, String> entry : sPredicateToNewString.entrySet()) {
            final String[] split = entry.getKey().split(":");
            final String act = split[0];
            final String viewPred = split[1];

            if (activityName.equals(act) && viewPred.equals(predicateSuffix)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private static String getTextViewPredicate(TextView textView) {
        final String currentActivityName = ApplicationObservers.getInstance()
                .getCurrentActivityName();
        return currentActivityName
                + ":"
                + PredicateUtils.generatePredicateForView(textView);
    }

    public static List<String> getTextHistoryForTextView(TextView textView) {
        String currentActivityName = ApplicationObservers.getInstance().getCurrentActivityName();
        if (sChangedTextList != null && currentActivityName != null && sChangedTextList.containsKey(
                textView) && sChangedTextList.get(textView).getLeft().equals(currentActivityName)) {
            return sChangedTextList.get(textView).getRight();
        }
        return null;
    }

    public static void addTextWatcher(TextView textView) {

        if (hasTextWatcher(textView) || textView instanceof CheckBox || textView instanceof EditText) {
            return;
        }

        textView.addTextChangedListener(new InsertTextWatcher(textView));
        textView.setText(textView.getText());
        InsertContentDescriptionManager.getInstance().setContentDescription(textView,
                textView.getText().toString(),
                null);
    }

    private static synchronized boolean hasTextWatcher(TextView textView) {
        try {
            Field mListeners = TextView.class.getDeclaredField("mListeners");
            mListeners.setAccessible(true);

            final Object listeners = mListeners.get(textView);
            if (listeners != null && listeners instanceof ArrayList<?>) {

                ArrayList<?> listenerList = (ArrayList<?>) listeners;
                for (Object textWatcher : listenerList) {
                    if (textWatcher instanceof InsertTextWatcher) {
                        return true;
                    }
                }
            }

        } catch (IllegalAccessException e) {
            InsertLogger.e(e, e.getMessage());
        } catch (NoSuchFieldException e) {
            InsertLogger.e(e, "SDK version: " + Build.VERSION.SDK_INT);
        } catch (Exception ignore) {
        }

        return false;
    }

    private boolean shouldRevertTextBackground(TextView textView,
                                               HashSet<String> textModificationStrings) {
        return !TextUtils.isEmpty(textView.getContentDescription())
                && textView.getContentDescription().toString().endsWith(
                BACKGROUND_CHANGED_INDICATOR)
                && textModificationStrings != null
                && !textModificationStrings.contains(textView.getText().toString());

    }
}
