package sdk.pendo.io.views.custom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;

import com.felipecsl.gifimageview.library.GifImageView;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;

import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType.UserEventType;
import sdk.pendo.io.handlers.LoadGifCorrectlyHandler;
import sdk.pendo.io.handlers.LoadImageCorrectlyHandler;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.script.JavascriptRunner;

import static sdk.pendo.io.views.custom.ActionableBlock.OnSubmitAction.CLOSE;

/**
 * View class that extends {@link ImageView} with some of our code.
 * <p/>
 * Created by assaf on 5/5/15.
 */
public final class VisualActionImage extends GifImageView implements ActionableBlock {

    private boolean mIsGif;
    private String mActionURL;
    boolean mAdjustViewBounds;
	private String mInsertId;

    public VisualActionImage(Context context) {
        this(context, (AttributeSet) null);
    }

    public VisualActionImage(Context context, String insertId){
        this(context, (AttributeSet) null);
        mInsertId = insertId;
    }

    public VisualActionImage(Context context, AttributeSet attrs) {
        super(context, attrs);

        setOnClickListener(this);
        InsertContentDescriptionManager.getInstance().setContentDescription(this, getContext().getString(
                        R.string.insert_visual_image_accessibility_description), null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            super.onDraw(canvas);
        } catch (Exception e){
            InsertLogger.e(e, e.getMessage());
            this.setImageBitmap(null);
            this.setVisibility(View.GONE);
        }
    }

    public void setResourceURL(final String url) {
        mIsGif = url.endsWith(".gif");

        if (mIsGif) {
            new LoadGifCorrectlyHandler(getContext(), this, url, mInsertId);
        }
        else {
            new LoadImageCorrectlyHandler(getContext(), this, url, mInsertId);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startAnimationIfNeeded();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimationIfNeeded();
    }

    @Override
    public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        if (mIsGif) {
            startAnimation();
        }
    }

    @Override
    public void setAdjustViewBounds(boolean adjustViewBounds) {
        mAdjustViewBounds = adjustViewBounds;
        super.setAdjustViewBounds(adjustViewBounds);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        Drawable mDrawable = getDrawable();
        if (mDrawable == null) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            return;
        }

        if (mAdjustViewBounds) {
            int mDrawableWidth = mDrawable.getIntrinsicWidth();
            int mDrawableHeight = mDrawable.getIntrinsicHeight();
            int heightSize = MeasureSpec.getSize(heightMeasureSpec);
            int widthSize = MeasureSpec.getSize(widthMeasureSpec);
            int heightMode = MeasureSpec.getMode(heightMeasureSpec);
            int widthMode = MeasureSpec.getMode(widthMeasureSpec);
            if (heightMode == MeasureSpec.EXACTLY && widthMode != MeasureSpec.EXACTLY) {
                // Fixed Height & Adjustable Width
                int height = heightSize;
                int width = height * mDrawableWidth / mDrawableHeight;
                if (isInScrollingContainer())
                setMeasuredDimension(width, height);
                else
                    setMeasuredDimension(Math.min(width, widthSize), Math.min(height, heightSize));
                } else if (widthMode == MeasureSpec.EXACTLY && heightMode != MeasureSpec.EXACTLY) {
                // Fixed Width & Adjustable Height
                int width = widthSize;
                int height = width * mDrawableHeight / mDrawableWidth;
                if (isInScrollingContainer())
                    setMeasuredDimension(width, height);
                else
                    setMeasuredDimension(Math.min(width, widthSize), Math.min(height, heightSize));
                } else {
                        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                }
            } else {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            }
    }

    private boolean isInScrollingContainer() {
        ViewParent p = getParent();
        while (p != null && p instanceof ViewGroup) {
            if (((ViewGroup) p).shouldDelayChildPressedState()) {
                return true;
            }
            p = p.getParent();
            }
        return false;
    }

    private int resolveAdjustedSize(int desiredSize, int measureSpec) {
        int result;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);
        switch (specMode) {
            case MeasureSpec.AT_MOST:
                // Parent says we can be as big as we want, up to specSize.
                // Don't be larger than specSize, and don't be larger than
                // the desired size imposed on ourselves.
                result = Math.min(desiredSize, specSize);
                break;
            case MeasureSpec.EXACTLY:
                // No choice. Do what we are told.
                result = specSize;
                break;
            default:
            case MeasureSpec.UNSPECIFIED:
                /* Parent says we can be as big as we want. Just don't be larger
                   than desired size imposed on ourselves.
                */
                result = desiredSize;
                break;
        }
        return result;
    }

    @Override
    public String getActionParam() {
        return mActionURL;
    }

    @Override
    public void setActionParam(String actionParam) {
        mActionURL = actionParam;
    }

    @NonNull
    @Override
    public CharSequence getElementId() {
        return getContentDescription();
    }

    @Override
    public Pair<OnSubmitAction, String> getOnSubmit() {
        // Default is close.
        return Pair.of(CLOSE, null);
    }

    @Override
    public void setOnSubmit(String onSubmit) {
    }

    private List<InsertCommand> mCommands = null;

    @Override
    public void setActions(List<InsertCommand> commands) {

        if (commands == null || commands.isEmpty()) {
            InsertLogger.d("No commands.");
            return;
        }

        mCommands = commands;
    }

    @Override
    public void onClick(View v) {

        if (mCommands == null || mCommands.isEmpty()) {
            InsertLogger.d("No commands.");
            return;
        }
        JavascriptRunner.InsertContext.addBasicParamsToInsertCommands(mCommands);
        InsertCommandDispatcher.getInstance().dispatchCommands(mCommands, UserEventType.TAP_ON, true);
    }

    public void startAnimationIfNeeded() {
        if (mIsGif && getDrawable() != null) {
            startAnimation();
        }
    }

    public void stopAnimationIfNeeded() {
        if (mIsGif && getDrawable() != null) {
            stopAnimation();
        }
    }
}
