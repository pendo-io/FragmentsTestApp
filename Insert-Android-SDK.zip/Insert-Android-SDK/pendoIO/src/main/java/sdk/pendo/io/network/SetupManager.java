package sdk.pendo.io.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.logging.InsertRemoteDebug;
import sdk.pendo.io.reactive.observers.InsertFlowableSubscriber;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.DeviceStateUtils;

import static sdk.pendo.io.network.SetupAction.ACCOUNT_ATTRIBUTES;
import static sdk.pendo.io.network.SetupAction.ACCOUNT_ID;
import static sdk.pendo.io.network.SetupAction.USER_ATTRIBUTES;
import static sdk.pendo.io.network.SetupAction.VISITOR_ID;

/**
 * Created by tomerlevinson on 4/10/16.
 * This class is responsible for the setup process we can go through after
 * receiving the authentication token.
 * The setup consists of actions to be done, init actions and other actions.
 * The init actions are actions that must be fulfilled before the inserts retrieval from the server.
 * The other actions have to be done, but aren't a must before the inserts retrieval.
 */
public final class SetupManager {

    private static final String SETTINGS_FIELD = "settings";
    private static final String DEBUG_SETTINGS_FIELD = "debug";
    private static final String REFRESH_INTERVAL_FIELD = "refreshInterval";
    private static final String OTHER_ACTIONS_FIELD = "otherActions";
    private static final String INIT_ACTIONS_FIELD = "initActions";
    private static final String REMOTE_DEBUG_MESSAGES_TAG = "messages";
    private static final String REMOTE_DEBUG_INFO_TAG = "info";
    private static final String PUSH_ID_KEY = "pushId";
    private static final int NOT_IN_ARRAY_INDEX = -1;
    private ArrayList<SetupAction> mOtherActions;
    private ArrayList<SetupAction> mInitActions;
    private BehaviorSubject<Boolean> mIsFinishedInitActionsSetup = BehaviorSubject.createDefault(false);
    private BehaviorSubject<Boolean> mIsFinishedSendingAppTermination = BehaviorSubject.createDefault(false);
    private BehaviorSubject<Boolean> mIsFinishedSendingPersistedAnalytics = BehaviorSubject.createDefault(false);
    private static BehaviorSubject<Boolean> sUserDataSent = BehaviorSubject.createDefault(false);
    private static BehaviorSubject<Boolean> sAccountDataSent = BehaviorSubject.createDefault(false);
    private static volatile SetupManager INSTANCE;

    private SetupManager() {
    }

    public void initSetupManager(JsonObject json) {
        mInitActions = new ArrayList<>();
        mOtherActions = new ArrayList<>();
        initFromJson(json);
    }

    public static synchronized SetupManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SetupManager();
        }

        return INSTANCE;
    }

    public synchronized void setUserDataSent(boolean wasSent) {
        sUserDataSent.onNext(wasSent);
    }

    public Observable<Boolean> getUserDataSent() {
        return sUserDataSent;
    }

    public Observable<Boolean> getAccountDataSent() {
        return sAccountDataSent;
    }

    public void setAccountDataSent(boolean wasSent) {
        sAccountDataSent.onNext(wasSent);
    }

    public void reset() {
        mIsFinishedInitActionsSetup.onNext(false);
        mInitActions.clear();
        mOtherActions.clear();
    }

    public BehaviorSubject<Boolean> getIsFinishedInitActionsSubject() {
        return mIsFinishedInitActionsSetup;
    }

    public void setIsFinishedSendingPersistedAnalytics(boolean finishedSendingPersistedAnalytics) {
        mIsFinishedSendingPersistedAnalytics.onNext(finishedSendingPersistedAnalytics);
    }


    private Maybe gotAllInitActionsObservable(JsonArray initActions) {
        return InsertCommandsEventBus.getInstance().getCommandEventBus()
                .filter(new Predicate<InsertCommand>() {
                    @Override
                    public boolean test(InsertCommand insertCommand) {
                        return insertCommand != null
                                && insertCommand.getDestinationId() != null
                                && insertCommand.getDestinationId().equals(
                                SetupAction.INIT_SETUP_ACTION);
                    }
                })
                .buffer(initActions.size())
                .firstElement();
    }

    private Maybe finishedSendingPendingAnalyticsObservable() {
        return getIsFinishedSendingPersistedAnalytics()
                .filter(new Predicate<Boolean>() {
                    @Override
                    public boolean test(Boolean b) {
                        return b;
                    }
                }).firstElement();
    }

    private void sendToServer(JSONObject responseJson, boolean isInitActions) {
        //Send to the server
        try {
            if (responseJson != null) {
                BackendApiManager.getInstance().sendSetupResult(responseJson, isInitActions, false, false);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
    }

    private JSONObject constructBulkResult(List<InsertCommand> commands) {
        JSONObject responseJsonObject = new JSONObject();
        for (InsertCommand insertCommand : commands) {
            responseJsonObject = constructSingleResult(insertCommand, responseJsonObject);
        }
        return responseJsonObject;
    }

    private JSONObject constructSingleResult(InsertCommand insertCommand, JSONObject responseJsonObject) {
        if (responseJsonObject == null) {
            responseJsonObject = new JSONObject();
        }
        InsertCommandsEventBus.Parameter receivedResponse = null;
        if (insertCommand != null && insertCommand.getParameters() != null
                && insertCommand.getParameters().size() > 0) {
            receivedResponse = insertCommand.getParameters().get(0);
        }
        if (receivedResponse != null) {
            try {
                JSONObject receivedResponseParam = null;
                String paramName = receivedResponse.getParameterName();
                if (paramName.equals(USER_ATTRIBUTES) ||
                        paramName.equals(ACCOUNT_ATTRIBUTES) ||
                        paramName.equals(SetupAction.REFRESH_DEVICE_INFO)) {
                    receivedResponseParam = new JSONObject(receivedResponse.getParameterValue());
                }
                responseJsonObject.put(
                        //Response param name
                        receivedResponse.getParameterName(),
                        //Response invocation result
                        receivedResponseParam == null ? receivedResponse.getParameterValue() : receivedResponseParam);
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return responseJsonObject;
    }


    private void registerSetupBulkActionsListener(JsonArray initActions) {
        Maybe.zip(
                gotAllInitActionsObservable(initActions),

                finishedSendingPendingAnalyticsObservable(),

                new BiFunction<List<InsertCommand>, Boolean, JSONObject>() {
                    @Override
                    public JSONObject apply(List<InsertCommand> insertCommands, Boolean o2) throws Exception {
                        return constructBulkResult(insertCommands);
                    }
                })
                .observeOn(Schedulers.io())
                .subscribe(InsertMaybeObserver.create(new Consumer<JSONObject>() {
                    @Override
                    public void accept(JSONObject commands) {
                        sendToServer(commands, true);
                    }
                }));
    }

    private void registerSetupSingleActionListener(final int id) {
        InsertCommandsEventBus.getInstance().getCommandEventBus()
                .filter(new Predicate<InsertCommand>() {
                    @Override
                    public boolean test(
                            InsertCommand insertCommand) {
                        return (insertCommand != null
                                && insertCommand.getDestinationId() != null
                                && insertCommand.getDestinationId().equals(
                                SetupAction.OTHER_SETUP_ACTION + id));
                    }
                })
                .observeOn(Schedulers.io())
                .subscribe(InsertFlowableSubscriber.create(
                        new Consumer<InsertCommand>() {
                            @Override
                            public void accept(InsertCommand insertCommand) {
                                sendToServer(constructSingleResult(insertCommand, new JSONObject()), false);
                            }
                        }));
    }

    private void checkIfDebugRemoteNeededAndInit(JsonObject initJsonObject) {
        if (initJsonObject.has(SETTINGS_FIELD)) {
            JsonObject settings = (JsonObject) initJsonObject.get(SETTINGS_FIELD);
            if (settings != null && settings.has(DEBUG_SETTINGS_FIELD)) {
                JsonObject settingsConfigurationJson = (JsonObject) settings.get(
                        DEBUG_SETTINGS_FIELD);
                if (settingsConfigurationJson != null
                        && settingsConfigurationJson.has(REFRESH_INTERVAL_FIELD)) {
                    final InsertRemoteDebug insertRemoteDebug = InsertRemoteDebug.getInstance();
                    insertRemoteDebug.setRefreshInterval(settingsConfigurationJson
                            .get(REFRESH_INTERVAL_FIELD)
                            .getAsInt());
                    // Tell timber to start logging.
                    insertRemoteDebug.clearRemoteDebugInfo();
                    insertRemoteDebug.setIsRefreshIntervalSet(true);
                    Observable.interval(insertRemoteDebug.getRefreshInterval(), TimeUnit.SECONDS, Schedulers.io())
                            .subscribe(InsertObserver.create(new Consumer<Long>() {
                                @Override
                                public void accept(Long aLong) {
                                    try {
                                        // Get insert logging info for the last "refreshInterval" milliseconds.
                                        JSONObject jsonToSend = new JSONObject();
                                        JSONArray loggingInfoArray = insertRemoteDebug.getRemoteDebuggingInfoAsJSONArray();
                                        insertRemoteDebug.clearRemoteDebugInfo();
                                        JSONObject deviceState = DeviceStateUtils.constructDeviceInfo();
                                        jsonToSend.put(REMOTE_DEBUG_MESSAGES_TAG, loggingInfoArray);
                                        jsonToSend.put(REMOTE_DEBUG_INFO_TAG, deviceState);
                                        //Send here to server.
                                        BackendApiManager.getInstance().sendDebugData(jsonToSend);
                                    } catch (Exception e) {
                                        InsertLogger.e(e, e.getMessage());
                                    }
                                }
                            }));
                }
            }
        }
    }

    private void initFromJson(JsonObject initJsonObject) {
        // Get other actions array.
        JsonArray otherActions = (JsonArray) initJsonObject.get(OTHER_ACTIONS_FIELD);
        // Get init actions array.
        JsonArray initActions = (JsonArray) initJsonObject.get(INIT_ACTIONS_FIELD);

        /*
            In case we receive user attributes/visitorId/accountId in the initSDK call, put them inside
            the init actions json, so that the setting them will happen before the init.
         */
        if (Pendo.getUserData() != null) {
            moveOtherActionToInitActions(initActions, otherActions, USER_ATTRIBUTES);
        }
        if (Pendo.getAccountData() != null) {
            moveOtherActionToInitActions(initActions, otherActions, ACCOUNT_ATTRIBUTES);
        }
        if (Pendo.getVisitorId() != null) {
            moveOtherActionToInitActions(initActions, otherActions, VISITOR_ID);
        } else {
            otherActions = removeFromOtherActions(otherActions, VISITOR_ID);
        }
        if (Pendo.getAccountId() != null) {
            moveOtherActionToInitActions(initActions, otherActions, ACCOUNT_ID);
        } else {
            otherActions = removeFromOtherActions(otherActions, ACCOUNT_ID);
        }

        if (initActions != null && initActions.getAsJsonArray() != null && initActions.getAsJsonArray().size() > 0) {
            registerSetupBulkActionsListener(initActions);
            //Parse init actions
            for (int i = 0; i < initActions.size(); i++) {
                mInitActions.add(new SetupAction((JsonObject) initActions.get(i), true));
                mInitActions.get(i).invoke();
            }
        } else {
            mIsFinishedInitActionsSetup.onNext(true);
        }

        if (otherActions != null && otherActions.getAsJsonArray() != null && otherActions.getAsJsonArray().size() > 0) {
            for (int i = 0; i < otherActions.size(); i++) {
                registerSetupSingleActionListener(i);
                mOtherActions.add(new SetupAction((JsonObject) otherActions.get(i), false, i));
                mOtherActions.get(i).invoke();
            }
        }
    }

    /**
     * Remove setupAction from other action and return a new JsonArray.
     *
     * @param otherActions
     * @param setupActionName
     * @return a new JsonArray that doesn't have actions named setupActionName
     */
    private JsonArray removeFromOtherActions(JsonArray otherActions, String setupActionName) {
        JsonArray newOtherActions = new JsonArray();
        if (otherActions != null && otherActions.size() > 0) {
            for (int i = 0; i < otherActions.size(); i++) {
                JsonObject otherAction = otherActions.get(i).getAsJsonObject();
                if (!otherAction.toString().contains(setupActionName)) {
                    newOtherActions.add(otherAction);
                }
            }
        }
        return newOtherActions;
    }

    /**
     * Looks for the given setupAction name inside 'other actions' and moves it to 'init actions'.
     *
     * @param initActions     - list of init actions to which we add the setupActionName.
     * @param otherActions    - list of other actions from which we remove the setupActionName.
     * @param setupActionName - the name of the setupAction we are looking for.
     */
    private void moveOtherActionToInitActions(JsonArray initActions, JsonArray otherActions, String setupActionName) {
        int index = NOT_IN_ARRAY_INDEX;
        if (otherActions != null && otherActions.size() > 0) {
            for (int i = 0; i < otherActions.size(); i++) {
                JsonObject otherAction = otherActions.get(i).getAsJsonObject();
                if (otherAction.toString().contains(setupActionName)) {
                    initActions.add(otherAction);
                    index = i;
                    break;
                }
            }
            if (index != NOT_IN_ARRAY_INDEX) {
                otherActions.remove(index);
            }
        }
    }

    /**
     * Sends the registration token to our backend.
     *
     * @param pushId The new Push ID.
     */
    public void sendPushIdToServer(String pushId) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(PUSH_ID_KEY, pushId);
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
        sendToServer(jsonObject, false);
    }

    public BehaviorSubject<Boolean> getIsFinishedSendingPersistedAnalytics() {
        return mIsFinishedSendingPersistedAnalytics;
    }
}
