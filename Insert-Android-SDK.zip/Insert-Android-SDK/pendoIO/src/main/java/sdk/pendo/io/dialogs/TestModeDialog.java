package sdk.pendo.io.dialogs;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.network.socketio.SocketIOManager;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;

public final class TestModeDialog extends DialogFragment {
    private static final String NAME_TAG = "insertNames";
    private static final int LAYOUT_ID = R.layout.activity_test_mode;

    public static TestModeDialog newInstance(String insertNames) {
        TestModeDialog testModeDialog = new TestModeDialog();

        Bundle args = new Bundle();
        args.putString(NAME_TAG, insertNames);
        testModeDialog.setArguments(args);

        return testModeDialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(LAYOUT_ID, container, false);
        String insertNamesToDisplay = getArguments().getString(NAME_TAG);
        View tv = v.findViewById(R.id.insert_active_inserts);
        ((TextView) tv).setText(insertNamesToDisplay);
        InsertContentDescriptionManager.getInstance().setContentDescription(tv,
                insertNamesToDisplay, null);
        // Setting the dialog background color
        getDialog().getWindow().setBackgroundDrawableResource(R.color.insert_backgrpund_test_dialog);
        // Dismiss when the user touches the dialog
        RelativeLayout layout = (RelativeLayout) v.findViewById(R.id.insert_testmode_container);
        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        View disconnectPermenantBtn = v.findViewById(R.id.btnDisconnectPermanently);
        disconnectPermenantBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SocketIOUtils.removeSessionDetails();
                SocketIOManager.getInstance().terminateSessionAndReInit();
                SocketIOManager.getInstance().disconnect();
                Toast.makeText(getActivity(), getResources().getString(R.string.insert_disconnected_permanently), Toast.LENGTH_SHORT).show();
                dismiss();
            }
        });

        View disconnectSessionOnlyBtn = v.findViewById(R.id.btnDisconnectSession);
        disconnectSessionOnlyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SocketIOManager.getInstance().terminateSessionAndReInit();
                SocketIOManager.getInstance().disconnect();
                Toast.makeText(getActivity(), getResources().getString(R.string.insert_disconnected_for_current_session), Toast.LENGTH_SHORT).show();
                dismiss();
            }
        });

        return v;
    }
}
