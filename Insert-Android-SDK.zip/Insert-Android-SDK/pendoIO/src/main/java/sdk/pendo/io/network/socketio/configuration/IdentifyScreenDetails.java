package sdk.pendo.io.network.socketio.configuration;

import com.google.gson.annotations.SerializedName;

/**
 *
 * This class is used for data extraction from server request,
 * once entering identify mode.
 */
public class IdentifyScreenDetails {

    @SerializedName("sid")
    public String sessionId;

    @SerializedName("from")
    public String from;

    @SerializedName("timestamp")
    public long timestamp;

    @SerializedName("data")
    public IdentifyScreenData data;

}
