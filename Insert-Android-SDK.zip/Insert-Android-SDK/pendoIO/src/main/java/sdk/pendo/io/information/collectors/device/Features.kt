package sdk.pendo.io.information.collectors.device

import org.json.JSONArray
import org.json.JSONObject
import sdk.pendo.io.information.collectors.Collector
import sdk.pendo.io.utilities.add

/**
 * Collect information about the device's features.

 * Created by assaf on 4/14/15.
 */
internal class Features : Collector() {

    override fun collectData(json: JSONObject) {

        // Get available device features (e.g. camera, bluetooth).
        addDeviceAvailableFeatures(json)
    }

    /**
     * Adds JSONArray with all of the device available features.

     * @param info The JSONObject to receive the device available features.
     */
    private fun addDeviceAvailableFeatures(info: JSONObject) {
        val pm = application!!.packageManager
        val systemAvailableFeatures = pm.systemAvailableFeatures
        val deviceFeatures = JSONArray()
        for (feature in systemAvailableFeatures) {
            deviceFeatures.add(feature.name)
        }

        info.add(DeviceInfoConstants.FEATURES, deviceFeatures)
    }
}
