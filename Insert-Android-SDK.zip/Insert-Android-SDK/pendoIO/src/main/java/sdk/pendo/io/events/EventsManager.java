package sdk.pendo.io.events;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.SparseArray;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.network.responses.ElementModel;
import sdk.pendo.io.network.responses.ScreenIdentificationData;
import sdk.pendo.io.network.responses.ScreenModel;
import sdk.pendo.io.network.responses.TriggerModel;
import sdk.pendo.io.utilities.GuideUtils;
import sdk.pendo.io.utilities.TriggerUtils;

import static sdk.pendo.io.events.InsertEvent.EventActions;

/**
 * Pendo's events manager.
 * <p/>
 * Created by assaf on 4/28/15.
 */
public final class EventsManager {

    public static final String NAME_SCREEN_ANY = "__screen_any__";
    public static final String NAME_ELEMENT_ANY = "__element_any__";

    private static volatile EventsManager INSTANCE;

    private static BehaviorSubject<Boolean> sIsInitedObservable = BehaviorSubject.createDefault(false);
    //    private final HashMap<String, List<ElementModel>> mScreenToElementMapping = new HashMap<>();
    private SparseArray<String> mScreenIdToScreenNameMapping = new SparseArray<>();
    private HashMap<EventActions, List<InsertEvent>> mGeneralApplicationInserts = new HashMap<>();
    private HashMap<String, ActivityModel> mActivities = new HashMap<>();
    private SparseArray<TriggerModel> mFlowTriggers = new SparseArray<>();
    private LinkedList<ScreenModel> mScreenAnyScreenModels = new LinkedList<>();
    private volatile HashSet<Integer> mDispatchedTriggers = new HashSet<>();

    private EventsManager(@NonNull List<ScreenModel> models) {
        populateEventsMapping(models);
    }

    public static synchronized EventsManager getInstance()
            throws EventsManagerNotReadyException {
        if (INSTANCE == null) {
            throw new EventsManagerNotReadyException("EventsManager is not yet instantiated. This is ok if Visitor has " +
                    "been switched and initializing with new visitor has not yet finished.");
        }

        return INSTANCE;
    }

    public static class EventsManagerNotReadyException extends IllegalStateException {

        public EventsManagerNotReadyException(String message) {
            super(message);
        }
    }

    public static synchronized void init(@NonNull List<ScreenModel> screens)
            throws IllegalStateException {

        if (INSTANCE == null) {
            INSTANCE = new EventsManager(screens);
            sIsInitedObservable.onNext(true);
        } else {
            InsertLogger.w("Cannot init more than once.");
            throw new IllegalStateException("EventsManager already initiated. "
                    + "if you need to repopulate the events mapping use repopulateEventsMapping");
        }
    }

    public synchronized void reset() {
        mScreenIdToScreenNameMapping.clear();
        mGeneralApplicationInserts.clear();
        mActivities.clear();
        mFlowTriggers.clear();
        mScreenAnyScreenModels.clear();
        mDispatchedTriggers.clear();
    }

    public InsertEvent getAppLaunchEvent() {
        return getEventByAction(null, EventActions.APP_LAUNCHED);
    }

    private void populateEventsMapping(@NonNull List<ScreenModel> screens) {
        for (ScreenModel screen : screens) {

            // Populate app level actions
            final ScreenIdentificationData screenIdentificationData =
                    screen.screenIdentificationData;

            if (screenIdentificationData == null) {
                continue;
            }

            String activity = screenIdentificationData.getActivityName();
            if (activity != null && activity.equals(NAME_SCREEN_ANY)) {
                populateGeneralAppEvents(screen);
                mScreenAnyScreenModels.add(screen);
                continue;
            }

            ActivityModel activityModel = mActivities.get(activity);

            if (activityModel == null) {
                activityModel = new ActivityModel(activity);
                mActivities.put(activity, activityModel);
            }

            final boolean screenAdded = activityModel.addScreen(screen);

            if (screenAdded) {
                InsertLogger.i("Screen added to: " + activity);
            } else {
                InsertLogger.d("Screen not added to: " + activity);
            }

            // TODO: 10/22/15 We should try to think of a better way to do this:
            mScreenIdToScreenNameMapping.put(screen.id, activity);

            for (ElementModel element : screen.elements) {
                List<InsertEvent> events = element.events;
                if (events != null) {
                    for (InsertEvent event : events) {
                        String action = event.getConfiguration().getAction();
                        if (action != null && action.equals(EventActions.SCREEN_LEFT.action)) {
                            if (event.getTriggers() != null) {
                                for (TriggerModel trigger : event.getTriggers()) {
                                    trigger.setSatisfiesFlow(false);
                                    trigger.setScreenId(screen.id);
                                    mFlowTriggers.put(trigger.getId(), trigger);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void populateGeneralAppEvents(ScreenModel screen) {
        for (ElementModel element : screen.elements) {
            List<InsertEvent> events = element.events;
            if (events != null) {
                for (InsertEvent event : events) {
                    String action = event.getConfiguration().getAction();
                    List<InsertEvent> eventList = mGeneralApplicationInserts.get(EventActions.get(action));
                    if (eventList == null) {
                        eventList = new ArrayList<>();
                    }
                    eventList.add(event);
                    mGeneralApplicationInserts.put(EventActions.get(action), eventList);
                }
            }
        }
    }

    @Nullable
    public String getScreenNameFromId(int id) {
        return mScreenIdToScreenNameMapping.get(id);
    }

    @Nullable
    public ElementModel getElementByScreenNameAndElementId(String screen, int elementId) {

        final ActivityModel activityModel = mActivities.get(screen);

        if (activityModel == null) {
            InsertLogger.d("Not activity model for given screen: " + screen);
            return null;
        }

        return activityModel.getElement(elementId);
    }

    public boolean hasElementsForActivity(String activityName) {
        if (activityName == null) {
            return false;
        }
        final ActivityModel activityModel = mActivities.get(activityName);

        return activityModel != null && activityModel.hasElements();
    }

    public boolean hasElementsWithEventsForActivity(String activityName) {
        if (activityName == null) {
            return false;
        }
        final ActivityModel activityModel = mActivities.get(activityName);

        return activityModel != null && activityModel.hasElementsWithEvents();
    }

    public boolean hasViewManipulationsForActivity(String activityName) {
        if (activityName == null) {
            return false;
        }
        final ActivityModel activityModel = mActivities.get(activityName);

        return activityModel != null && activityModel.hasViewManipulations();
    }

    public InsertEvent getEventByAction(@NonNull String activityLocalClassName,
                                        @NonNull EventActions eventAction) {
        return getEventByActionAndIdentification(activityLocalClassName, eventAction, null);
    }

    @Nullable
    public ElementModel getElement(@NonNull String activityLocalClassName,
                                   @Nullable IdentificationData identificationData) {

        final ActivityModel activityModel = mActivities.get(activityLocalClassName);

        if (activityModel == null) {
            return null;
        }

        if (identificationData == null) {
            return null;
        }

        return activityModel.getElement(identificationData);
    }

    /**
     * Returns all elements that match the given {@link IdentificationData}.
     *
     * @param activityLocalClassName the activity name. if null,
     *                               the identification data will be compared to elements
     *                               across all activity models
     * @param identificationData     the {@link IdentificationData} to match.
     * @return all elements that match the given {@link IdentificationData},
     * if the given {@code identificationData} is null returns null.
     */
    @Nullable
    public List<ElementModel> getAllElements(@Nullable String activityLocalClassName,
                                             @Nullable IdentificationData identificationData) {
        if (identificationData == null) {
            return null;
        }

        List<ElementModel> elements = new ArrayList<>();

        if (activityLocalClassName == null) {
            // There is a need to ignore the activity itself - occurs when the drawer is opened
            // get the identical elements across all activity models
            for (ActivityModel activityModel : mActivities.values()) {
                elements.addAll(activityModel.getAllElements(identificationData));
            }
        } else {
            final ActivityModel activityModel = mActivities.get(activityLocalClassName);
            elements.addAll(activityModel.getAllElements(identificationData));
        }

        return elements;
    }

    @Nullable
    public List<InsertEvent> getViewManipulationElement(
            @NonNull String activityLocalClassName,
            @NonNull IdentificationData identificationData) {

        if (activityLocalClassName == null) {
            return null;
        }
        final ActivityModel activityModel = mActivities.get(activityLocalClassName);

        if (activityModel == null) {
            return null;
        }

        return activityModel.getVisualManipulationElement(identificationData);
    }

    @Nullable
    public HashSet<String> getTextModificationStrings(@NonNull String activityLocalClassName) {
        if (activityLocalClassName == null) {
            return null;
        }

        final ActivityModel activityModel = mActivities.get(activityLocalClassName);

        if (activityModel == null) {
            return null;
        }

        return activityModel.getTextModificationStrings();
    }

    @Nullable
    public InsertEvent getEventByActionAndElement(@NonNull EventActions eventAction,
                                                  @NonNull ElementModel element) {
        if (element.events != null) {
            for (InsertEvent event : element.events) {
                if (eventAction.equals(event.getConfiguration().getAction())) {
                    return event;
                }
            }
        }

        InsertLogger.d("Did not find an event for action '" + eventAction + "' and given element.");
        return null;
    }

    @Nullable
    public InsertEvent getEventByActionAndIdentification(
            @NonNull String activityLocalClassName,
            @NonNull EventActions eventAction,
            @Nullable IdentificationData identificationData) {

        if (EventActions.APP_LAUNCHED.equals(eventAction)) {
            return getAppLaunchInsertEvent();
        }

        ElementModel element = getElement(activityLocalClassName, identificationData);

        if (element != null) {

            if (identificationData != null) {
                return getEventByActionAndElement(eventAction, element);
            } else {
                return getEventByActionAndElement(EventActions.SCREEN_VIEW, element);
            }
        }

        return null;
    }

    public InsertEvent getAppLaunchInsertEvent() {
        InsertEvent result = null;
        List<InsertEvent> appLaunchInserts = mGeneralApplicationInserts.get(EventActions.APP_LAUNCHED);
        if (appLaunchInserts != null) {
            result = appLaunchInserts.get(0);
        }
        return result;
    }

    public HashMap<String, List<ElementModel>> getScreenToElementMapping() {

        HashMap<String, List<ElementModel>> retMap = new HashMap<>();

        for (ActivityModel activity : mActivities.values()) {
            retMap.put(activity.getActivityName(), activity.getAllElements());
        }

        return retMap;
    }


    public InsertEvent getDirectLinkEventByTriggerId(int triggerId) {
        List<InsertEvent> directLinkInsertsList =
                mGeneralApplicationInserts.get(EventActions.DIRECT_LINK);

        if (directLinkInsertsList != null) {
            for (InsertEvent directLinkEvent : directLinkInsertsList) {
                for (TriggerModel trigger : directLinkEvent.getTriggers()) {
                    if (trigger.getId() == triggerId) {
                        return directLinkEvent;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Resets the showing state of all sensitive screen states that aren't the given activity name.
     *
     * @param localClassName the activity's name to ignore.
     */
    public void resetSensitiveStates(String localClassName) {

        // If the activity to ignore is Pendo's activity, don't reset any state.
        if (!GuideUtils.isInsertActivity(localClassName)) {
            for (ActivityModel activity : mActivities.values()) {

                if (!activity.getActivityName().equals(localClassName)) {
                    activity.resetAllStates();
                }
            }
        }
    }

    @Nullable
    public ActivityModel getActivityModelByName(String localClassName) {
        return mActivities.get(localClassName);
    }

    @Nullable
    public TriggerModel getFlowTrigger(int triggerId) {
        return mFlowTriggers.get(triggerId);
    }

    public void handleFlowTriggersIfNeeded(View root) {
        for (int i = 0; i < mFlowTriggers.size(); i++) {
            TriggerModel trigger = mFlowTriggers.get(mFlowTriggers.keyAt(i));
            if (trigger.satisfiesFlow()) {
                if (TriggerUtils.satisfiesAllConditions(trigger, root)) {
                    InsertsManager.getInstance().runScreenLeftTrigger(trigger);
                }
            }
        }
    }

    public void setTriggerDispatched(int triggerId) {
        mDispatchedTriggers.add(triggerId);
    }

    public boolean wasTriggerDispatched(int triggerId) {
        return mDispatchedTriggers.contains(triggerId);
    }

    public void resetTriggerDispatched(int triggerId) {
        mDispatchedTriggers.remove(triggerId);
    }
}
