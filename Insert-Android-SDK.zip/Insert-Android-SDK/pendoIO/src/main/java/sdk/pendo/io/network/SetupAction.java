package sdk.pendo.io.network;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommand.InsertCommandScope;
import sdk.pendo.io.actions.InsertCommandAction;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.reactive.observers.InsertObserver;

import sdk.pendo.io.utilities.script.JavascriptRunner;
import sdk.pendo.io.information.collectors.DeviceInfoCollector;
import sdk.pendo.io.logging.InsertLogger;

import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;

/**
 * Created by tomerlevinson on 4/10/16.
 * <p>
 * This class is responsible for the creation of SetupAction.
 * SetupAction - a json of the following type:
 * "name": "functionToInvokeName",
 * "parameters": [
 * {
 * "name": "Param1Name",
 * "value": "Param1Value",
 * "type": "string"
 * }
 * ],
 * "response": {
 * "name": "resultParamName",
 * "type": "resultParamType"
 * }
 * <p>
 * The class is responsible on invoking the received operations as
 * depicted above.
 * <p>
 * The invocation should look like so for the example above:
 * resultParamType resultParamName = functionToInvokeName(Param1Value)
 * where Param1Value's name is Param1Name and type is java.lang.String
 */
public final class SetupAction {
    private InsertRPC.InsertRPCEnum mFunctionToInvoke;
    private ArrayList<SetupParamModel> mSetupParams;
    private InsertCommandsEventBus.Parameter mResponse;
    private boolean mIsInitSetupAction;
    private int mId;

    private static final String NAME_FIELD = "name";
    private static final String PARAMETERS_FIELD = "parameters";
    private static final String RESPONSE_FIELD = "response";
    private static final String TYPE_FIELD = "type";
    private static final String VALUE_FIELD = "value";

    public static final String USER_ATTRIBUTES = "userAttr";
    public static final String ACCOUNT_ATTRIBUTES = "accountAttr";
    public static final String VISITOR_ID = "visitorId";
    public static final String ACCOUNT_ID = "accountId";
    public static final String PUSH_ID = "pushId";
    public static final String REFRESH_DEVICE_INFO = "deviceInfo";
    public static final String BAD_INVOCATION_RESULT = "badInvocationResponse";
    public static final String DEFAULT_RESPONSE_VALUE = "setupActionResponse";
    public static final String INIT_SETUP_ACTION = "initSetupAction";
    public static final String SETUP_ACTION = "setupAction";
    public static final String OTHER_SETUP_ACTION = "otherSetupAction";
    public static final String COMMAND_INIT = "commandInit";

    /*
     * C'tor for the SetupAction that receives a json object and a boolean
     * saying whether the action we want to create is an obligatory action or not.
     * Obligatory actions are actions that must occur before the initialization from the backend,
     * these actions can be spotted under the initActions json we receive from the server.
     */
    public SetupAction(JsonObject setupActionJson, boolean isInit) {
        mFunctionToInvoke = InsertRPC.InsertRPCEnum.get(
                setupActionJson.get(NAME_FIELD).getAsString());
        mIsInitSetupAction = isInit;
        mSetupParams = new ArrayList<>();
        JsonObject responseJson = (JsonObject) setupActionJson.get(RESPONSE_FIELD);
        mResponse = new InsertCommandsEventBus.Parameter(responseJson.get(NAME_FIELD).getAsString(),
                responseJson.get(TYPE_FIELD).getAsString(), DEFAULT_RESPONSE_VALUE);
        JsonArray setupParams = setupActionJson.getAsJsonArray(PARAMETERS_FIELD);
        if (setupParams != null && setupParams.size() > 0) {
            for (JsonElement setupParam : setupParams) {
                JsonObject currentObject = (JsonObject) setupParam;
                Object nameField = currentObject.get(NAME_FIELD);
                Object typeField = currentObject.get(TYPE_FIELD);
                Object valueField = currentObject.get(VALUE_FIELD);
                mSetupParams.add(new SetupParamModel(
                        nameField != null ? nameField.toString().replace("\'", "").replace("\"",
                                "") : null,
                        typeField != null ? typeField.toString().replace("\'", "").replace("\"",
                                "") : null,
                        valueField != null ? valueField.toString().replace("\'", "").replace("\"",
                                "") : null));
            }
        }
    }

    /*
     * Explanation as above with an id parameter for action identification purposes.
     */
    public SetupAction(JsonObject setupActionJson, boolean isInit, int id) {
        this(setupActionJson, isInit);
        mId = id;
    }

    public void invoke() {
        Method method = null;
        Class<?>[] paramTypes = null;
        Object[] parameters = null;
        if (mSetupParams != null) {
            paramTypes = new Class<?>[mSetupParams.size()];
            parameters = new Object[mSetupParams.size()];
            for (int i = 0; i < mSetupParams.size(); i++) {
                paramTypes[i] = mSetupParams.get(i).getTypeOfValue();
                parameters[i] = mSetupParams.get(i).getTypeOfValue().cast(
                        mSetupParams.get(i).getValue());
            }
        }
        // Try and get function we want to invoke.
        try {
            method = SetupAction.class.getMethod(mFunctionToInvoke.getRpcFunction(), paramTypes);
        } catch (NoSuchMethodException e) {
            InsertLogger.e(e, e.getMessage());
        }
        // Invoke the function if it exists.
        if (method != null) {
            try {
                Object invocationResult = method.invoke(this, parameters);
                // In case we don't have to wait for the key,
                // send message on the bus after invocation.
                // Otherwise the message will be sent on the bus after callback of waitForKey.
                if (invocationResult != null &&
                        !mFunctionToInvoke.getRpcFunction().equals(
                                InsertRPC.InsertRPCEnum.WAIT_FOR_KEY.getRpcFunction())) {
                    InsertCommandDispatcher.getInstance().dispatchCommand(
                            new InsertCommand(
                                    COMMAND_INIT,
                                    SETUP_ACTION,
                                    mIsInitSetupAction ? INIT_SETUP_ACTION
                                            : OTHER_SETUP_ACTION + mId,
                                    //Any action
                                    InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                                    //Any event.
                                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY,
                                    //Invocation result
                                    createResponseParam(invocationResult)), false);
                }
            } catch (IllegalAccessException e) {
                InsertLogger.d("Illegal Access Exception when invoking.");
                InsertLogger.e(e, e.getMessage());
            } catch (InvocationTargetException e) {
                if (!InsertRPC.InsertRPCEnum.WAIT_FOR_KEY.equals(mFunctionToInvoke)) {
                    // Send empty extra message to the bus.
                    // This has to be sent for the buffering/ listeners not to be stuck.
                    InsertCommandDispatcher.getInstance().dispatchCommand(
                            new InsertCommand(
                                    COMMAND_INIT,
                                    SETUP_ACTION,
                                    mIsInitSetupAction ? INIT_SETUP_ACTION
                                            : OTHER_SETUP_ACTION + mId,
                                    //Any action
                                    InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                                    //Any event.
                                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY), false);
                }
                InsertLogger.d("Invocation target exception.");
                InsertLogger.e(e, e.getMessage());
            }
        }
    }

    /*
     * Creates a response parameter.
     */
    InsertCommandsEventBus.Parameter createResponseParam(Object invocationResult) {
        return new InsertCommandsEventBus.Parameter(
                mResponse.getParameterName(),
                mResponse.getValueType(),
                invocationResult != null ? (invocationResult.toString()) : BAD_INVOCATION_RESULT);
    }
    /*
     * **************************
     * Invocation functions area.
     * **************************
     */

    @SuppressWarnings("unused")
    public String evaluate(String script) {
        Class<?> responseType = String.class;
        if (TYPE_STRING.equals(mResponse.getValueType())) {
            responseType = String.class;

        }
        Object jsInvocationResult = JavascriptRunner.runCode(script, responseType);
        if (jsInvocationResult != null) {
            return (String) jsInvocationResult;
        }
        return null;
    }

    @SuppressWarnings("unused")
    public void waitForKey(String key) {
        switch (key) {
            case VISITOR_ID:
                String currentVisitorId = Pendo.getVisitorId();
                if (currentVisitorId != null) {
                    InsertCommandDispatcher.getInstance().dispatchCommand(
                            new InsertCommand(
                                    COMMAND_INIT,
                                    SETUP_ACTION,
                                    mIsInitSetupAction ? INIT_SETUP_ACTION
                                            : OTHER_SETUP_ACTION + mId,
                                    //Any action
                                    InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                                    //Any event.
                                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY,
                                    //Invocation result
                                    createResponseParam(currentVisitorId)), false);
                }
                break;
            case ACCOUNT_ID:
                String currentAccountId = Pendo.getAccountId();
                if (currentAccountId != null) {
                    InsertCommandDispatcher.getInstance().dispatchCommand(
                            new InsertCommand(
                                    COMMAND_INIT,
                                    SETUP_ACTION,
                                    mIsInitSetupAction ? INIT_SETUP_ACTION
                                            : OTHER_SETUP_ACTION + mId,
                                    //Any action
                                    InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                                    //Any event.
                                    InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                    InsertCommandScope.INSERT_COMMAND_SCOPE_ANY,
                                    //Invocation result
                                    createResponseParam(currentAccountId)), false);
                }
                break;
            case PUSH_ID:
//                Pendo.getPushIdAsObservable().filter(new Predicate<Boolean>() {
//                    @Override
//                    public boolean test(Boolean isPushIdSet) {
//                        return isPushIdSet;
//                    }
//                }).subscribe(InsertObserver.create(new Consumer<Boolean>() {
//                    @Override
//                    public void accept(Boolean isSet) {
//                        //Send command on bus
//                        InsertCommandDispatcher.getInstance().dispatchCommand(
//                                new InsertCommand(
//                                        COMMAND_INIT,
//                                        SETUP_ACTION,
//                                        mIsInitSetupAction ? INIT_SETUP_ACTION
//                                                : OTHER_SETUP_ACTION + mId,
//                                        //Any action
//                                        InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
//                                        //Any event.
//                                        InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
//                                        InsertCommandScope.INSERT_COMMAND_SCOPE_ANY,
//                                        //Invocation result
//                                        createResponseParam(Pendo.getPushId())), false);
//                    }
//                }));
                break;
            case REFRESH_DEVICE_INFO:
                JSONObject deviceInfo = new JSONObject();
                DeviceInfoCollector deviceInfoCollector = Pendo.getInstance().deviceInformationCollector();
                deviceInfoCollector.addInformation(deviceInfo);

                try {
                    deviceInfo = deviceInfo.getJSONObject(DeviceInfoCollector.Companion
                            .getDEVICE_INFO());
                } catch (JSONException e) {
                    InsertLogger.e(e, e.getMessage());
                }

                //Send command on bus
                InsertCommandDispatcher.getInstance().dispatchCommand(
                        new InsertCommand(
                                COMMAND_INIT,
                                SETUP_ACTION,
                                mIsInitSetupAction ? INIT_SETUP_ACTION
                                        : OTHER_SETUP_ACTION + mId,
                                //Any action
                                InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                                //Any event.
                                InsertCommandEventType.INSERT_COMMAND_EVENT_TYPE_ANY,
                                InsertCommandScope.INSERT_COMMAND_SCOPE_ANY,
                                //Invocation result
                                createResponseParam(deviceInfo)), false);
                break;
            default:
                InsertLogger.d("Unknown key: " + key);
                break;
        }
    }
}
