package sdk.pendo.io.views;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.views.listener.FloatingListenerButton;

/**
 * Flash effect view.
 * <p/>
 * Created by assaf on 4/13/15.
 */
public class FlashView extends View {

    final static Interpolator INTERPOLATOR = new AccelerateInterpolator();

    private ViewGroup mRoot;
    private FloatingListenerButton mFloatingButton;

    public interface OnFlashViewFinished {

        public void flashFinished();
    }

    public FlashView(Context context) {
        super(context);
    }

    /**
     * Init the view.
     *
     * @param caller The view that calls this flash view.
     * @return The FlashView instance for chaining.
     */
    public FlashView init(View caller, FloatingListenerButton floatingButton) {
        mRoot = (ViewGroup) caller;
        mFloatingButton = floatingButton;

        DisplayMetrics displayMetrics = Pendo.getApplicationContext().getResources().getDisplayMetrics();
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(width, height);
        setAlpha(0.5f);
        setBackgroundColor(Color.WHITE);

        mRoot.addView(this, params);

        ObjectAnimator fadeIn = ObjectAnimator.ofFloat(this, View.ALPHA, 0.5f, 1);
        ObjectAnimator fadeOut = ObjectAnimator.ofFloat(this, View.ALPHA, 1, 0);
        AnimatorSet anim = new AnimatorSet();
        anim.playSequentially(fadeIn, fadeOut);
        anim.setInterpolator(INTERPOLATOR);
        anim.setDuration(50);

        anim.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                setVisibility(View.GONE);
                mRoot.removeView(FlashView.this);
                if (mFloatingButton != null) {
                    mFloatingButton.flashFinished();
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });

        anim.start();

        return this;
    }
}
