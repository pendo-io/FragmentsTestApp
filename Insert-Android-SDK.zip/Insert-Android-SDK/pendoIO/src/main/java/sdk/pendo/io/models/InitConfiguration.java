package sdk.pendo.io.models;

import com.google.gson.annotations.SerializedName;

public class InitConfiguration {

    @SerializedName("analytics")
    private AnalyticsConfigurationModel mInitAnalyticsModel;

    @SerializedName("sessionTimeout")
    private int mSessionTimeout;

    @SerializedName("debug")
    private DebugConfigurationModel mDebugConfigurationModel;

    @SerializedName("guides")
    private GuidesConfigurationModel mGuidesConfigurationModel;

    public int getSessionTimeout() {
        return mSessionTimeout;
    }

    public void setSessionTimeout(int sessionTimeout) {
        this.mSessionTimeout = sessionTimeout;
    }

    public AnalyticsConfigurationModel getInitAnalyticsModel() {
        return mInitAnalyticsModel;
    }

    public DebugConfigurationModel getDebugConfigurationModel() {
        return mDebugConfigurationModel;
    }

    public GuidesConfigurationModel getGuidesConfigurationModel() {
        return mGuidesConfigurationModel;
    }
}
