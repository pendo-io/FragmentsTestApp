package sdk.pendo.io.exceptions

import java.lang.Exception

/**
 * Pendo's exception for errors.
 *
 * Created by Oren Dayan 21/1/20
 */
class PendoException(message: String) : Exception(message)