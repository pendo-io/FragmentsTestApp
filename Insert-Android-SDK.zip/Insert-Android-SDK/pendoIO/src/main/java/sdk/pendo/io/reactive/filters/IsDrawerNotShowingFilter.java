package sdk.pendo.io.reactive.filters;

import io.reactivex.functions.Predicate;

/**
 * Created by tomerlevinson on 2/7/16.
 */
public class IsDrawerNotShowingFilter implements Predicate<Boolean> {
    @Override
    public boolean test(Boolean isDrawerShowing) {
        return !isDrawerShowing;
    }
}
