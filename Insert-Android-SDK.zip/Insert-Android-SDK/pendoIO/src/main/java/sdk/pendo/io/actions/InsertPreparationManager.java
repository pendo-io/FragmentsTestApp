package sdk.pendo.io.actions;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.squareup.picasso.Callback;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;

import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.actions.InsertCommandAction.InsertInternalAction;
import sdk.pendo.io.actions.InsertCommandsEventBus.Parameter;
import sdk.pendo.io.cache.InsertGifCache;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.utilities.AnalyticsUtils;

import static sdk.pendo.io.actions.InsertCommandEventType.InsertPreparationEventType.PREFETCH_IMAGES_END;

/**
 * A class for preparing perquisites before inserts are shown.
 * For example, prefetch image before insert is shown.
 */
public final class InsertPreparationManager {
    private static volatile InsertPreparationManager sInstance;

    public static final String COMMAND_ACTION_DESTINATION = "InsertPreparationManager";

    private static final String IMAGE_FETCH_RESULT = "ImageFetchResult";
    private static final String GIF_FILENAME_EXTENSION = ".gif";
    private static final Parameter SUCCESS = new Parameter(IMAGE_FETCH_RESULT, "boolean", "true");
    private static final Parameter FAIL = new Parameter(IMAGE_FETCH_RESULT, "boolean", "false");
    private static final String FAIL_PARAMETER_VALUE = "false";
    private static final String SUCCESS_PARAMETER_VALUE = "true";
    private static final int BUFFER_TIMEOUT = 25;

    private static final Object LOCK = new Object();
    private static final Object IMAGES_LOADED_LOCK = new Object();
    private static final Object IMAGES_SET_LOCK = new Object();

    @SuppressWarnings("CheckStyle")
    private static final String URL_EXTRACTING_REGEX = "^(http:\\/\\/www\\.|https:\\/\\/www\\.|http:\\/\\/|https:\\/\\/)?[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}(:[0-9]{1,5})?(\\/.*)?\\.(?:jpg|png|jpeg|webp|bmp|gif)$";
    private static final String BACKGROUND_IMAGE_URL_EXTRACTING_REGEX = "\"backgroundImageUrl\"";
    private static final String VIDEO_THUMB_URL_EXTRACTING_REGEX = "\"video_thumb_url\"";
    private static final String SRC_PROPERTY_REGEX = "(\\\"name\\\":[\\s\\t]*\\\"src\\\")";
    private static final String JSON_ELEMENT_EXTRACTING_REGEX =
            "\\{\\s*(\"name\"|\"type\"|\"value\")(\\s*?.*?)\\}";
    private static final String VALUE_MATCHING_REGEX =
            "\"value\"(\\s|\\t|\\r)*:(\\s|\\t|\\r)*\".*?\"";
    private static final String JSON_OBJECT_CLOSING_PARANTHESIS = "}";
    private static final String JSON_OBJECT_OPENING_PARANTHESIS = "{";
    private static final String JSON_OBJECT_VALUE_KEY = "value";

    private static Map<String, Boolean> sHasImages = new HashMap<>();
    private static Map<String, BehaviorSubject<Boolean>> sImagesLoaded = new HashMap<>();
    private static Map<String, BehaviorSubject<Boolean>> sImagesSet = new HashMap<>();

    @SuppressWarnings("CheckStyle")
    public static InsertPreparationManager getInstance() {
        InsertPreparationManager result = sInstance;
        if (result == null) { // 1st check (no lock)
            synchronized (LOCK) {
                result = sInstance;
                if (result == null) { // 2nd check (w/ lock)
                    sInstance = result = new InsertPreparationManager();
                }
            }
        }
        return result;
    }

    private InsertPreparationManager() {
    }

    /**
     * set the boolean indicating whether the images were loaded for a specific insert id.
     * @param insertId
     * @param imagesLoaded
     */
    public void setImagesLoaded(String insertId, Boolean imagesLoaded) {
        synchronized (IMAGES_LOADED_LOCK) {
            if (!sImagesLoaded.containsKey(insertId)) {
                BehaviorSubject<Boolean> finishedLoadingImages = BehaviorSubject.createDefault(false);
                sImagesLoaded.put(insertId, finishedLoadingImages);
                sImagesLoaded.get(insertId).onNext(imagesLoaded);
            } else {
                sImagesLoaded.get(insertId).onNext(imagesLoaded);
            }
        }
    }

    /**
     * Get observable indicating whether the images for a specific insert id were loaded or not.
     * @param insertId
     * @return observable indicating whether the images for the specific insert id were loaded.
     */
    public Observable<Boolean> getImagesLoadedAsObservable(String insertId) {
        synchronized (IMAGES_LOADED_LOCK) {
            if (!sImagesLoaded.containsKey(insertId)) {
                BehaviorSubject<Boolean> finishedLoadingImages = BehaviorSubject.createDefault(false);
                sImagesLoaded.put(insertId, finishedLoadingImages);
            }
            return sImagesLoaded.get(insertId);
        }
    }

    /**
     * set the boolean indicating whether the images were set for a specific insert id.
     * @param stepId
     * @param imagesLoaded
     */
    public void setImagesSet(String stepId, Boolean imagesLoaded) {
        synchronized (IMAGES_SET_LOCK) {
            if (!sImagesSet.containsKey(stepId)) {
                BehaviorSubject<Boolean> finishedSettingImages = BehaviorSubject.createDefault(false);
                sImagesSet.put(stepId, finishedSettingImages);
                sImagesSet.get(stepId).onNext(imagesLoaded);
            } else {
                sImagesSet.get(stepId).onNext(imagesLoaded);
            }
        }
    }

    /**
     *
     * @param insertId the insertId we want to remove from the map of set inserts.
     */
    public void removeImageSetForInsertId(String insertId) {
        synchronized (IMAGES_SET_LOCK) {
            BehaviorSubject<Boolean> imagesSetObservableForInsertId = sImagesSet.get(insertId);
            if (insertId != null && imagesSetObservableForInsertId != null) {
                sImagesSet.remove(imagesSetObservableForInsertId);
            }
        }
    }

    /**
     * Get observable indicating whether the images for a specific insert id were set or not.
     * @param stepId
     * @return observable indicating whether the images for the specific insert id were set.
     */
    public Observable<Boolean> getImagesSetAsObservable(String stepId) {
        synchronized (IMAGES_SET_LOCK) {
            if (!sImagesSet.containsKey(stepId)) {
                BehaviorSubject<Boolean> finishedSettingImages = BehaviorSubject.createDefault(false);
                sImagesSet.put(stepId, finishedSettingImages);
            }
            return sImagesSet.get(stepId);
        }
    }

    /**
     * Check whether the specific insert id has images.
     * @param guideStepId
     * @return
     */
    public Boolean getHasImages(String guideStepId) {
        if (guideStepId != null) {
            return sHasImages.get(guideStepId);
        }
        return false;
    }

    public void setHasImages(String insertId, boolean hasImages) {
        sHasImages.put(insertId, hasImages);
    }

    /**
     * Collect '"name": "src"' type strings.
     * Which will be later used in order to find their enclosing JSON object,
     * and will help us identify correctly images that are relevant for guide loading.
     * @param screenString - the screen JSON array in question.
     * @return a Set of all the image urls aforementioned.
     */
    public Set<String> getImageSourcePropertySet(String screenString) {
        Set<String> imageSourcePropertyMatchedSources = new HashSet<>();
        Matcher imageSourcePropertyMatcher = Pattern.compile(SRC_PROPERTY_REGEX).matcher(screenString);
        while (imageSourcePropertyMatcher.find()) {
            int srcPropertyStartIndex = imageSourcePropertyMatcher.start();
            // Find index of JSON object start
            int indexOfJSONStart = screenString.lastIndexOf(JSON_OBJECT_OPENING_PARANTHESIS,srcPropertyStartIndex);
            // Find index of JSON object end
            int indexOfJSONEnd = screenString.indexOf(JSON_OBJECT_CLOSING_PARANTHESIS, srcPropertyStartIndex) + 1;
            try {
                // Try creating a JSON object from the found
                JSONObject jsonObject = new JSONObject(screenString.substring(indexOfJSONStart, indexOfJSONEnd));
                String JSONObjectValueValue = jsonObject.getString(JSON_OBJECT_VALUE_KEY);
                imageSourcePropertyMatchedSources.add(JSONObjectValueValue);
            } catch(JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
        }
        return imageSourcePropertyMatchedSources;
    }

    /**
     * @param jsonScreen
     *
     * @return the number of images we need to wait for in order to show an insert.
     */
    private int getNumberOfImages(JsonElement jsonScreen) {
        if (jsonScreen != null && jsonScreen instanceof JsonArray) {
            return getImageSourcePropertySet(jsonScreen.getAsJsonArray().toString()).size();
        }
        return 0;
    }

    /**
     *
     * @param jsonString
     * @return An array list of urls needed to be loaded before the insert is shown.
     */
    public ArrayList<String> getImages(String jsonString){
        ArrayList<String> allImagesList = new ArrayList<>();
        allImagesList.addAll(getImageSourcePropertySet(jsonString));
        return allImagesList;
    }

    /**
     * Function overloading
     * @param jsonScreen
     * @return An array list of urls needed to be loaded before the insert is shown.
     */
    public ArrayList<String> getImages(JsonElement jsonScreen) {
        if (jsonScreen != null && jsonScreen instanceof JsonArray) {
            try {
                return getImages(jsonScreen.getAsJsonArray().toString());
            } catch (Exception e) {

                // If the screen didn't come as a JsonArray, just turn it to String as it is.
                return getImages(jsonScreen.toString().replace("\\/", "/"));
            }
        }

        return null;
    }

    private void subscribeToEndOfImageFetching(final String stepId,
                                               int numberOfImageSources) {
        final String finalStepId = stepId;
        final Predicate<InsertCommand> filter = new InsertCommand.Builder(
                InsertInternalAction.PREFETCH_IMAGES, PREFETCH_IMAGES_END)
                .setDestinationId(COMMAND_ACTION_DESTINATION)
                .setSourceId(finalStepId)
                .build()
                .getFilter();

                InsertCommandsEventBus.getInstance().getCommandEventBus()
                        // Check that we receive the command we're waiting for.
                        .filter(filter)
                        // Check that our success isn't made up from failures.
                        .filter(new Predicate<InsertCommand>() {
                            @Override
                            public boolean test(InsertCommand insertCommand) {
                                List<Parameter> list = insertCommand.getParameters();
                                for (Parameter parameter: list) {
                                    if (parameter.getParameterValue().contains(FAIL_PARAMETER_VALUE)) {
                                        return false;
                                    } else if (parameter.getParameterValue().contains(SUCCESS_PARAMETER_VALUE)) {
                                        return true;
                                    }
                                }
                                return false;
                            }
                        })
                        .buffer(numberOfImageSources)

                        // Used in order to make sure we get rid of this
                        // observable, when we have > 0 fails.
                        .timeout(BUFFER_TIMEOUT, TimeUnit.SECONDS)
                        .firstElement()
                        .subscribe(InsertMaybeObserver.create(
                                new Consumer<Object>() {
                                    @Override
                                    public void accept(Object o) {
                                        setImagesLoaded(finalStepId, true);
                                    }
                                }));
    }

    private void subscribeToEndOfImageSetting(final String stepId,
                                               int numberOfImageSources) {
        final String finalStepId = stepId;
        final Predicate<InsertCommand> filter = new InsertCommand.Builder(
                InsertInternalAction.IMAGES_SET, PREFETCH_IMAGES_END)
                .setDestinationId(COMMAND_ACTION_DESTINATION)
                .setSourceId(finalStepId)
                .build()
                .getFilter();
        InsertCommandsEventBus.getInstance().getCommandEventBus()
                .filter(filter)
                .buffer(numberOfImageSources)
                .firstElement()
                .subscribe(InsertMaybeObserver.create(
                        new Consumer<Object>() {
                            @Override
                            public void accept(Object o) {
                                setImagesSet(finalStepId, true);
                            }
                        }));
    }

    public void fetchImages(final String guideStepId, final ArrayList<String> imageSources) {
        Callback callback = new Callback() {
            @Override
            public void onSuccess() {
                InsertCommandDispatcher.getInstance().dispatchCommand(
                        new InsertCommand.Builder(
                                InsertInternalAction.PREFETCH_IMAGES,
                                PREFETCH_IMAGES_END)
                                .setDestinationId(COMMAND_ACTION_DESTINATION)
                                .setSourceId(guideStepId)
                                .addParameter(SUCCESS)
                                .build(), false
                );
            }

            @Override
            public void onError(Exception e) {
                if (e != null) {
                    InsertLogger.e(e, e.getMessage());
                }
                AnalyticsUtils.sendErrorReportImageLoadingFailed(guideStepId, imageSources);
                InsertCommandDispatcher.getInstance().dispatchCommand(
                        new InsertCommand.Builder(
                                InsertInternalAction.PREFETCH_IMAGES,
                                PREFETCH_IMAGES_END)
                                .setDestinationId(COMMAND_ACTION_DESTINATION)
                                .setSourceId(guideStepId)
                                .addParameter(FAIL)
                                .build(), false
                );
            }
        };

        for (String urlToLoad : imageSources) {
            if (urlToLoad.endsWith(GIF_FILENAME_EXTENSION)) {
                InsertGifCache.fetchGifIntoCache(urlToLoad, callback);
            }
            else {
                VisualInsert.picasso().load(urlToLoad).fetch(callback);
            }
        }
    }

    public void fetchImagesForPager(final String stepId, final ArrayList<String> imageSources) {
        Callback callback = new Callback() {
            @Override
            public void onSuccess() {
                InsertCommandDispatcher.getInstance().dispatchCommand(
                        new InsertCommand.Builder(
                                InsertInternalAction.IMAGES_SET,
                                PREFETCH_IMAGES_END)
                                .setDestinationId(COMMAND_ACTION_DESTINATION)
                                .setSourceId(stepId)
                                .addParameter(SUCCESS)
                                .build(), false
                );
            }

            @Override
            public void onError(Exception e) {
                if (e != null) {
                    InsertLogger.e(e, e.getMessage());
                }
                AnalyticsUtils.sendErrorReportImageLoadingFailed(stepId, imageSources);
                InsertCommandDispatcher.getInstance().dispatchCommand(
                        new InsertCommand.Builder(
                                InsertInternalAction.IMAGES_SET,
                                PREFETCH_IMAGES_END)
                                .setDestinationId(COMMAND_ACTION_DESTINATION)
                                .setSourceId(stepId)
                                .addParameter(FAIL)
                                .build(), false
                );
            }
        };

        for (String urlToLoad : imageSources) {
            if (urlToLoad.endsWith(".gif")) {
                InsertGifCache.fetchGifIntoCache(urlToLoad, callback);
            }
            else {
                VisualInsert.picasso().load(urlToLoad).fetch(callback);
            }
        }
    }

    public void prepareGuideImages(final JsonArray guideViews, String stepId) {
        // Find all the images. (regex) *number of images.*
        int imageSourcesSize = getNumberOfImages(guideViews);

        if (imageSourcesSize > 0) {
            //This will only happen once per insert.
            if (!sHasImages.containsKey(stepId)) {
                setHasImages(stepId, true);
            }
            // Subscribe on the event of received *number of images* of either failure or success.
            subscribeToEndOfImageFetching(stepId, imageSourcesSize);
            // Subscribe on the event of setting *number of images* of either failure or success.
            subscribeToEndOfImageSetting(stepId, imageSourcesSize);
            // Load all images with picasso and send events on completion or error.
            // fetchImagesWithPicasso(insertId, imageSources);

        } else {
            setHasImages(stepId, false);
            setImagesSet(stepId, true);
        }
    }
}
