package sdk.pendo.io.sdk.manager;

import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.res.Configuration;

import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertObserver;

/**
 * Manages and keeps track of the flow of the application.
 *
 * Created by tomerlevinson on 10/14/15.
 */
public final class ApplicationFlowManager {

    /**
     * States for {@link #IN_BACKGROUND} and {@link #IN_FOREGROUND}.
     */
    public enum AppFlowState {
        IN_BACKGROUND, IN_FOREGROUND
    }

    private static final ApplicationFlowManager mInstance = new ApplicationFlowManager();
    private String mLastActivity;
//    private static volatile AtomicInteger mStartStopCounter = new AtomicInteger();

//    private final PublishSubject<Object> mAppInBackgroundObservable = PublishSubject.create();

    // Subject for receiving the application state.
    private final BehaviorSubject<AppFlowState> mAppBackgroundStateChangeSubject =
            BehaviorSubject.createDefault(AppFlowState.IN_FOREGROUND);

    private ApplicationFlowManager() {

        Context applicationContext = Pendo.getApplicationContext();
        if (applicationContext != null) {
            applicationContext.registerComponentCallbacks(new ComponentCallbacks2() {
                @Override
                public void onTrimMemory(int level) {
                    InsertLogger.d("Test = level = " + level);

                    if (level >= TRIM_MEMORY_UI_HIDDEN) {
                        mAppBackgroundStateChangeSubject.onNext(AppFlowState.IN_BACKGROUND);
                    }
                }

                @Override
                public void onConfigurationChanged(Configuration newConfig) {

                }

                @Override
                public void onLowMemory() {

                }
            });
        }

        mAppBackgroundStateChangeSubject
                .subscribe(InsertObserver.create(new Consumer<AppFlowState>() {
                    @Override
                    public void accept(AppFlowState appFlowState) {
                        InsertLogger.d("AppFlow: " + appFlowState.name());
                    }
                }));

//        mAppInBackgroundObservable
//                .debounce(500, TimeUnit.MILLISECONDS) // Ignore multiple inside the 500 millis time frame.
//                .subscribeOn(Schedulers.io()) // Do it on the I/O thread?
//                .subscribe(InsertObserver.create(new Action1<Object>() {
//                    @Override
//                    public void call(Object o) {
//                        if (isInBackground()) {
//                            mAppBackgroundStateChangeSubject.onNext(AppFlowState.IN_BACKGROUND);
//                        } else {
//                        }
//                    }
//                }));
    }

    /**
     * @return the application flow state as observable.
     */
    public Observable<AppFlowState> getAppFlowChanges() {
        return getAppFlowChanges(false);
    }

    /**
     * If {@code distinct} is true, returns an {@link Observable<AppFlowState>} that emits all {@link AppFlowState}
     * that are distinct from their immediate predecessors.
     *
     * @param distinct whether to observe only distinct values changes or all changes.
     *
     * @return the application flow state as observable.
     */
    @SuppressWarnings("WeakerAccess")
    public Observable<AppFlowState> getAppFlowChanges(boolean distinct) {

        final Observable<AppFlowState> stateObservable = mAppBackgroundStateChangeSubject;

        return distinct ? stateObservable.distinctUntilChanged() : stateObservable;
    }

    public AppFlowState getAppFlowState() {
        return mAppBackgroundStateChangeSubject.getValue();
    }

    public boolean isInBackground() {
        return AppFlowState.IN_BACKGROUND.equals(getAppFlowState());
    }

    public void appInForeground() {
        mAppBackgroundStateChangeSubject.onNext(AppFlowState.IN_FOREGROUND);
    }

    // Used in order to reset the app background foreground state
    // and trigger reset in the application flow clocks.
    public void appBackgroundToForegeound() {
        mAppBackgroundStateChangeSubject.onNext(AppFlowState.IN_BACKGROUND);
        mAppBackgroundStateChangeSubject.onNext(AppFlowState.IN_FOREGROUND);
    }

//    public void incrementStartStopCounter() {
//
//        // Check if the application is in the background before incrementing the counter.
//        boolean isInBg = isInBackground();
//        mStartStopCounter.incrementAndGet();
//
//        // If the application is in the background, it's not anymore, publish it.
//        if (isInBg) {
//            mAppBackgroundStateChangeSubject.onNext(AppFlowState.IN_FOREGROUND);
//        }
//    }

//    public void decrementStartStopCounter() {
//
//        if (mStartStopCounter.get() > 0) {
//            mStartStopCounter.decrementAndGet();
//        }
//
//        // Checks if the application went to background.
//        mAppInBackgroundObservable.onNext("");
//    }

    public void setPreviousActivity(String lastActivity) {
        mLastActivity = lastActivity;
    }

    public String getLastActivity() {
        return mLastActivity;
    }

    public static synchronized ApplicationFlowManager getInstance() {
        return mInstance;
    }
}
