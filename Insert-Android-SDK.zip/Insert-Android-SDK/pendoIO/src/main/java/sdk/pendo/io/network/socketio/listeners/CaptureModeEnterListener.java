package sdk.pendo.io.network.socketio.listeners;

import org.json.JSONObject;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.Pendo;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.network.socketio.utilities.SocketIOUtils;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Listen on {@link SocketEvents#EVENT_CAPTURE_MODE_ENTER}.
 */
public final class CaptureModeEnterListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got: captureModeEnter");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_CAPTURE_MODE_ENTER);
        if (SocketEventFSM.getInstance().getCurrentState()
                .equals(SocketEventFSM.States.STATE_CAPTURE_MODE)) {
            sendCaptureModeEnteredEvent();
            if (InsertsManager.isInited()) {
                InsertsManager.getInstance().dismissVisibleGuides();
            }
        }
    }

    private void sendCaptureModeEnteredEvent() {
        JSONObject jsonObject = new JSONObject();
        SocketIOUtils.addSuccesfulToResponse(jsonObject, true);
        SocketIOUtils.emitToSocket(SocketEvents.EVENT_CAPTURE_MODE_ENTERED.getCommand(),
                                   jsonObject);
    }
}
