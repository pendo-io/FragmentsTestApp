package sdk.pendo.io.actions;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import sdk.pendo.io.actions.handlers.InsertGlobalCommandHandler;
import sdk.pendo.io.reactive.observers.InsertObserver;

import static sdk.pendo.io.actions.InsertCommand.InsertCommandScope.INSERT_COMMAND_SCOPE_ANY;
import static sdk.pendo.io.actions.InsertCommand.InsertCommandScope.ONCE_PER_SESSION;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.DISMISS_INSERT;
import static sdk.pendo.io.actions.InsertCommandEventType.UserEventType.TAP_ON;

/**
 * A repository for {@link InsertCommand}s to dispatch
 * over the {@link InsertCommandsEventBus}.
 *
 * Created by assaf on 3/28/16.
 */
@SuppressWarnings("unused")
public final class InsertCommandDispatcher {
    private static volatile InsertCommandDispatcher INSTANCE;
    private static final Object mLock = new Object();

    public static final String INSERT_COMMAND_ANALYTICS_SOURCE = "analyticsSource";


    // After we send a once-per-session command,
    // we put its id here so we won't send it again in this session.
    private static HashSet<String> sOncePerSessionCommands = new HashSet<>();

    /**
     * Dispatches the given command.
     *
     * @param command the {@link InsertCommand} to dispatch.
     *
     * @return True if the command was dispatched, false otherwise.
     */
    public void dispatchCommand(@NonNull InsertCommand command, boolean forceMainThread) {
        dispatchCommands(Collections.singletonList(command), command.eventType, forceMainThread);
    }

    /**
     * Dispatches the given commands that matches the {@link InsertCommandEventType}.
     *
     * @param commands {@link List} of {@link InsertCommand}s to dispatch.
     * @param eventType the {@link InsertCommandEventType} to match with.
     *
     */
    @SuppressLint("CheckResult")
    public void dispatchCommands(@NonNull List<InsertCommand> commands,
                                 @NonNull InsertCommandEventType eventType,
                                 boolean forceMainThread) {
        final List<InsertCommand> foundCommands = filterCommands(commands, eventType);
        if (!foundCommands.isEmpty()) {
            Observable.fromIterable(foundCommands)
                    .observeOn(forceMainThread ? AndroidSchedulers.mainThread() : Schedulers.trampoline())
                    .subscribe(InsertObserver.create(new Consumer<InsertCommand>() {
                        @Override
                        public void accept(InsertCommand insertCommand) {
                            InsertCommandsEventBus.getInstance().send(insertCommand);
                        }
                    }));
        }
    }

    /**
     * Determines whether this command should be sent, according to its scope.
     * @param command The command we wish to check.
     * @return True if it's in scope and should be sent. False otherwise.
     */
    private static boolean isInScope(@NonNull InsertCommand command) {
        if (command.scope == ONCE_PER_SESSION) {
            synchronized (mLock) {
                if (sOncePerSessionCommands.contains(command.commandId)) {
                    return false;
                } else {
                    sOncePerSessionCommands.add(command.commandId);
                    return true;
                }
            }
        }

        return true;
    }

    @NonNull
    static List<InsertCommand> filterCommands(
            @NonNull List<InsertCommand> commands,
            @NonNull InsertCommandEventType eventType) {

        LinkedList<InsertCommand> retList = new LinkedList<>();

        if (commands == null || commands.isEmpty()) {
            return retList;
        }

        final InsertCommand command =
                new InsertCommand(null,
                                  InsertCommand.COMMAND_STRING_ANY,
                                  InsertCommand.COMMAND_STRING_ANY,
                                  InsertCommandAction.INSERT_COMMAND_ACTION_ANY,
                                  eventType,
                                  INSERT_COMMAND_SCOPE_ANY);

        for (InsertCommand insertCommand : commands) {
            if (command.equals(true, insertCommand)
                    && isInScope(insertCommand)) {
                retList.add(insertCommand);
            }
        }

        return retList;
    }

    private InsertCommandDispatcher() {
        // Register all global handlers.
        InsertGlobalCommandHandler.getInstance();
    }

    public static synchronized InsertCommandDispatcher getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InsertCommandDispatcher();
        }

        return INSTANCE;
    }

    public void init() {

    }

    public static final class PredefinedCommands {
        public static final String SOURCE_ID_BACK_BUTTON = "backButton";

        private PredefinedCommands() {
        }

        public static final InsertCommand BACK_PRESSED =
                new InsertCommand.Builder(DISMISS_INSERT, TAP_ON)
                        .setCommandId("onBackPressed-command-id")
                        .setSourceId(SOURCE_ID_BACK_BUTTON)
                        .setDestinationId(InsertGlobalCommandHandler.INSERT_GLOBAL_COMMAND_DEST)
                        .build();
    }
}
