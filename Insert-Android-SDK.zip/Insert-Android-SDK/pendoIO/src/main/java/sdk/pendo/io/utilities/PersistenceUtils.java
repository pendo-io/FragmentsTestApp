package sdk.pendo.io.utilities;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Predicate;
import io.reactivex.subjects.BehaviorSubject;
import sdk.pendo.io.analytics.AnalyticEventsManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.sdk.manager.ApplicationFlowManager;

import static sdk.pendo.io.analytics.AnalyticsProperties.CONTROL_GROUP_GID;
import static sdk.pendo.io.analytics.AnalyticsProperties.DISPLAY_DURATION;
import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_BACKGROUND;
import static sdk.pendo.io.sdk.manager.ApplicationFlowManager.AppFlowState.IN_FOREGROUND;

/**
 * Created by itayvallach on 20/08/2017.
 * Utilities to save persistent app data.
 */
public class PersistenceUtils {
    private static final String PERSISTED_INSERT_APP_SESSION_ANALYTICS = "persisted_insert_app_session_analytics";
    private static final String PERSISTED_TIME_ANALYTICS = "persisted_time_analytics";
    private static final String PERSISTED_INSERT_DISMISSED_ANALYTICS = "persisted_insert_dismissed_analytics";
    private static final String ANALYTICS_APP_IN_BACKGROUND_COUNTER = "analytics_app_in_background_counter";
    private static final String INSERT_DISPLAYED_INTERVALLED_TIME_ANALYTICS_KEY = "insert_displayed_time_analytics";
    private static final String INSERT_SCREEN_LEFT_INTERVALLED_TIME_ANALYTICS_KEY = "insert_screen_left_time_analytics";
    private static final String INSERT_APP_IN_BACKGROUND_INTERVALLED_TIME_ANALYTICS_KEY = "insert_app_in_background_time_analytics";
    public static final String INSERT_APP_SESSION_END_COMMAND_KEY = "insert_app_session_end_command_key";
    private static final String DELIMITER = ":";
    private static final String APP_SESSION_DURATION_KEY_IN_PREFERENCES = "app_session_duration";
    private static int sAnalyticsAppInBackgroundCounter = 0;
    private static final int APP_SESSION_DURATION_COUNT_INTERVAL_MS = 1000;
    private static final int APP_SESSION_DURATION_COUNT_INTERVAL = 1;
    static final String APP_SESSION_DURATION_FIRST_TIME_DURATION = "first_time_app_session_duration";
    private static String sAppSessionDuration = APP_SESSION_DURATION_FIRST_TIME_DURATION;
    // Synchronization locks.
    private static final Object LOCK = new Object();
    private static final Object INSERT_DISMISSED_ANALYTICS_LOCK = new Object();
    private static final Object INSERT_APP_SESSION_LOCK = new Object();
    private static final Object INSERT_TIME_INTERVALS_LOCK = new Object();
    private static final Object INSERT_VISITOR_ACCOUNT_LOCK = new Object();
    // Persistent analytics consts.
    private static final String PERSISTED_INSERT_ANALYTICS = "persisted_insert_analytics";
    private static final String PERSISTED_VISITOR_ACCOUNT = "persisted_visitor_account";
    private static final String JSON_STRING = "json_string";
    public static final String INCLUDE_FEATURE_CLICK_TEXTS = "include_feature_click_texts";
    public static final String INCLUDE_PAGE_VIEW_TEXTS = "include_page_view_texts";
    private static final String PERSISTED_VISITOR_ID = "persisted_visitor_id";
    private static final String PERSISTED_ACCOUNT_ID = "persisted_account_id";
    private static int sAnalyticsBufferCounter = 0;
    public static final String PENDING_ANALYTICS_KEY = "pending";
    public static final String PENDING_ANALYTICS_VALUE = "analytics";
    private static BehaviorSubject<Boolean> sClearedAppSessionDuration = BehaviorSubject.createDefault(false);
    private static AtomicBoolean sPauseIntervalObservableEmissions = new AtomicBoolean(false);
    private static Observable<Long> sPausableIntervalObservable = null;
    private static Disposable sPausableIntervalObservableSubscription = null;
    private static BehaviorSubject<Boolean> sAppInBackgroundAnalyticsExist = BehaviorSubject.createDefault(false);

    /**
     * Stores info about Pendo that is displayed and is yet to be dismissed.
     * Used in cases of app termination while an Pendo is showing, we will check
     * if we have such inserts stored on the next app launch and send appropriate dismiss analytics.
     *
     * @param insertId
     * @param displayDuration
     */
    public static void persistInsertDisplayedAnalytics(String insertId,
                                                       long displayDuration) {
        synchronized (INSERT_DISMISSED_ANALYTICS_LOCK) {
            Set<String> paramSet = new HashSet<>();
            paramSet.add(DISPLAY_DURATION + DELIMITER + displayDuration);
            PreferencesUtils.storeStringSet(PERSISTED_INSERT_DISMISSED_ANALYTICS,
                    insertId,
                    paramSet, false);
        }
    }

    /**
     * Removes the insert info from the shared preferences.
     * Used after the insert is dismissed.
     *
     * @param insertId
     */
    public static void removeStoredInsertDisplayedAnalytics(String insertId) {
        synchronized (INSERT_DISMISSED_ANALYTICS_LOCK) {
            PreferencesUtils.deleteStoredDataByKey(PERSISTED_INSERT_DISMISSED_ANALYTICS, insertId);
        }
    }

    /**
     * Remove analytics json objects in case we sent the analytics properly.
     */
    public static void removeStoredAnalytics() {
        synchronized (LOCK) {
            int i = 0;
            while (i < sAnalyticsBufferCounter) {
                PreferencesUtils.deleteStoredDataByKey(PERSISTED_INSERT_ANALYTICS,
                        Integer.toString(i));
                i++;
            }
            sAnalyticsBufferCounter = 0;
        }
    }

    /**
     * Updates the display duration of the insert in SharedPreferences every fixed interval.
     *
     * @param insertId
     * @param displayDuration
     */
    public static void persistInsertDisplayDuration(String insertId, long displayDuration) {
        synchronized (INSERT_DISMISSED_ANALYTICS_LOCK) {
            if (displayDuration > 0 && insertId != null) {
                Set<String> paramSet = PreferencesUtils.retrieveStoredStringSet(
                        PERSISTED_INSERT_DISMISSED_ANALYTICS, insertId);
                if (paramSet != null) {
                    Set<String> newParamSet = new HashSet<>();
                    newParamSet.addAll(paramSet);
                    for (String param : newParamSet) {
                        if (param.startsWith(DISPLAY_DURATION)) {
                            newParamSet.remove(param);
                            newParamSet.add(DISPLAY_DURATION + DELIMITER + displayDuration);
                            PreferencesUtils.storeStringSet(PERSISTED_INSERT_DISMISSED_ANALYTICS,
                                    insertId,
                                    newParamSet, true);
                            break;
                        }
                    }
                }
            }
        }
    }

    /**
     * Checks if we have buffered pending analytics from the previous session, stored in our
     * shared preferences. If we do, we send them and remove them from the shared preferences.
     * <p>
     * !!!This method is will be unused in further version, its main purpose
     * is to copy buffered events from previous SDK version(2.1.0.1052) stored in old file and old format
     * to new storage and format in new SDK versions
     */
    public static void handlePendingAnalytics() {
        handlePendingInsertDismissedAnalytics();
        persistAppSessionDuration();
        synchronized (LOCK) {
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(PERSISTED_INSERT_ANALYTICS);
            if (sharedPref != null) {
                Map<String, Set<String>> map = (Map<String, Set<String>>) sharedPref.getAll();
                if (map.isEmpty()) {
                    return;
                }
                List<JSONObject> jsonObjects = new ArrayList<>();
                // Populate jsonObjects list.
                try {
                    for (Set<String> values : map.values()) {
                        for (String value : values) {
                            // Get JSON objects from shared preferences.
                            // Find the index of the delimiter.
                            int delimiterIndexInPreferenceMap = value.indexOf(DELIMITER);
                            if (delimiterIndexInPreferenceMap != 1) {
                                // JSON object stored is right after the delimiter
                                String jsonStored = value.substring(
                                        delimiterIndexInPreferenceMap + 1);
                                try {
                                    jsonObjects.add(new JSONObject(jsonStored));
                                } catch (JSONException e) {
                                    InsertLogger.e(e, e.getMessage());
                                }
                            }
                        }
                    }
                    if (jsonObjects.size() > 0) {
                        AnalyticEventsManager.getInstance().handleTrackedAnalyticEvents(jsonObjects, false);
                    }
                    sharedPref.edit().clear().apply();
                } catch (ClassCastException e) {
                    InsertLogger.e(e, e.getMessage());
                } catch (Exception e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }

    }

    /**
     * Checks if we have pending analytics stored in SharedPreferences. If so,
     * we send the analytics and remove them from SharedPreferences.
     */
    public static void handlePendingInsertDismissedAnalytics() {
        synchronized (INSERT_DISMISSED_ANALYTICS_LOCK) {
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(
                            PERSISTED_INSERT_DISMISSED_ANALYTICS);
            if (sharedPref != null) {
                Map<String, Set<String>> map = (Map<String, Set<String>>) sharedPref.getAll();
                for (Map.Entry<String, Set<String>> entry : map.entrySet()) {
                    String groupId = null;
                    String displayDuration = null;
                    for (String param : entry.getValue()) {
                        if (param.startsWith(CONTROL_GROUP_GID)) {
                            groupId = param.split(DELIMITER)[1];
                        } else if (param.startsWith(DISPLAY_DURATION)) {
                            displayDuration = param.split(DELIMITER)[1];
                        }
                    }

                    if (groupId != null && displayDuration != null) {
                        AnalyticsUtils.sendInsertDismissedAppTerminationAnalytics(
                                entry.getKey(),
                                displayDuration);
                        removeStoredInsertDisplayedAnalytics(entry.getKey());
                    }
                }
            }
        }
    }

    /**
     * Handles the app session duration storage in the shared preferences.
     */
    public static void handleAppSessionDurationStorageInPreferences() {
        synchronized (INSERT_APP_SESSION_LOCK) {
            // Retrieve current app session duration.
            Set<String> paramSet = PreferencesUtils.retrieveStoredStringSet(
                    PERSISTED_INSERT_APP_SESSION_ANALYTICS,
                    APP_SESSION_DURATION_KEY_IN_PREFERENCES);
            int appSessionDuration = 0;
            // In case we already have one stored, increment it
            if (paramSet != null) {
                Set<String> newParamSet = new HashSet<>();
                newParamSet.addAll(paramSet);
                for (String param : newParamSet) {
                    if (param.startsWith(APP_SESSION_DURATION_KEY_IN_PREFERENCES)) {
                        appSessionDuration = Integer.parseInt(param.split(DELIMITER)[1]);
                        newParamSet.remove(param);
                        newParamSet.add(
                                APP_SESSION_DURATION_KEY_IN_PREFERENCES + DELIMITER + (appSessionDuration + APP_SESSION_DURATION_COUNT_INTERVAL));
                        PreferencesUtils.storeStringSet(
                                PERSISTED_INSERT_APP_SESSION_ANALYTICS,
                                APP_SESSION_DURATION_KEY_IN_PREFERENCES,
                                newParamSet, true);
                        break;
                    }
                }
            } else {
                // Otherwise start with storing a 0.
                Set<String> newParamSet = new HashSet<>();
                newParamSet.add(
                        APP_SESSION_DURATION_KEY_IN_PREFERENCES + DELIMITER + appSessionDuration);
                PreferencesUtils.storeStringSet(PERSISTED_INSERT_APP_SESSION_ANALYTICS,
                        APP_SESSION_DURATION_KEY_IN_PREFERENCES,
                        newParamSet, true);
            }
        }
    }

    /**
     * This method is called in order to send the previous app session duration
     * and clear the previous session's duration
     *
     * @return duration time as a string.
     */
    public static String handleAppSessionDurationAnalyticsRecovery() {
        String result = APP_SESSION_DURATION_FIRST_TIME_DURATION;
        synchronized (INSERT_APP_SESSION_LOCK) {
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(
                            PERSISTED_INSERT_APP_SESSION_ANALYTICS);
            if (sharedPref != null) {
                Map<String, Set<String>> map = (Map<String, Set<String>>) sharedPref.getAll();
                if (map.containsKey(APP_SESSION_DURATION_KEY_IN_PREFERENCES)) {
                    for (String param : map.get(APP_SESSION_DURATION_KEY_IN_PREFERENCES)) {
                        if (param.startsWith(APP_SESSION_DURATION_KEY_IN_PREFERENCES)) {
                            result = param.split(DELIMITER)[1];
                            sAppSessionDuration = result;
                            PreferencesUtils.clearStoredData(
                                    PersistenceUtils.PERSISTED_INSERT_APP_SESSION_ANALYTICS);
                            break;
                        }
                    }
                }
            }
        }
        sClearedAppSessionDuration.onNext(true);
        return result;
    }

    /**
     * Stop recording session duration when in background,
     * continue when come to foreground.
     */
    private static void handleAppSessionDurationInBackgroundAndForeground() {
        /**
         * Create pausable interval observable.
         * Can be paused by setting the atomic boolean sPauseIntervalObservableEmissions
         * to true, and can be resumed by setting it to false.
         */
        sPausableIntervalObservable =
                ObservableUtils.createPausableInterval(sPauseIntervalObservableEmissions,
                        APP_SESSION_DURATION_COUNT_INTERVAL_MS, TimeUnit.MILLISECONDS);

        ApplicationFlowManager.getInstance().getAppFlowChanges()
                .subscribe(InsertObserver.create(
                        new Consumer<ApplicationFlowManager.AppFlowState>() {
                            @Override
                            public void accept(
                                    ApplicationFlowManager.AppFlowState appFlowState) {
                                if (appFlowState.equals(IN_BACKGROUND)) {
                                    sPauseIntervalObservableEmissions.set(true);
                                    if (sPausableIntervalObservableSubscription != null) {
                                        sPausableIntervalObservableSubscription.dispose();
                                        sPausableIntervalObservableSubscription = null;
                                    }
                                } else if (appFlowState.equals(IN_FOREGROUND)) {
                                    if (sPausableIntervalObservableSubscription == null) {
                                        /**
                                         * Subscribe to handling the session interval storing.
                                         */
                                        sPausableIntervalObservableSubscription = sPausableIntervalObservable.subscribeWith(
                                                InsertObserver.create(
                                                        new Consumer<Long>() {
                                                            @Override
                                                            public void accept(
                                                                    Long timePassed) {
                                                                handleAppSessionDurationStorageInPreferences();
                                                            }
                                                        }));
                                        sPauseIntervalObservableEmissions.set(false);
                                    }
                                }
                            }
                        }));
    }

    /**
     * This method is used to persist the app session duration.
     * We wait until the previous one is cleared and sent to the backend and then
     * start counting again.
     */
    public static void persistAppSessionDuration() {
        sClearedAppSessionDuration
                .filter(new Predicate<Boolean>() {
                    @Override
                    public boolean test(Boolean sessionIsCleared) {
                        return sessionIsCleared;
                    }
                })
                .firstElement().subscribe(
                InsertMaybeObserver.create(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean sessionIsCleared) {
                        handleAppSessionDurationInBackgroundAndForeground();
                    }
                }));
    }

    /**
     ******************* INTERVALLED INSERT DISMISSED BEGIN*******************
     */

    /**
     * Start saving the insert dismissed intervals by the new format of:
     * {unixStartTime, duration}
     *
     * @param unixStartTime - when we first started counting the insert displayed.
     * @param duration      - the duration of the current display chunk.
     */
    public static void persistInsertDisplayedIntervalledAnalytics(long unixStartTime,
                                                                  long duration,
                                                                  String insertId) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            if (insertId != null) {
                persistTimeInterval(unixStartTime, duration,
                        INSERT_DISPLAYED_INTERVALLED_TIME_ANALYTICS_KEY + insertId);
            }
        }
    }

    /**
     * remove the cached analytics for the shown insert with the given insertId.
     *
     * @param insertId - the insert's id.
     */
    public static void removeInsertDismissedIntervalledAnalytics(String insertId) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            if (insertId != null) {
                PreferencesUtils.deleteStoredDataByKey(PERSISTED_TIME_ANALYTICS,
                        INSERT_DISPLAYED_INTERVALLED_TIME_ANALYTICS_KEY + insertId);
            }
        }
    }

    /**
     * Get all of the intervals the insert was shown at until the dismissal.
     * Will be of this form:
     * [{"time":1500311837, "duration":5000}, {"time":1500312017, "duration":2000}]
     *
     * @param insertId
     * @return
     */
    public static JSONArray getFullTimeIntervalledAnalyticsInsertDismissed(String insertId) {
        if (insertId != null) {
            return getFullTimeAnalytics(INSERT_DISPLAYED_INTERVALLED_TIME_ANALYTICS_KEY + insertId);
        }
        return new JSONArray();
    }

    /**
     ******************* INTERVALLED INSERT DISMISSED END*******************
     */


    /**
     ******************* INTERVALLED SCREEN LEFT BEGIN*******************
     */

    /**
     * Start saving the insert dismissed intervals by the new format of:
     * {unixStartTime, duration}
     *
     * @param unixStartTime - when we first started counting the insert displayed.
     * @param duration      - the duration of the current display chunk.
     */
    public static void persistScreenLeftIntervalledAnalytics(long unixStartTime,
                                                             long duration,
                                                             int screenId) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            persistTimeInterval(unixStartTime, duration,
                    INSERT_SCREEN_LEFT_INTERVALLED_TIME_ANALYTICS_KEY + String.valueOf(screenId));
        }
    }

    /**
     * remove the cached analytics for the screen left.
     *
     * @param screenId - the insert's id.
     */
    public static void removeScreenLeftIntervalledAnalytics(int screenId) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            PreferencesUtils.deleteStoredDataByKey(PERSISTED_TIME_ANALYTICS,
                    INSERT_SCREEN_LEFT_INTERVALLED_TIME_ANALYTICS_KEY + String.valueOf(screenId));
        }
    }

    /**
     * Get all of the intervals the screen was shown until left.
     * Will be of this form:
     * [{"time":1500311837, "duration":5000}, {"time":1500312017, "duration":2000}]
     *
     * @param screenId - the id of the screen
     * @return
     */
    public static JSONArray getFullTimeIntervalledAnalyticsScreenLeft(String screenId) {
        return getFullTimeAnalytics(INSERT_SCREEN_LEFT_INTERVALLED_TIME_ANALYTICS_KEY + screenId);
    }

    /**
     ******************* INTERVALLED SCREEN LEFT END*******************
     */


    /**
     * ****************** INTERVALLED APP IN BACKGROUND BEGIN*******************
     */

    /**
     * Persist each appInForeground/AppSessionStart ----> appInbackground interval.
     *
     * @param unixStartTime
     * @param duration
     */
    public static void persistAppInBackgroundIntervalledAnalytics(long unixStartTime,
                                                                  long duration) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            persistTimeInterval(unixStartTime, duration,
                    INSERT_APP_IN_BACKGROUND_INTERVALLED_TIME_ANALYTICS_KEY + String.valueOf(
                            sAnalyticsAppInBackgroundCounter));
            sAppInBackgroundAnalyticsExist.onNext(true);
            Set<String> paramSet = new HashSet<>();
            paramSet.add(Integer.toString(sAnalyticsAppInBackgroundCounter));
            PreferencesUtils.storeStringSet(PERSISTED_TIME_ANALYTICS,
                    ANALYTICS_APP_IN_BACKGROUND_COUNTER, paramSet, true);
            sAnalyticsAppInBackgroundCounter++;
        }
    }

    /**
     * Remove all the app in background interval analytics in case of appSessionEnd, and also clear
     * the sAnalyticsAppInBackgroundCounter counter.
     */
    public static void removeAppInBackgroundIntervalledAnalytics() {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            Set<String> counterSet = PreferencesUtils.retrieveStoredStringSet(
                    PERSISTED_TIME_ANALYTICS, ANALYTICS_APP_IN_BACKGROUND_COUNTER);
            String backgroundCounterString = null;
            int backgroundCounter = 0;
            if (counterSet != null) {
                for (String s : counterSet) {
                    backgroundCounterString = s;
                }
                if (backgroundCounterString != null) {
                    backgroundCounter = Integer.parseInt(backgroundCounterString);
                }
                for (int i = 0; i <= backgroundCounter; i++) {
                    PreferencesUtils.deleteStoredDataByKey(PERSISTED_TIME_ANALYTICS,
                            INSERT_APP_IN_BACKGROUND_INTERVALLED_TIME_ANALYTICS_KEY
                                    + String.valueOf(i));
                }
                sAnalyticsAppInBackgroundCounter = 0;
            }
        }
    }

    /**
     * Get all the intervals in which the app was alive.
     *
     * @return json array string of all the intervals in which the app was alive
     * between going to backgrounds.
     */
    public static JSONArray getFullTimeIntervalledAnalyticsAppSessionEnd() {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            JSONArray fullTimeAnalytics = new JSONArray();
            Set<String> counterSet = PreferencesUtils.retrieveStoredStringSet(
                    PERSISTED_TIME_ANALYTICS, ANALYTICS_APP_IN_BACKGROUND_COUNTER);
            if (counterSet == null) {
                return fullTimeAnalytics;
            }
            String backgroundCounterString = null;
            int backgroundCounter = 0;
            for (String s : counterSet) {
                backgroundCounterString = s;
            }
            if (backgroundCounterString != null) {
                backgroundCounter = Integer.parseInt(backgroundCounterString);
            }
            for (int i = 0; i <= backgroundCounter; i++) {
                String currentAppInBackgroundIntervalString = getLastIntervalTimeAnaytics(
                        INSERT_APP_IN_BACKGROUND_INTERVALLED_TIME_ANALYTICS_KEY,
                        i);
                if (currentAppInBackgroundIntervalString == null) {
                    return fullTimeAnalytics;
                }
                JSONObject currentAppInBackgroundIntervalJSON = null;
                try {
                    currentAppInBackgroundIntervalJSON = new JSONObject(
                            currentAppInBackgroundIntervalString);
                } catch (JSONException e) {
                    InsertLogger.e(e, e.getMessage());
                }
                if (currentAppInBackgroundIntervalJSON != null) {
                    try {
                        fullTimeAnalytics.put(i, currentAppInBackgroundIntervalJSON);
                    } catch (JSONException e) {
                        InsertLogger.e(e, e.getMessage());
                    }
                }
            }
            return fullTimeAnalytics;
        }
    }

    /**
     * Will return the last interval in which the app was in the foreground, before it went down again.
     *
     * @return the last interval of the app in background.
     */
    public static String getLastIntervalledAnalyticsForAppInBackground() {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            // This is done for the first time only
            JSONObject defaultJSONObject = new JSONObject();
            if (sAnalyticsAppInBackgroundCounter > 0) {
                return getLastIntervalTimeAnaytics(
                        INSERT_APP_IN_BACKGROUND_INTERVALLED_TIME_ANALYTICS_KEY,
                        sAnalyticsAppInBackgroundCounter - 1);
            } else {
                return defaultJSONObject.toString();
            }
        }
    }

    /**
     ******************* INTERVALLED APP IN BACKGROUND END*******************
     */


    /**
     * Here we'll send the last event of the timed analytics.
     * The following will trigger this:
     * 1) AppInBackground
     * 2) AppScreenLeft
     * 3) InsertDismissed
     */
    public static String getLastIntervalTimeAnaytics(String keyInPreferences,
                                                     int indexOfLastInterval) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            if (keyInPreferences == null) {
                return null;
            }
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(
                            PERSISTED_TIME_ANALYTICS);
            String lastTimeAnalytics = null;
            if (sharedPref != null) {
                Map<String, Set<String>> map = (Map<String, Set<String>>) sharedPref.getAll();
                if (map != null) {
                    String key = keyInPreferences + String.valueOf(indexOfLastInterval);
                    if (map.containsKey(key) && map.get(key).size() > 0) {
                        Set<String> timeAnalyticsSet = map.get(key);
                        if (timeAnalyticsSet != null) {
                            for (String s : timeAnalyticsSet) {
                                lastTimeAnalytics = s;
                            }
                        }
                    }
                }
            }
            if (lastTimeAnalytics != null) {
                return lastTimeAnalytics;
            }
            return null;
        }
    }


    /**
     * Here we'll return all the time analytics we've stored thus far for the specific key.
     *
     * @param keyInPreferences will be the key we will search inside the analytics.
     */
    public static JSONArray getFullTimeAnalytics(String keyInPreferences) {
        synchronized (INSERT_TIME_INTERVALS_LOCK) {
            JSONArray fullTimeAnalytics = new JSONArray();
            if (keyInPreferences == null) {
                return fullTimeAnalytics;
            }
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(
                            PERSISTED_TIME_ANALYTICS);
            if (sharedPref != null) {
                Map<String, Set<String>> map = (Map<String, Set<String>>) sharedPref.getAll();
                if (map != null) {
                    if (map.containsKey(keyInPreferences)) {
                        Set<String> timeAnalyticsSet = map.get(keyInPreferences);
                        for (String currentAnalyticsString : timeAnalyticsSet) {
                            JSONObject currentAnalyticsJson = null;
                            try {
                                currentAnalyticsJson = new JSONObject(currentAnalyticsString);
                            } catch (JSONException e) {
                                InsertLogger.e(e, e.getMessage());
                            }
                            if (currentAnalyticsJson != null) {
                                fullTimeAnalytics.put(currentAnalyticsJson);
                            }
                        }
                    }
                }
            }
            return fullTimeAnalytics;
        }
    }

    /**
     * We'll persist the time interval each time this is called.
     * The time intervals will be of this form:
     * {time: unitTimeMillis, duration: timeInMillis}
     */
    public static void persistTimeInterval(long startTime, long durationInMs,
                                           String keyInPreferences) {
        if (keyInPreferences == null) {
            return;
        }
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("time", startTime);
            jsonObject.put("duration", durationInMs);
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }

        /**
         * Check if we already have time analytics.
         * If we have time analytics add to the current one.
         * If we don't, create a new paramSet.
         */
        SharedPreferences sharedPref =
                PreferencesUtils.getSharedPreferencesByFileName(
                        PERSISTED_TIME_ANALYTICS);
        Set<String> timeAnalyticsJSONs = null;
        if (sharedPref != null) {
            Map<String, Set<String>> map = (Map<String, Set<String>>) sharedPref.getAll();
            if (map != null && !map.isEmpty()) {
                for (Map.Entry<String, Set<String>> entry : map.entrySet()) {
                    if (entry.getKey().equals(keyInPreferences)) {
                        // We found the current time analytics JSONs.
                        timeAnalyticsJSONs = entry.getValue();
                        break;
                    }
                }
            }
            // Remove the unneeded key - value pair.
            if (timeAnalyticsJSONs != null && map.containsKey(keyInPreferences)) {
                map.remove(keyInPreferences);
            }
        }

        if (timeAnalyticsJSONs == null) {
            // In case we don't have time analytics.
            Set<String> paramSet = new HashSet<>();
            if (jsonObject.length() > 0) {
                paramSet.add(jsonObject.toString());
            }
            PreferencesUtils.storeStringSet(PERSISTED_TIME_ANALYTICS,
                    keyInPreferences,
                    paramSet, true);
        } else {
            // In case we have time analytics.
            timeAnalyticsJSONs.add(jsonObject.toString());
            PreferencesUtils.storeStringSet(PERSISTED_TIME_ANALYTICS,
                    keyInPreferences,
                    timeAnalyticsJSONs, true);
        }
    }

    public static String getAppSessionDuration() {
        return sAppSessionDuration;
    }

    public static void persistVisitorId(String visitorId) {
        synchronized (INSERT_VISITOR_ACCOUNT_LOCK) {
            if (visitorId != null) {
                PreferencesUtils.storeString(PERSISTED_VISITOR_ACCOUNT,
                        PERSISTED_VISITOR_ID, visitorId, true);
            } else {
                PreferencesUtils.deleteStoredDataByKey(PERSISTED_VISITOR_ACCOUNT, PERSISTED_VISITOR_ID);
            }
        }
    }


    public static void persistAccountId(String accountId) {
        synchronized (INSERT_VISITOR_ACCOUNT_LOCK) {
            if (accountId != null) {
                PreferencesUtils.storeString(PERSISTED_VISITOR_ACCOUNT,
                        PERSISTED_ACCOUNT_ID, accountId, true);
            } else {
                PreferencesUtils.deleteStoredDataByKey(PERSISTED_VISITOR_ACCOUNT, PERSISTED_ACCOUNT_ID);
            }
        }
    }


    public static String getPersistedVisitorId() {
        synchronized (INSERT_VISITOR_ACCOUNT_LOCK) {
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(
                            PERSISTED_VISITOR_ACCOUNT);
            if (sharedPref != null) {
                return sharedPref.getString(PERSISTED_VISITOR_ID, null);
            }
            return null;
        }
    }

    public static String getPersistedAccountId() {
        synchronized (INSERT_VISITOR_ACCOUNT_LOCK) {
            SharedPreferences sharedPref =
                    PreferencesUtils.getSharedPreferencesByFileName(
                            PERSISTED_VISITOR_ACCOUNT);
            if (sharedPref != null) {
                return sharedPref.getString(PERSISTED_ACCOUNT_ID, null);
            }
            return null;
        }
    }

    /**
     * Removes the stored visitor and account id from the shared preferences.
     * Used when we call clearVisitor public API.
     */
    public static void removeStoredVisitorAccountId() {
        synchronized (INSERT_VISITOR_ACCOUNT_LOCK) {
            PreferencesUtils.clearStoredData(PERSISTED_VISITOR_ACCOUNT);
        }
    }
}
