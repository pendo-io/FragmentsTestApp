package sdk.pendo.io.utilities;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.SystemClock;
import android.telephony.TelephonyManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.regex.Pattern;

import sdk.pendo.io.Pendo;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Created by tomerlevinson on 7/21/16.
 * This class gathers functions we need in order to send back to the backend more info
 * concerning the specific device we are on.
 */
public final class DeviceStateUtils {

    private static final String CPU_USAGE = "cpuUsage";
    private static final String CPU_COUNT = "cpuCount";
    private static final String AVAILABLE_MEMORY = "availableMemory";
    private static final String APP_USED_MEMORY_SIZE = "appUsedMemorySize";
    private static final String APP_FREE_MEMORY_SIZE = "appFreeMemorySize";
    private static final String APP_TOTAL_MEMORY_SIZE = "appTotalMemorySize";
    private static final String SYSTEM_UP_TIME = "systemUpTime";
    private static final String NETWORK_TYPE = "networkType";
    private static final String DEVICE_ORIENTATION = "deviceOrientation";
    private static final String BATTERY_USAGE = "batterUsage";

    /**
     * Gets the number of cores available in this device, across all processors.
     * Requires: Ability to peruse the filesystem at "/sys/devices/system/cpu"
     * @return The number of cores, or 1 if failed to get result
     */
    private static int getNumCoresOldPhones() {
        //Private Class to display only CPU devices in the directory listing
        class CpuFilter implements FileFilter {
            @Override
            public boolean accept(File pathname) {
                //Check if filename is "cpu", followed by a single digit number
                if(Pattern.matches("cpu[0-9]+", pathname.getName())) {
                    return true;
                }
                return false;
            }
        }

        try {
            //Get directory containing CPU info
            File dir = new File("/sys/devices/system/cpu/");
            //Filter to only list the devices we care about
            File[] files = dir.listFiles(new CpuFilter());
            //Return the number of cores (virtual CPU devices)
            return files != null ? files.length : 1;
        } catch (Exception e) {
            //Default to return 1 core
            return 1;
        }
    }

    public static float getBatteryLevel() {
        Intent batteryIntent = Pendo.getApplicationContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = -1;
        int scale = -1;
        if (batteryIntent != null) {
            level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        }

        // Error checking that probably isn't needed but I added just in case.
        if (level == -1 || scale == -1) {
            return 0.0f;
        }

        return ((float) level / (float) scale) * 100.0f;
    }

    private static ActivityManager.MemoryInfo getMemoryConsumption() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager activityManager = (ActivityManager) Pendo
                .getApplicationContext()
                .getSystemService(Pendo.getApplicationContext().ACTIVITY_SERVICE);
        activityManager.getMemoryInfo(mi);
        return mi;
    }


    public static long getAvailableMemory(){
        ActivityManager.MemoryInfo mi = getMemoryConsumption();
        return mi.availMem / 1048576L;
    }

    public static float readCPUUsage() {
        try {
            RandomAccessFile reader = new RandomAccessFile("/proc/stat", "r");
            String load = reader.readLine();

            String[] toks = load.split(" ");

            long idle1 = Long.parseLong(toks[5]);
            long cpu1 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[4])
                    + Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);

            try {
                Thread.sleep(360);
            } catch (Exception e) {}

            reader.seek(0);
            load = reader.readLine();
            reader.close();

            toks = load.split(" ");

            long idle2 = Long.parseLong(toks[5]);
            long cpu2 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[4])
                    + Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);

            return (float) (cpu2 - cpu1) / ((cpu2 + idle2) - (cpu1 + idle1));

        } catch (IOException e) {
            InsertLogger.e(e, e.getMessage());
        }

        return 0;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public static int getNumberOfCores() {
        if (Build.VERSION.SDK_INT >= 17) {
            return Runtime.getRuntime().availableProcessors();
        }
        else {
            return getNumCoresOldPhones();
        }
    }

    public static long getAppUsedMemorySize() {
        long totalSize = 0L;
        long usedSize = -1L;
        try {
            Runtime info = Runtime.getRuntime();
            totalSize = info.totalMemory();
            usedSize = totalSize - info.freeMemory();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return usedSize;

    }

    public static long getAppFreeMemorySize() {
        long freeSize = 0L;
        try {
            Runtime info = Runtime.getRuntime();
            freeSize = info.freeMemory();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return freeSize;
    }

    public static long getAppTotalMemorySize() {
        long totalSize = 0L;
        try {
            Runtime info = Runtime.getRuntime();
            totalSize = info.totalMemory();
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return totalSize;

    }

    public static long getSystemUptime() {
        return SystemClock.uptimeMillis();
    }

    public static String getNetworkType() {
        TelephonyManager teleMan = (TelephonyManager)
                Pendo
                        .getApplicationContext()
                        .getSystemService(Context.TELEPHONY_SERVICE);
        int networkType = teleMan.getNetworkType();
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_1xRTT: return "1xRTT";
            case TelephonyManager.NETWORK_TYPE_CDMA: return "CDMA";
            case TelephonyManager.NETWORK_TYPE_EDGE: return "EDGE";
            case TelephonyManager.NETWORK_TYPE_EHRPD: return "eHRPD";
            case TelephonyManager.NETWORK_TYPE_EVDO_0: return "EVDO rev. 0";
            case TelephonyManager.NETWORK_TYPE_EVDO_A: return "EVDO rev. A";
            case TelephonyManager.NETWORK_TYPE_EVDO_B: return "EVDO rev. B";
            case TelephonyManager.NETWORK_TYPE_GPRS: return "GPRS";
            case TelephonyManager.NETWORK_TYPE_HSDPA: return "HSDPA";
            case TelephonyManager.NETWORK_TYPE_HSPA: return "HSPA";
            case TelephonyManager.NETWORK_TYPE_HSPAP: return "HSPA+";
            case TelephonyManager.NETWORK_TYPE_HSUPA: return "HSUPA";
            case TelephonyManager.NETWORK_TYPE_IDEN: return "iDen";
            case TelephonyManager.NETWORK_TYPE_LTE: return "LTE";
            case TelephonyManager.NETWORK_TYPE_UMTS: return "UMTS";
            case TelephonyManager.NETWORK_TYPE_UNKNOWN: return "Unknown";
        }
        return "Unknown network type";
    }

    public static String getDeviceOrientation() {
        int orientation = Pendo.getApplicationContext().getResources().getConfiguration().orientation;
        return ResourceUtils.orientationToString(orientation);
    }

    public static JSONObject constructDeviceInfo() {
        JSONObject deviceInfo = new JSONObject();
        try {
            deviceInfo.put(CPU_USAGE, Float.toString(readCPUUsage()));
            deviceInfo.put(CPU_COUNT, Integer.toString(getNumberOfCores()));
            deviceInfo.put(AVAILABLE_MEMORY, Long.toString(getAvailableMemory()));
            deviceInfo.put(APP_USED_MEMORY_SIZE, Long.toString(getAppUsedMemorySize()));
            deviceInfo.put(APP_FREE_MEMORY_SIZE, Long.toString(getAppFreeMemorySize()));
            deviceInfo.put(APP_TOTAL_MEMORY_SIZE, Long.toString(getAppTotalMemorySize()));
            deviceInfo.put(SYSTEM_UP_TIME, Long.toString(getSystemUptime()));
            deviceInfo.put(BATTERY_USAGE, Float.toString(getBatteryLevel()));
            deviceInfo.put(NETWORK_TYPE, getNetworkType());
            deviceInfo.put(DEVICE_ORIENTATION, getDeviceOrientation());
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
        return deviceInfo;
    }

}
