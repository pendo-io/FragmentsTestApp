package sdk.pendo.io.actions

import android.content.Intent
import android.view.View
import com.google.gson.JsonArray
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import sdk.pendo.io.Pendo
import sdk.pendo.io.activities.InsertVisualActivity
import sdk.pendo.io.analytics.InsertAnalytics
import sdk.pendo.io.constants.Constants.GeneralConsts.IRRELEVANT
import sdk.pendo.io.listeners.ApplicationObservers
import sdk.pendo.io.logging.InsertLogger
import sdk.pendo.io.models.GuideModel
import sdk.pendo.io.models.GuideModel.*
import sdk.pendo.io.models.Quadruple
import sdk.pendo.io.models.StepSeen
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM
import sdk.pendo.io.reactive.observers.InsertMaybeObserver
import sdk.pendo.io.reactive.observers.InsertObserver
import sdk.pendo.io.utilities.ActivityUtils
import sdk.pendo.io.utilities.GuideUtils
import java.lang.ref.WeakReference
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.HashMap

/**
 * The guide Manager class is responsible of showing a guide and also holding a guide Id to guide mapping.
 * Once a trigger occurs, the show function for the needed guide is called from the ActivationManager class.
 * https://pendo-io.atlassian.net/wiki/spaces/ENG/pages/373293493/New+Guide+Activation+Model+Retroactive+SDK
 */
object GuideManager {
    /**
     * Repopulate guide mapping with fresh guides.
     * @param guides - list of GuideModels
     */
    @Synchronized
    fun init(guides: List<GuideModel>) {
        if (!isInited()) {
            repopulateGuidesMapping(guides)
        }
        InsertLogger.d("Cannot init more than once")
    }

    private val guideIDToGuideMap: MutableMap<String, GuideModel> = HashMap()
    private var mGuideActions: List<InsertCommand> = LinkedList()
    private const val FIRST_BIGGER = 1
    private const val SECOND_BIGGER = -1
    private const val PQ_INITIAL_CAPACITY = 11
    private const val FIRST_STEP_INDEX = 0


    @Synchronized
    fun setGuideActions(guideActions: List<InsertCommand>) {
        mGuideActions = guideActions
    }

    @Synchronized
    fun getGuideActions(): List<InsertCommand>? {
        return if (mGuideActions != null) LinkedList(mGuideActions) else null
    }

    /**
     * Go over the received guideIdStepIndexActivationEventTriplets and show the ones needed
     * @param guideIdStepIndexActivationEventQuadruples - List of guide IDs.
     * @return whether we've shown guides or not.
     */
    @Synchronized
    fun show(guideIdStepIndexActivationEventQuadruples: List<Quadruple<String, Int, ActivationManager.ActivationEvents, WeakReference<View>?>>): String {
        if (Pendo.areGuidesPaused()) {
            InsertLogger.d("Pause guides from showing api was called.")
            return InsertAction.NO_ID
        }

        //As we wish to deliver a list of ordered guides according to their priority we extract the guides by their ids, we then filter out the guides that lack a GuideModel and
        //sort them as intended mapping them back into a Quadruple of the same format we started with.
        val guideModelsOrdered = guideIdStepIndexActivationEventQuadruples.map { quadruple ->
            Quadruple(getGuide(quadruple.first), quadruple.second, ActivationManager.ActivationEvents.fromString(quadruple.third.activationEvent), quadruple.fourth)
        }.filter { it.first != null }.toMutableList()
        guideModelsOrdered.sortBy { it.first?.priority }

        val guideModelsIdsOrdered = guideModelsOrdered.map {
            guideModelStepAIntdexActivationViewquadruple -> Quadruple(guideModelStepAIntdexActivationViewquadruple.first?.guideId, guideModelStepAIntdexActivationViewquadruple.second,
                guideModelStepAIntdexActivationViewquadruple.third, guideModelStepAIntdexActivationViewquadruple.fourth)
        }

        val guideModelStepIndexWithEventPair = GuideShowDecider.getInstance().chooseSingleGuideBasedOnCapping(guideModelsIdsOrdered)

        if (VisualInsertManager.getInstance().isAnyFullScreenInsertShowing) {
            InsertLogger.d("Not showing guides because one is already showing.")
            return InsertAction.NO_ID
        }
        try {
            // Check if we aren't inside an active Multi-step guide
            if (guideModelStepIndexWithEventPair?.first != null && StepSeenManager.getInstance().currentStepSeen == null) {
                val guideStepId = guideModelStepIndexWithEventPair.first.getGuideStepId(FIRST_STEP_INDEX)
                if (guideStepId != DEFAULT_GUIDE_STEP_ID) {
                    StepSeenManager.getInstance().currentStepSeen =
                            StepSeen(
                                    guideModelStepIndexWithEventPair.first.guideId,
                                    guideStepId,
                                    guideModelStepIndexWithEventPair.first.getGuideStepLocation(guideStepId))
                }
            }
            if (guideModelStepIndexWithEventPair != null) {
                runGuide(guideModelStepIndexWithEventPair)
            }
            if (guideModelStepIndexWithEventPair?.first != null) {
                return guideModelStepIndexWithEventPair.first.guideId
            }
        } catch (e: Exception) {
            InsertLogger.e(e, e.message)
        }
        return InsertAction.NO_ID
    }

    @Synchronized
    fun runGuide(guideModelEventPair: Quadruple<GuideModel, Int, ActivationManager.ActivationEvents, WeakReference<View>?>?) {
        val guideModel = guideModelEventPair?.first
        val stepIndex = guideModelEventPair?.second
        val guideActivatedBy = guideModelEventPair?.third
        val view = guideModelEventPair?.fourth
        if (stepIndex != null) {
            val stepGuideModel = guideModel?.getGuideStepModel(stepIndex)
            if (stepGuideModel != null) {
                val insertDelay = stepGuideModel.configuration.delayMs
                if (insertDelay > 0) {
                    InsertLogger.d("Pendo got delay.")
                    Observable.just<Any>(IRRELEVANT)
                            .delay(insertDelay, TimeUnit.MILLISECONDS)
                            .filter {
                                val showing = VisualInsertManager
                                        .getInstance().isAnyFullScreenInsertShowing
                                InsertLogger.d("Is insert showing: '%b'.", showing)
                                !showing
                            }
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(InsertObserver.create {
                                InsertLogger.d("Running delayed insert.")
                                internalRunGuide(guideModel, false, guideActivatedBy, stepIndex, view)
                            })
                } else {
                    internalRunGuide(guideModel, false, guideActivatedBy, stepIndex, view)
                }
            }
        }
    }

    /**
     * Show preview guide
     */
    @Synchronized
    fun showPreview() {
        InsertsManager.getInstance().dismissVisibleGuides()
        StepSeenManager.getInstance().currentStepSeen =
                StepSeen(
                        PREVIEW_GUIDE_ID,
                        PREVIEW_GUIDE_STEP_ID,
                        null)
        VisualInsertManager.getInstance().isFullScreenInsertShowingObservable
                .filter { isFullScreenInsertShowing -> (!isFullScreenInsertShowing) }.firstElement()
                .subscribe(InsertMaybeObserver.create { internalRunGuide(SocketEventFSM.getInstance().previewInsert, true, ActivationManager.ActivationEvents.PREVIEW, FIRST_STEP_INDEX, null) })
    }

    /**
     * Given a guideId return the corresponding guide.
     * @param guideId - the desired guide's id.
     * @return the GuideModel the guideId corresponds to.
     */
    @Synchronized
    fun getGuide(guideId: String): GuideModel? {
        return guideIDToGuideMap[guideId]
    }

    @Synchronized
    private fun internalRunGuide(guideModel: GuideModel?, isPreviewGuide: Boolean, activatedBy: ActivationManager.ActivationEvents?, stepIndex: Int, targetView: WeakReference<View>?): String? {
        if (guideModel == null && !isPreviewGuide) {
            InsertLogger.w("Pendo guide model is null.")
            return null
        }
        val guideId = guideModel?.guideId
        if (!GuideShowDecider.getInstance().shouldShowGuide(guideId, isPreviewGuide, stepIndex)) {
            InsertLogger.d("Not showing guide, Should show guide = false")
            return null
        }

        if (!isPreviewGuide && activatedBy == ActivationManager.ActivationEvents.CLICK) {
            InsertTapOnManager.runTapOnIndication()
        }
        val intent = InsertVisualActivity.getVisualActivityIntent(
                isPreviewGuide, guideId, activatedBy)
        val currentActivityNameBeforeImagesDownloaded = ApplicationObservers.getInstance().currentActivityName
        if (InsertPreparationManager.getInstance().getHasImages(guideModel?.getGuideStepId(stepIndex))!!) {
            InsertPreparationManager.getInstance().getImagesLoadedAsObservable(guideModel?.getGuideStepId(stepIndex))
                    .filter { hasImages -> hasImages }
                    .firstElement()
                    .subscribe(InsertMaybeObserver.create {
                        val currentVisibleActivityName = ApplicationObservers.getInstance().currentActivityName
                        if (currentVisibleActivityName != null
                                && currentActivityNameBeforeImagesDownloaded != null
                                && currentVisibleActivityName == currentActivityNameBeforeImagesDownloaded) {
                            startExecutionByGuideType(guideModel, activatedBy, targetView, isPreviewGuide, guideId, stepIndex)

//                            startVisualActivityAndSetAsFullScreen(intent, guideId, stepIndex)
                        }
                    })
        } else {
            startExecutionByGuideType(guideModel, activatedBy, targetView, isPreviewGuide, guideId, stepIndex)
//            startVisualActivityAndSetAsFullScreen(intent, guideId, stepIndex)
        }
        return guideId
    }

    /**
     * Method identifies the type of the guide, currently if it is a tooltip or not and calls the
     * proper execution method. In the case of tooltip we move to working on the main thread
     */
    private fun startExecutionByGuideType(guideModel: GuideModel?,
                                          activatedBy: ActivationManager.ActivationEvents?,
                                          targetView: WeakReference<View>?,
                                          isPreviewGuide: Boolean,
                                          guideId: String?,
                                          stepIndex: Int) {
        val visualInsertType: InsertActionConfiguration.VisualInsertType = InsertActionConfiguration.getStepVisualInsertType(guideModel?.steps?.get(stepIndex)?.asJsonObject)
        when (visualInsertType) {
            InsertActionConfiguration.VisualInsertType.TOOLTIP -> {
                Observable.just<Any>(IRRELEVANT)
                        .subscribeOn(Schedulers.computation())
                        .filter {
                            val showing = VisualInsertManager
                                    .getInstance().isAnyFullScreenInsertShowing
                            InsertLogger.d("Is insert showing: '%b'.", showing)
                            !showing
                        }
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(InsertObserver.create {
                            InsertLogger.d("Running delayed insert.")
                            startVisualTooltip(guideModel, activatedBy, targetView, stepIndex)
                        })
            }
            InsertActionConfiguration.VisualInsertType.FULLSCREEN -> {
                val intent = InsertVisualActivity.getVisualActivityIntent(isPreviewGuide, guideId, activatedBy)
                startVisualActivityAndSetAsFullScreen(intent, guideId, stepIndex, isPreviewGuide)
            }
        }
    }

    @Synchronized
    private fun startVisualTooltip(guideModel: GuideModel?, activatedBy: ActivationManager.ActivationEvents?, targetViewRef: WeakReference<View>?, stepIndex: Int) {
        val analytics = InsertAnalytics.getInstance().newGuideGenericAnalytics(guideModel)
        val visualInsert = ToolTipVisualInsert(guideModel, VisualInsertManager.getInstance())
        GuideUtils.showToolTipVisualInsert(targetViewRef, visualInsert, analytics, activatedBy?.activationEvent)
        VisualInsertManager.getInstance().setIsFullScreenInsertShowing(true)
    }


    @Synchronized
    private fun startVisualActivityAndSetAsFullScreen(intent: Intent, insertActionId: String?, stepIndex: Int, isPreviewGuide: Boolean) {
        ActivityUtils.startActivityFromBoundActivity(intent, insertActionId, stepIndex, isPreviewGuide)
        VisualInsertManager.getInstance().setIsFullScreenInsertShowing(true)
    }

    /**
     * Add a guideID to Guide mapping.
     * @param guideId - the guideID to add.
     * @param stepContentModels - the guide steps.
     */
    @Synchronized
    fun addGuideMapping(guideModel: GuideModel) {
        guideIDToGuideMap[guideModel.guideId] = guideModel
    }

    /**
     * Clears the guide mapping.
     */
    @Synchronized
    fun clearGuideMapping() {
        guideIDToGuideMap.clear()
    }

    /**
     * is Guide id to GuideModel not empty.
     */
    @Synchronized
    fun isInited(): Boolean = guideIDToGuideMap.isNotEmpty()

    /**
     * The repopulating is used in the test mode functionality, in which there's a need
     * to repopulate the inserts manager with fresh inserts from the server.
     *
     * @param guides Is the new guides we want to populate.
     */
    @Synchronized
    fun repopulateGuidesMapping(guides: List<GuideModel>) {

        // Clears the current guides.
        clearGuideMapping()

        // Iterates over the given inserts.
        populate(guides)
    }

    @Synchronized
    fun populate(guideModels: List<GuideModel>) {
        for (guideModel in guideModels) {
            val steps: JsonArray? = guideModel.steps
            if (steps != null) {
                for (stepIndex in 0 until guideModel.steps.size()) {
                    val stepGuideModel = guideModel.getGuideStepModel(stepIndex)
                    val stepId = guideModel.getGuideStepId(stepIndex)
                    if (stepGuideModel != null && stepId != DEFAULT_GUIDE_STEP_ID) {
                        val guideStepViews = stepGuideModel.views
                        InsertPreparationManager.getInstance().prepareGuideImages(guideStepViews, stepId)
                        val imagesToDownload = InsertPreparationManager.getInstance().getImages(
                                guideStepViews)
                        InsertPreparationManager.getInstance().fetchImages(stepId, imagesToDownload)
                    }
                }
            }
            addGuideMapping(guideModel)
        }
    }

}
