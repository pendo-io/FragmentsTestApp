package sdk.pendo.io.utilities;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;

import com.google.gson.JsonObject;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import sdk.pendo.io.actions.configurations.InsertTypeValue;
import sdk.pendo.io.logging.InsertLogger;

/**
 * A generic utility class.
 *
 * Created by assaf on 4/5/15.
 */
@SuppressWarnings("WeakerAccess")
public final class Utils {

    public interface Predicate<T> {

        /**
         * Evaluates this predicate on the given argument.
         *
         * @param t the input argument
         * @return {@code true} if the input argument matches the predicate,
         * otherwise {@code false}
         */
        boolean test(T t);
    }

    private Utils() {}

    /**
     * Convert time duration from a given {@link InsertTypeValue#value}
     * of a given {@link TimeUnit} from {@link InsertTypeValue#type} to a given {@link TimeUnit}.
     *
     * <p>
     * Supports:
     * {@code "milliseconds"},
     * {@code "seconds"},
     * {@code "minutes"},
     * {@code "hours"},
     * {@code "days"}
     * </p>
     *
     * @param typeValue time duration from {@link InsertTypeValue#value}
     *                  and {@link TimeUnit} from {@link InsertTypeValue#type}
     * @param convertTo {@link TimeUnit} to convert the duration to.
     *
     * @return the duration in the converted {@link TimeUnit}.
     */
    public static long convertToTimeUnit(InsertTypeValue typeValue, TimeUnit convertTo) {
        TimeUnit convertFrom = null;
        String type = typeValue.type;

        if ("milliseconds".equals(type)) {
            convertFrom = TimeUnit.MILLISECONDS;
        } else if ("seconds".equals(type)) {
            convertFrom = TimeUnit.SECONDS;
        } else if ("minutes".equals(type)) {
            convertFrom = TimeUnit.MINUTES;
        } else if ("hours".equals(type)) {
            convertFrom = TimeUnit.HOURS;
        } else if ("days".equals(type)) {
            convertFrom = TimeUnit.DAYS;
        }

        if (convertFrom == null) {
            throw new IllegalArgumentException("Cannot get time unit from type: '"
                                                       + typeValue.type + "'.");
        }

        return convertTo.convert(typeValue.value, convertFrom);
    }

    /**
     * Filters the given {@link List} according to the given {@link Predicate}.
     *
     * @param list the list to manipulate.
     * @param predicate the predicate to check.
     *
     * @return {@code true} if the {@code list} is modified, {@code false} otherwise.
     */
    public static <T> boolean filterList(@NonNull List<T> list, @NonNull Predicate<T> predicate) {
        ArrayList<T> remove = new ArrayList<>();
        for (T t : list) {
            if (predicate.test(t)) {
                remove.add(t);
            }
        }

        return list.removeAll(remove);
    }

    private static final int MAX_TEXT_LENGTH = 256;

    /**
     * If given {@code text} is longer than {@link Utils#MAX_TEXT_LENGTH} the returned text will be
     * shortened to only the first {@link Utils#MAX_TEXT_LENGTH} characters.
     *
     * @param text the text to shorten.
     *
     * @return If needed returned text will be shortened to only the first
     * {@link Utils#MAX_TEXT_LENGTH} characters.
     */
    public static CharSequence truncateStringToLength(CharSequence text) {
        if (text.length() > MAX_TEXT_LENGTH) {
            return text.subSequence(0, MAX_TEXT_LENGTH);
        }

        return text;
    }

    /**
     * <p>Checks whether the String a valid Java number.</p>
     *
     * <p>Valid numbers include hexadecimal marked with the <code>0x</code> or
     * <code>0X</code> qualifier, octal numbers, scientific notation and numbers
     * marked with a type qualifier (e.g. 123L).</p>
     *
     * <p>Non-hexadecimal strings beginning with a leading zero are
     * treated as octal values. Thus the string <code>09</code> will return
     * <code>false</code>, since <code>9</code> is not a valid octal value.
     * However, numbers beginning with {@code 0.} are treated as decimal.</p>
     *
     * <p><code>null</code> and empty/blank {@code String} will return
     * <code>false</code>.</p>
     *
     * @param str  the <code>String</code> to check
     * @return <code>true</code> if the string is a correctly formatted number
     * @since 3.3 the code supports hex {@code 0Xhhh} and octal {@code 0ddd} validation
     */
    public static boolean isNumber(final String str) {
        if (StringUtils.isEmpty(str)) {
            return false;
        }
        final char[] chars = str.toCharArray();
        int sz = chars.length;
        boolean hasExp = false;
        boolean hasDecPoint = false;
        boolean allowSigns = false;
        boolean foundDigit = false;
        // deal with any possible sign up front
        final int start = (chars[0] == '-') ? 1 : 0;
        if (sz > start + 1 && chars[start] == '0') { // leading 0
            if (
                    (chars[start + 1] == 'x') ||
                            (chars[start + 1] == 'X')
                    ) { // leading 0x/0X
                int i = start + 2;
                if (i == sz) {
                    return false; // str == "0x"
                }
                // checking hex (it can't be anything else)
                for (; i < chars.length; i++) {
                    if ((chars[i] < '0' || chars[i] > '9')
                            && (chars[i] < 'a' || chars[i] > 'f')
                            && (chars[i] < 'A' || chars[i] > 'F')) {
                        return false;
                    }
                }
                return true;
            } else if (Character.isDigit(chars[start + 1])) {
                // leading 0, but not hex, must be octal
                int i = start + 1;
                for (; i < chars.length; i++) {
                    if (chars[i] < '0' || chars[i] > '7') {
                        return false;
                    }
                }
                return true;
            }
        }
        sz--; // don't want to loop to the last char, check it afterwords
        // for type qualifiers
        int i = start;
        // loop to the next to last char or to the last char if we need another digit to
        // make a valid number (e.g. chars[0..5] = "1234E")
        while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
            if (chars[i] >= '0' && chars[i] <= '9') {
                foundDigit = true;
                allowSigns = false;

            } else if (chars[i] == '.') {
                if (hasDecPoint || hasExp) {
                    // two decimal points or dec in exponent
                    return false;
                }
                hasDecPoint = true;
            } else if (chars[i] == 'e' || chars[i] == 'E') {
                // we've already taken care of hex.
                if (hasExp) {
                    // two E's
                    return false;
                }
                if (!foundDigit) {
                    return false;
                }
                hasExp = true;
                allowSigns = true;
            } else if (chars[i] == '+' || chars[i] == '-') {
                if (!allowSigns) {
                    return false;
                }
                allowSigns = false;
                foundDigit = false; // we need a digit after the E
            } else {
                return false;
            }
            i++;
        }
        if (i < chars.length) {
            if (chars[i] >= '0' && chars[i] <= '9') {
                // no type qualifier, OK
                return true;
            }
            if (chars[i] == 'e' || chars[i] == 'E') {
                // can't have an E at the last byte
                return false;
            }
            if (chars[i] == '.') {
                if (hasDecPoint || hasExp) {
                    // two decimal points or dec in exponent
                    return false;
                }
                // single trailing decimal point after non-exponent is ok
                return foundDigit;
            }
            if (!allowSigns
                    && (chars[i] == 'd'
                    || chars[i] == 'D'
                    || chars[i] == 'f'
                    || chars[i] == 'F')) {
                return foundDigit;
            }
            if (chars[i] == 'l'
                    || chars[i] == 'L') {
                // not allowing L with an exponent or decimal point
                return foundDigit && !hasExp && !hasDecPoint;
            }
            // last character is illegal
            return false;
        }
        // allowSigns is true iff the val ends in 'E'
        // found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
        return !allowSigns && foundDigit;
    }

    public static boolean isJSONObjectValid(String test) {
        try {
            new JSONObject(test);
        } catch (JSONException ex) {
            return false;
        }
        return true;
    }

    public static boolean isJSONArrayValid(String test) {
        try {
            new JSONArray(test);
        } catch (JSONException ex) {
                return false;
        }
        return true;
    }

    public static boolean isLong(String s) {
        boolean isValidLong = false;
        try {
            Long.parseLong(s);
            isValidLong = true;
        } catch (NumberFormatException ex) {
        }
        return isValidLong;
    }


    @Nullable
    public static Integer stringToInteger(String str) {

        if (str != null) {
            try {
                return Integer.parseInt(str);
            } catch (NumberFormatException ignore) {}
        }

        return null;
    }

    public static String replaceIfNull(String input) {
        return input == null ? "" : input;
    }

    public static boolean isInteger(String str) {

        return stringToInteger(str) != null;
    }

    public static String censorString(String str) {

        if (str.length() > 2) {
            return str.charAt(0) + "*****" + str.charAt(str.length() - 1);
        }

        // Cannot censor.
        return "***";
    }

    @Nullable
    public static JSONObject convertJsonObject(@Nullable JsonObject jsonObject) {

        if (jsonObject != null) {
            try {
                return new JSONObject(jsonObject.toString());
            } catch (JSONException e) {
                InsertLogger.d("Failed to convert JSON: " + e.getMessage());
            }
        }
        return null;
    }

    public static float distance(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2;
        float dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    public static String stacktraceToString(StackTraceElement[] stackTrace) {
        if (stackTrace == null)
            return "";
        StringBuilder stringBuilder = new StringBuilder();
        for (StackTraceElement element : stackTrace)
            stringBuilder.append(element.toString()).append("\n");
        return stringBuilder.toString();
    }

    private static final AtomicInteger sNextGeneratedId = new AtomicInteger(1);

    /**
     * Generate a value suitable for use in {@link #setId(int)}.
     * This value will not collide with ID values generated at build time by aapt for R.id.
     *
     * @return a generated ID value
     */
    public static int generateViewId() { // TODO: 6/30/16 Move to ViewUtils.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return View.generateViewId();
        } else {
            for (;;) {
                final int result = sNextGeneratedId.get();
                // aapt-generated IDs have the high byte nonzero; clamp to the range under that.
                int newValue = result + 1;
                if (newValue > 0x00FFFFFF) newValue = 1; // Roll over to 1, not 0.
                if (sNextGeneratedId.compareAndSet(result, newValue)) {
                    return result;
                }
            }
        }
    }

    public static List<String> getAllClasses(Object o) {
        ArrayList<String> retList = new ArrayList<>();
        Class C = o.getClass();

        while (C != null) {
            retList.add(C.getName());
            C = C.getSuperclass();
        }

        return retList;
    }

    public static JSONArray listToJSONArray(List<? extends Object> list) {
        JSONArray retArray = new JSONArray();

        for (Object o : list) {
            retArray.put(o.toString());
        }

        return retArray;
    }

    public static List<String> jsonArrayToList(JSONArray jsonArray) {
        ArrayList<String> retList = new ArrayList<>();
        if (jsonArray != null) {
            int len = jsonArray.length();
            for (int i = 0; i < len; i++) {
                final String s = jsonArray.optString(i);
                if (!TextUtils.isEmpty(s)) {
                    retList.add(s);
                }
            }
        }

        return retList;
    }

    /** **************************************************************************************** **/
    /** Taken from {@link java.util.Objects} **/
    /**
     * Returns 0 if {@code a == b}, or {@code c.compare(a, b)} otherwise.
     * That is, this makes {@code c} null-safe.
     */
    public static <T> int compare(T a, T b, Comparator<? super T> c) {
        if (a == b) {
            return 0;
        }
        return c.compare(a, b);
    }

    /**
     * Returns true if both arguments are null,
     * the result of {@link Arrays#equals} if both arguments are primitive arrays,
     * the result of {@link Arrays#deepEquals} if both arguments are arrays of reference types,
     * and the result of {@link #equals} otherwise.
     */
    public static boolean deepEquals(Object a, Object b) {
        if (a == null || b == null) {
            return a == b;
        } else if (a instanceof Object[] && b instanceof Object[]) {
            return Arrays.deepEquals((Object[]) a, (Object[]) b);
        } else if (a instanceof boolean[] && b instanceof boolean[]) {
            return Arrays.equals((boolean[]) a, (boolean[]) b);
        } else if (a instanceof byte[] && b instanceof byte[]) {
            return Arrays.equals((byte[]) a, (byte[]) b);
        } else if (a instanceof char[] && b instanceof char[]) {
            return Arrays.equals((char[]) a, (char[]) b);
        } else if (a instanceof double[] && b instanceof double[]) {
            return Arrays.equals((double[]) a, (double[]) b);
        } else if (a instanceof float[] && b instanceof float[]) {
            return Arrays.equals((float[]) a, (float[]) b);
        } else if (a instanceof int[] && b instanceof int[]) {
            return Arrays.equals((int[]) a, (int[]) b);
        } else if (a instanceof long[] && b instanceof long[]) {
            return Arrays.equals((long[]) a, (long[]) b);
        } else if (a instanceof short[] && b instanceof short[]) {
            return Arrays.equals((short[]) a, (short[]) b);
        }
        return a.equals(b);
    }

    /**
     * Null-safe equivalent of {@code a.equals(b)}.
     */
    public static boolean equals(Object a, Object b) {
        return (a == null) ? (b == null) : a.equals(b);
    }

    /**
     * Convenience wrapper for {@link Arrays#hashCode}, adding varargs.
     * This can be used to compute a hash code for an object's fields as follows:
     * {@code Objects.hash(a, b, c)}.
     */
    public static int hash(Object... values) {
        return Arrays.hashCode(values);
    }

    /**
     * Returns 0 for null or {@code o.hashCode()}.
     */
    public static int hashCode(Object o) {
        return (o == null) ? 0 : o.hashCode();
    }

    /**
     * Returns {@code o} if non-null, or throws {@code NullPointerException}.
     */
    public static <T> T requireNonNull(T o) {
        if (o == null) {
            throw new NullPointerException();
        }
        return o;
    }

    /**
     * Returns {@code o} if non-null, or throws {@code NullPointerException}
     * with the given detail message.
     */
    public static <T> T requireNonNull(T o, String message) {
        if (o == null) {
            throw new NullPointerException(message);
        }
        return o;
    }

    /**
     * Returns {@code o} if non-null, or throws {@code IllegalArgumentException}
     * with the given detail message.
     */
    public static <T> T requireArgumentNonNull(T o, String message) {
        if (o == null) {
            throw new IllegalArgumentException(message);
        }
        return o;
    }

    /**
     * Returns {@code s} if not {@link android.text.TextUtils#isEmpty(CharSequence)},
     * or throws {@code IllegalArgumentException} with the given detail message.
     */
    public static CharSequence requireArgumentNotEmpty(CharSequence s, String message) {
        if (TextUtils.isEmpty(s)) {
            throw new IllegalArgumentException(message);
        }
        return s;
    }

    /**
     * Returns "null" for null or {@code o.toString()}.
     */
    public static String toString(Object o) {
        return (o == null) ? "null" : o.toString();
    }

    /**
     * Returns {@code nullString} for null or {@code o.toString()}.
     */
    public static String toString(Object o, String nullString) {
        return (o == null) ? nullString : o.toString();
    }
    /** **************************************************************************************** **/

    /**
     * Null-safe check if the specified collection is empty.
     * <p>
     * Null returns true.
     *
     * @param coll  the collection to check, may be null
     * @return true if empty or null
     */
    public static boolean isEmpty(Collection coll) {
        return (coll == null || coll.isEmpty());
    }
}
