package sdk.pendo.io.utilities;

/**
 * Interface which defines a basic profiler to be used for analyzing performance, data, etc..
 */
public interface InsertProfiler {
    /**
     * Used to get the stats currently aggregated in the profiler. use; delimiters for title;body.
     * @return
     */
    String[] getStats();

    /**
     * Mark the profiler with a specific message. use; delimiters for title;body.
     * @param message
     */
    void mark(String message);
}
