package sdk.pendo.io.utilities;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;
import java.util.HashSet;

public class TooltipUtils {

    private static final String VIEWS_KEY = "views";
    private static final String WIDGET_KEY = "widget";
    private static final String WIDGET_VALUE = "LinearLayout";
    private static final String CONTAINER_ID_KEY = "id";
    private static final String CONTAINER_ID_VALUE = "insert_container";
    public static final String PROPERTIES_KEY = "properties";
    private static final String SCROLLABLE_KEY = "scrollable";

    private static final String PROPERTY_NAME_KEY = "name";
    private static final String PROPERTY_NAME_TYPE = "type";
    private static final String PROPERTY_NAME_VALUE = "value";

    private static final String PROPERTY_NAME_TYPE_DIMEN = "dimen";
    private static final String PROPERTY_NAME_TYPE_STRING = "string";
    private static final String PROPERTY_NAME_TYPE_BOOLEAN = "boolean";
    private static final String PROPERTY_NAME_TYPE_REF = "ref";
    private static final String PROPERTY_NAME_TYPE_COLOR = "color";

    private static final String PROPERTY_NAME_LAYOUT_WIDTH_KEY = "layout_width";
    private static final String PROPERTY_NAME_LAYOUT_HEIGHT_KEY = "layout_height";
    private static final String PROPERTY_NAME_LAYOUT_WRAP_CONTENT_VALUE = "wrap_content";
    private static final String PROPERTY_NAME_ENABLED_KEY = "enabled";
    private static final String PROPERTY_NAME_ORIENTATION_KEY = "orientation";
    private static final String PROPERTY_NAME_ORIENTATION_VALUE = "vertical";

    private static final String PROPERTY_TO_COPY_PADDING_BOTTOM_KEY = "paddingBottom";
    private static final String PROPERTY_TO_COPY_PADDING_LEFT_KEY = "paddingLeft";
    private static final String PROPERTY_TO_COPY_PADDING_RIGHT_KEY = "paddingRight";
    private static final String PROPERTY_TO_COPY_PADDING_TOP_KEY = "paddingTop";

    private static final String PROPERTY_TO_COPY_MARGIN_BOTTOM_KEY = "layout_marginBottom";
    private static final String PROPERTY_TO_COPY_MARGIN_LEFT_KEY = "layout_marginLeft";
    private static final String PROPERTY_TO_COPY_MARGIN_RIGHT_KEY = "layout_marginRight";
    private static final String PROPERTY_TO_COPY_MARGIN_TOP_KEY = "layout_marginTop";

    private static final HashSet<String> TOOLTIP_PROPERTIES_TO_COPY =
            new HashSet<>(Arrays.asList(
                    PROPERTY_TO_COPY_PADDING_BOTTOM_KEY,
                    PROPERTY_TO_COPY_PADDING_LEFT_KEY,
                    PROPERTY_TO_COPY_PADDING_RIGHT_KEY,
                    PROPERTY_TO_COPY_PADDING_TOP_KEY,
                    PROPERTY_TO_COPY_MARGIN_BOTTOM_KEY,
                    PROPERTY_TO_COPY_MARGIN_LEFT_KEY,
                    PROPERTY_TO_COPY_MARGIN_RIGHT_KEY,
                    PROPERTY_TO_COPY_MARGIN_TOP_KEY));

    public static JsonObject wrapWithLinearLayout(final JsonObject tooltip) {
        JsonObject wrapperLinearLayoutObject = new JsonObject();
        wrapperLinearLayoutObject.add(PROPERTIES_KEY, createProperties(tooltip.getAsJsonArray(PROPERTIES_KEY)));
        wrapperLinearLayoutObject.add(VIEWS_KEY, tooltip.getAsJsonArray(VIEWS_KEY));
        wrapperLinearLayoutObject.addProperty(WIDGET_KEY, WIDGET_VALUE);
        wrapperLinearLayoutObject.addProperty(CONTAINER_ID_KEY, CONTAINER_ID_VALUE);
        wrapperLinearLayoutObject.addProperty(SCROLLABLE_KEY, false);

        return wrapperLinearLayoutObject;
    }

    private static JsonObject createProperty(
            @NonNull final String propertyName,
            @NonNull final String propertyType,
            @NonNull final Object propertyValue) {
        final JsonObject property = new JsonObject();
        property.addProperty(PROPERTY_NAME_KEY, propertyName);
        property.addProperty(PROPERTY_NAME_TYPE, propertyType);
        if (propertyType.contains(PROPERTY_NAME_TYPE_STRING) || propertyType.contains(PROPERTY_NAME_TYPE_DIMEN)) {
            property.addProperty(PROPERTY_NAME_VALUE, (String) propertyValue);
        } else if (propertyType.contains(PROPERTY_NAME_TYPE_BOOLEAN)) {
            property.addProperty(PROPERTY_NAME_VALUE, (Boolean) propertyValue);
        }
        return property;
    }

    @NonNull
    private static JsonArray createProperties(final JsonArray tooltipProperties) {
        final JsonArray properties = new JsonArray();
        properties.add(createProperty(PROPERTY_NAME_LAYOUT_WIDTH_KEY, PROPERTY_NAME_TYPE_DIMEN, PROPERTY_NAME_LAYOUT_WRAP_CONTENT_VALUE));
        properties.add(createProperty(PROPERTY_NAME_LAYOUT_HEIGHT_KEY, PROPERTY_NAME_TYPE_DIMEN, PROPERTY_NAME_LAYOUT_WRAP_CONTENT_VALUE));
        properties.add(createProperty(PROPERTY_NAME_ORIENTATION_KEY, PROPERTY_NAME_TYPE_STRING, PROPERTY_NAME_ORIENTATION_VALUE));
        properties.add(createProperty(PROPERTY_NAME_ENABLED_KEY, PROPERTY_NAME_TYPE_BOOLEAN, true));
        for (String propertyName : TOOLTIP_PROPERTIES_TO_COPY) {
            JsonObject property = getPropertyWithName(tooltipProperties, propertyName);
            if (property != null) {
                properties.add(property);
            }
        }
        return properties;
    }

    @Nullable
    public static JsonObject getPropertyWithName(@Nullable final JsonArray properties, @NonNull final String propertyName) {
        if (properties == null || properties.size() == 0) {
            return null;
        }

        for (int i = 0; i < properties.size(); i++) {
            JsonObject jsonObject = properties.get(i).getAsJsonObject();
            JsonPrimitive primitive = jsonObject.getAsJsonPrimitive(PROPERTY_NAME_KEY);
            if (primitive != null && propertyName.contentEquals(primitive.getAsString())) {
                return jsonObject;
            }
        }
        return null;
    }

    private static final int FORMAT_RGB_LENGTH = 4;
    private static final int FORMAT_RRGGBB_LENGTH = 7;
    private static final int FORMAT_RRGGBBAA_LENGTH = 9;
    private static final int ALPHA_HEX_OFFSET = 7;
    private static final int RRGGBBAA_START_OFFSET = 1;

    /**
     * Convert #RRGGBBAA to #AARRGGBB
     * @param rawColor color in #X...X format string
     * @return if the color is in #XXXXXX format, or #XXX format returns the color, if it is in
     * #XXXXXXXX we assume it is #RRGGBBAA and convert it to #AARRGGBB
     */
    @NonNull
    public static String convertRRGGBBAAToAARRGGBBColor(@NonNull final String rawColor) {
        if (!rawColor.startsWith("#")) {
            return rawColor;
        }
        int rawColorLength = rawColor.length();
        if (rawColorLength == FORMAT_RGB_LENGTH || rawColorLength == FORMAT_RRGGBB_LENGTH) { //meaning #RGB or #RRGGBB
            return rawColor;
        }
        if (rawColorLength == FORMAT_RRGGBBAA_LENGTH) { //meaning #RRGGBBAA we wish to flip it to #AARRGGBB
            String opacityBytes = rawColor.substring(ALPHA_HEX_OFFSET);
            String colorBytes = rawColor.substring(RRGGBBAA_START_OFFSET, ALPHA_HEX_OFFSET);
            return String.format("#%s%s", opacityBytes, colorBytes);
        }
        return rawColor;
    }

}
