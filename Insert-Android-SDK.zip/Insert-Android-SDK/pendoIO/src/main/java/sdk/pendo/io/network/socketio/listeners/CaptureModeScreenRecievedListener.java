package sdk.pendo.io.network.socketio.listeners;

import external.sdk.pendo.io.socket.emitter.Emitter;
import sdk.pendo.io.network.socketio.configuration.SocketEvents;
import sdk.pendo.io.network.socketio.state.machines.SocketEventFSM;
import sdk.pendo.io.logging.InsertLogger;

/**
 * Listen on {@link SocketEvents#EVENT_CAPTURE_MODE_SCREEN_RECEIVED}.
 */
public final class CaptureModeScreenRecievedListener implements Emitter.Listener {

    @Override
    public void call(Object... args) {
        InsertLogger.d("SocketIO device got: captureModeScreenRecieved");
        SocketEventFSM.getInstance().move(SocketEventFSM.Events.EVENT_CAPTURE_MODE_SCREEN_RECEIVED);
    }
}
