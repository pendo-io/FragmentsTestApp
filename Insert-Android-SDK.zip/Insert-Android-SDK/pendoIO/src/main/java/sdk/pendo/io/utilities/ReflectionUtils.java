package sdk.pendo.io.utilities;

import java.lang.reflect.Field;

import sdk.pendo.io.logging.InsertLogger;

/**
 * Utility class for Java reflection.
 *
 * Created by assaf on 11/23/16.
 */
public final class ReflectionUtils {
    private ReflectionUtils() {
    }

    public static Object getFieldValue(String fieldName, Object target) {
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(target);
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

        return null;
    }
}
