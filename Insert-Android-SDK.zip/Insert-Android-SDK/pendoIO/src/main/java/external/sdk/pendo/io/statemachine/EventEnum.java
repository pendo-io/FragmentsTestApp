package external.sdk.pendo.io.statemachine;

/**
 * User: andrey
 * Date: 3/12/2013
 * Time: 9:52 PM
 */
public interface EventEnum {
    String name();
}
