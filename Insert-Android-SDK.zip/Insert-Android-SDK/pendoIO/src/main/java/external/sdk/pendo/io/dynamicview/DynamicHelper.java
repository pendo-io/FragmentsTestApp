package external.sdk.pendo.io.dynamicview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputType;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.analytics.GenericInsertAnalyticsData;
import sdk.pendo.io.constants.Constants;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.AnalyticsUtils;
import sdk.pendo.io.utilities.FontUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.views.custom.ActionableBlock;
import sdk.pendo.io.views.custom.IBackgroundRenderView;
import sdk.pendo.io.views.custom.InsertCircularCloseButton;
import sdk.pendo.io.views.custom.InsertCompoundButton;
import sdk.pendo.io.views.custom.InsertCustomView;
import sdk.pendo.io.views.custom.InsertEditText;
import sdk.pendo.io.views.custom.InsertRadioButton;
import sdk.pendo.io.views.custom.VisualActionButton;
import sdk.pendo.io.views.custom.VisualActionImage;

import static sdk.pendo.io.constants.Constants.GeneralConsts.TYPE_STRING;
import static sdk.pendo.io.utilities.ResourceUtils.getResources;
import static sdk.pendo.io.constants.Constants.GeneralConsts.RTL;

/**
 * Created by avocarrot on 11/12/2014. Helper function that applies properties in views.
 */
@SuppressWarnings("CheckStyle")
public class DynamicHelper {

    /**
     * apply dynamic properties that are not relative with layout in view
     *
     * @param view
     * @param properties
     */
    public static String applyStyleProperties(View view, List<DynamicProperty> properties) {
        String id = "";
        DynamicProperty textStyle = null;

        //Find text style prop, for font-family.
        for (DynamicProperty dynProp : properties) {
            if (dynProp.name != null && dynProp.name.equals(DynamicProperty.NAME.TEXTSTYLE)) {
                textStyle = dynProp;
                break;
            }
        }

        for (DynamicProperty dynProp : properties) {
            switch (dynProp.name) {
                case ID: {
                    id = dynProp.getValueString();
                }
                break;
                case BACKGROUND: {
                    applyBackground(view, dynProp);
                }
                break;
                case TEXT: {
                    applyText(view, dynProp);
                }
                break;
                case TEXTCOLOR: {
                    applyTextColor(view, dynProp);
                }
                break;
                case TEXTSIZE: {
                    applyTextSize(view, dynProp);
                }
                break;
                case TEXTSTYLE: {
                    applyTextStyle(view, dynProp);
                }
                break;
                case PADDING: {
                    applyPadding(view, dynProp);
                }
                break;
                case PADDING_LEFT: {
                    applyPadding(view, dynProp, 0);
                }
                break;
                case PADDING_TOP: {
                    applyPadding(view, dynProp, 1);
                }
                break;
                case PADDING_RIGHT: {
                    applyPadding(view, dynProp, 2);
                }
                break;
                case PADDING_BOTTOM: {
                    applyPadding(view, dynProp, 3);
                }
                break;
                case MINWIDTH: {
                    applyMinWidth(view, dynProp);
                }
                break;
                case MINHEIGHT: {
                    applyMinHeight(view, dynProp);
                }
                break;
                case ELLIPSIZE: {
                    applyEllipsize(view, dynProp);
                }
                break;
                case MAXLINES: {
                    applyMaxLines(view, dynProp);
                }
                break;
                case ORIENTATION: {
                    applyOrientation(view, dynProp);
                }
                break;
                case SUM_WEIGHT:
                case WEIGHTSUM: {
                    applyWeightSum(view, dynProp);
                }
                break;
                case GRAVITY: {
                    applyGravity(view, dynProp);
                }
                break;
                case FONTFAMILY: {
                    applyFontFamily(view, dynProp, textStyle);
                }
                break;
                case SRC: {
                    applySrc(view, dynProp);
                }
                break;
                case SCALETYPE: {
                    applyScaleType(view, dynProp);
                }
                break;
                case ADJUSTVIEWBOUNDS: {
                    applyAdjustBounds(view, dynProp);
                }
                break;
                case DRAWABLELEFT: {
                    applyCompoundDrawable(view, dynProp, 0);
                }
                break;
                case DRAWABLETOP: {
                    applyCompoundDrawable(view, dynProp, 1);
                }
                break;
                case DRAWABLERIGHT: {
                    applyCompoundDrawable(view, dynProp, 2);
                }
                break;
                case DRAWABLEBOTTOM: {
                    applyCompoundDrawable(view, dynProp, 3);
                }
                break;
                case ENABLED: {
                    applyEnabled(view, dynProp);
                }
                break;
                case SELECTED: {
                    applySelected(view, dynProp);
                }
                break;
                case CLICKABLE: {
                    applyClickable(view, dynProp);
                }
                break;
                case SCALEX: {
                    applyScaleX(view, dynProp);
                }
                break;
                case SCALEY: {
                    applyScaleY(view, dynProp);
                }
                break;
                case TAG: {
                    applyTag(view, dynProp);
                }
                break;
                case FUNCTION: {
                    applyFunction(view, dynProp);
                }
                break;
                case VISIBILITY: {
                    applyVisibility(view, dynProp);
                }
                break;
                case ONSUBMIT: {
                    applyOnSubmit(view, dynProp);
                }
                break;
                case XCOLOR: {
                    applyXColor(view, dynProp);
                }
                break;
                case XWIDTH: {
                    applyXWidth(view, dynProp);
                }
                break;
                case FRAMECOLOR: {
                    applyFrameColor(view, dynProp);
                }
                break;
                case FRAMEWIDTH: {
                    applyFrameWidth(view, dynProp);
                }
                break;
                case TEXTDIRECTION: {
                    applyTextDirection(view, dynProp);
                }
                break;
                case CHECKED: {
                    applyChecked(view, dynProp, properties);
                }
                break;
                case CHECKEDBACKGROUND: {
                    applyCheckedBackground(view, dynProp);
                }
                break;
                case CHECKEDTEXTCOLOR: {
                    applyCheckedTextColor(view, dynProp);
                }
                break;
                case BACKGROUNDIMAGEURL: {
                    applyBackgroundImage(view, dynProp);
                }
                break;
                case BACKGROUNDIMAGEFILLTYPE: {
                    applyBackgroundImageFillType(view, dynProp);
                }
                case HINT: {
                    applyHint(view, dynProp);
                }
                break;
                case VALIDATOR: {
                    applyValidator(view, dynProp);
                }
                break;
                case TEXTCOLORHINT: {
                    applyHintTextColor(view, dynProp);
                }
                break;
                case SINGLELINE: {
                    applySingleLine(view, dynProp);
                }
                break;
                case INPUTTYPE: {
                    applyInputType(view, dynProp, properties);
                }
                break;
                case CORNERRADIUS: {
                    applyCornerRadius(view, dynProp);
                }
                break;
                case TEXTCOLORNORMAL: {
                    applyTextColorNormal(view, dynProp);
                }
                break;
                case TEXTCOLORPRESSED: {
                    applyTextColorPressed(view, dynProp);
                }
                break;
                case TEXTCOLORDISABLED: {
                    applyTextColorDisabled(view, dynProp);
                }
                break;
                case BACKGROUNDCOLORNORMAL: {
                    applyBackgroundColorNormal(view, dynProp);
                }
                break;
                case BACKGROUNDCOLORPRESSED: {
                    applyBackgroundColorPressed(view, dynProp);
                }
                break;
                case BACKGROUNDCOLORDISABLED: {
                    applyBackgroundColorDisabled(view, dynProp);
                }
                break;
            }
        }

        // Finished applying all properties, now ready to render the view.
        if (view instanceof InsertCustomView) {
            ((InsertCustomView) view).renderView();
        }

        return id;
    }

    private static void applyHintTextColor(View view, DynamicProperty dynProp) {
        if (view instanceof EditText &&
                dynProp.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((EditText) view).setHintTextColor(dynProp.getValueColor());
        }
    }

    private static void applyVisibility(View view, DynamicProperty dynProp) {
        final String valueString = dynProp.getValueString();

        if (valueString == null) {
            return;
        }

        if (valueString.equalsIgnoreCase("removed") || valueString.equalsIgnoreCase("gone")) {
            view.setVisibility(View.GONE);
        } else if (valueString.equals("hidden")) {
            view.setVisibility(View.INVISIBLE);
        } else if (valueString.equals("visible")) {
            view.setVisibility(View.VISIBLE);
        }
    }

    private static void applyInputType(View view, DynamicProperty dynProp,
                                       List<DynamicProperty> properties) {
        if (view instanceof EditText) {
            ((EditText) view).setInputType(calculateInputType(dynProp.getValueString()));
        }
    }

    private static int calculateInputType(String valueString) {
        int inputType = InputType.TYPE_NULL;
        if (valueString.equals("text")) {
            inputType = InputType.TYPE_CLASS_TEXT;
        } else if (valueString.equals("textMultiLine")) {
            inputType = InputType.TYPE_TEXT_FLAG_MULTI_LINE;
        } else if (valueString.equals("textUri")) {
            inputType = InputType.TYPE_TEXT_VARIATION_URI;
        } else if (valueString.equals("textEmailAddress")) {
            inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS;
        } else if (valueString.equals("textPassword")) {
            inputType = InputType.TYPE_TEXT_VARIATION_PASSWORD;
        } else if (valueString.equals("number")) {
            inputType = InputType.TYPE_CLASS_NUMBER;
        } else if (valueString.equals("phone")) {
            inputType = InputType.TYPE_CLASS_PHONE;
        }
        return inputType;
    }

    private static void applySingleLine(View view, DynamicProperty dynProp) {
        if (view instanceof EditText) {
            ((EditText) view).setSingleLine(dynProp.getValueBoolean());
        }
    }

    private static void applyHint(View view, DynamicProperty dynProp) {
        if (view instanceof EditText) {
            ((EditText) view).setHint(dynProp.getValueString());
        }
    }

    private static void applyValidator(View view, DynamicProperty dynProp) {
        if (view instanceof InsertEditText) {
            final String validator = dynProp.getValueString();

            if (DynamicProperty.TYPE.REGEX.equals(dynProp.type)) {
                final Pattern pattern = Pattern.compile(validator);
                ((InsertEditText) view).setValidator(pattern);
            }
        }
    }

    private static void applyBackgroundImageFillType(View view, DynamicProperty dynProp) {
        if (view instanceof IBackgroundRenderView) {
            ((IBackgroundRenderView) view).setImageFillType(dynProp.getValueString());
        }
    }

    private static void applyBackgroundImage(View view, DynamicProperty dynProp) {
        if (view instanceof IBackgroundRenderView) {
            ((IBackgroundRenderView) view).setImageBackgroundURL(dynProp.getValueString());
        }
    }

    private static void applyTextDirection(View view, DynamicProperty property) {
        if (RTL.equals(property.getValueString())) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                // WARNING: This will cause RTL languages to be aligned to the left.
                // view.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
                view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        }
    }

//    private static void applyActionType(View view, DynamicProperty property) {
//        if (view instanceof ActionableBlock
//                && property.type.equals(DynamicProperty.TYPE.STRING)) {
//            ((ActionableBlock) view).setActionType(ActionableBlock.BlockActionType.get(property.getValueString()));
//        }
//    }

    private static void applyXColor(View view, DynamicProperty property) {
        if (view instanceof InsertCircularCloseButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((InsertCircularCloseButton) view).setXColor(property.getValueColor());

        }
    }

    private static void applyXWidth(View view, DynamicProperty property) {
        if (view instanceof InsertCircularCloseButton
                && property.type.equals(DynamicProperty.TYPE.DIMEN)) {
            ((InsertCircularCloseButton) view).setXWidth(property.getValueInt());
        }
    }

    private static void applyFrameWidth(View view, DynamicProperty property) {
        if (property.type.equals(DynamicProperty.TYPE.DIMEN)) {
            if (view instanceof InsertCustomView) {
                ((InsertCustomView) view).setStrokeWidth(property.getValueInt());
            }
        }
    }

    private static void applyFrameColor(View view, DynamicProperty property) {
        if (property.type.equals(DynamicProperty.TYPE.COLOR)) {
            if (view instanceof InsertCustomView) {
                ((InsertCustomView) view).setStrokeColor(property.getValueColor());
            }
        }
    }

    private static void applyCheckedBackground(View view, DynamicProperty property) {
        if (property.type.equals(DynamicProperty.TYPE.COLOR)) {
            if (view instanceof InsertCompoundButton) {
                ((InsertCompoundButton) view).setCheckedBackgroundColor(property.getValueColor());

                // TODO: 8/26/15 Once we find a way to merge InsertRadioButton and InsertCompoundButton, remove this.
            } else if (view instanceof InsertRadioButton) {
                ((InsertRadioButton) view).setCheckedBackgroundColor(property.getValueColor());
            }
        }
    }

    private static void applyCheckedTextColor(View view, DynamicProperty property) {
        if (property.type.equals(DynamicProperty.TYPE.COLOR)) {
            if (view instanceof InsertCompoundButton) {
                ((InsertCompoundButton) view).setCheckedTextColor(property.getValueColor());

                // TODO: 8/26/15 Once we find a way to merge InsertRadioButton and InsertCompoundButton, remove this.
            } else if (view instanceof InsertRadioButton) {
                ((InsertRadioButton) view).setCheckedTextColor(property.getValueColor());
            }
        }
    }

    private static void applyAction(View view, DynamicProperty property) {

        if (view instanceof ActionableBlock
                && property.type.equals(DynamicProperty.TYPE.STRING)) {

            ((ActionableBlock) view).setActionParam(property.getValueString());
        }
    }

    private static void applyOnSubmit(View view, DynamicProperty property) {

        if (view instanceof ActionableBlock
                && property.type.equals(DynamicProperty.TYPE.STRING)) {

            ((ActionableBlock) view).setOnSubmit(property.getValueString());
        }
    }

    private static void applyCornerRadius(View view, DynamicProperty property) {
        if (view instanceof InsertCustomView) {
            switch (property.type) {
                case DIMEN:
                    ((InsertCustomView) view).setCornerRadius(property.getValueFloat());
                    break;

                case ARRAY:
                    ((InsertCustomView) view).setCornerRadii(property.getValueFloatArray());
                    break;
            }
        }
    }

    private static void applyTextColorNormal(View view, DynamicProperty property) {
        if (view instanceof VisualActionButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((VisualActionButton) view).setNormalTextColor(property.getValueColor());
        }
    }

    private static void applyTextColorPressed(View view, DynamicProperty property) {
        if (view instanceof VisualActionButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((VisualActionButton) view).setPressedTextColor(property.getValueColor());
        }
    }

    private static void applyTextColorDisabled(View view, DynamicProperty property) {
        if (view instanceof VisualActionButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((VisualActionButton) view).setDisabledTextColor(property.getValueColor());
        }
    }

    private static void applyBackgroundColorNormal(View view, DynamicProperty property) {
        if (view instanceof VisualActionButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((VisualActionButton) view).setNormalBackgroundColor(property.getValueColor());
        }
    }

    private static void applyBackgroundColorPressed(View view, DynamicProperty property) {
        if (view instanceof VisualActionButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((VisualActionButton) view).setPressedBackgroundColor(property.getValueColor());
        }
    }

    private static void applyBackgroundColorDisabled(View view, DynamicProperty property) {
        if (view instanceof VisualActionButton
                && property.type.equals(DynamicProperty.TYPE.COLOR)) {
            ((VisualActionButton) view).setDisabledBackgroundColor(property.getValueColor());
        }
    }

    /**
     * apply dynamic properties for layout in view
     *
     * @param view
     * @param properties : layout properties to apply
     * @param viewGroup  : parent view
     * @param ids        : hashmap of ids <String, Integer> (string as setted in json, int that we use in
     *                   layout)
     */
    public static void applyLayoutProperties(View view, List<DynamicProperty> properties,
                                             ViewGroup viewGroup, HashMap<String, Integer> ids) {
        if (viewGroup == null) {
            return;
        }
        ViewGroup.LayoutParams params = createLayoutParams(viewGroup);

        for (DynamicProperty dynProp : properties) {
            try {
                switch (dynProp.name) {
                    case LAYOUT_HEIGHT: {
                        params.height = resolveHeight(dynProp.getValueInt(), properties);
                    }
                    break;
                    case LAYOUT_WIDTH: {
                        params.width = dynProp.getValueInt();
                    }
                    break;
                    case LAYOUT_MARGIN: {
                        if (params instanceof ViewGroup.MarginLayoutParams) {
                            ViewGroup.MarginLayoutParams p = ((ViewGroup.MarginLayoutParams) params);
                            p.bottomMargin = p.topMargin = p.leftMargin = p.rightMargin = dynProp.getValueInt();
                        }
                    }
                    break;
                    case LAYOUT_MARGINLEFT: {
                        if (params instanceof ViewGroup.MarginLayoutParams) {
                            ((ViewGroup.MarginLayoutParams) params).leftMargin = dynProp.getValueInt();
                        }
                    }
                    break;
                    case LAYOUT_MARGINTOP: {
                        if (params instanceof ViewGroup.MarginLayoutParams) {
                            ((ViewGroup.MarginLayoutParams) params).topMargin = dynProp.getValueInt();
                        }
                    }
                    break;
                    case LAYOUT_MARGINRIGHT: {
                        if (params instanceof ViewGroup.MarginLayoutParams) {
                            ((ViewGroup.MarginLayoutParams) params).rightMargin = dynProp.getValueInt();
                        }
                    }
                    break;
                    case LAYOUT_MARGINBOTTOM: {
                        if (params instanceof ViewGroup.MarginLayoutParams) {
                            ((ViewGroup.MarginLayoutParams) params).bottomMargin = dynProp.getValueInt();
                        }
                    }
                    break;
                    case LAYOUT_ABOVE: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.ABOVE,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_BELOW: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.BELOW,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_TOLEFTOF: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.LEFT_OF,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_TORIGHTOF: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.RIGHT_OF,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_TOSTARTOF: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.START_OF,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_TOENDOF: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.END_OF,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNBASELINE: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_BASELINE,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNLEFT: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_LEFT, ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNTOP: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.ALIGN_TOP,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNRIGHT: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_RIGHT, ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNBOTTOM: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_BOTTOM, ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNSTART: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_START, ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNEND: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(RelativeLayout.ALIGN_END,
                                    ids.get(dynProp.getValueString()));
                        }
                    }
                    break;
                    case LAYOUT_ALIGNWITHPARENTIFMISSING: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).alignWithParent = dynProp.getValueBoolean();
                        }
                    }
                    break;
                    case LAYOUT_ALIGNPARENTTOP: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_PARENT_TOP);
                        }
                    }
                    break;
                    case LAYOUT_ALIGNPARENTBOTTOM: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_PARENT_BOTTOM);
                        }
                    }
                    break;
                    case LAYOUT_ALIGNPARENTLEFT: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_PARENT_LEFT);
                        }
                    }
                    break;
                    case LAYOUT_ALIGNPARENTRIGHT: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_PARENT_RIGHT);
                        }
                    }
                    break;
                    case LAYOUT_ALIGNPARENTSTART: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_PARENT_START);
                        }
                    }
                    break;
                    case LAYOUT_ALIGNPARENTEND: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.ALIGN_PARENT_END);
                        }
                    }
                    break;
                    case LAYOUT_CENTERHORIZONTAL: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.CENTER_HORIZONTAL);
                        }
                    }
                    break;
                    case LAYOUT_CENTERVERTICAL: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.CENTER_VERTICAL);
                        }
                    }
                    break;
                    case LAYOUT_CENTERINPARENT: {
                        if (params instanceof RelativeLayout.LayoutParams) {
                            ((RelativeLayout.LayoutParams) params).addRule(
                                    RelativeLayout.CENTER_IN_PARENT);
                        }
                    }
                    break;
                    case LAYOUT_GRAVITY: {
                        if (!(viewGroup instanceof ScrollView)) {
                            switch (dynProp.type) {
                                case INTEGER: {
                                    if (params instanceof LinearLayout.LayoutParams) {
                                        ((LinearLayout.LayoutParams) params).gravity = dynProp.getValueInt();
                                    }
                                    if (params instanceof FrameLayout.LayoutParams) {
                                        ((FrameLayout.LayoutParams) params).gravity = dynProp.getValueInt();
                                    }
                                    if (params instanceof RadioGroup.LayoutParams) {
                                        ((RadioGroup.LayoutParams) params).gravity = dynProp.getValueInt();
                                    }
                                }
                                break;
                                case STRING: {
                                    if (params instanceof LinearLayout.LayoutParams) {
                                        Integer gravityIntValue = getGravityIntValue(dynProp,
                                                dynProp.getValueString().toUpperCase());
                                        ((LinearLayout.LayoutParams) params).gravity = gravityIntValue;
                                    }
                                    if (params instanceof FrameLayout.LayoutParams) {
                                        Integer gravityIntValue = getGravityIntValue(dynProp,
                                                dynProp.getValueString().toUpperCase());
                                        ((FrameLayout.LayoutParams) params).gravity = gravityIntValue;
                                    }
                                    if (params instanceof RadioGroup.LayoutParams) {
                                        Integer gravityIntValue = getGravityIntValue(dynProp,
                                                dynProp.getValueString().toUpperCase());
                                        ((RadioGroup.LayoutParams) params).gravity = gravityIntValue;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    break;
                    case LAYOUT_WEIGHT: {
                        switch (dynProp.type) {
                            case FLOAT: {
                                if (params instanceof LinearLayout.LayoutParams) {
                                    ((LinearLayout.LayoutParams) params).weight = dynProp.getValueFloat();
                                }
                            }
                            break;
                        }
                    }
                    break;
                }
            } catch (Exception ignore) {
            }
        }
        view.setLayoutParams(params);
    }

    /**
     * Resolving the height by limiting the max height of a view group
     * in case match parent / wrap content is used.
     * This useful especially for tablet scenarios where you would want
     * the insert to not take all the height of the screen
     * @param heightValue required height value
     * @param properties list of properties
     * @return the resolved height
     */
    private static int resolveHeight(int heightValue, List<DynamicProperty> properties) {
        if (heightValue == ViewGroup.LayoutParams.MATCH_PARENT
                || heightValue == ViewGroup.LayoutParams.WRAP_CONTENT) {
            // Height was set as match parent.
            // check if there is no max height to limit this requirement
            Integer maxHeight = null;
            for (DynamicProperty property : properties) {
                if (property.name.equals(DynamicProperty.NAME.MAXHEIGHT)) {
                     maxHeight = property.getValueInt();
                }
            }
            if (maxHeight != null) {
                // max height exists
                DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
                float heightPixels = displayMetrics.heightPixels;
                if (maxHeight < heightPixels) {
                    return maxHeight;
                }
            }
        }
        return heightValue;
    }

    private static Integer getGravityIntValue(DynamicProperty dynProp, String varName) {
        String[] splitedVarName = varName.split("\\|");
        int valueSum = 0;
        for (String splitedVarNameItem : splitedVarName) {
            valueSum += (Integer) dynProp.getValueInt(Gravity.class,
                    splitedVarNameItem.toUpperCase(Locale.US));
        }
        return valueSum;
    }

    public static ViewGroup.LayoutParams createLayoutParams(ViewGroup viewGroup) {
        ViewGroup.LayoutParams params = null;
        if (viewGroup != null) {
            try {
                /* find parent viewGroup and create LayoutParams of that class */
                Class layoutClass = viewGroup.getClass();
                while (!classExists(layoutClass.getName() + "$LayoutParams")) {
                    layoutClass = layoutClass.getSuperclass();
                }
                String layoutParamsClassname = layoutClass.getName() + "$LayoutParams";
                Class layoutParamsClass = Class.forName(layoutParamsClassname);
                /* create the actual layoutParams object */
                params = (ViewGroup.LayoutParams) layoutParamsClass.getConstructor(Integer.TYPE,
                        Integer.TYPE).newInstance(
                        new Object[]{ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT});
            } catch (Exception e) {
                InsertLogger.e(e,
                        "view class: '" + viewGroup.getClass() + "' Message:" + e.getMessage());
            }
        }
        if (params == null) {
            params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        return params;
    }

    /*** View Properties ***/

    /**
     * apply background in view (except image from url). possible types:
     * - COLOR
     * - REF => search for that drawable in resources
     * - BASE64 => convert base64 to bitmap and apply in view
     */
    public static void applyBackground(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case COLOR: {

                    int valueColor = property.getValueColor();
                    if (view instanceof InsertCircularCloseButton) {
                        ((InsertCircularCloseButton) view).setCircleColor(valueColor);
                    } else {

                        if (view instanceof InsertCompoundButton) {
                            ((InsertCompoundButton) view).setDefaultBackgroundColor(valueColor);

                            // TODO: 8/26/15 Once we find a way to merge InsertRadioButton and InsertCompoundButton, remove this.
                        } else if (view instanceof InsertRadioButton) {
                            ((InsertRadioButton) view).setDefaultBackgroundColor(valueColor);
                        }
                        view.setBackgroundColor(valueColor);
                    }
                }
                break;
                case REF: {
                    view.setBackgroundResource(
                            getDrawableId(view.getContext(), property.getValueString()));
                }
                break;
                case BASE64: {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
                        view.setBackground(property.getValueBitmapDrawable());
                    } else {
                        //noinspection deprecation
                        view.setBackgroundDrawable(property.getValueBitmapDrawable());
                    }
                }
                break;
                case DRAWABLE: {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
                        view.setBackground(property.getValueGradientDrawable());
                    } else {
                        //noinspection deprecation
                        view.setBackgroundDrawable(property.getValueGradientDrawable());
                    }
                }
                break;
            }
        }
    }

    /**
     * apply padding in view
     */
    public static void applyPadding(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case DIMEN: {
                    int padding = property.getValueInt();
                    view.setPadding(padding, padding, padding, padding);
                }
                break;
            }
        }
    }

    /**
     * apply padding in view
     */
    public static void applyPadding(View view, DynamicProperty property, int position) {
        if (view != null && !(view instanceof InsertRadioButton)) {
            switch (property.type) {
                case DIMEN: {
                    int[] padding = new int[]{
                            view.getPaddingLeft(),
                            view.getPaddingTop(),
                            view.getPaddingRight(),
                            view.getPaddingBottom()
                    };
                    padding[position] = property.getValueInt();
                    view.setPadding(padding[0], padding[1], padding[2], padding[3]);
                }
                break;
            }
        }
    }

    /**
     * apply minimum Width in view
     */
    public static void applyMinWidth(View view, DynamicProperty property) {
        if (view != null) {
            if (property.type == DynamicProperty.TYPE.DIMEN) {
                view.setMinimumWidth(property.getValueInt());
            }
        }
    }

    /**
     * apply minimum Height in view
     */
    public static void applyMinHeight(View view, DynamicProperty property) {
        if (view != null) {
            if (property.type == DynamicProperty.TYPE.DIMEN) {
                view.setMinimumHeight(property.getValueInt());
            }
        }
    }

    /**
     * apply enabled in view
     */
    public static void applyEnabled(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case BOOLEAN: {
                    view.setEnabled(property.getValueBoolean());
                }
                break;
            }
        }
    }

    /**
     * apply selected in view
     */
    public static void applySelected(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case BOOLEAN: {
                    view.setSelected(property.getValueBoolean());
                }
                break;
            }
        }
    }

    /**
     * apply checked in view
     */
    public static void applyChecked(View view, DynamicProperty property,
                                    List<DynamicProperty> properties) {
        if (view != null && view instanceof CompoundButton) {
            switch (property.type) {
                case BOOLEAN: {

                    if (view instanceof RadioButton) {

                        // A fix for Android's bug where it will not account for checked RadioButtons
                        // with no ids that comes from XML; the checked RadioButton stuck as checked forever.
                        boolean setFakeId = true;
                        for (DynamicProperty prop : properties) {
                            if (DynamicProperty.NAME.ID.equals(prop.name)) {
                                setFakeId = false;
                                break;
                            }
                        }
                        if (setFakeId) {
                            view.setId(Utils.generateViewId());

                            JSONObject ai = new JSONObject();

                            try {
                                ai.put("elementType", "RadioButton");
                                ai.put("error", "No ID for RadioButton!");
                            } catch (JSONException ignore) {
                            }

                            AnalyticsUtils.sendErrorReport(
                                    GenericInsertAnalyticsData.NotDisplayReason.ERROR_REASON_CONFIGURATION,
                                    ai);
                        }
                    }
                    ((CompoundButton) view).setChecked(property.getValueBoolean());
                }
                break;
            }
        }
    }

    /**
     * apply clickable in view
     */
    public static void applyClickable(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case BOOLEAN: {
                    view.setClickable(property.getValueBoolean());
                }
                break;
            }
        }
    }

    /**
     * apply selected in view
     */
    public static void applyScaleX(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case BOOLEAN: {
                    view.setScaleX(property.getValueFloat());
                }
                break;
            }
        }
    }

    /**
     * apply selected in view
     */
    public static void applyScaleY(View view, DynamicProperty property) {
        if (view != null) {
            switch (property.type) {
                case BOOLEAN: {
                    view.setScaleY(property.getValueFloat());
                }
                break;
            }
        }
    }

    /*** TextView Properties ***/

    /**
     * apply text (used only in TextView)
     * - STRING : the actual string to set in textView
     * - REF : the name of string resource to apply in textView
     */
    public static void applyText(View view, DynamicProperty property) {
        if (view instanceof TextView) {
            switch (property.type) {
                case STRING: {
                    TextView tView = ((TextView) view);
                    String textToSet = property.getValueString();
                    tView.setText(textToSet);
                    // Add TextView content description in case of accessibility option turned on.
                    InsertContentDescriptionManager.getInstance().setTextViewImportance(tView,
                            textToSet);
                }
                break;
                case REF: {
                    ((TextView) view).setText(
                            getStringId(view.getContext(), property.getValueString()));
                }
                break;
            }
        }
    }

    /**
     * apply the color in textView
     */
    public static void applyTextColor(View view, DynamicProperty property) {
        if (view instanceof TextView) {
            switch (property.type) {
                case COLOR: {

                    int valueColor = property.getValueColor();
                    if (view instanceof InsertCompoundButton) {
                        ((InsertCompoundButton) view).setDefaultTextColor(valueColor);

                        // TODO: 8/26/15 Once we find a way to merge InsertRadioButton and InsertCompoundButton, remove this.
                    } else if (view instanceof InsertRadioButton) {
                        ((InsertRadioButton) view).setDefaultTextColor(valueColor);
                    }

                    ((TextView) view).setTextColor(valueColor);
                }
                break;
            }
        }
    }

    /**
     * apply the textSize in textView
     */
    public static void applyTextSize(View view, DynamicProperty property) {
        if (view instanceof TextView) {
            switch (property.type) {
                case DIMEN: {
                    ((TextView) view).setTextSize(TypedValue.COMPLEX_UNIT_PX,
                            property.getValueFloat());
                }
                break;
            }
        }
    }

    /**
     * apply the textStyle in textView
     */
    public static void applyTextStyle(View view, DynamicProperty property) {
        if (view instanceof TextView) {
            switch (property.type) {
                case INTEGER: {
                    ((TextView) view).setTypeface(null, property.getValueInt());
                }
                break;
                case STRING: {
                    final String valueString = property.getValueString();
                    final TextView textView = (TextView) view;

                    if ("bold".equals(valueString)) {
                        textView.setTypeface(null, Typeface.BOLD);
                    } else if ("italic".equals(valueString)) {
                        textView.setTypeface(null, Typeface.ITALIC);
                    } else if ("bold_italic".equals(valueString)) {
                        textView.setTypeface(null, Typeface.BOLD_ITALIC);
                    } else if ("underline".equals(valueString)) {
                        textView.setPaintFlags(
                                textView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
                    }
                }
                break;
            }
        }
    }

    /**
     * apply ellipsize property in textView
     */
    public static void applyEllipsize(View view, DynamicProperty property) {
        if (view instanceof TextView) {
            ((TextView) view).setEllipsize(
                    TextUtils.TruncateAt.valueOf(property.getValueString().toUpperCase().trim()));
        }
    }

    /**
     * apply maxLines property in textView
     */
    public static void applyMaxLines(View view, DynamicProperty property) {
        if (view instanceof TextView) {
            ((TextView) view).setMaxLines(property.getValueInt());
        }
    }

    /**
     * apply gravity property in textView
     * - INTEGER => valus of gravity in @link(Gravity.java)
     * - STRING => name of variable in @link(Gravity.java)
     */
    public static void applyGravity(View view, DynamicProperty property) {

        if (view instanceof TextView
                || view instanceof LinearLayout
                || view instanceof RelativeLayout
                || view instanceof EditText) {
            switch (property.type) {
                case INTEGER: {
                    int gravityIntValue = property.getValueInt();
                    if (view instanceof InsertRadioButton) {
                        ((InsertRadioButton) view).setGravity(
                                gravityIntValue | Gravity.CENTER_VERTICAL);
                    } else if (view instanceof LinearLayout) {
                        ((LinearLayout) view).setGravity(gravityIntValue);
                    } else if (view instanceof TextView) {
                        ((TextView) view).setGravity(gravityIntValue);
                    } else if (view instanceof RelativeLayout) {
                        ((RelativeLayout) view).setGravity(gravityIntValue);
                    } else if (view instanceof EditText) {
                        ((EditText) view).setGravity(gravityIntValue);
                    }
                }
                break;
                case STRING: {
                    int gravityIntValue = getGravityIntValue(property, property.getValueString());
                    if (view instanceof InsertRadioButton) {
                        ((InsertRadioButton) view).setGravity(
                                gravityIntValue | Gravity.CENTER_VERTICAL);
                    } else if (view instanceof LinearLayout) {
                        ((LinearLayout) view).setGravity(gravityIntValue);
                    } else if (view instanceof TextView) {
                        ((TextView) view).setGravity(gravityIntValue);
                    } else if (view instanceof RelativeLayout) {
                        ((RelativeLayout) view).setGravity(gravityIntValue);
                    } else if (view instanceof EditText) {
                        ((EditText) view).setGravity(gravityIntValue);
                    }
                }
                break;
            }
        }
    }

    public static void applyGravity(View view, String gravity) {
        JsonObject gravityObject = new JsonObject();
        try {
            gravityObject.addProperty(Constants.DynamicViewsConsts.NAME, Constants.ViewAttrsConsts.GRAVITY);
            gravityObject.addProperty(Constants.DynamicViewsConsts.TYPE,
                    (DynamicProperty.TYPE.STRING).toString());
            gravityObject.addProperty(Constants.DynamicViewsConsts.VALUE, gravity);
            DynamicHelper.applyGravity(view, new DynamicProperty(gravityObject));
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

    }

    public static void applyFontFamily(View view, DynamicProperty fontFamilyProperty,
                                       DynamicProperty textStyleProperty) {
        String fontFamilyString = fontFamilyProperty.getValueString();
        if (view instanceof TextView &&
                fontFamilyProperty.type != null &&
                fontFamilyProperty.type.equals(DynamicProperty.TYPE.STRING)) {
            // Try loading an external font.
            try {
                //Check if the received string is an array of fonts.
                if (Utils.isJSONArrayValid(fontFamilyString)) {
                    JSONArray fontListArray = new JSONArray(fontFamilyString);
                    for (int i = 0; i < fontListArray.length(); i++) {
                        final String font = fontListArray.get(i).toString();
                        if (FontUtils.checkIfExternalAndLoad(font, (TextView) view)) {
                            // In case we've found our external font.
                            return;
                        }
                    }
                } else {
                    if (!Utils.isJSONObjectValid(fontFamilyString)) {
                        // In case the received string is a single font (not an array or a json object)
                        boolean isExternal = FontUtils.checkIfExternalAndLoad(fontFamilyString,
                                (TextView) view);
                        if (isExternal) {
                            return;
                        }
                    }
                }
            } catch (JSONException e) {
                InsertLogger.e(e, e.getMessage());
            }
            // Choose font from received array in case the font isn't external.
            FontUtils.chooseAndSetFontFromArray(fontFamilyString,
                            textStyleProperty, (TextView) view);
        }
    }

    public static void applyFontFamily(View view, String fontStyle, String fontsArray) {
        JsonObject styleObject = new JsonObject();
        JsonObject fontObject = new JsonObject();
        try {
            styleObject.addProperty(Constants.DynamicViewsConsts.NAME,
                    Constants.ViewAttrsConsts.TEXT_STYLE);
            styleObject.addProperty(Constants.DynamicViewsConsts.TYPE,
                    (DynamicProperty.TYPE.STRING).toString());
            styleObject.addProperty(Constants.DynamicViewsConsts.VALUE, fontStyle);
            fontObject.addProperty(Constants.DynamicViewsConsts.NAME,
                    Constants.ViewAttrsConsts.FONT_FAMILY);
            fontObject.addProperty(Constants.DynamicViewsConsts.TYPE,
                    (DynamicProperty.TYPE.STRING).toString());
            fontObject.addProperty(Constants.DynamicViewsConsts.VALUE,
                    (new JSONArray(fontsArray)).toString());
            DynamicHelper.applyFontFamily(view, new DynamicProperty(fontObject), new DynamicProperty(styleObject));
        } catch (JSONException e) {
            InsertLogger.e(e, e.getMessage());
        }
    }
    /**
     * apply compound property in textView
     * position 0:left, 1:top, 2:right, 3:bottom
     * - REF : drawable to load as compoundDrawable
     * - BASE64 : decode as base64 and set as CompoundDrawable
     */
    public static void applyCompoundDrawable(View view, DynamicProperty property, int position) {
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            Drawable[] d = textView.getCompoundDrawables();
            switch (property.type) {
                case REF: {
                    try {
                        d[position] = view.getContext().getResources().getDrawable(
                                getDrawableId(view.getContext(), property.getValueString()));
                    } catch (Exception e) {
                    }
                }
                break;
                case BASE64: {
                    d[position] = property.getValueBitmapDrawable();
                }
                break;
                case DRAWABLE: {
                    d[position] = property.getValueGradientDrawable();
                }
                break;
            }
            textView.setCompoundDrawablesWithIntrinsicBounds(d[0], d[1], d[2], d[3]);
        }
    }


    /*** ImageView Properties ***/

    /**
     * apply src property in imageView
     * - REF => name of drawable
     * - BASE64 => decode value as base64 image
     */
    public static void applySrc(View view, DynamicProperty property) {

        if (view instanceof VisualActionImage
                && property.type.equals(DynamicProperty.TYPE.STRING)) {

            ((VisualActionImage) view).setResourceURL(property.getValueString());
            //We will receive this in the json, no need to always set this.
            //((VisualActionImage) view).setAdjustViewBounds(true);

        } else if (view instanceof ImageView) {
            switch (property.type) {
                case REF: {
                    ((ImageView) view).setImageResource(
                            getDrawableId(view.getContext(), property.getValueString()));
                }
                break;
                case BASE64: {
                    ((ImageView) view).setImageBitmap(property.getValueBitmap());
                }
                break;
            }
        }
    }

    /**
     * apply scaleType property in ImageView
     */
    public static void applyScaleType(View view, DynamicProperty property) {
        if (view instanceof ImageView) {
            switch (property.type) {
                case STRING: {
                    ((ImageView) view).setScaleType(
                            ImageView.ScaleType.valueOf(property.getValueString().toUpperCase()));
                }
                break;
            }
        }
    }

    /**
     * apply adjustBounds property in ImageView
     */
    public static void applyAdjustBounds(View view, DynamicProperty property) {
        if (view instanceof ImageView) {
            switch (property.type) {
                case BOOLEAN: {
                    ((ImageView) view).setAdjustViewBounds(property.getValueBoolean());
                }
                break;
            }
        }
    }

    /*** LinearLayout Properties ***/
    /**
     * apply orientation property in LinearLayout
     * - INTEGER => 0:Horizontal , 1:Vertical
     * - STRING
     */
    public static void applyOrientation(View view, DynamicProperty property) {
        if (view instanceof LinearLayout) {
            switch (property.type) {
                case INTEGER: {
                    ((LinearLayout) view).setOrientation(
                            property.getValueInt() == 0 ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
                }
                break;
                case STRING: {
                    ((LinearLayout) view).setOrientation(property.getValueString().equalsIgnoreCase(
                            "HORIZONTAL") ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
                }
                break;
            }
        }
    }

    /**
     * apply WeightSum property in LinearLayout
     */
    public static void applyWeightSum(View view, DynamicProperty property) {
        if ((view instanceof LinearLayout) && (property.type == DynamicProperty.TYPE.FLOAT)) {
            float valueFloat = property.getValueFloat();
            ((LinearLayout) view).setWeightSum(valueFloat);
        }
    }

    /**
     * add string as tag
     */
    public static void applyTag(View view, DynamicProperty property) {
        view.setTag(property.getValueString());
    }


    /**
     * apply generic function in View
     */
    public static void applyFunction(View view, DynamicProperty property) {

        if (property.type == DynamicProperty.TYPE.JSON) {
            try {
                JSONObject json = property.getValueJSON();

                String functionName = json.getString("function");
                JSONArray args = json.getJSONArray("args");

                Class[] argsClass;
                Object[] argsValue;
                if (args == null) {
                    argsClass = new Class[0];
                    argsValue = new Object[0];
                } else {
                    try {
                        List<Class> classList = new ArrayList<>();
                        List<Object> valueList = new ArrayList<>();

                        int i = 0;
                        int count = args.length();
                        for (; i < count; i++) {
                            JSONObject argJsonObj = args.getJSONObject(i);
                            boolean isPrimitive = argJsonObj.has("primitive");
                            String className = argJsonObj.getString(
                                    isPrimitive ? "primitive" : "class");
                            String classFullName = className;
                            if (!classFullName.contains(".")) {
                                classFullName = "java.lang." + className;
                            }
                            Class clazz = Class.forName(classFullName);
                            if (isPrimitive) {
                                Class primitiveType = (Class) clazz.getField("TYPE").get(null);
                                classList.add(primitiveType);
                            } else {
                                classList.add(clazz);
                            }

                            try {
                                valueList.add(getFromJSON(argJsonObj, "value", clazz));
                            } catch (Exception e) {
                                InsertLogger.e(e, e.getMessage());
                            }
                        }
                        argsClass = classList.toArray(new Class[classList.size()]);
                        argsValue = valueList.toArray(new Object[valueList.size()]);
                    } catch (Exception e) {
                        argsClass = new Class[0];
                        argsValue = new Object[0];
                    }
                }

                try {
                    view.getClass().getMethod(functionName, argsClass).invoke(view, argsValue);
                } catch (SecurityException e) {
                    InsertLogger.e(e, e.getMessage());
                } catch (NoSuchMethodException e) {
                    InsertLogger.e(e, e.getMessage());
                }

            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

    }


    /**
     * return the id (from the R.java autogenerated class) of the drawable that pass its name as
     * argument
     */
    public static int getDrawableId(Context context, String name) {
        return context.getResources().getIdentifier(name, "drawable", context.getPackageName());
    }

    /**
     * return the id (from the R.java autogenerated class) of the string that pass its name as
     * argument
     */
    public static int getStringId(Context context, String name) {
        return context.getResources().getIdentifier(name, TYPE_STRING, context.getPackageName());
    }

    /**
     * convert densityPixel to pixel
     */
    public static float dpToPx(float dp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                Resources.getSystem().getDisplayMetrics());
//        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    /**
     * convert scalePixel to pixel
     */
    public static float spToPx(float sp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp,
                Resources.getSystem().getDisplayMetrics());
    }

    /**
     * convert pixel to densityPixel
     */
    public static float pxToDp(int px) {
        return (px / Resources.getSystem().getDisplayMetrics().density);
    }

    /**
     * convert pixel to scaledDensityPixel
     */
    public static float pxToSp(int px) {
        return (px / Resources.getSystem().getDisplayMetrics().scaledDensity);
//        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, px, Resources.getSystem().getDisplayMetrics());
    }

    /**
     * convert densityPixel to scaledDensityPixel
     */
    public static float dpToSp(float dp) {
        return (int) (dpToPx(dp) / Resources.getSystem().getDisplayMetrics().scaledDensity);
    }

    /**
     * return device Width
     */
    public static int deviceWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    /**
     * get ViewHolder class and make reference for evert @link(DynamicViewId) to the actual view if
     * target contains HashMap<String, Integer> will replaced with the idsMap
     */
    public static void parseDynamicView(Object target, View container,
                                        HashMap<String, Integer> idsMap) {

        for (Field field : target.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(DynamicViewId.class)) {
                /* if variable is annotated with @DynamicViewId */
                final DynamicViewId dynamicViewIdAnnotation = field.getAnnotation(
                        DynamicViewId.class);
                /* get the Id of the view. if it is not set in annotation user the variable name */
                String id = dynamicViewIdAnnotation.id();
                if (id.equalsIgnoreCase("")) {
                    id = field.getName();
                }
                if (idsMap.containsKey(id)) {
                    try {
                        /* get the view Id from the Hashmap and make the connection to the real View */
                        field.set(target, container.findViewById(idsMap.get(id)));
                    } catch (IllegalArgumentException ignore) {
                    } catch (IllegalAccessException e) {
                        InsertLogger.e(e, e.getMessage());
                    }
                }
            } else if ((field.getName().equalsIgnoreCase(
                    "ids")) && (field.getType() == idsMap.getClass())) {
                try {
                    field.set(target, idsMap);
                } catch (IllegalArgumentException ignore) {
                } catch (IllegalAccessException e) {
                    InsertLogger.e(e, e.getMessage());
                }
            }
        }

    }

    private static Object getFromJSON(JSONObject json, String name, Class clazz)
            throws JSONException {
        if ((clazz == Integer.class) || (clazz == Integer.TYPE)) {
            return json.getInt(name);
        } else if ((clazz == Boolean.class) || (clazz == Boolean.TYPE)) {
            return json.getBoolean(name);
        } else if ((clazz == Double.class) || (clazz == Double.TYPE)) {
            return json.getDouble(name);
        } else if ((clazz == Float.class) || (clazz == Float.TYPE)) {
            return (float) json.getDouble(name);
        } else if ((clazz == Long.class) || (clazz == Long.TYPE)) {
            return json.getLong(name);
        } else if (clazz == String.class) {
            return json.getString(name);
        } else if (clazz == JSONObject.class) {
            return json.getJSONObject(name);
        } else {
            return json.get(name);

        }
    }

    public static boolean classExists(String className) {
        try {
            Class.forName(className);
            return true;
        } catch (ClassNotFoundException ex) {
            return false;
        }
    }
}
