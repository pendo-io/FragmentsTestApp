package external.sdk.pendo.io.dynamicview;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import android.view.ViewGroup;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.JsonUtils;

/**
 * Created by avocarrot on 11/12/2014.
 * Every Property of a View is a Dynamic Property.
 */
public class DynamicProperty {

    public static final String ORIENTATION_HORIZONTAL = "{\"name\": \"orientation\",\"type\": \"string\",\"value\": \"horizontal\"}";

    /**
     * possible types that we handle.
     **/
    public enum TYPE {
        NO_VALID,
        STRING,
        DIMEN,
        INTEGER,
        FLOAT,
        ARRAY,
        COLOR,
        REF,
        BOOLEAN,
        BASE64,
        DRAWABLE,
        JSON,
        REGEX
    }

    /**
     * possible property name that we handle.
     **/
    public enum NAME {
        NO_VALID,
        ID,
        LAYOUT_WIDTH,
        LAYOUT_HEIGHT,
        PADDING_LEFT,
        PADDING_RIGHT,
        PADDING_TOP,
        PADDING_BOTTOM,
        PADDING,
        LAYOUT_MARGINLEFT,
        LAYOUT_MARGINRIGHT,
        LAYOUT_MARGINTOP,
        LAYOUT_MARGINBOTTOM,
        LAYOUT_MARGIN,
        BACKGROUND,
        ENABLED,
        SELECTED,
        CLICKABLE,
        SCALEX,
        SCALEY,
        MINWIDTH,
        MINHEIGHT,

        MAXHEIGHT,
        MAXWIDTH,
        /* textView */
        TEXT,
        TEXTCOLOR,
        TEXTSIZE,
        TEXTSTYLE,
        FONTFAMILY,
        ELLIPSIZE,
        MAXLINES,
        GRAVITY,
        DRAWABLETOP,
        DRAWABLEBOTTOM,
        DRAWABLELEFT,
        DRAWABLERIGHT,
        /* imageView */
        SRC,
        SCALETYPE,
        ADJUSTVIEWBOUNDS,
        /* Video*/
        VIDEO_ID,
        VIDEO_URL,
        VIDEO_THUMB_URL,
        VIDEO_TITLE,
        AUTOPLAY,
        /* rating */
        STEPS,
        HINTLOCATION,
        MINVALUEHINTTEXT,
        MAXVALUEHINTTEXT,
        /* Icons */
        ICONSIZE,
        ICONFONTFAMILY,
        SELECTEDICON,
        UNSELECTEDICON,
        SELECTEDICONCOLOR,
        UNSELECTEDICONCOLOR,
        SELECTEDICONSIZE,
        SELECTEDTEXTSIZE,
        SELECTEDICONFONTFAMILY,
        SELECTEDTEXTSTYLE,
        SELECTEDTEXTFONTFAMILY,
        PADDING_BETWEEN,
        /* layout */
        LAYOUT_ABOVE,
        LAYOUT_ALIGNBASELINE,
        LAYOUT_ALIGNBOTTOM,
        LAYOUT_ALIGNEND,
        LAYOUT_ALIGNLEFT,
        LAYOUT_ALIGNPARENTBOTTOM,
        LAYOUT_ALIGNPARENTEND,
        LAYOUT_ALIGNPARENTLEFT,
        LAYOUT_ALIGNPARENTRIGHT,
        LAYOUT_ALIGNPARENTSTART,
        LAYOUT_ALIGNPARENTTOP,
        LAYOUT_ALIGNRIGHT,
        LAYOUT_ALIGNSTART,
        LAYOUT_ALIGNTOP,
        LAYOUT_ALIGNWITHPARENTIFMISSING,
        LAYOUT_BELOW,
        LAYOUT_CENTERHORIZONTAL,
        LAYOUT_CENTERINPARENT,
        LAYOUT_CENTERVERTICAL,
        LAYOUT_TOENDOF,
        LAYOUT_TOLEFTOF,
        LAYOUT_TORIGHTOF,
        LAYOUT_TOSTARTOF,
        LAYOUT_GRAVITY,
        LAYOUT_WEIGHT,
        SUM_WEIGHT,
        WEIGHTSUM,
        ORIENTATION,

        VISIBILITY,
        TAG,
        FUNCTION,

        ACTION,
        ACTIONTYPE,
        ONSUBMIT,

        TEXTDIRECTION,

        BACKGROUNDIMAGEURL, // backgroundImageUrl
        BACKGROUNDIMAGEFILLTYPE, // backgroundImageFillType

        // CompoundButtons
        CHECKED,
        CHECKEDBACKGROUND, // checkedBackground
        CHECKEDTEXTCOLOR, // checkedTextColor

        // InsertCircularCloseButton
        XCOLOR,
        XWIDTH,
        FRAMECOLOR,
        FRAMEWIDTH,

        //VisualActionButton
        CORNERRADIUS,
        TEXTCOLORNORMAL,
        TEXTCOLORPRESSED,
        TEXTCOLORDISABLED,
        BACKGROUNDCOLORNORMAL,
        BACKGROUNDCOLORPRESSED,
        BACKGROUNDCOLORDISABLED,

        // TextField
        HINT,
        TEXTCOLORHINT,
        INPUTTYPE,
        SINGLELINE,
        VALIDATOR
    }

    public NAME name;
    public TYPE type;
    private Object value;

    /**
     * @param v value to convert as string.
     * @return Value as object depends on the type.
     */
    private Object convertValue(JsonElement v) {
        if (v == null)
            return null;
        switch (type) {
            case INTEGER:
                return v.getAsInt();
            case FLOAT:
                return v.getAsFloat();
            case DIMEN:
                return convertDimenToPixel(v.getAsString());
            case COLOR:
                return PropertyTranslator.translateColorProperty(v.getAsString());
            case BOOLEAN:
                String locValue = v.getAsString();
                if (locValue.equalsIgnoreCase("t")) {
                    return true;
                } else if (locValue.equalsIgnoreCase("f")) {
                    return false;
                } else if (locValue.equalsIgnoreCase("true")) {
                    return true;
                } else if (locValue.equalsIgnoreCase("false")) {
                    return false;
                }
                return Integer.parseInt(locValue) == 1;
            case BASE64:
                try {
                    InputStream stream = new ByteArrayInputStream(Base64.decode(v.getAsString(),
                            Base64.DEFAULT));
                    return BitmapFactory.decodeStream(stream);
                } catch (Exception e) {
                    return null;
                }
            case ARRAY:
                try {
                    float[] arr = new float[8];
                    JsonArray jsonArray = v.getAsJsonArray();
                    if (jsonArray != null) {
                        for (int i = 0; i < jsonArray.size(); i++) {
                            arr[i] = jsonArray.get(i).getAsFloat();
                        }
                    }
                    return arr;
                } catch (Exception e)  {
                    return null;
                }
        }
        return v;
    }

    /**
     * create property and parse json.
     * @param jsonObject : json to parse
     */
    public DynamicProperty(JsonObject jsonObject) {
        super();
        try {
            String jsonPropertyName = JsonUtils.getString(jsonObject, "name");
            name = PropertyTranslator.translatePropertyName(jsonPropertyName);
        } catch (Exception e) {
            name = NAME.NO_VALID;
        }
        try {
            String jsonPropertyType = JsonUtils.getString(jsonObject, "type");
            type = PropertyTranslator.translatePropertyType(jsonPropertyType);
        } catch (Exception e) {
            type = TYPE.NO_VALID;
        }
        try {
            value = convertValue(jsonObject.get("value"));
        } catch (Exception e) {}
    }

    public boolean isValid() {
        return value != null;
    }

    /**
     * @param clazz
     * @param varName
     * @return search in clazz of possible variable name (varName) and return its value.
     */
    public Object getValueInt(Class clazz, String varName) {

        java.lang.reflect.Field fieldRequested;

        try {
            fieldRequested = clazz.getField(varName);
            if (fieldRequested != null) {
                return fieldRequested.get(clazz);
            }
        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }
        return null;
    }


    /** next function just cast value and return the object. **/

    public int getValueColor() {
        if (type == TYPE.COLOR) return Integer.class.cast(value);
        return -1;
    }
    public String getValueString() {
        return ((JsonElement) value).getAsString();
    }
    public int getValueInt() {
        if (value instanceof Integer)
            return Integer.class.cast(value);
        else if (value instanceof Float)
            return (int) getValueFloat();
        else
            return (int) value;
    }
    public float getValueFloat() {
        return Float.class.cast(value);
    }
    public Boolean getValueBoolean() {
        return Boolean.class.cast(value);
    }
    public Bitmap getValueBitmap() {
        return (Bitmap)value;
    }
    public Drawable getValueBitmapDrawable() {
        return new BitmapDrawable(Resources.getSystem(), getValueBitmap());
    }
    public Drawable getValueGradientDrawable() {
        return (Drawable)value;
    }
    public JSONObject getValueJSON() {
        return JSONObject.class.cast(value);
    }
    public float[] getValueFloatArray() {
        return float[].class.cast(value);
    }

    float convertDimenToPixel(String dimen) {
        if (dimen.endsWith("dp"))
            return DynamicHelper.dpToPx(Float.parseFloat(dimen.substring(0, dimen.length() - 2)));
        else if (dimen.endsWith("sp"))
            return DynamicHelper.spToPx(Float.parseFloat(dimen.substring(0, dimen.length() - 2)));
        else if (dimen.endsWith("px"))
            return Integer.parseInt(dimen.substring(0, dimen.length() - 2));
        else if (dimen.endsWith("%"))
            return (int)(Float.parseFloat(dimen.substring(0, dimen.length() - 1))/100f * DynamicHelper.deviceWidth());
        else if (dimen.equalsIgnoreCase("match_parent"))
            return ViewGroup.LayoutParams.MATCH_PARENT;
        else if (dimen.equalsIgnoreCase("wrap_content"))
            return ViewGroup.LayoutParams.WRAP_CONTENT;
        else
            return Integer.parseInt(dimen);
    }

}
