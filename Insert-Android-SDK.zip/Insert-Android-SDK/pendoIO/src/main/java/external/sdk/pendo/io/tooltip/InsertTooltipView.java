package external.sdk.pendo.io.tooltip;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;

import com.jakewharton.rxbinding3.view.RxView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Observable;
import io.reactivex.functions.Consumer;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandParameterInjector;
import sdk.pendo.io.actions.InsertCommandsEventBus;
import sdk.pendo.io.actions.InsertsManager;
import sdk.pendo.io.actions.VisualInsertBase;
import sdk.pendo.io.actions.VisualInsertManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertMaybeObserver;

import static android.util.Log.ERROR;
import static android.util.Log.INFO;
import static android.util.Log.VERBOSE;
import static android.util.Log.WARN;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.DBG;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.Gravity;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.Gravity.BOTTOM;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.Gravity.CENTER;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.Gravity.LEFT;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.Gravity.RIGHT;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.Gravity.TOP;
import static external.sdk.pendo.io.tooltip.InsertTooltipManager.log;
import static sdk.pendo.io.actions.InsertCommand.InsertCommandScope.INSERT_COMMAND_SCOPE_ANY;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.DISMISS_INSERT;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.HOST_APP_DEVELOPER_CALL;
import static sdk.pendo.io.actions.VisualInsertBase.DEFAULT_ACTIVATED_BY;
import static sdk.pendo.io.actions.handlers.InsertGlobalCommandHandler.INSERT_GLOBAL_COMMAND_DEST;
import static sdk.pendo.io.utilities.ActivityUtils.getActivity;

@SuppressLint("ViewConstructor")
public class InsertTooltipView extends ViewGroup implements InsertTooltip {
    private static final String TAG = "TooltipView";
    private static final List<Gravity> gravities = new ArrayList<>(Arrays.asList(LEFT, RIGHT, TOP, BOTTOM, CENTER));
    private static final int ARROW_BASE_WIDTH_RATIO = 10;
    private final List<Gravity> viewGravities = new ArrayList<>(gravities);
    private final long mShowDelay;
    private final String mInsertId;
    private final String mToolTipId;
    private final Rect mDrawRect;
    private final Rect mTempRect;
    private final long mShowDuration;
    private final Point mPoint;
    private final int mTopRule;
    private final boolean mHideArrow;
    private final long mActivateDelay;
    private final boolean mRestrict;
    private final long mFadeDuration;
    private final InsertTooltipManager.onTooltipClosingCallback mCloseCallback;
    private final InsertTooltipTextDrawable mDrawable;
    private final int[] mTempLocation = new int[2];
    private final Handler mHandler = new Handler();
    private final Rect mScreenRect = new Rect();
    private final Point mTmpPoint = new Point();
    private final Observable<Object> mCloseObserver;
    private Gravity mGravity;
    private int mGlobalLayoutCount = 0;
    private Animator mShowAnimation;
    private boolean mShowing;
    private WeakReference<View> mViewAnchor;
    private boolean mAttached;
    private boolean mInitialized;
    private boolean mActivated;
    private int mBorderPadding, mArrowExtraPadding;
    private Rect mViewRect;
    private View mView;
    private OnToolTipListener mTooltipListener;
    private long mDisplayDuration = 0;
    private long mStartTime = 0;
    private final AtomicBoolean mWasShown = new AtomicBoolean(false);
    private final boolean mTouchPassThrough;
    Runnable hideRunnable = new Runnable() {
        @Override
        public void run() {
            onClose(false, false, false);
        }
    };
    Runnable activateRunnable = new Runnable() {
        @Override
        public void run() {
            log(TAG, VERBOSE, "activated..");

            mActivated = true;
        }
    };
    private final ViewTreeObserver.OnPreDrawListener mPreDrawListener = new ViewTreeObserver.OnPreDrawListener() {
        @Override
        public boolean onPreDraw() {
            if (!mAttached) {
                log(TAG, WARN, "onPreDraw. not attached");
                removePreDrawObserver(null);
                return true;
            }

            if (null != mViewAnchor) {
                View view = mViewAnchor.get();
                if (null != view) {
                    view.getLocationOnScreen(mTempLocation);

                    if (mTempLocation[0] != mViewRect.left) {
                        setOffsetX(mTempLocation[0]);
                    }

                    if (mTempLocation[0] != mViewRect.top) {
                        setOffsetY(mTempLocation[1]);
                    }
                }
            }
            return true;
        }
    };
    private final ViewTreeObserver.OnGlobalLayoutListener mGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
        @Override
        public void onGlobalLayout() {
            if (!mAttached) {
                log(TAG, WARN, "onGlobalLayout. removeListeners");
                removeGlobalLayoutObserver(null);
                return;
            }

            log(TAG, INFO, "onGlobalLayout");

            if (null != mViewAnchor) {
                View view = mViewAnchor.get();

                if (null != view) {
                    Rect rect = new Rect();
                    view.getGlobalVisibleRect(rect);

                    if (DBG) {
                        log(TAG, VERBOSE, "mViewRect: %s, newRect: %s, equals: %b", mViewRect, rect, mViewRect.equals(rect));
                    }

                    if (!mViewRect.equals(rect)) {
                        mViewRect.set(rect);
                        viewGravities.clear();
                        viewGravities.addAll(gravities);
                        viewGravities.remove(mGravity);
                        viewGravities.add(0, mGravity);
                        calculatePositions(viewGravities, ++mGlobalLayoutCount <= 1 && mRestrict);
                        requestLayout();
                    }
                } else {
                    log(TAG, WARN, "view is null");
                }
            }
        }
    };
    private final View.OnAttachStateChangeListener mAttachedStateListener = new OnAttachStateChangeListener() {
        @Override
        public void onViewAttachedToWindow(final View v) {
            // setVisibility(VISIBLE);
        }

        @Override
        @TargetApi(17)
        public void onViewDetachedFromWindow(final View v) {
            log(TAG, INFO, "onViewDetachedFromWindow");
            removeViewListeners(v);
            if (null != mCloseCallback) {
                mCloseCallback.onClosing(mToolTipId, true, true,
                        mDisplayDuration, mWasShown.get());
            }

            if (!mAttached) {
                log(TAG, WARN, "not attached");
                return;
            }

            Activity activity = (Activity) getContext();
            if (null != activity) {
                if (activity.isFinishing()) {
                    log(TAG, WARN, "skipped because activity is finishing...");
                    return;
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1
                        && activity.isDestroyed()) {
                    return;
                }
                onClose(false, false, true);
            }
        }
    };

    public InsertTooltipView(Context context, final InsertTooltipManager.Builder builder) {
        super(context);

        this.mToolTipId = builder.id;
        this.mGravity = builder.gravity;
        this.mTopRule = builder.actionbarSize;
        this.mCloseObserver = builder.closeObserver;
        this.mShowDelay = builder.showDelay;
        this.mTouchPassThrough = builder.touchPassThrough;

        if (builder.showDuration > 0) {
            this.mShowDuration = builder.showDuration + (this.mShowDelay > 0 ? this.mShowDelay : 0);
        } else {
            mShowDuration = builder.showDuration;
        }

        this.mInsertId = builder.insertId;
        this.mHideArrow = builder.hideArrow;
        this.mActivateDelay = builder.activateDelay;
        this.mRestrict = builder.restrictToScreenEdges;
        this.mFadeDuration = builder.fadeDuration;
        this.mCloseCallback = builder.closeCallback;
        this.mBorderPadding = builder.strokeWidth;

        setContentDescription(builder.contentDescription);

        if (null != builder.point) {
            this.mPoint = new Point(builder.point);
            this.mPoint.y += mTopRule;
        } else {
            this.mPoint = null;
        }

        this.mDrawRect = new Rect();
        this.mTempRect = new Rect();

        if (null != builder.view) {
            mViewRect = new Rect();
            builder.view.getGlobalVisibleRect(mViewRect);
            mViewAnchor = new WeakReference<>(builder.view);

            if (builder.view.getViewTreeObserver().isAlive()) {
                builder.view.getViewTreeObserver().addOnGlobalLayoutListener(mGlobalLayoutListener);
                builder.view.getViewTreeObserver().addOnPreDrawListener(mPreDrawListener);
                builder.view.addOnAttachStateChangeListener(mAttachedStateListener);
            }
        }

        if (!builder.isCustomView) {
            this.mDrawable = new InsertTooltipTextDrawable(builder.strokeWidth, builder.bgColor, builder.strokeColor, builder.frameRadius);
        } else {
            this.mDrawable = null;
        }
        mView = builder.customView;
        setVisibility(INVISIBLE);

        if (mCloseObserver != null) {
            mCloseObserver
                    .takeUntil(RxView.detaches(this))
                    .firstElement()
                    .subscribe(InsertMaybeObserver.create(new Consumer<Object>() {
                        @Override
                        public void accept(Object aVoid) {
                            InsertLogger.d("Closing the tooltip.");
                            onClose(false, false, true);
                        }
                    }));
        }

        InsertCommandsEventBus.getInstance()
                .subscribe(RxView.detaches(this).toFlowable(BackpressureStrategy.BUFFER),
                        InsertCommand.createFilter(VisualInsertBase.DISMISS_VISIBLE_INSERTS,
                                INSERT_GLOBAL_COMMAND_DEST,
                                DISMISS_INSERT,
                                HOST_APP_DEVELOPER_CALL,
                                INSERT_COMMAND_SCOPE_ANY),
                        new Consumer<InsertCommand>() {
                            @Override
                            public void accept(InsertCommand insertCommand) {
                                InsertLogger.d(insertCommand.toString());
                                onClose(false, false, true);
                            }
                        }
                );
    }

    String getTooltipId() {
        return mToolTipId;
    }

    @SuppressWarnings("unused")
    public boolean isShowing() {
        return mShowing;
    }

    void removeFromParent() {
        log(TAG, INFO, "removeFromParent: %d", mToolTipId);
        ViewParent parent = getParent();
        removeCallbacks();

        if (null != parent) {
            ((ViewGroup) parent).removeView(InsertTooltipView.this);

            if (null != mShowAnimation && mShowAnimation.isStarted()) {
                mShowAnimation.cancel();
            }
        }
    }

    private void removeCallbacks() {
        mHandler.removeCallbacks(hideRunnable);
        mHandler.removeCallbacks(activateRunnable);
    }

    @Override
    protected void onAttachedToWindow() {
        log(TAG, INFO, "onAttachedToWindow");
        super.onAttachedToWindow();
        mAttached = true;

        final Activity act = getActivity(getContext());
        if (act != null) {
            Window window = act.getWindow();
            try {
                window.getDecorView().getWindowVisibleDisplayFrame(mScreenRect);
            } catch (Exception e) {
                InsertLogger.d(e, "Attempt to read from field mVisibleInsets on a null attachInfo of the view in question.");
            }
        } else {
            WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
            android.view.Display display;
            if (wm != null) {
                display = wm.getDefaultDisplay();
                display.getRectSize(mScreenRect);
            }
        }

        initializeView();
        show();
    }

    @Override
    protected void onDetachedFromWindow() {
        log(TAG, INFO, "onDetachedFromWindow");
        removeListeners();
        mAttached = false;
        mViewAnchor = null;
        VisualInsertManager.getInstance().setIsFullScreenInsertShowing(false);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onLayout(final boolean changed, final int l, final int t, final int r, final int b) {
        log(TAG, INFO, "onLayout(%b, %d, %d, %d, %d)", changed, l, t, r, b);

        //  The layout has actually already been performed and the positions
        //  cached.  Apply the cached values to the children.
        if (null != mView) {
            mView.layout(mView.getLeft(), mView.getTop(), mView.getMeasuredWidth(), mView.getMeasuredHeight());
        }

        if (changed) {
            viewGravities.clear();
            viewGravities.addAll(gravities);
            viewGravities.remove(mGravity);
            viewGravities.add(0, mGravity);
            calculatePositions(viewGravities, mRestrict);
        }
    }

    private void removeListeners() {
        mTooltipListener = null;

        if (null != mViewAnchor) {
            View view = mViewAnchor.get();
            removeViewListeners(view);
        }
    }

    private void removeViewListeners(final View view) {
        log(TAG, INFO, "removeListeners");
        removeGlobalLayoutObserver(view);
        removePreDrawObserver(view);
        removeOnAttachStateObserver(view);
    }

    private void removeGlobalLayoutObserver(@Nullable View view) {
        if (null == view && null != mViewAnchor) {
            view = mViewAnchor.get();
        }
        if (null != view && view.getViewTreeObserver().isAlive()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                view.getViewTreeObserver().removeOnGlobalLayoutListener(mGlobalLayoutListener);
            } else {
                view.getViewTreeObserver().removeGlobalOnLayoutListener(mGlobalLayoutListener);
            }
        } else {
            log(TAG, ERROR, "removeGlobalLayoutObserver failed");
        }
    }

    private void removePreDrawObserver(@Nullable View view) {
        if (null == view && null != mViewAnchor) {
            view = mViewAnchor.get();
        }
        if (null != view && view.getViewTreeObserver().isAlive()) {
            view.getViewTreeObserver().removeOnPreDrawListener(mPreDrawListener);
        } else {
            log(TAG, ERROR, "removePreDrawObserver failed");
        }
    }

    private void removeOnAttachStateObserver(@Nullable View view) {
        if (null == view && null != mViewAnchor) {
            view = mViewAnchor.get();
        }
        if (null != view) {
            view.removeOnAttachStateChangeListener(mAttachedStateListener);
        } else {
            log(TAG, ERROR, "removeOnAttachStateObserver failed");
        }
    }

    private void initializeView() {
        if (!isAttached() || mInitialized) {
            return;
        }
        mInitialized = true;

        log(TAG, VERBOSE, "initializeView");

        LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        mView.setLayoutParams(params);

        if (null != mDrawable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                mView.setBackground(mDrawable);
            } else {
                mView.setBackgroundDrawable(mDrawable);
            }
            mView.setPadding(mView.getPaddingLeft() + mBorderPadding,
                    mView.getPaddingTop() + mBorderPadding,
                    mView.getPaddingRight() + mBorderPadding,
                    mView.getPaddingBottom() + mBorderPadding);
        }

        this.addView(mView);
    }

    @Override
    public void show() {
        log(TAG, INFO, "show");
        if (!isAttached()) {
            log(TAG, ERROR, "not attached!");
            return;
        }
        fadeIn(mFadeDuration);
    }

    @Override
    public void hide(boolean remove) {
        hide(remove, mFadeDuration);
    }

    private void hide(boolean remove, long fadeDuration) {
        log(TAG, INFO, "hide(%b, %d)", remove, fadeDuration);

        if (!isAttached()) {
            return;
        }
        fadeOut(remove, fadeDuration);
    }

    protected void fadeOut(final boolean remove, long fadeDuration) {
        if (!isAttached() || !mShowing) {
            return;
        }

        log(TAG, INFO, "fadeOut(%b, %d)", remove, fadeDuration);

        if (null != mShowAnimation) {
            mShowAnimation.cancel();
        }

        mShowing = false;

        if (fadeDuration > 0) {
            float alpha = getAlpha();
            mShowAnimation = ObjectAnimator.ofFloat(this, "alpha", alpha, 0);
            mShowAnimation.setDuration(fadeDuration);
            mShowAnimation.addListener(
                    new Animator.AnimatorListener() {
                        boolean cancelled;

                        @Override
                        public void onAnimationStart(final Animator animation) {
                            cancelled = false;
                        }

                        @Override
                        public void onAnimationEnd(final Animator animation) {
                            log(TAG, VERBOSE, "fadeout::onAnimationEnd, cancelled: %b", cancelled);
                            if (cancelled) {
                                return;
                            }

                            if (remove) {
                                fireOnHideCompleted();
                            }
                            mShowAnimation = null;
                        }

                        @Override
                        public void onAnimationCancel(final Animator animation) {
                            log(TAG, VERBOSE, "fadeout::onAnimationCancel");
                            cancelled = true;
                        }

                        @Override
                        public void onAnimationRepeat(final Animator animation) {

                        }
                    });
            mShowAnimation.start();
        } else {
            setVisibility(View.INVISIBLE);
            if (remove) {
                fireOnHideCompleted();
            }
        }
    }

    private void fireOnHideCompleted() {
        if (null != mTooltipListener) {
            mTooltipListener.onHideCompleted(InsertTooltipView.this);
        }
    }

    @Override
    public void setOffsetX(int x) {
        mView.setTranslationY(x - mViewRect.left + mDrawRect.left);
    }

    @Override
    public void setOffsetY(int y) {
        mView.setTranslationY(y - mViewRect.top + mDrawRect.top);
    }

    @Override
    public void offsetTo(final int x, final int y) {
        mView.setTranslationX(x - mViewRect.left + mDrawRect.left);
        mView.setTranslationY(y - mViewRect.top + mDrawRect.top);
    }

    @Override
    public boolean isAttached() {
        return mAttached;
    }

    protected void fadeIn(final long fadeDuration) {
        if (mShowing) {
            return;
        }

        if (null != mShowAnimation) {
            mShowAnimation.cancel();
        }

        log(TAG, INFO, "fadeIn");

        mShowing = true;

        if (fadeDuration > 0) {
            mShowAnimation = ObjectAnimator.ofFloat(this, "alpha", 0, 1);
            mShowAnimation.setDuration(fadeDuration);
            if (this.mShowDelay > 0) {
                mShowAnimation.setStartDelay(this.mShowDelay);
            }
            mShowAnimation.addListener(
                    new Animator.AnimatorListener() {
                        boolean cancelled;

                        @Override
                        public void onAnimationStart(final Animator animation) {
                            setVisibility(View.VISIBLE);
                            cancelled = false;

                            if (animation.isRunning()) {
                                mWasShown.set(true);
                                InsertCommandParameterInjector
                                        .getInstance()
                                        .handleInsertDisplayedAnalytics(mInsertId, false, DEFAULT_ACTIVATED_BY);
                            }
                        }

                        @Override
                        public void onAnimationEnd(final Animator animation) {
                            log(TAG, VERBOSE, "fadein::onAnimationEnd, cancelled: %b", cancelled);

                            InsertsManager.getInstance().setInsertFullyDisplayedAfterAnimation(mInsertId);

                            // Set the start time to be when the show animation ends.
                            mStartTime = System.currentTimeMillis();

                            if (null != mTooltipListener && !cancelled) {
                                mTooltipListener.onShowCompleted(InsertTooltipView.this);
                                postActivate(mActivateDelay);
                            }
                        }

                        @Override
                        public void onAnimationCancel(final Animator animation) {
                            log(TAG, VERBOSE, "fadein::onAnimationCancel");
                            cancelled = true;
                        }

                        @Override
                        public void onAnimationRepeat(final Animator animation) {

                        }
                    });
            mShowAnimation.start();
        } else {
            setVisibility(View.VISIBLE);
            mTooltipListener.onShowCompleted(InsertTooltipView.this);
            if (!mActivated) {
                postActivate(mActivateDelay);
            }
        }

        if (mShowDuration > 0) {
            mHandler.removeCallbacks(hideRunnable);
            mHandler.postDelayed(hideRunnable, mShowDuration);
        }
    }

    void postActivate(long ms) {
        log(TAG, VERBOSE, "postActivate: %d", ms);
        if (ms > 0) {
            if (isAttached()) {
                mHandler.postDelayed(activateRunnable, ms);
            }
        } else {
            mActivated = true;
        }
    }

    private void calculatePositions(List<Gravity> gravities, final boolean checkEdges) {
        final long t1 = System.currentTimeMillis();
        if (!isAttached()) {
            return;
        }

        // failed to display the tooltip due to
        // something wrong with its dimensions or
        // the target position..
        if (gravities.size() < 1) {
            if (null != mTooltipListener) {
                mTooltipListener.onShowFailed(this);
            }
            setVisibility(View.GONE);
            return;
        }

        Gravity gravity = gravities.remove(0);

        log(TAG, INFO, "calculatePositions. mGravity: %s, gravities: %d, mRestrict: %b", gravity, gravities.size(), checkEdges);

        int statusbarHeight = mScreenRect.top;

        if (mViewRect == null) {
            mViewRect = new Rect();
            mViewRect.set(mPoint.x, mPoint.y + statusbarHeight, mPoint.x, mPoint.y + statusbarHeight);
        }

        mScreenRect.top += mTopRule;

        int width = mView.getWidth();
        int height = mView.getHeight();

        log(TAG, VERBOSE, "mView.size: %dx%d", height, width);

        // get the destination mPoint

        if (gravity == BOTTOM) {
            mDrawRect.set(
                    mViewRect.centerX() - width / 2,
                    mViewRect.bottom,
                    mViewRect.centerX() + width / 2,
                    mViewRect.bottom + height);

            mTmpPoint.x = mViewRect.centerX();
            mTmpPoint.y = mViewRect.bottom;

            if (mRestrict && !mScreenRect.contains(mDrawRect)) {
                if (mDrawRect.right > mScreenRect.right) {
                    mDrawRect.offset(mScreenRect.right - mDrawRect.right, 0);
                } else if (mDrawRect.left < mScreenRect.left) {
                    mDrawRect.offset(-mDrawRect.left, 0);
                }
                if (mDrawRect.bottom > mScreenRect.bottom) {
                    // this means there's no enough space!
                    calculatePositions(gravities, checkEdges);
                    return;
                } else if (mDrawRect.top < mScreenRect.top) {
                    mDrawRect.offset(0, mScreenRect.top - mDrawRect.top);
                }
            }
        } else if (gravity == TOP) {
            mDrawRect.set(
                    mViewRect.centerX() - width / 2,
                    mViewRect.top - height,
                    mViewRect.centerX() + width / 2,
                    mViewRect.top);

            mTmpPoint.x = mViewRect.centerX();
            mTmpPoint.y = mViewRect.top;

            if (mRestrict && !mScreenRect.contains(mDrawRect)) {
                if (mDrawRect.right > mScreenRect.right) {
                    mDrawRect.offset(mScreenRect.right - mDrawRect.right, 0);
                } else if (mDrawRect.left < mScreenRect.left) {
                    mDrawRect.offset(-mDrawRect.left, 0);
                }
                if (mDrawRect.top < mScreenRect.top) {
                    // this means there's no enough space!
                    calculatePositions(gravities, checkEdges);
                    return;
                } else if (mDrawRect.bottom > mScreenRect.bottom) {
                    mDrawRect.offset(0, mScreenRect.bottom - mDrawRect.bottom);
                }
            }
        } else if (gravity == RIGHT) {
            mDrawRect.set(
                    mViewRect.right,
                    mViewRect.centerY() - height / 2,
                    mViewRect.right + width,
                    mViewRect.centerY() + height / 2);

            mTmpPoint.x = mViewRect.right;
            mTmpPoint.y = mViewRect.centerY();

            if (mRestrict && !mScreenRect.contains(mDrawRect)) {
                if (mDrawRect.bottom > mScreenRect.bottom) {
                    mDrawRect.offset(0, mScreenRect.bottom - mDrawRect.bottom);
                } else if (mDrawRect.top < mScreenRect.top) {
                    mDrawRect.offset(0, mScreenRect.top - mDrawRect.top);
                }
                if (mDrawRect.right > mScreenRect.right) {
                    // this means there's no enough space!
                    calculatePositions(gravities, checkEdges);
                    return;
                } else if (mDrawRect.left < mScreenRect.left) {
                    mDrawRect.offset(mScreenRect.left - mDrawRect.left, 0);
                }
            }
        } else if (gravity == LEFT) {
            mDrawRect.set(
                    mViewRect.left - width,
                    mViewRect.centerY() - height / 2,
                    mViewRect.left,
                    mViewRect.centerY() + height / 2);

            mTmpPoint.x = mViewRect.left;
            mTmpPoint.y = mViewRect.centerY();

            if (mRestrict && !mScreenRect.contains(mDrawRect)) {
                if (mDrawRect.bottom > mScreenRect.bottom) {
                    mDrawRect.offset(0, mScreenRect.bottom - mDrawRect.bottom);
                } else if (mDrawRect.top < mScreenRect.top) {
                    mDrawRect.offset(0, mScreenRect.top - mDrawRect.top);
                }
                if (mDrawRect.left < mScreenRect.left) {
                    // this means there's no enough space!
                    this.mGravity = RIGHT;
                    calculatePositions(gravities, checkEdges);
                    return;
                } else if (mDrawRect.right > mScreenRect.right) {
                    mDrawRect.offset(mScreenRect.right - mDrawRect.right, 0);
                }
            }
        } else if (this.mGravity == CENTER) {
            mDrawRect.set(
                    mViewRect.centerX() - width / 2,
                    mViewRect.centerY() - height / 2,
                    mViewRect.centerX() + width / 2,
                    mViewRect.centerY() + height / 2);

            mTmpPoint.x = mViewRect.centerX();
            mTmpPoint.y = mViewRect.centerY();

            if (mRestrict && !mScreenRect.contains(mDrawRect)) {
                if (mDrawRect.bottom > mScreenRect.bottom) {
                    mDrawRect.offset(0, mScreenRect.bottom - mDrawRect.bottom);
                } else if (mDrawRect.top < mScreenRect.top) {
                    mDrawRect.offset(0, mScreenRect.top - mDrawRect.top);
                }
                if (mDrawRect.right > mScreenRect.right) {
                    mDrawRect.offset(mScreenRect.right - mDrawRect.right, 0);
                } else if (mDrawRect.left < mScreenRect.left) {
                    mDrawRect.offset(mScreenRect.left - mDrawRect.left, 0);
                }
            }
        }

        if (DBG) {
            log(TAG, VERBOSE, "mScreenRect: %s, mTopRule: %d, statusBar: %d", mScreenRect, mTopRule, statusbarHeight);
            log(TAG, VERBOSE, "mDrawRect: %s", mDrawRect);
            log(TAG, VERBOSE, "mViewRect: %s", mViewRect);
        }

        // translate the textview

        mView.setTranslationX(mDrawRect.left);
        mView.setTranslationY(mDrawRect.top);

        log(TAG, VERBOSE, "setTranslationY: %g", mView.getTranslationY());

        if (null != mDrawable) {
            // get the global rect for the textview
            mView.getGlobalVisibleRect(mTempRect);

            log(TAG, VERBOSE, "mView visible rect: %s", mTempRect);

            mTmpPoint.x -= mTempRect.left;
            mTmpPoint.y -= mTempRect.top;

            if (!mHideArrow) {
                if (gravity == LEFT || gravity == RIGHT) {
                    mTmpPoint.y -= mBorderPadding / 2;
                } else if (gravity == TOP || gravity == BOTTOM) {
                    mTmpPoint.x -= mBorderPadding / 2;
                }
                switch (gravity) {
                    case LEFT:
                        mArrowExtraPadding = (mTempRect.bottom - mTempRect.top) / ARROW_BASE_WIDTH_RATIO;
                        mView.setPadding(mView.getPaddingLeft(), mView.getPaddingTop(),
                                mView.getPaddingRight() + mArrowExtraPadding, mView.getPaddingBottom());
                        break;
                    case TOP:
                        mArrowExtraPadding = (mTempRect.right - mTempRect.left) / ARROW_BASE_WIDTH_RATIO;
                        mView.setPadding(mView.getPaddingLeft(), mView.getPaddingTop(),
                                mView.getPaddingRight(), mView.getPaddingBottom() + mArrowExtraPadding);
                        break;
                    case RIGHT:
                        mArrowExtraPadding = (mTempRect.bottom - mTempRect.top) / ARROW_BASE_WIDTH_RATIO;
                        mView.setPadding(mView.getPaddingLeft() + mArrowExtraPadding, mView.getPaddingTop(),
                                mView.getPaddingRight(), mView.getPaddingBottom());
                        break;
                    case BOTTOM:
                        mArrowExtraPadding = (mTempRect.right - mTempRect.left) / ARROW_BASE_WIDTH_RATIO;
                        mView.setPadding(mView.getPaddingLeft(), mView.getPaddingTop() + mArrowExtraPadding,
                                mView.getPaddingRight(), mView.getPaddingBottom());
                        break;
                }
                mDrawable.setAnchor(gravity, mBorderPadding / 2, mArrowExtraPadding, mTmpPoint);
            } else {
                mDrawable.setAnchor(gravity, mBorderPadding / 2, 0, null);
            }
        }

        if (DBG) {
            final long t2 = System.currentTimeMillis();
            log(TAG, WARN, "calculate time: %d", (t2 - t1));
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(@NonNull final MotionEvent event) {
        if (!mAttached || !mShowing || !isShown()) {
            return false;
        }

        final int action = event.getActionMasked();

        log(TAG, INFO, "onTouchEvent: %d, active: %b", action, mActivated);


        if (!mActivated) {
            log(TAG, WARN, "not yet activated...");
            return true;
        }

        if (action == MotionEvent.ACTION_DOWN) {

            Rect outRect = new Rect();
            mView.getGlobalVisibleRect(outRect);
            final boolean touchedInsideTooltip = outRect.contains((int) event.getX(), (int) event.getY());

            if (DBG) {
                log(TAG, VERBOSE, "containsTouch: %b", touchedInsideTooltip);
                log(TAG, VERBOSE, "mDrawRect: %s, point: %g, %g", mDrawRect, event.getX(), event.getY());
                log(
                        TAG,
                        VERBOSE, "real drawing rect: %s, contains: %b", outRect,
                        outRect.contains((int) event.getX(), (int) event.getY()));
            }

            if (touchedInsideTooltip) {
                return true;
            } else {
                touchOutsideOfTooltip();
                return !mTouchPassThrough;
            }

        }

        return false;
    }

    @Override
    protected void onDraw(final Canvas canvas) {
        if (!mAttached) {
            return;
        }
        super.onDraw(canvas);
    }

    @Override
    protected void onMeasure(final int widthMeasureSpec, final int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int myWidth = 0;
        int myHeight = 0;

        final int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        final int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        final int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        final int heightSize = MeasureSpec.getSize(heightMeasureSpec);

        // Record our dimensions if they are known;
        if (widthMode != MeasureSpec.UNSPECIFIED) {
            myWidth = widthSize;
        }

        if (heightMode != MeasureSpec.UNSPECIFIED) {
            myHeight = heightSize;
        }

        log(TAG, VERBOSE, "myWidth: %d, myHeight: %d", myWidth, myHeight);

        if (null != mView) {
            if (mView.getVisibility() != GONE) {
                int childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(myWidth, MeasureSpec.AT_MOST);
                int childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(myHeight, MeasureSpec.AT_MOST);
                mView.measure(childWidthMeasureSpec, childHeightMeasureSpec);
                //                myWidth = mView.getMeasuredWidth();
                //                myHeight = mView.getMeasuredHeight();
            } else {
                myWidth = 0;
                myHeight = 0;
            }
        }

        setMeasuredDimension(myWidth, myHeight);
    }

    private final AtomicBoolean mClosed = new AtomicBoolean(false);

    private synchronized void onClose(boolean fromUser, boolean containsTouch, boolean immediate) {

        if (mClosed.getAndSet(true)) {
            return;
        }

        log(TAG, INFO, "onClose. fromUser: %b, containsTouch: %b, immediate: %b", fromUser, containsTouch, immediate);

        if (!isAttached()) {
            return;
        }

        mDisplayDuration = System.currentTimeMillis() - mStartTime;
        if (null != mCloseCallback) {
            mCloseCallback.onClosing(mToolTipId, fromUser, containsTouch,
                    mDisplayDuration, mWasShown.get());
        }

        hide(true, immediate ? 0 : mFadeDuration);
    }

    private synchronized void touchOutsideOfTooltip() {
        if (mCloseCallback != null) {
            mCloseCallback.onTouchOutside(mToolTipId);
        }
    }

    void setOnToolTipListener(OnToolTipListener listener) {
        this.mTooltipListener = listener;
    }

    interface OnToolTipListener {
        void onHideCompleted(InsertTooltipView layout);

        void onShowCompleted(InsertTooltipView layout);

        void onShowFailed(InsertTooltipView layout);
    }
}