package external.sdk.pendo.io.statemachine.call;

/**
 * User: andrey
 * Date: 6/12/2013
 * Time: 11:16 AM
 */
public interface Handler {
}
