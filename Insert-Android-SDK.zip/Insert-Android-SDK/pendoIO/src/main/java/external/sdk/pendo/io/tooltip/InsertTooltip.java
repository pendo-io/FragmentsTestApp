package external.sdk.pendo.io.tooltip;

/**
 * Created by alessandro on 04/09/14.
 */
@SuppressWarnings("CheckStyle")
public interface InsertTooltip {
    void show();

    void hide(boolean remove);

    void setOffsetX(int x);

    void setOffsetY(int y);

    void offsetTo(int x, int y);

    boolean isAttached();

    boolean isShown();

    void requestLayout();
}
