package external.sdk.pendo.io.statemachine;

import sdk.pendo.io.logging.InsertLogger;

import static java.lang.String.format;

/**
 * User: andrey
 * Date: 20/02/2014
 * Time: 10:43 PM
 */
public class FlowLoggerImpl implements FlowLogger {

    public FlowLoggerImpl() {
    }

    @Override
    public void info(String message, Object... o) {
        String formattedMessage = format(message, o);
        InsertLogger.i("INFO " + EasyFlow.class.getName() + " " + formattedMessage);
    }

    @Override
    public void error(String message, Throwable e) {
        InsertLogger.d(("ERROR " + EasyFlow.class.getName() + " " + message));
    }
}
