package external.sdk.pendo.io.tooltip;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Point;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.Observable;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertAction;
import sdk.pendo.io.listeners.ApplicationObservers;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.ViewUtils;

import static android.util.Log.INFO;
import static android.util.Log.VERBOSE;

@SuppressWarnings("ALL")
public class InsertTooltipManager {
    private static volatile InsertTooltipManager INSTANCE;
    public static boolean DBG = false;
    private static final String TAG = "InsertTooltipManager";
    private static WeakReference<Context> mContextRef;
    private final List<OnTooltipAttachedStateChange> mTooltipAttachStatusListeners = new ArrayList<>();
    final HashMap<String, WeakReference<InsertTooltipView>> mTooltips = new HashMap<>();
    private final Object mLock = new Object();
    public static final String DEFAULT_STROKE_WIDTH = "1.3f";
    public static synchronized InsertTooltipManager getInstance()
            throws IllegalStateException {
        if (INSTANCE == null) {
            INSTANCE = new InsertTooltipManager();
            final Activity activity = ApplicationObservers.getInstance()
                    .getCurrentVisibleActivity();
            INSTANCE.resetContext(activity);
        }
        return INSTANCE;
    }

    public interface OnTooltipAttachedStateChange {
        void onTooltipAttached(String id);

        void onTooltipDetached(String id);
    }

    private InsertTooltipView.OnToolTipListener mTooltipListener = new InsertTooltipView.OnToolTipListener() {
        @Override
        public void onHideCompleted(final InsertTooltipView layout) {
            log(TAG, INFO, "onHideCompleted: %d", layout.getTooltipId());
            remove(layout.getTooltipId());
        }

        @Override
        public void onShowCompleted(final InsertTooltipView layout) {
            log(TAG, INFO, "onShowCompleted: %d", layout.getTooltipId());
        }

        @Override
        public void onShowFailed(final InsertTooltipView layout) {
            log(TAG, INFO, "onShowFailed: %d", layout.getTooltipId());
            remove(layout.getTooltipId());
        }
    };

    private InsertTooltipManager() {
    }

    public static void resetContext(final Context context) {
        mContextRef = new WeakReference<>(context);
    }

    public void addOnTooltipAttachedStateChange(OnTooltipAttachedStateChange listener) {
        if (!mTooltipAttachStatusListeners.contains(listener)) {
            mTooltipAttachStatusListeners.add(listener);
        }
    }

    public void removeOnTooltipAttachedStateChange(OnTooltipAttachedStateChange listener) {
        mTooltipAttachStatusListeners.remove(listener);
    }

    private void fireOnTooltipDetached(String id) {
        if (mTooltipAttachStatusListeners.size() > 0) {
            for (OnTooltipAttachedStateChange listener : mTooltipAttachStatusListeners) {
                listener.onTooltipDetached(id);
            }
        }
    }

    private void fireOnTooltipAttached(String id) {
        if (mTooltipAttachStatusListeners.size() > 0) {
            for (OnTooltipAttachedStateChange listener : mTooltipAttachStatusListeners) {
                listener.onTooltipAttached(id);
            }
        }
    }

    @SuppressWarnings ("unused")
    public boolean show(Builder builder) {
        log(TAG, INFO, "show");

        if (!builder.completed) {
            throw new IllegalArgumentException("Builder incomplete. Call 'build()' first");
        }

        synchronized (mLock) {
            if (mTooltips.containsKey(builder.id)) {
                Log.w(TAG, "A InsertTooltip with the same id was walready specified");
                return false;
            }

            List<Activity> allVisibleActivities = ApplicationObservers.getInstance().getAllVisibleActivities();
            if (null == allVisibleActivities ||  0 == allVisibleActivities.size() ) {
                return false;
            }
            final Activity act = allVisibleActivities.get(0);
            if (null == act || act.getWindow() == null || act.getWindow().getDecorView() == null || act.isFinishing()) {
                return false;
            }

            InsertTooltipView layout = new InsertTooltipView(mContextRef.get(), builder);
            layout.setOnToolTipListener(mTooltipListener);
            mTooltips.put(builder.id, new WeakReference<>(layout));
            showInternal(act.getWindow().getDecorView(), layout, true);
        }
        printStats();
        return true;
    }

    @SuppressWarnings ("unused")
    public void hide(int id) {
        log(TAG, INFO, "hide(%d)", id);

        final WeakReference<InsertTooltipView> layout;
        synchronized (mLock) {
            layout = null;
        }
        if (null != layout) {
            InsertTooltipView tooltipView = layout.get();
            tooltipView.hide(true);
        }
    }

    @Nullable
    public InsertTooltip get(String id) {
        synchronized (mLock) {
            WeakReference<InsertTooltipView> weakReference = mTooltips.get(id);

            if (weakReference != null) {
                return weakReference.get();
            }
        }
        return null;
    }

    @SuppressWarnings ("unused")
    public boolean active(int id) {
        synchronized (mLock) {
            return mTooltips.containsKey(id);
        }
    }

    @SuppressWarnings ("unused")
    public void remove(String id) {
        log(TAG, INFO, "remove(%d)", id);

        final WeakReference<InsertTooltipView> layout;
        synchronized (mLock) {
            layout = mTooltips.remove(id);
        }
        if (null != layout) {
            InsertTooltipView tooltipView = layout.get();
            tooltipView.setOnToolTipListener(null);
            tooltipView.removeFromParent();
            fireOnTooltipDetached(id);

        }
    }

    private void printStats() {
        log(TAG, VERBOSE, "active tooltips: %d", mTooltips.size());
    }

    private void destroy() {
        log(TAG, INFO, "destroy");

        synchronized (mLock) {
            for (String id : mTooltips.keySet()) {
                remove(id);
            }
        }
        mTooltipAttachStatusListeners.clear();
        printStats();
    }

    private void showInternal(View rootView, InsertTooltipView layout, boolean immediate) {
        if (null != rootView && rootView instanceof ViewGroup) {
            if (layout.getParent() == null) {
                log(TAG, VERBOSE, "attach to mToolTipLayout parent");

                ViewGroup.LayoutParams params =
                        new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                ((ViewGroup) rootView).addView(layout, params);
            }

            if (immediate) {
                layout.show();
            }

            fireOnTooltipAttached(layout.getTooltipId());
        }
    }

    @SuppressWarnings("CheckStyle")
    public static final class Builder {
        String id;
        View view;
        Gravity gravity;
        int actionbarSize = 0;
        int textResId = R.layout.tooltip_textview;
        long showDuration;
        Point point;
        long showDelay = 0;
        String insertId = InsertAction.NO_ID;
        boolean hideArrow;
        long activateDelay = 0;
        boolean isCustomView;
        boolean restrictToScreenEdges = true;
        long fadeDuration = 200;
        onTooltipClosingCallback closeCallback;
        boolean completed;
        @ColorInt int bgColor = Color.DKGRAY;
        @ColorInt int strokeColor = Color.DKGRAY;
        int strokeWidth = ViewUtils.convertDpToPx(Float.parseFloat(DEFAULT_STROKE_WIDTH));
        int frameRadius = 0;
        String contentDescription;
        Observable<Object> closeObserver;
        View customView;
        boolean touchPassThrough;

        public Builder(String id) {
            this.id = id;
        }

        private void throwIfCompleted() {
            if (completed) {
                throw new IllegalStateException("Builder cannot be modified");
            }
        }

        /**
         * Use a custom View for the tooltip. Note that the custom view
         * must include a TextView which id is `@android:id/text1`.<br />
         * Moreover, when using a custom view, the anchor arrow will not be shown
         *
         * @param resId              the custom layout view.
         * @param replace_background if true the custom view's background won't be replaced
         * @return the builder for chaining.
         */
        public Builder withCustomView(int resId, boolean replace_background) {
            this.textResId = resId;
            this.isCustomView = replace_background;
            return this;
        }

        public Builder withCustomView(int resId) {
            throwIfCompleted();
            return withCustomView(resId, true);
        }

        public Builder withCustomView(View view) {
            throwIfCompleted();
            this.customView = view;
            return this;
        }

        public Builder fitToScreen(boolean value) {
            throwIfCompleted();
            restrictToScreenEdges = value;
            return this;
        }

        public Builder fadeDuration(long ms) {
            throwIfCompleted();
            fadeDuration = ms;
            return this;
        }

        public Builder withCallback(onTooltipClosingCallback callback) {
            throwIfCompleted();
            this.closeCallback = callback;
            return this;
        }

        public Builder anchor(View view, Gravity gravity) {
            throwIfCompleted();
            this.point = null;
            this.view = view;
            this.gravity = gravity;
            return this;
        }

        public Builder withTouchPassThrough(final boolean passThrough) {
            this.touchPassThrough = passThrough;
            return this;
        }

        public Builder anchor(final Point point, final Gravity gravity) {
            throwIfCompleted();
            this.view = null;
            this.point = new Point(point);
            this.gravity = gravity;
            return this;
        }

        /**
         * @param show true to show the arrow, false to hide it
         * @return the builder for chaining.
         */
        public Builder toggleArrow(boolean show) {
            throwIfCompleted();
            this.hideArrow = !show;
            return this;
        }

        public Builder actionBarSize(final int actionBarSize) {
            throwIfCompleted();
            this.actionbarSize = actionBarSize;
            return this;
        }

        public Builder actionBarSize(Resources resources, int resId) {
            return actionBarSize(resources.getDimensionPixelSize(resId));
        }

        public Builder closeObserver(Observable<Object> closeObserver) {
            throwIfCompleted();
            this.closeObserver = closeObserver;
            return this;
        }

        public Builder closePolicy(long milliseconds) {
            throwIfCompleted();
            this.showDuration = milliseconds;
            return this;
        }

        public Builder activateDelay(long ms) {
            throwIfCompleted();
            this.activateDelay = ms;
            return this;
        }

        public Builder showDelay(long ms) {
            throwIfCompleted();
            this.showDelay = ms;
            return this;
        }

        public Builder insertId(String insertId) {
            throwIfCompleted();
            this.insertId = insertId;
            return this;
        }

        public Builder build() {
            throwIfCompleted();
            completed = true;
            return this;
        }

        public Builder setContentDescription(String contentDescription) {
            this.contentDescription = contentDescription;
            return this;
        }

        public Builder backgroundRes(@ColorRes int color) {
            bgColor = view.getContext().getResources().getColor(color);
            return this;
        }

        public Builder background(@ColorInt int color) {
            bgColor = color;
            return this;
        }

        public Builder background(String color) {
            bgColor = Color.parseColor(color);
            return this;
        }

        public Builder strokeColorRes(@ColorRes int color) {
            strokeColor = view.getContext().getResources().getColor(color);
            return this;
        }

        public Builder strokeColor(@ColorInt int color) {
            strokeColor = color;
            return this;
        }

        public Builder strokeColor(String color) {
            strokeColor = Color.parseColor(color);
            return this;
        }

        public Builder strokeWidth(String width) {
            strokeWidth = ViewUtils.convertDpToPx(Float.parseFloat(width));
            return this;
        }

        public Builder frameRadius(String radius) {
            frameRadius = ViewUtils.convertDpToPx(Float.parseFloat(radius));
            return this;
        }

    }

    public enum Gravity {
        LEFT, RIGHT, TOP, BOTTOM, CENTER
    }

    public interface onTooltipClosingCallback {
        /**
         * tooltip is being closed
         *
         * @param id
         * @param fromUser      true if the close operation started from a user click
         * @param containsTouch true if the original touch came from inside the tooltip
         */
        void onClosing(String id, boolean fromUser, final boolean containsTouch,
                       final long displayDuration, final boolean wasShown);

        void onTouchOutside(final String id);
    }

    static void log(final String tag, final int level, final String format, Object... args) {
        if (DBG) {
            switch (level) {
                case Log.DEBUG:
                    InsertLogger.d(tag + " - " + String.format(format, args));
                    break;
                case Log.ERROR:
                    InsertLogger.d(tag + "ERROR! - " + String.format(format, args));
                    break;
                case INFO:
                    InsertLogger.i(tag + " - " + String.format(format, args));
                    break;
                case Log.WARN:
                    InsertLogger.d(tag + "WARNING! - " + String.format(format, args));
                    break;
                default:
                case VERBOSE:
                    InsertLogger.v(tag + " - " + String.format(format, args));
                    break;
            }
        }
    }
}