package external.sdk.pendo.io.dynamicview;

import android.graphics.Color;

import java.util.HashMap;
import java.util.Map;

/**
 * This class translates properties sent by the BE to SDK properties
 */
public class PropertyTranslator {

    private static String EXTERNAL_PADDING_LEFT = "paddingLeft";
    private static String EXTERNAL_PADDING_RIGHT = "paddingRight";
    private static String EXTERNAL_PADDING_TOP = "paddingTop";
    private static String EXTERNAL_PADDING_BOTTOM = "paddingBottom";
    private static String BASE_16_COLOR_PREFIX = "0x";
    private static String RGB_COLOR_PREFIX = "#";
    private static int RGBA_TO_ARGB_COLOR_STRING_LENGHT = 9;

    private static Map<String, DynamicProperty.NAME> dynamicPropertyNameMap = new HashMap<String, DynamicProperty.NAME>() {
        {
            // Padding
            put(EXTERNAL_PADDING_LEFT, DynamicProperty.NAME.PADDING_LEFT);
            put(EXTERNAL_PADDING_RIGHT, DynamicProperty.NAME.PADDING_RIGHT);
            put(EXTERNAL_PADDING_TOP, DynamicProperty.NAME.PADDING_TOP);
            put(EXTERNAL_PADDING_BOTTOM, DynamicProperty.NAME.PADDING_BOTTOM);
        }
    };

    /**
     * Translate external property name to SDK property name
     * @param jsonPropertyName property name to translate
     * @return translated SDK property name
     */
    public static DynamicProperty.NAME translatePropertyName(String jsonPropertyName) {
        // Search this property in the map
        DynamicProperty.NAME name = dynamicPropertyNameMap.get(jsonPropertyName);
        if (name == null) {
            // Property not found so just uppercase its
            name = DynamicProperty.NAME.valueOf(jsonPropertyName.toUpperCase().trim());
        }
        return name;
    }

    /**
     * Translate external property type to SDK property type
     * @param jsonPropertyType property type to translate
     * @return translated SDK property type
     */
    public static DynamicProperty.TYPE translatePropertyType(String jsonPropertyType) {
        return DynamicProperty.TYPE.valueOf(jsonPropertyType.toUpperCase().trim());
    }

    /**
     * Translate color property to color that can be used by the SDK.
     * @param color color to translate
     * @return translated SDK color
     */
    public static int translateColorProperty(String color) {
        if (color.startsWith(BASE_16_COLOR_PREFIX)) {
            return (int) Long.parseLong(color.substring(2), 16);
        }
        if (color.length() == RGBA_TO_ARGB_COLOR_STRING_LENGHT) {
            color = convertRgbaToArgb(color);
        }
        return Color.parseColor(color);
    }

    /**
     * Convert RGBA to ARGB.
     * P2 guides send RGBA, while SDK expect ARGB.
     * @param rgba color in RGBA format
     * @return color in ARGB format
     */
    private static String convertRgbaToArgb(String rgba) {
        String convertedString = rgba;
        if (rgba.startsWith(RGB_COLOR_PREFIX)) {
            String alpha = rgba.substring(7);
            convertedString = RGB_COLOR_PREFIX + alpha;
            convertedString+=rgba.substring(1,7);
        }
        return convertedString;
    }
}
