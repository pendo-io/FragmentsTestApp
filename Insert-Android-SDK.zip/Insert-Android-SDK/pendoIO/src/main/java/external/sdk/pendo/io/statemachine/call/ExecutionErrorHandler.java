package external.sdk.pendo.io.statemachine.call;

import external.sdk.pendo.io.statemachine.*;
import external.sdk.pendo.io.statemachine.err.ExecutionError;

public interface ExecutionErrorHandler<C extends StatefulContext> extends Handler {
	void call(ExecutionError error, C context);
}
