package external.sdk.pendo.io.statemachine.call;

import external.sdk.pendo.io.statemachine.*;

public interface StateHandler<C extends StatefulContext> extends Handler {
	void call(StateEnum state, C context) throws Exception;
}
