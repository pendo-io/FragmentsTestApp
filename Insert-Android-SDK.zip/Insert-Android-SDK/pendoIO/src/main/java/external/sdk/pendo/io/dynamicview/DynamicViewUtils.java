package external.sdk.pendo.io.dynamicview;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.Context;
import android.graphics.Shader;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.gson.JsonArray;

import java.util.EnumSet;

import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.utilities.Utils;

/**
 *
 * Created by assaf on 7/20/15.
 */
public final class DynamicViewUtils {
    private DynamicViewUtils() { }

    // P2 properties.
    public static final String P2_ACTION_BUTTON = "Button";
    public static final String P2_CLOSE_BUTTON = "CloseButton";
    public static final String P2_ROW_BLOCK = "RowBlock";

    public static final String LINEAR_LAYOUT = "LinearLayout";
    public static final String TOOLTIP = "Tooltip";
    public static final String LINEAR_LAYOUT_WIDGET =
            "sdk.pendo.io.views.custom.InsertLinearLayout";

    public static final String CIRCULAR_CLOSE_BUTTON = "pendo.io.CircularCloseButton";
    public static final String CIRCULAR_CLOSE_BUTTON_WIDGET =
            "sdk.pendo.io.views.custom.InsertCircularCloseButton";

    public static final String INSERT_IMAGEVIEW = "insert.io.ImageView";
    public static final String INSERT_IMAGEVIEW_WIDGET =
            "sdk.pendo.io.views.custom.VisualActionImage";

    public static final String INSERT_ACTION_BUTTON = "insert.io.Button";
    private static final String INSERT_ACTION_BUTTON_WIDGET =
            "sdk.pendo.io.views.custom.VisualActionButton";

    public static final String INSERT_MULTI_PAGE_LAYOUT = "insert.io.MultiPageLayout";
    private static final String INSERT_MULTI_PAGE_LAYOUT_WIDGET =
            "android.widget.RelativeLayout";

    public static final String INSERT_ACTION_TEXT_FIELD = "insert.io.TextField";
    private static final String INSERT_ACTION_TEXT_FIELD_WIDGET =
            "sdk.pendo.io.views.custom.InsertEditText";

    /** Form elements. **/
    public static final String INSERT_FORM = "insert.io.Form";
    private static final String INSERT_FORM_WIDGET = "sdk.pendo.io.views.custom.InsertForm";

    public static final String INSERT_RADIO_GROUP = "insert.io.RadioButtonGroup";
    private static final String INSERT_RADIO_GROUP_WIDGET = "android.widget.RadioGroup";

    public static final String INSERT_RADIO_BUTTON = "insert.io.RadioButton";
    private static final String INSERT_RADIO_BUTTON_WIDGET =
            "sdk.pendo.io.views.custom.InsertRadioButton";

    /** Toast element. **/
    public static final String POPUP_MESSAGE_TOAST_WIDGET = "insert.io.popupMessage";

    /** Pager elements. **/
    public static final String INSERT_PAGER = "insert.io.pager";
    public static final String INSERT_PAGE = "insert.io.page";
    public static final String INSERT_PAGE_WIDGET = "android.widget.LinearLayout";

    /** Banner elements. **/
    public static final String INSERT_BANNER_WIDGET = "android.widget.FrameLayout";

    public static final String INSERT_RATING_CONTROL = "RatingControl";
    static final String INSERT_RATING_CONTROL_WIDGET =
            "sdk.pendo.io.views.custom.InsertIoRatingBar";

    /** backgroundImageFillType. **/
    public enum BackgroundImageTileTypes {
        MIRROR("mirror", Shader.TileMode.MIRROR),
        REPEAT("repeat", Shader.TileMode.REPEAT),
        FILL("fill", null),
        FIT("fit", null);

        private final String mType;
        private final Shader.TileMode mMode;

        BackgroundImageTileTypes(String type, Shader.TileMode mode) {
            mType = type;
            mMode = mode;
        }

        public Shader.TileMode getMode() {
            return mMode;
        }

        @SuppressWarnings("CheckStyle")
        public boolean equals(String type) {
            return mType.equals(type);
        }

        /**
         * Finds the correct tile type for a given string.
         *
         * @param type The tile type as string.
         *
         * @return the correct {@link Shader.TileMode} from that string, or null if not found.
         */
        @Nullable
        public static BackgroundImageTileTypes findFillMode(String type) {
            for (BackgroundImageTileTypes fillType : EnumSet
                    .allOf(BackgroundImageTileTypes.class)) {

                if (fillType.equals(type)) {
                    return fillType;
                }
            }

            return null;
        }
    }

    public static String getWidget(@NonNull String widget) {
        /**
         * P2 widgets
         */
        if (widget.endsWith(P2_ACTION_BUTTON)) {
            return INSERT_ACTION_BUTTON_WIDGET;
        }

        if (widget.equals(P2_CLOSE_BUTTON)) {
            return CIRCULAR_CLOSE_BUTTON_WIDGET;
        }

        if (widget.equals(P2_ROW_BLOCK)) {
            return LINEAR_LAYOUT_WIDGET;
        }

        /**
         * Regular widgets
         */
        if (widget.equals(LINEAR_LAYOUT) || widget.equals(TOOLTIP)) {
            return LINEAR_LAYOUT_WIDGET;
        }

        if (widget.equals(CIRCULAR_CLOSE_BUTTON)) {
            return CIRCULAR_CLOSE_BUTTON_WIDGET;
        }

        if (widget.endsWith(INSERT_IMAGEVIEW)) {
            return INSERT_IMAGEVIEW_WIDGET;
        }
        if (widget.endsWith(INSERT_ACTION_BUTTON)) {
            return INSERT_ACTION_BUTTON_WIDGET;
        }

        if (widget.endsWith(INSERT_ACTION_TEXT_FIELD)) {
            return INSERT_ACTION_TEXT_FIELD_WIDGET;
        }

        if (widget.endsWith(INSERT_FORM)) {
            return INSERT_FORM_WIDGET;
        }

        if (widget.endsWith(INSERT_RADIO_BUTTON)) {
            return INSERT_RADIO_BUTTON_WIDGET;
        }

        if (widget.endsWith(INSERT_RADIO_GROUP)) {
            return INSERT_RADIO_GROUP_WIDGET;
        }

        if (widget.equals(INSERT_PAGER)) {
            return INSERT_PAGER;
        }

        if (widget.equals(INSERT_PAGE)) {
            return INSERT_PAGE_WIDGET;
        }

        if (widget.equals(INSERT_MULTI_PAGE_LAYOUT)) {
            return INSERT_MULTI_PAGE_LAYOUT_WIDGET;
        }

        if (widget.equals(INSERT_RATING_CONTROL)) {
            return INSERT_RATING_CONTROL_WIDGET;
        }

        if (!widget.contains(".")) {
            return "android.widget." + widget;
        }

        return widget;
    }
}
