package external.sdk.pendo.io.dynamicview;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jakewharton.rxbinding3.widget.RxCompoundButton;
import com.jakewharton.rxbinding3.widget.RxRadioGroup;
import com.trello.rxlifecycle3.android.RxLifecycleAndroid;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.functions.Consumer;
import sdk.pendo.io.R;
import sdk.pendo.io.actions.InsertActionConfiguration;
import sdk.pendo.io.actions.InsertCommand;
import sdk.pendo.io.actions.InsertCommandDispatcher;
import sdk.pendo.io.actions.InsertCommandEventType;
import sdk.pendo.io.actions.InsertContentDescriptionManager;
import sdk.pendo.io.actions.InsertPreparationManager;
import sdk.pendo.io.actions.handlers.InsertCommandViewHandlerUtility;
import sdk.pendo.io.logging.InsertLogger;
import sdk.pendo.io.reactive.observers.InsertObserver;
import sdk.pendo.io.utilities.JsonUtils;
import sdk.pendo.io.utilities.Utils;
import sdk.pendo.io.utilities.script.JavascriptRunner;
import sdk.pendo.io.views.custom.ActionableBlock;
import sdk.pendo.io.views.custom.InsertEditText;
import sdk.pendo.io.views.custom.InsertForm;
import sdk.pendo.io.views.custom.InsertIoRatingBar;
import sdk.pendo.io.views.custom.InsertRadioButton;
import sdk.pendo.io.views.custom.VisualActionImage;
import sdk.pendo.io.views.pager.InsertPager;

import static external.sdk.pendo.io.dynamicview.DynamicViewUtils.P2_ROW_BLOCK;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.InsertInfoConsts;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_INVALID;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_SELECTION_CHANGED;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_VALID;

/**
 * Created by avocarrot on 11/12/2014. parse the json as a tree and create View with its
 * dynamicProperties
 */
@SuppressWarnings("unchecked")
public final class DynamicView {

    public static final int INTERNAL_TAG_ID = 0x7f020000;
    private static HashMap<String, Integer> sIdsMap = new HashMap<>();

    public static HashMap<String, Integer> getIdsMap() {
        return sIdsMap;
    }

    private DynamicView() {
    }

    /**
     * @param jsonObject : json object
     * @param parent : parent viewGroup
     * @param holderClass : class that will be created as an holder and attached as a tag in the
     * View, If contains HashMap ids will replaced with idsMap
     *
     * @return the view that created
     */
    public static View createView(Context context, JsonObject jsonObject, ViewGroup parent,
                                  Class holderClass, String insertId, String stepId) {

        if (jsonObject == null) {
            return null;
        }

        HashMap<String, Integer> ids = new HashMap<>();

        View container = createViewInternal(context, jsonObject, parent, ids, insertId, stepId);

        if (container == null) {
            return null;
        }

        if (container.getTag(INTERNAL_TAG_ID) != null) {
            DynamicHelper.applyLayoutProperties(container,
                    (List<DynamicProperty>) container.getTag(INTERNAL_TAG_ID), parent, ids);
        }

        // clear tag from properties.
        container.setTag(null);

        if (holderClass != null) {

            try {
                Object holder = holderClass.getConstructor().newInstance();
                DynamicHelper.parseDynamicView(holder, container, ids);

                container.setTag(holder);
            } catch (Exception e) {
                InsertLogger.e(e, e.getMessage());
            }
        }

        return container;

    }

    /**
     * Use internal to parse the json as a tree to create View.
     *
     * @param jsonObject : json object
     * @param ids : the hashMap where we keep ids as string from json to ids as int in the layout
     *
     * @param insertId
     * @return the view that created
     */
    @SuppressWarnings("CheckStyle")
    private static View createViewInternal(
            Context context,
            JsonObject jsonObject,
            ViewGroup parent,
            HashMap<String, Integer> ids, String insertId, String stepId) {

        View view = null;
        String widgetName = "";

        ArrayList<DynamicProperty> properties;
        String widget = null;
        ScrollView scrollView = null;
        boolean isViewPager = false;
        try {
            // Create ScrollView container in case scrollable attribute was sent from backend
            if (jsonObject.has("scrollable")) {
                boolean scrollable = jsonObject.get("scrollable").getAsBoolean();

                // Getting fillViewport form configuration. fill == true (default), wrap == false;
                boolean fillViewport = "fill".equals(JsonUtils.optString(jsonObject, "scrollMode", "fill"));

                if (scrollable) {
                    // We create a scrollview which will contain the following control
                    scrollView = new ScrollView(context);
                    scrollView.setFillViewport(fillViewport);
//                    ViewGroup.LayoutParams params = DynamicHelper.createLayoutParams(parent);
//                    params.height = ViewGroup.LayoutParams.MATCH_PARENT;
//                    params.width = ViewGroup.LayoutParams.MATCH_PARENT;
//                    scrollView.setLayoutParams(params);
//                    parent = scrollView;
                }
            }

            // Create the View Object.
            // If not full package is available try to create a view from android.widget.
            widgetName = JsonUtils.getString(jsonObject, InsertActionConfiguration.GUIDE_SCREEN_WIDGET);
            widget = DynamicViewUtils.getWidget(widgetName);

            if (DynamicViewUtils.INSERT_PAGER.equals(widget)) {
                view = InsertPager.insertPagerFactory(context, parent, jsonObject, insertId);
                // Warm up the cache and downloads the images for all the pages.
                ArrayList<String> imagesToDownload =
                        InsertPreparationManager.getInstance().getImages(jsonObject);
                InsertPreparationManager.getInstance()
                        .fetchImagesForPager(insertId, imagesToDownload);
                isViewPager = true;

            } else if (DynamicViewUtils.INSERT_RATING_CONTROL_WIDGET.equals(widget)) {
                view = new InsertIoRatingBar(context, jsonObject, insertId);
            } else if (DynamicViewUtils.INSERT_IMAGEVIEW_WIDGET.equals(widget)) {
                // TODO: 6/21/16 Should this be for all ActionableBlock?
                if (stepId.isEmpty()) {
                    // In case we don't have a stepId for some reason, let's use the guideId.
                    view = new VisualActionImage(context, insertId);
                } else {
                    view = new VisualActionImage(context, stepId);
                }
            } else {
                Class viewClass = Class.forName(widget);

                // create the actual view object.
                view = (View)
                        viewClass.getConstructor(Context.class).newInstance(context);

                InsertContentDescriptionManager.getInstance().setContentDescription(view, widget,
                        null);
            }

            if (view instanceof InsertRadioButton) {
                ((InsertRadioButton) view).setup(jsonObject);
            }

            generalViewProcess(jsonObject, view, insertId);
            InsertContentDescriptionManager.getInstance().setImportantForAccessibility(view);

        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

        if (view == null) {
            InsertLogger.w("View couldn't be created: " + widget);

            return null;
        }

        if (view instanceof ActionableBlock) {
            if (jsonObject.has(InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME)) {

                final JsonArray actions =
                        JsonUtils.optJsonArray(jsonObject, InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);
                if (actions == null || actions.size() == 0) {
                    InsertLogger.d("No actions.");
                } else {
                    final JavascriptRunner.InsertContext insertContext =
                            new JavascriptRunner.InsertContext(insertId);
                    List<InsertCommand> commands =
                            InsertCommand.getInsertCommandsWithParameters(
                                    actions,
                                    InsertInfoConsts.createInsertMetadataParams(insertId),
                                    insertContext);

                    ((ActionableBlock) view).setActions(commands);
                }
            }
        }

        try {

            if (!isViewPager) {
                // default Layout in case the user not set it.
                ViewGroup.LayoutParams params = DynamicHelper.createLayoutParams(parent);
                view.setLayoutParams(params);

                if (scrollView != null) {
                    scrollView.setLayoutParams(params);
                }
            }

            // Iterate json and get all properties in array.
            properties = new ArrayList<>();
            JsonArray jArray = jsonObject
                    .getAsJsonArray(InsertActionConfiguration.GUIDE_SCREEN_WIDGET_PROPERTIES);
            DynamicProperty orientationProperty = null;
            if (jArray != null) {
                for (int i = 0; i < jArray.size(); i++) {
                    DynamicProperty p = new DynamicProperty(jArray.get(i).getAsJsonObject());
                    if (p.isValid()) {
                        properties.add(p);
                    }
                    if (p.name.equals(DynamicProperty.NAME.ORIENTATION)) {
                        orientationProperty = p;
                    }
                }
            }
            // keep properties obj as a tag.
            view.setTag(INTERNAL_TAG_ID, properties);

            // P2 row block property addition.
            if (widgetName.equals(P2_ROW_BLOCK)) {
                if (orientationProperty != null && properties.contains(orientationProperty)) {
                    properties.remove(orientationProperty);
                }
                properties.add(new DynamicProperty(new Gson().fromJson(DynamicProperty.ORIENTATION_HORIZONTAL, JsonObject.class)));
            }
            if (scrollView != null) {
                scrollView.setTag(INTERNAL_TAG_ID, properties);
            }

            // add and integer as a universal id  and keep it in a HashMap.
            String id = DynamicHelper.applyStyleProperties(view, properties);
            String layoutId = JsonUtils.optString(jsonObject, "layoutId");
            String relativeFakeId = JsonUtils.optString(jsonObject, "id");
            if (isViewPager) {
                if (!TextUtils.isEmpty(id)) {
                    ids.put(id, view.getId());
                }
                if (!TextUtils.isEmpty(layoutId)) {
                    ids.put(layoutId, view.getId());
                }
                return view;
            }

            final int viewId = Utils.generateViewId();
            if (!TextUtils.isEmpty(id)) {
                sIdsMap.put(id, viewId);
                InsertContentDescriptionManager.getInstance().setContentDescription(view, null, id);

                if (scrollView != null) {
                    scrollView.setId(viewId);
                    view.setId(Utils.generateViewId());
                } else {
                    view.setId(viewId);
                }

                ids.put(id, viewId);

                InsertCommandViewHandlerUtility.handleInsertCommandsForView(view, id);
            }

            if (!TextUtils.isEmpty(relativeFakeId)) {
                ids.put(relativeFakeId, viewId);
            }

            if (!TextUtils.isEmpty(layoutId)) {
                ids.put(layoutId, viewId);
            }

            // if view is type of ViewGroup check for its children view in json.
            if (view instanceof ViewGroup && jsonObject.has("views")) {
                ViewGroup viewGroup = (ViewGroup) view;
                InsertContentDescriptionManager.getInstance().setContentDescription(view,
                        context.getString(R.string.insert_visual_accessibility), null);
                // parse the array to get the children views.
                List<View> views = new ArrayList<>();
                JsonArray jViews = jsonObject.getAsJsonArray("views");
                if (jViews != null) {
                    int count = jViews.size();
                    for (int i = 0; i < count; i++) {
                        // create every child,
                        // add it in viewGroup and set its tag with its properties.
                        View dynamicChildView = DynamicView
                                .createViewInternal(context, jViews.get(i).getAsJsonObject(), viewGroup, ids, insertId, stepId);

                        if (dynamicChildView != null && dynamicChildView.getParent() == null) {
                            views.add(dynamicChildView);
                            viewGroup.addView(dynamicChildView);
                        } else {
                            InsertLogger.e("Error: Cannot create view: " + jViews.get(i).getAsJsonObject());
                        }
                    }
                }

                // after create all the children apply layout properties
                // we need to do this after al children creation to have create all possible ids.
                for (View v : views) {
                    List<DynamicProperty> dynamicProperties =
                            (List<DynamicProperty>) v.getTag(INTERNAL_TAG_ID);
                    if (dynamicProperties != null) {
                        DynamicHelper.applyLayoutProperties(v, dynamicProperties, viewGroup, ids);
                        // clear tag from properties.
                        v.setTag(INTERNAL_TAG_ID, null);
                    }
                }
            }

        } catch (Exception e) {
            InsertLogger.e(e, e.getMessage());
        }

        if (scrollView != null) {
            // We have created a scrollview we need to apply layout properties to the original view
            scrollView.addView(view);
            List<DynamicProperty> dynamicProperties =
                    (List<DynamicProperty>) view.getTag(INTERNAL_TAG_ID);
            if (dynamicProperties != null) {
                // We are applying the layout properties here as we are returning scrollview
                // as the created view in case the view is scrollable.
                // We need to take care of the widget / view in this recursion level which
                // is the child of the scrollview as the parent will apply the layout properties
                // only on it's direct children
                DynamicHelper.applyLayoutProperties(view, dynamicProperties, scrollView, ids);
                // clear tag from properties.
                view.setTag(INTERNAL_TAG_ID, null);
            }
            return scrollView;
        }
        return view;
    }

    private static void generalViewProcess(final JsonObject jsonObject,
                                           final View view,
                                           String insertId) {

        final JsonArray actions =
                JsonUtils.optJsonArray(jsonObject, InsertCommand.INSERT_COMMANDS_SERIALIZED_NAME);
        if (actions != null && actions.size() > 0) {
            final JavascriptRunner.InsertContext insertContext =
                    new JavascriptRunner.InsertContext(insertId);
            final List<InsertCommand> commands =
                    InsertCommand.getInsertCommandsWithParameters(
                            actions,
                            InsertInfoConsts.createInsertMetadataParams(insertId),
                            insertContext);

            if (view instanceof InsertEditText) {
                ((InsertEditText) view).setCommands(commands);
            }

            if (view instanceof InsertForm) {

                ((InsertForm) view).processForm(jsonObject, commands, insertId);

            } else {

                if (view instanceof RadioButton) {
                    RxCompoundButton
                            .checkedChanges((CompoundButton) view)
                            .compose(RxLifecycleAndroid.<Boolean>bindView(view))
                            .skip(1)
                            .subscribe(InsertObserver.create(new Consumer<Boolean>() {
                                @Override
                                public void accept(Boolean isChecked) {
                                    InsertCommandDispatcher.getInstance()
                                            .dispatchCommands(
                                                    commands,
                                                    InsertCommandEventType
                                                            .UserEventType.TAP_ON, true);
                                }
                            }));

                } else if (view instanceof RadioGroup) {
                    RxRadioGroup.checkedChanges((RadioGroup) view)
                            .compose(RxLifecycleAndroid.<Integer>bindView(view))
                            .skip(1)
                            .subscribe(InsertObserver.create(new Consumer<Integer>() {
                                @Override
                                public void accept(Integer checkedId) {
                                    final boolean valid = checkedId != View.NO_ID;
                                    if (valid) {
                                        InsertCommandDispatcher.getInstance()
                                                .dispatchCommands(commands,
                                                        ON_SELECTION_CHANGED, true);
                                        InsertCommandDispatcher.getInstance()
                                                .dispatchCommands(commands, ON_VALID, true);
                                    } else {
                                        InsertCommandDispatcher.getInstance()
                                                .dispatchCommands(commands, ON_INVALID, true);
                                    }
                                }
                            }));
                }
            }
        }
    }
}
