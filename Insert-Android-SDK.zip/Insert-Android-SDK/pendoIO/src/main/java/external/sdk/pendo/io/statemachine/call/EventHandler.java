package external.sdk.pendo.io.statemachine.call;

import external.sdk.pendo.io.statemachine.*;

public interface EventHandler<C extends StatefulContext> extends Handler {
	void call(EventEnum event, StateEnum from, StateEnum to, C context) throws Exception;
}
