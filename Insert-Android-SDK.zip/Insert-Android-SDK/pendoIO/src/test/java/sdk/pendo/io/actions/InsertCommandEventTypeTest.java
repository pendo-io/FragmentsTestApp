package sdk.pendo.io.actions;

import junit.framework.Assert;

import org.junit.Test;

import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_INVALID;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_SUBMIT;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_VALID;
import static sdk.pendo.io.actions.InsertCommandEventType.InsertPreparationEventType.PREFETCH_IMAGES_END;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_CHANGE_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_FIRST_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_INNER_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerEventType.ON_LAST_PAGE;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerPageEventType.ON_APPEAR;
import static sdk.pendo.io.actions.InsertCommandEventType.PagerPageEventType.ON_DISAPPEAR;
import static sdk.pendo.io.actions.InsertCommandEventType.FormEventType.ON_SELECTION_CHANGED;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.HOST_APP_DEVELOPER_CALL;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.TRIGGER_OCCURRED;
import static sdk.pendo.io.actions.InsertCommandEventType.TextFieldEventType.ON_TEXT_CHANGED;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.ANIMATION_DONE;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.GUIDE_DISMISSED;
import static sdk.pendo.io.actions.InsertCommandEventType.SdkEventType.TIME_OUT;
import static sdk.pendo.io.actions.InsertCommandEventType.UserEventType.PINCH_IN;
import static sdk.pendo.io.actions.InsertCommandEventType.UserEventType.PINCH_OUT;
import static sdk.pendo.io.actions.InsertCommandEventType.UserEventType.SWIPE_LEFT;
import static sdk.pendo.io.actions.InsertCommandEventType.UserEventType.SWIPE_RIGHT;
import static sdk.pendo.io.actions.InsertCommandEventType.UserEventType.TAP_ON;
import static sdk.pendo.io.actions.InsertCommandEventType.VideoEventType.ON_COMPLETE;
import static sdk.pendo.io.actions.InsertCommandEventType.VideoEventType.ON_PAUSE;
import static sdk.pendo.io.actions.InsertCommandEventType.VideoEventType.ON_START;
import static sdk.pendo.io.actions.InsertCommandEventType.VideoEventType.ON_STOP;

/**
 * Tests the {@link InsertCommandEventType} class.
 *
 * Created by assaf on 3/28/16.
 */
public class InsertCommandEventTypeTest {

    @Test
    public void testGetEventType() throws Exception {
        Assert.assertEquals(InsertCommandEventType.getEventType("guideDismissed"), GUIDE_DISMISSED);
        Assert.assertEquals(InsertCommandEventType.getEventType("timeOut"), TIME_OUT);
        Assert.assertEquals(InsertCommandEventType.getEventType("animationDone"), ANIMATION_DONE);
        Assert.assertEquals(InsertCommandEventType.getEventType("hostAppDeveloperCall"), HOST_APP_DEVELOPER_CALL);
        Assert.assertEquals(InsertCommandEventType.getEventType("triggerOccurred"), TRIGGER_OCCURRED);
        Assert.assertEquals(InsertCommandEventType.getEventType("prefetchImagesEnd"), PREFETCH_IMAGES_END);
        Assert.assertEquals(InsertCommandEventType.getEventType("tapOn"), TAP_ON);
        Assert.assertEquals(InsertCommandEventType.getEventType("swipeLeft"), SWIPE_LEFT);
        Assert.assertEquals(InsertCommandEventType.getEventType("swipeRight"), SWIPE_RIGHT);
        Assert.assertEquals(InsertCommandEventType.getEventType("pinchIn"), PINCH_IN);
        Assert.assertEquals(InsertCommandEventType.getEventType("pinchOut"), PINCH_OUT);
        Assert.assertEquals(InsertCommandEventType.getEventType("onSubmit"), ON_SUBMIT);
        Assert.assertEquals(InsertCommandEventType.getEventType("onValid"), ON_VALID);
        Assert.assertEquals(InsertCommandEventType.getEventType("onInvalid"), ON_INVALID);
        Assert.assertEquals(InsertCommandEventType.getEventType("onSelectionChanged"), ON_SELECTION_CHANGED);
        Assert.assertEquals(InsertCommandEventType.getEventType("onTextChanged"), ON_TEXT_CHANGED);
        Assert.assertEquals(InsertCommandEventType.getEventType("onChangePage"), ON_CHANGE_PAGE);
        Assert.assertEquals(InsertCommandEventType.getEventType("onFirstPage"), ON_FIRST_PAGE);
        Assert.assertEquals(InsertCommandEventType.getEventType("onLastPage"), ON_LAST_PAGE);
        Assert.assertEquals(InsertCommandEventType.getEventType("onInnerPage"), ON_INNER_PAGE);
        Assert.assertEquals(InsertCommandEventType.getEventType("onAppear"), ON_APPEAR);
        Assert.assertEquals(InsertCommandEventType.getEventType("onDisappear"), ON_DISAPPEAR);
        Assert.assertEquals(InsertCommandEventType.getEventType("onStart"), ON_START);
        Assert.assertEquals(InsertCommandEventType.getEventType("onStop"), ON_STOP);
        Assert.assertEquals(InsertCommandEventType.getEventType("onComplete"), ON_COMPLETE);
        Assert.assertEquals(InsertCommandEventType.getEventType("onPause"), ON_PAUSE);


        Assert.assertNull(InsertCommandEventType.getEventType("onPause2"));
    }
}
