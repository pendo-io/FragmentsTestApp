package sdk.pendo.io.actions;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import junit.framework.Assert;

import org.junit.Test;

public class InsertActionConfigurationTest {

    @Test
    public void testTetTooltipProperties() throws Exception {
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(elementViewMock2, JsonObject.class);
        JsonObject step = (JsonObject) jsonObject.getAsJsonArray("steps").get(0);

        JsonArray result = InsertActionConfiguration.getTooltipProperties(step);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.size(), 12);
    }


    @Test
    public void testGetTooltipContent() throws Exception {
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(elementViewMock2, JsonObject.class);
        JsonObject step = (JsonObject) jsonObject.getAsJsonArray("steps").get(0);
        JsonObject result = InsertActionConfiguration.getTooltipContent(step);
        Assert.assertNotNull(result);
        Assert.assertEquals(result.get("widget").getAsString(),"LinearLayout");
    }

    @Test
    public void testVisualInsertType() throws Exception {
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(elementViewMock2, JsonObject.class);
        JsonObject step = (JsonObject) jsonObject.getAsJsonArray("steps").get(0);
        InsertActionConfiguration.VisualInsertType result = InsertActionConfiguration.getStepVisualInsertType(step);
        Assert.assertNotNull(result);
        Assert.assertEquals(result, InsertActionConfiguration.VisualInsertType.TOOLTIP);
    }



    private static final String elementViewMock2 = "{\n" +
            "  \"recurrence\": 0,\n" +
            "  \"activations\": [\n" +
            "    {\n" +
            "      \"activationId\": 1359446259,\n" +
            "      \"event\": \"elementView\",\n" +
            "      \"mobileSelector\": \"$[?(($.retroactiveScreenData.retroactiveScreenId=='RecyclerViewActivity') && ($.retroElementInfo.predicate=='[android.view.ViewRootImpl][com.android.internal.policy.DecorView][android.widget.LinearLayout][android.widget.FrameLayout][android.support.v7.widget.FitWindowsLinearLayout][android.support.v7.widget.ContentFrameLayout][android.support.design.widget.CoordinatorLayout][android.support.v4.widget.SwipeRefreshLayout][android.support.v7.widget.RecyclerView][android.support.v7.widget.CardView][indexPath=(0,2)]'))]\"\n" +
            "    }\n" +
            "  ],\n" +
            "  \"guideId\": \"0NZgYQvP22XMqAlr5QZcIWSGMI0\",\n" +
            "  \"guideName\": \"Unnamed 11/28 @ 5:54 PM\",\n" +
            "  \"appId\": 5771506779684864,\n" +
            "  \"priority\": 1,\n" +
            "  \"configuration\": {\n" +
            "    \"capping\": {\n" +
            "      \"maxSessionImpressions\": 10\n" +
            "    }\n" +
            "  },\n" +
            "  \"steps\": [\n" +
            "    {\n" +
            "      \"guideId\": \"0NZgYQvP22XMqAlr5QZcIWSGMI0\",\n" +
            "      \"guideStepId\": \"qekwn2ZBgtSl8syAgC8ZUQ96MYI\",\n" +
            "      \"content\": {\n" +
            "        \"guide\": {\n" +
            "          \"widget\": \"Base\",\n" +
            "          \"id\": \"base-block\",\n" +
            "          \"web\": {\n" +
            "            \"domClasses\": [],\n" +
            "            \"pseudoStyles\": [],\n" +
            "            \"domId\": \"pendo-base\",\n" +
            "            \"layout\": \"tooltipBlank\",\n" +
            "            \"editingId\": \"AUTO_GENERATED_ID\"\n" +
            "          },\n" +
            "          \"actions\": [],\n" +
            "          \"properties\": [],\n" +
            "          \"views\": [\n" +
            "            {\n" +
            "              \"widget\": \"LinearLayout\",\n" +
            "              \"id\": \"insert_visual_floating_layout\",\n" +
            "              \"web\": {\n" +
            "                \"domClasses\": [\n" +
            "                  \"_pendo-backdrop_\"\n" +
            "                ],\n" +
            "                \"pseudoStyles\": [],\n" +
            "                \"domId\": \"pendo-backdrop\",\n" +
            "                \"editingId\": \"AUTO_GENERATED_ID\"\n" +
            "              },\n" +
            "              \"actions\": [],\n" +
            "              \"properties\": [\n" +
            "                {\n" +
            "                  \"name\": \"layout_width\",\n" +
            "                  \"type\": \"dimen\",\n" +
            "                  \"value\": \"match_parent\"\n" +
            "                },\n" +
            "                {\n" +
            "                  \"name\": \"layout_height\",\n" +
            "                  \"type\": \"dimen\",\n" +
            "                  \"value\": \"match_parent\"\n" +
            "                },\n" +
            "                {\n" +
            "                  \"name\": \"background\",\n" +
            "                  \"type\": \"color\",\n" +
            "                  \"value\": \"#FFFFFFBF\"\n" +
            "                },\n" +
            "                {\n" +
            "                  \"name\": \"z-index\",\n" +
            "                  \"type\": \"string\",\n" +
            "                  \"value\": \"200000\"\n" +
            "                },\n" +
            "                {\n" +
            "                  \"name\": \"orientation\",\n" +
            "                  \"type\": \"dimen\",\n" +
            "                  \"value\": \"vertical\"\n" +
            "                },\n" +
            "                {\n" +
            "                  \"name\": \"gravity\",\n" +
            "                  \"type\": \"string\",\n" +
            "                  \"value\": \"center_vertical|center_horizontal\"\n" +
            "                }\n" +
            "              ],\n" +
            "              \"views\": [\n" +
            "                {\n" +
            "                  \"widget\": \"Tooltip\",\n" +
            "                  \"id\": \"pendo_visual_tooltip\",\n" +
            "                  \"web\": {\n" +
            "                    \"domClasses\": [],\n" +
            "                    \"pseudoStyles\": [],\n" +
            "                    \"domId\": \"pendo-backdrop\",\n" +
            "                    \"editingId\": \"AUTO_GENERATED_ID\"\n" +
            "                  },\n" +
            "                  \"actions\": [],\n" +
            "                  \"properties\": [\n" +
            "                    {\n" +
            "                      \"name\": \"id\",\n" +
            "                      \"type\": \"ref\",\n" +
            "                      \"value\": \"AUTO_GENERATED_ID\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"caret_enabled\",\n" +
            "                      \"type\": \"boolean\",\n" +
            "                      \"value\": \"true\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"caret_height\",\n" +
            "                      \"type\": \"dimen\",\n" +
            "                      \"value\": \"15dp\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"caret_width\",\n" +
            "                      \"type\": \"dimen\",\n" +
            "                      \"value\": \"15dp\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"padding\",\n" +
            "                      \"type\": \"dimen\",\n" +
            "                      \"value\": \"18dp\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"gravity\",\n" +
            "                      \"type\": \"string\",\n" +
            "                      \"value\": \"center_vertical|center_horizontal\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"layout_width\",\n" +
            "                      \"type\": \"dimen\",\n" +
            "                      \"value\": \"454dp\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"layout_height\",\n" +
            "                      \"type\": \"dimen\",\n" +
            "                      \"value\": \"wrap_content\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"background\",\n" +
            "                      \"type\": \"color\",\n" +
            "                      \"value\": \"#FF30ED\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"z-index\",\n" +
            "                      \"type\": \"string\",\n" +
            "                      \"value\": \"200000\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"orientation\",\n" +
            "                      \"type\": \"dimen\",\n" +
            "                      \"value\": \"vertical\"\n" +
            "                    },\n" +
            "                    {\n" +
            "                      \"name\": \"position\",\n" +
            "                      \"value\": \"top\",\n" +
            "                      \"type\": \"string\"\n" +
            "                    }\n" +
            "                  ],\n" +
            "                  \"views\": [\n" +
            "                    {\n" +
            "                      \"widget\": \"LinearLayout\",\n" +
            "                      \"id\": \"insert_visual_container_layout\",\n" +
            "                      \"web\": {\n" +
            "                        \"domClasses\": [],\n" +
            "                        \"pseudoStyles\": [],\n" +
            "                        \"domId\": \"pendo-guide-container\",\n" +
            "                        \"editingId\": \"d71c6eeb-6a12-49eb-8bab-4fca7d5fe11a\",\n" +
            "                        \"tabIndex\": \"-1\"\n" +
            "                      },\n" +
            "                      \"actions\": [],\n" +
            "                      \"properties\": [\n" +
            "                        {\n" +
            "                          \"name\": \"background\",\n" +
            "                          \"type\": \"color\",\n" +
            "                          \"value\": \"#FFFFFFFF\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"paddingTop\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"45dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"paddingLeft\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"45dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"paddingRight\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"45dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"paddingBottom\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"45dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"frameWidth\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"1dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"frameColor\",\n" +
            "                          \"type\": \"color\",\n" +
            "                          \"value\": \"#BBBBBB\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"frameStyle\",\n" +
            "                          \"type\": \"string\",\n" +
            "                          \"value\": \"solid\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"shadowColor\",\n" +
            "                          \"type\": \"color\",\n" +
            "                          \"value\": \"#888888FF\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"shadowOffsetVertical\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"0dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"shadowOffsetHorizontal\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"0dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"shadowRadius\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"22dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"shadowSpread\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"0dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"frameRadius\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"0dp\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"layout_position_type\",\n" +
            "                          \"type\": \"string\",\n" +
            "                          \"value\": \"relative\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"maxHeight\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"100vh\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"overflow\",\n" +
            "                          \"type\": \"string\",\n" +
            "                          \"value\": \"scroll\"\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"name\": \"orientation\",\n" +
            "                          \"type\": \"dimen\",\n" +
            "                          \"value\": \"vertical\"\n" +
            "                        }\n" +
            "                      ],\n" +
            "                      \"views\": [\n" +
            "                        {\n" +
            "                          \"widget\": \"RowBlock\",\n" +
            "                          \"id\": \"insert_visual_row\",\n" +
            "                          \"web\": {\n" +
            "                            \"domClasses\": [],\n" +
            "                            \"pseudoStyles\": [],\n" +
            "                            \"domId\": \"pendo-row-40d2f427\",\n" +
            "                            \"displayFlex\": true,\n" +
            "                            \"justifyContent\": \"flex-end\",\n" +
            "                            \"editingId\": \"4c44d32f-475c-423a-830a-acbe14d8a667\"\n" +
            "                          },\n" +
            "                          \"actions\": [],\n" +
            "                          \"properties\": [\n" +
            "                            {\n" +
            "                              \"name\": \"id\",\n" +
            "                              \"type\": \"ref\",\n" +
            "                              \"value\": \"pendo-row-40d2f427\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_height\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"wrap_content\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_width\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"match_parent\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"gravity\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"right\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"background\",\n" +
            "                              \"type\": \"color\",\n" +
            "                              \"value\": \"#FFFFFF00\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginBottom\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginLeft\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginRight\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginTop\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingBottom\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingLeft\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingRight\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingTop\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_position_type\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"static\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textAlign\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"right\"\n" +
            "                            }\n" +
            "                          ],\n" +
            "                          \"templateName\": null,\n" +
            "                          \"views\": [\n" +
            "                            {\n" +
            "                              \"widget\": \"CloseButton\",\n" +
            "                              \"id\": \"insert_visual_close_button\",\n" +
            "                              \"web\": {\n" +
            "                                \"domClasses\": [],\n" +
            "                                \"pseudoStyles\": [],\n" +
            "                                \"domId\": \"pendo-close-guide-bff54d8b\",\n" +
            "                                \"ariaLabel\": \"Close\",\n" +
            "                                \"rowDomId\": \"pendo-row-40d2f427\",\n" +
            "                                \"editingId\": \"bfb394d0-9acb-42e7-8805-a83f4fc0cf17\"\n" +
            "                              },\n" +
            "                              \"actions\": [\n" +
            "                                {\n" +
            "                                  \"action\": \"dismissGuide\",\n" +
            "                                  \"source\": \"insert_visual_close_button\",\n" +
            "                                  \"destination\": \"Global\",\n" +
            "                                  \"parameters\": [],\n" +
            "                                  \"uiMetadata\": {},\n" +
            "                                  \"eventType\": \"click\",\n" +
            "                                  \"id\": \"17eb5bbf-ba32-40f2-9a46-f8f1763af562\"\n" +
            "                                }\n" +
            "                              ],\n" +
            "                              \"properties\": [\n" +
            "                                {\n" +
            "                                  \"name\": \"frameWidth\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"textLineHeight\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": 1\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"layout_margin\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"paddingBottom\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"paddingLeft\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"paddingRight\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"paddingTop\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"text\",\n" +
            "                                  \"type\": \"string\",\n" +
            "                                  \"value\": \"×\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"z-index\",\n" +
            "                                  \"type\": \"string\",\n" +
            "                                  \"value\": \"20\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"layout_minWidth\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"0dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"background\",\n" +
            "                                  \"type\": \"color\",\n" +
            "                                  \"value\": \"#00000000\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"textColor\",\n" +
            "                                  \"type\": \"color\",\n" +
            "                                  \"value\": \"#9A9CA5\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"textSize\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"32dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"layout_width\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"22dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"layout_height\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"32dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"layout_position_type\",\n" +
            "                                  \"type\": \"string\",\n" +
            "                                  \"value\": \"relative\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"xColor\",\n" +
            "                                  \"type\": \"color\",\n" +
            "                                  \"value\": \"#9A9CA5\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"xWidth\",\n" +
            "                                  \"type\": \"dimen\",\n" +
            "                                  \"value\": \"1dp\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"enabled\",\n" +
            "                                  \"type\": \"boolean\",\n" +
            "                                  \"value\": true\n" +
            "                                },\n" +
            "                                {\n" +
            "                                  \"name\": \"id\",\n" +
            "                                  \"type\": \"ref\",\n" +
            "                                  \"value\": \"e3495804-88df-49bf-9168-00032b72e2fd\"\n" +
            "                                }\n" +
            "                              ],\n" +
            "                              \"templateName\": null,\n" +
            "                              \"views\": [],\n" +
            "                              \"layoutId\": null,\n" +
            "                              \"uiMetadata\": {\n" +
            "                                \"name\": \"\",\n" +
            "                                \"wizard\": {\n" +
            "                                  \"defaultValues\": {},\n" +
            "                                  \"defaultActions\": {}\n" +
            "                                }\n" +
            "                              }\n" +
            "                            }\n" +
            "                          ],\n" +
            "                          \"layoutId\": null,\n" +
            "                          \"uiMetadata\": {\n" +
            "                            \"name\": \"\",\n" +
            "                            \"wizard\": {\n" +
            "                              \"defaultValues\": {},\n" +
            "                              \"defaultActions\": {}\n" +
            "                            }\n" +
            "                          }\n" +
            "                        },\n" +
            "                        {\n" +
            "                          \"widget\": \"TextView\",\n" +
            "                          \"id\": \"insert_visual_title\",\n" +
            "                          \"web\": {\n" +
            "                            \"domClasses\": [],\n" +
            "                            \"pseudoStyles\": [],\n" +
            "                            \"domId\": \"pendo-text-dd605b68\",\n" +
            "                            \"themeStyle\": \"paragraph\",\n" +
            "                            \"editingId\": \"66ac0d3b-30a6-4602-8c11-7a33242c6cf0\"\n" +
            "                          },\n" +
            "                          \"actions\": [],\n" +
            "                          \"properties\": [\n" +
            "                            {\n" +
            "                              \"name\": \"cursor\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"inherit\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"display\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"block\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textColor\",\n" +
            "                              \"type\": \"color\",\n" +
            "                              \"value\": \"#000000\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textSize\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"15dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"letterSpacing\",\n" +
            "                              \"type\": \"pixel-dimen\",\n" +
            "                              \"value\": \"0px\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textLineHeight\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": 1.4\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginBottom\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"11dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginTop\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"11dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingBottom\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingLeft\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingRight\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"paddingTop\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_position_type\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"relative\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textTransform\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"none\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_width\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"auto\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"fontFamily\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"sans-serif\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"fontStyle\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"regular\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textAlign\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"center\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"whiteSpace\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"pre-wrap\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginLeft\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_marginRight\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": \"0dp\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"id\",\n" +
            "                              \"type\": \"ref\",\n" +
            "                              \"value\": \"pendo-text-dd605b68\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"layout_gravity\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"left\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"gravity\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"left\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"text\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"This is some placeholder text. Enjoy Guide Building!\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"markdownText\",\n" +
            "                              \"type\": \"string\",\n" +
            "                              \"value\": \"This is some placeholder text. Enjoy Guide Building!\"\n" +
            "                            },\n" +
            "                            {\n" +
            "                              \"name\": \"textStyle\",\n" +
            "                              \"type\": \"dimen\",\n" +
            "                              \"value\": 400\n" +
            "                            }\n" +
            "                          ],\n" +
            "                          \"templateName\": null,\n" +
            "                          \"views\": [],\n" +
            "                          \"layoutId\": null,\n" +
            "                          \"uiMetadata\": {\n" +
            "                            \"name\": \"\",\n" +
            "                            \"wizard\": {\n" +
            "                              \"defaultValues\": {},\n" +
            "                              \"defaultActions\": {}\n" +
            "                            }\n" +
            "                          },\n" +
            "                          \"nestedStyles\": {\n" +
            "                            \"link\": {\n" +
            "                              \"content\": \"\",\n" +
            "                              \"display\": \"inline-block\",\n" +
            "                              \"fontDecoration\": \"none\",\n" +
            "                              \"fontSize\": \"inherit\",\n" +
            "                              \"href\": \"\",\n" +
            "                              \"letterSpacing\": \"inherit\",\n" +
            "                              \"lineHeight\": \"inherit\",\n" +
            "                              \"marginBottom\": \"0px\",\n" +
            "                              \"marginLeft\": \"0px\",\n" +
            "                              \"marginRight\": \"0px\",\n" +
            "                              \"marginTop\": \"0px\",\n" +
            "                              \"padding\": \"0px\",\n" +
            "                              \"paddingBottom\": \"0px\",\n" +
            "                              \"positionType\": \"relative\",\n" +
            "                              \"target\": \"_blank\",\n" +
            "                              \"textAlign\": \"inherit\",\n" +
            "                              \"textTransform\": \"inherit\",\n" +
            "                              \"title\": \"\",\n" +
            "                              \"fontColor\": {\n" +
            "                                \"value\": \"#000000\",\n" +
            "                                \"enabled\": false\n" +
            "                              }\n" +
            "                            }\n" +
            "                          }\n" +
            "                        }\n" +
            "                      ],\n" +
            "                      \"layoutId\": null,\n" +
            "                      \"uiMetadata\": {\n" +
            "                        \"name\": \"\",\n" +
            "                        \"wizard\": {\n" +
            "                          \"defaultValues\": {},\n" +
            "                          \"defaultActions\": {}\n" +
            "                        }\n" +
            "                      }\n" +
            "                    }\n" +
            "                  ],\n" +
            "                  \"layoutId\": null,\n" +
            "                  \"uiMetadata\": {\n" +
            "                    \"name\": \"\",\n" +
            "                    \"wizard\": {\n" +
            "                      \"defaultValues\": {},\n" +
            "                      \"defaultActions\": {}\n" +
            "                    }\n" +
            "                  }\n" +
            "                }\n" +
            "              ],\n" +
            "              \"layoutId\": null,\n" +
            "              \"uiMetadata\": {\n" +
            "                \"name\": \"\",\n" +
            "                \"wizard\": {\n" +
            "                  \"defaultValues\": {},\n" +
            "                  \"defaultActions\": {}\n" +
            "                }\n" +
            "              }\n" +
            "            }\n" +
            "          ],\n" +
            "          \"layoutId\": null,\n" +
            "          \"uiMetadata\": {\n" +
            "            \"name\": \"\",\n" +
            "            \"wizard\": {\n" +
            "              \"defaultValues\": {},\n" +
            "              \"defaultActions\": {}\n" +
            "            }\n" +
            "          },\n" +
            "          \"theme\": {\n" +
            "            \"supplementalCss\": {\n" +
            "              \"_pendo-step-container-size\": {},\n" +
            "              \"_pendo-backdrop\": {},\n" +
            "              \"_pendo-step-container-styles\": {},\n" +
            "              \"_pendo-close-guide\": {}\n" +
            "            }\n" +
            "          },\n" +
            "          \"location\": {\n" +
            "            \"locationId\": 1537723805,\n" +
            "            \"mobileSelector\": \"$[?(($.retroactiveScreenData.retroactiveScreenId=='UISplitViewController/UINavigationController/UINavigationController/UIKitCatalog.ButtonViewController' && $.retroactiveScreenData.childControllers[0].childControllers[0].info.kind=='UINavigationController' && $.retroactiveScreenData.info.master.info.kind=='UINavigationController' && $.retroactiveScreenData.info.master.info.stack[1].info.kind=='UINavigationController' && $.retroactiveScreenData.childControllers[0].info.kind=='UINavigationController' && $.retroactiveScreenData.childControllers[0].info.stack[1].info.kind=='UINavigationController'))]\"\n" +
            "          },\n" +
            "          \"configuration\": {\n" +
            "            \"transition\": [\n" +
            "              {\n" +
            "                \"type\": \"in\",\n" +
            "                \"effect\": \"pop\",\n" +
            "                \"duration\": 1000,\n" +
            "                \"contentId\": \"insert_visual_container_layout\",\n" +
            "                \"direction\": \"left\",\n" +
            "                \"backgroundId\": \"insert_visual_main_layout\"\n" +
            "              },\n" +
            "              {\n" +
            "                \"type\": \"out\",\n" +
            "                \"effect\": \"pop\",\n" +
            "                \"duration\": 1000,\n" +
            "                \"contentId\": \"insert_visual_container_layout\",\n" +
            "                \"direction\": \"left\",\n" +
            "                \"backgroundId\": \"insert_visual_main_layout\"\n" +
            "              }\n" +
            "            ],\n" +
            "            \"delayMs\": \"0\",\n" +
            "            \"timeoutMs\": \"0\",\n" +
            "            \"capping\": {\n" +
            "              \"maxSessionImpressions\": \"1\"\n" +
            "            }\n" +
            "          }\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  ],\n" +
            "  \"layoutId\": null,\n" +
            "  \"uiMetadata\": {\n" +
            "    \"name\": \"\",\n" +
            "    \"wizard\": {\n" +
            "      \"defaultValues\": {},\n" +
            "      \"defaultActions\": {}\n" +
            "    }\n" +
            "  },\n" +
            "  \"theme\": {\n" +
            "    \"supplementalCss\": {\n" +
            "      \"_pendo-step-container-size\": {},\n" +
            "      \"_pendo-backdrop\": {},\n" +
            "      \"_pendo-step-container-styles\": {},\n" +
            "      \"_pendo-close-guide\": {}\n" +
            "    }\n" +
            "  }\n" +
            "}";
}
