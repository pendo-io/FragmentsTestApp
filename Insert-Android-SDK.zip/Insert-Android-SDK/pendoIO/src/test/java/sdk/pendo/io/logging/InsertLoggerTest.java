package sdk.pendo.io.logging;

//@RunWith(RobolectricTestRunner.class) //
//@Config(manifest = Config.NONE)
//public class InsertLoggerTest {
//    @Before @After public void setUpAndTearDown() {
//        InsertLogger.uprootAll();
//    }

//    // NOTE: This class references the line number. Keep it at the top so it does not change.
//    @Test public void debugTreeCanAlterCreatedTag() {
//        InsertLogger.plant(new InsertLogger.DebugTree() {
//            @Override protected String createStackElementTag(StackTraceElement element) {
//                return super.createStackElementTag(element) + ':' + element.getLineNumber();
//            }
//        });
//
//        InsertLogger.d("Test");
//
//        assertLog()
//                .hasDebugMessage("NativeMethodAccessorImpl:38", "Test")
//                .hasNoMoreMessages();
//    }

//    @Test public void recursion() {
//        InsertLogger.Tree insertLogger = InsertLogger.asTree();
//        try {
//            InsertLogger.plant(insertLogger);
//            fail();
//        } catch (IllegalArgumentException e) {
//            assertThat(e).hasMessage("Cannot plant InsertLogger into itself.");
//        }
//        try {
//            InsertLogger.plant(new InsertLogger.Tree[] { insertLogger });
//            fail();
//        } catch (IllegalArgumentException e) {
//            assertThat(e).hasMessage("Cannot plant InsertLogger into itself.");
//        }
//    }
//
//    @Test public void treeCount() {
//        // inserts trees and checks if the amount of returned trees matches.
//        assertThat(InsertLogger.treeCount()).isEqualTo(0);
//        for(int i= 1 ; i < 50 ; i++){
//            InsertLogger.plant(new InsertLogger.DebugTree());
//            assertThat(InsertLogger.treeCount()).isEqualTo(i);
//        }
//        InsertLogger.uprootAll();
//        assertThat(InsertLogger.treeCount()).isEqualTo(0);
//    }
//
//    @SuppressWarnings("ConstantConditions")
//    @Test public void nullTree() {
//        InsertLogger.Tree nullTree = null;
//        try {
//            InsertLogger.plant(nullTree);
//            fail();
//        } catch (NullPointerException e) {
//            assertThat(e).hasMessage("tree == null");
//        }
//    }
//
//    @SuppressWarnings("ConstantConditions")
//    @Test public void nullTreeArray() {
//        InsertLogger.Tree[] nullTrees = null;
//        try {
//            InsertLogger.plant(nullTrees);
//            fail();
//        } catch (NullPointerException e) {
//            assertThat(e).hasMessage("trees == null");
//        }
//        nullTrees = new InsertLogger.Tree[] { null };
//        try {
//            InsertLogger.plant(nullTrees);
//            fail();
//        } catch (NullPointerException e) {
//            assertThat(e).hasMessage("trees contains null");
//        }
//    }
//
//    @Test public void forestReturnsAllPlanted() {
//        InsertLogger.DebugTree tree1 = new InsertLogger.DebugTree();
//        InsertLogger.DebugTree tree2 = new InsertLogger.DebugTree();
//        InsertLogger.plant(tree1);
//        InsertLogger.plant(tree2);
//
//        assertThat(InsertLogger.forest()).containsExactly(tree1, tree2);
//    }
//
//    @Test public void forestReturnsAllTreesPlanted() {
//        InsertLogger.DebugTree tree1 = new InsertLogger.DebugTree();
//        InsertLogger.DebugTree tree2 = new InsertLogger.DebugTree();
//        InsertLogger.plant(tree1, tree2);
//
//        assertThat(InsertLogger.forest()).containsExactly(tree1, tree2);
//    }
//
//    @Test public void uprootThrowsIfMissing() {
//        try {
//            InsertLogger.uproot(new InsertLogger.DebugTree());
//            fail();
//        } catch (IllegalArgumentException e) {
//            assertThat(e).hasMessageStartingWith("Cannot uproot tree which is not planted: ");
//        }
//    }
//
//    @Test public void uprootRemovesTree() {
//        InsertLogger.DebugTree tree1 = new InsertLogger.DebugTree();
//        InsertLogger.DebugTree tree2 = new InsertLogger.DebugTree();
//        InsertLogger.plant(tree1);
//        InsertLogger.plant(tree2);
//        InsertLogger.d("First");
//        InsertLogger.uproot(tree1);
//        InsertLogger.d("Second");
//
//        assertLog()
//                .hasDebugMessage("NativeMethodAccessorImpl", "First")
//                .hasDebugMessage("NativeMethodAccessorImpl", "First")
//                .hasDebugMessage("NativeMethodAccessorImpl", "Second")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void uprootAllRemovesAll() {
//        InsertLogger.DebugTree tree1 = new InsertLogger.DebugTree();
//        InsertLogger.DebugTree tree2 = new InsertLogger.DebugTree();
//        InsertLogger.plant(tree1);
//        InsertLogger.plant(tree2);
//        InsertLogger.d("First");
//        InsertLogger.uprootAll();
//        InsertLogger.d("Second");
//
//        assertLog()
//                .hasDebugMessage("NativeMethodAccessorImpl", "First")
//                .hasDebugMessage("NativeMethodAccessorImpl", "First")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void noArgsDoesNotFormat() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.d("te%st");
//
//        assertLog()
//                .hasDebugMessage("NativeMethodAccessorImpl", "te%st")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void debugTreeTagGeneration() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.d("Hello, world!");
//
//        assertLog()
//                .hasDebugMessage("NativeMethodAccessorImpl", "Hello, world!")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void debugTreeTagGenerationStripsAnonymousClassMarker() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        new Runnable() {
//            @Override public void run() {
//                InsertLogger.d("Hello, world!");
//
//                new Runnable() {
//                    @Override public void run() {
//                        InsertLogger.d("Hello, world!");
//                    }
//                }.run();
//            }
//        }.run();
//
//        assertLog()
//                .hasDebugMessage("InsertLoggerTest", "Hello, world!")
//                .hasDebugMessage("InsertLoggerTest", "Hello, world!")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void debugTreeCustomTag() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.tag("Custom").d("Hello, world!");
//
//        assertLog()
//                .hasDebugMessage("Custom", "Hello, world!")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void messageWithException() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        NullPointerException datThrowable = new NullPointerException();
//        InsertLogger.e(datThrowable, "OMFG!");
//
//        assertExceptionLogged(Log.ERROR, "OMFG!", "java.lang.NullPointerException");
//    }
//
//    @Test public void exceptionOnly() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//
//        InsertLogger.v(new IllegalArgumentException());
//        assertExceptionLogged(Log.VERBOSE, null, "java.lang.IllegalArgumentException", "NativeMethodAccessorImpl", 0);
//
//        InsertLogger.i(new NullPointerException());
//        assertExceptionLogged(Log.INFO, null, "java.lang.NullPointerException", "NativeMethodAccessorImpl", 1);
//
//        InsertLogger.d(new UnsupportedOperationException());
//        assertExceptionLogged(Log.DEBUG, null, "java.lang.UnsupportedOperationException", "NativeMethodAccessorImpl", 2);
//
//        InsertLogger.w(new UnknownHostException());
//        assertExceptionLogged(Log.WARN, null, "java.net.UnknownHostException", "NativeMethodAccessorImpl", 3);
//
//        InsertLogger.e(new ConnectException());
//        assertExceptionLogged(Log.ERROR, null, "java.net.ConnectException", "NativeMethodAccessorImpl", 4);
//
//        InsertLogger.wtf(new AssertionError());
//        assertExceptionLogged(Log.ASSERT, null, "java.lang.AssertionError", "NativeMethodAccessorImpl", 5);
//    }
//
//    @Test public void exceptionOnlyCustomTag() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//
//        InsertLogger.tag("Custom").v(new IllegalArgumentException());
//        assertExceptionLogged(Log.VERBOSE, null, "java.lang.IllegalArgumentException", "Custom", 0);
//
//        InsertLogger.tag("Custom").i(new NullPointerException());
//        assertExceptionLogged(Log.INFO, null, "java.lang.NullPointerException", "Custom", 1);
//
//        InsertLogger.tag("Custom").d(new UnsupportedOperationException());
//        assertExceptionLogged(Log.DEBUG, null, "java.lang.UnsupportedOperationException", "Custom", 2);
//
//        InsertLogger.tag("Custom").w(new UnknownHostException());
//        assertExceptionLogged(Log.WARN, null, "java.net.UnknownHostException", "Custom", 3);
//
//        InsertLogger.tag("Custom").e(new ConnectException());
//        assertExceptionLogged(Log.ERROR, null, "java.net.ConnectException", "Custom", 4);
//
//        InsertLogger.tag("Custom").wtf(new AssertionError());
//        assertExceptionLogged(Log.ASSERT, null, "java.lang.AssertionError", "Custom", 5);
//    }
//
//    @Test public void exceptionFromSpawnedThread() throws InterruptedException {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        final NullPointerException datThrowable = new NullPointerException();
//        final CountDownLatch latch = new CountDownLatch(1);
//        new Thread() {
//            @Override public void run() {
//                InsertLogger.e(datThrowable, "OMFG!");
//                latch.countDown();
//            }
//        }.run();
//        latch.await();
//        assertExceptionLogged(Log.ERROR, "OMFG!", "java.lang.NullPointerException");
//    }
//
//    @Test public void nullMessageWithThrowable() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        final NullPointerException datThrowable = new NullPointerException();
//        InsertLogger.e(datThrowable, null);
//
//        assertExceptionLogged(Log.ERROR, "", "java.lang.NullPointerException");
//    }
//
//    @Test public void chunkAcrossNewlinesAndLimit() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.d(repeat('a', 3000) + '\n' + repeat('b', 6000) + '\n' + repeat('c', 3000));
//
//        assertLog()
//                .hasDebugMessage("NativeMethodAccessorImpl", repeat('a', 3000))
//                .hasDebugMessage("NativeMethodAccessorImpl", repeat('b', 4000))
//                .hasDebugMessage("NativeMethodAccessorImpl", repeat('b', 2000))
//                .hasDebugMessage("NativeMethodAccessorImpl", repeat('c', 3000))
//                .hasNoMoreMessages();
//    }
//
//    @Test public void nullMessageWithoutThrowable() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.d(null);
//
//        assertLog().hasNoMoreMessages();
//    }
//
//    @Test public void logMessageCallback() {
//        final List<String> logs = new ArrayList<String>();
//        InsertLogger.plant(new InsertLogger.DebugTree() {
//            @Override protected void log(int priority, String tag, String message, Throwable t) {
//                logs.add(priority + " " + tag + " " + message);
//            }
//        });
//
//        InsertLogger.v("Verbose");
//        InsertLogger.tag("Custom").v("Verbose");
//        InsertLogger.d("Debug");
//        InsertLogger.tag("Custom").d("Debug");
//        InsertLogger.i("Info");
//        InsertLogger.tag("Custom").i("Info");
//        InsertLogger.w("Warn");
//        InsertLogger.tag("Custom").w("Warn");
//        InsertLogger.e("Error");
//        InsertLogger.tag("Custom").e("Error");
//        InsertLogger.wtf("Assert");
//        InsertLogger.tag("Custom").wtf("Assert");
//
//        assertThat(logs).containsExactly( //
//                                          "2 NativeMethodAccessorImpl Verbose", //
//                                          "2 Custom Verbose", //
//                                          "3 NativeMethodAccessorImpl Debug", //
//                                          "3 Custom Debug", //
//                                          "4 NativeMethodAccessorImpl Info", //
//                                          "4 Custom Info", //
//                                          "5 NativeMethodAccessorImpl Warn", //
//                                          "5 Custom Warn", //
//                                          "6 NativeMethodAccessorImpl Error", //
//                                          "6 Custom Error", //
//                                          "7 NativeMethodAccessorImpl Assert", //
//                                          "7 Custom Assert" //
//        );
//    }
//
//    @Test public void logAtSpecifiedPriority() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//
//        InsertLogger.log(Log.VERBOSE, "Hello, World!");
//        InsertLogger.log(Log.DEBUG, "Hello, World!");
//        InsertLogger.log(Log.INFO, "Hello, World!");
//        InsertLogger.log(Log.WARN, "Hello, World!");
//        InsertLogger.log(Log.ERROR, "Hello, World!");
//        InsertLogger.log(Log.ASSERT, "Hello, World!");
//
//        assertLog()
//                .hasVerboseMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasDebugMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasInfoMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasWarnMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasErrorMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasAssertMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void formatting() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.v("Hello, %s!", "World");
//        InsertLogger.d("Hello, %s!", "World");
//        InsertLogger.i("Hello, %s!", "World");
//        InsertLogger.w("Hello, %s!", "World");
//        InsertLogger.e("Hello, %s!", "World");
//        InsertLogger.wtf("Hello, %s!", "World");
//
//        assertLog()
//                .hasVerboseMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasDebugMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasInfoMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasWarnMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasErrorMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasAssertMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void isLoggableControlsLogging() {
//        InsertLogger.plant(new InsertLogger.DebugTree() {
//            @Override protected boolean isLoggable(int priority) {
//                return priority == Log.INFO;
//            }
//        });
//        InsertLogger.v("Hello, World!");
//        InsertLogger.d("Hello, World!");
//        InsertLogger.i("Hello, World!");
//        InsertLogger.w("Hello, World!");
//        InsertLogger.e("Hello, World!");
//        InsertLogger.wtf("Hello, World!");
//
//        assertLog()
//                .hasInfoMessage("NativeMethodAccessorImpl", "Hello, World!")
//                .hasNoMoreMessages();
//    }
//
//    @Test public void logsUnknownHostExceptions() {
//        InsertLogger.plant(new InsertLogger.DebugTree());
//        InsertLogger.e(new UnknownHostException(), null);
//
//        assertExceptionLogged(Log.ERROR, "", "UnknownHostException");
//    }
//
//    @Test public void tagIsClearedWhenNotLoggable() {
//        InsertLogger.plant(new InsertLogger.DebugTree() {
//            @Override
//            protected boolean isLoggable(int priority) {
//                return priority >= Log.WARN;
//            }
//        });
//        InsertLogger.tag("NotLogged").i("Message not logged");
//        InsertLogger.w("Message logged");
//
//        assertLog()
//                .hasWarnMessage("NativeMethodAccessorImpl", "Message logged")
//                .hasNoMoreMessages();
//    }
//
//    private static String repeat(char c, int number) {
//        char[] data = new char[number];
//        Arrays.fill(data, c);
//        return new String(data);
//    }
//
//    private static void assertExceptionLogged(int logType, String message, String exceptionClassname) {
//        assertExceptionLogged(logType, message, exceptionClassname, null, 0);
//    }
//
//    private static void assertExceptionLogged(int logType, String message, String exceptionClassname, String tag, int index) {
//        List<LogItem> logs = ShadowLog.getLogs();
//        assertThat(logs).hasSize(index + 1);
//        LogItem log = logs.get(index);
//        assertThat(log.type).isEqualTo(logType);
//        assertThat(log.tag).isEqualTo(tag != null ? tag : "InsertLoggerTest");
//
//        if (message != null) {
//            assertThat(log.msg).startsWith(message);
//        }
//
//        assertThat(log.msg).contains(exceptionClassname);
//        // We use a low-level primitive that Robolectric doesn't populate.
//        assertThat(log.throwable).isNull();
//    }
//
//    private static LogAssert assertLog() {
//        return new LogAssert(ShadowLog.getLogs());
//    }
//
//    private static final class LogAssert {
//        private final List<LogItem> items;
//        private int index = 0;
//
//        private LogAssert(List<LogItem> items) {
//            this.items = items;
//        }
//
//        public LogAssert hasVerboseMessage(String tag, String message) {
//            return hasMessage(Log.VERBOSE, tag, message);
//        }
//
//        public LogAssert hasDebugMessage(String tag, String message) {
//            return hasMessage(Log.DEBUG, tag, message);
//        }
//
//        public LogAssert hasInfoMessage(String tag, String message) {
//            return hasMessage(Log.INFO, tag, message);
//        }
//
//        public LogAssert hasWarnMessage(String tag, String message) {
//            return hasMessage(Log.WARN, tag, message);
//        }
//
//        public LogAssert hasErrorMessage(String tag, String message) {
//            return hasMessage(Log.ERROR, tag, message);
//        }
//
//        public LogAssert hasAssertMessage(String tag, String message) {
//            return hasMessage(Log.ASSERT, tag, message);
//        }
//
//        private LogAssert hasMessage(int priority, String tag, String message) {
//            LogItem item = items.get(index++);
//            assertThat(item.type).isEqualTo(priority);
//            assertThat(item.tag).isEqualTo(tag);
//            assertThat(item.msg).isEqualTo(message);
//            return this;
//        }
//
//        public void hasNoMoreMessages() {
//            assertThat(items).hasSize(index);
//        }
//    }
//}
