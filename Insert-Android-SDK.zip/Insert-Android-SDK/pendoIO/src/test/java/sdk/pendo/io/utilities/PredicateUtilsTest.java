package sdk.pendo.io.utilities;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.annotation.Config;

import java.util.ArrayList;

import sdk.pendo.io.CustomRobolectricRunner;
import sdk.pendo.io.R;
import sdk.pendo.io.events.IdentificationData;

/**
 * Unit testing for the predicate utility class.
 *
 * Created by assaf on 1/11/16.
 */
@RunWith(CustomRobolectricRunner.class)
@Config(sdk = 21, manifest = "../insertIO/src/main/AndroidManifest.xml")
public class PredicateUtilsTest {
/*
    private static class TestActivity extends Activity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.pairing_fail);
        }
    }

    private static final String PREDICATE_PREFIX = "/android.view.ViewRootImpl/android.widget.LinearLayout/android.widget.FrameLayout/android.support.v7.widget.FitWindowsLinearLayout/android.support.v7.widget.ContentFrameLayout/android.support.v4.widget.DrawerLayout/android.widget.LinearLayout/";
    private static final String PREDICATE_COMMON_VIEW_PAGER = "android.widget.FrameLayout/android.widget.LinearLayout/android.support.v4.view.ViewPager/";
    private static final String PREDICATE_RECYCLER_VIEW_CARD_VIEW = "android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.support.v7.widget.CardView";
    private static final String[] PREDICATES = new String[] {
            PREDICATE_PREFIX + "android.support.v7.widget.Toolbar/android.support.v7.widget.ActionMenuView/android.support.v7.view.menu.ActionMenuItemView",
            PREDICATE_PREFIX + "android.support.v7.widget.Toolbar/android.widget.ImageButton",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + "android.support.v4.view.PagerTabStrip/android.widget.TextView[text=\"TWVucw==\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + "android.support.v4.view.PagerTabStrip/android.widget.TextView[text=\"V29tZW5z\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + "android.support.v4.view.PagerTabStrip/android.widget.TextView[indexPath=(0,0)][text=\"V29tZW5z\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(*,*)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcnQgQnJpbSBTdW4gTWFuJ3MgSGF0\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatImageView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"MTAlCiBPRkY=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcnQgQnJpbSBTdW4gTWFuJ3MgSGF0\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"JDQwLjA=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcC5mb3R0LmNvbQ==\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatImageView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvdWxkZXIgYmFn\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"JDQwLjA=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"VGFwYW5kZHll\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatImageView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U3R1ZGVudCBiYWc=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"JDQwLjA=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"VGFwYW5kZHll\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"VGFwYW5kZHll\"]"
    };

    private TextView mTextView;

    @Before
    public void setUp() {
        final TestActivity activity = Robolectric
                .setupActivity(TestActivity.class);

        final View view = activity.getLayoutInflater()
                .inflate(R.layout.pairing_fail, null);
        mTextView = (TextView) view.findViewById(R.id.pairing_mode_status);
    }

    @Test
    public void testComparePredicateWithViewString() throws Exception {
        final String common = PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW;
        String viewPredicate = common + "[indexPath=(0,2)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U3R1ZGVudCBiYWc=\"]";
        String view2Predicate = common + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvdWxkZXIgYmFn\"]";
        String predicateAny = common + "[indexPath=(*,*)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcnQgQnJpbSBTdW4gTWFuJ3MgSGF0\"]";

        IdentificationData viewID = new IdentificationData();
        viewID.setPredicate(viewPredicate);

        IdentificationData view2ID = new IdentificationData();
        view2ID.setPredicate(view2Predicate);

        IdentificationData anyId = new IdentificationData();
        anyId.setPredicate(predicateAny);
        Assert.assertTrue(PredicateUtils.compareIdentificationDetailsWithView(anyId, viewID, false, null));
        Assert.assertTrue(PredicateUtils.compareIdentificationDetailsWithView(anyId, view2ID, false, null));

        Assert.assertTrue(PredicateUtils.compareIdentificationDetailsWithView(viewID, viewID, false, null));
        Assert.assertTrue(PredicateUtils.compareIdentificationDetailsWithView(view2ID, view2ID, false, null));

        Assert.assertFalse(PredicateUtils.compareIdentificationDetailsWithView(viewID, view2ID, false, null));
        Assert.assertFalse(PredicateUtils.compareIdentificationDetailsWithView(view2ID, viewID, false, null));
    }

    @Test
    public void testComparePredicateWithView() throws Exception {
        final String predicateForView = PredicateUtils.generatePredicateForView(mTextView);
        IdentificationData viewID = new IdentificationData();
        viewID.setPredicate(predicateForView);

        Assert.assertTrue(PredicateUtils.isValidPredicate(predicateForView));
        Assert.assertTrue(PredicateUtils.compareIdentificationDetailsWithView(viewID, mTextView, null));
    }

    @Test
    public void testGeneratePredicateForView() throws Exception {
        final String predicateForView = PredicateUtils.generatePredicateForView(mTextView);

        Assert.assertTrue(PredicateUtils.isValidPredicate(predicateForView));
    }

    private static final String[] NOT_VALID_PREDICATE = new String[] {
            PREDICATE_PREFIX + "android.support.v7.widget.Toolbar/android.support.v7.widget.ActionMenuView/android.support.v7.view.menu.ActionMenuItemView/",
            PREDICATE_PREFIX + "android.support.v7.widget.Toolbar/android.widget.ImageButton.",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + "android.support.v4.view.PagerTabStrip/android.widget.TextView[indexPath=\"TWVucw==\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + "android.support.v4.view.PagerTabStrip/android.widget.[indexPath=(0,0)]TextView[text=\"V29tZW5z\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(*,*)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcnQgQnJpbSBTdW4gTWFuJ3MgSGF0\"]]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(d,0)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatImageView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,w)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"MTAlCiBPRkY=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,@)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcnQgQnJpbSBTdW4gTWFuJ3MgSGF0\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(%,0)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]//android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"JDQwLjA=\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,0)]/[indexPath=(0,0)]/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.support.v7.widget.AppCompatTextView[text=\"U2hvcC5mb3R0LmNvbQ==\"]",
            PREDICATE_PREFIX + PREDICATE_COMMON_VIEW_PAGER + PREDICATE_RECYCLER_VIEW_CARD_VIEW + "[indexPath=(0,1)]/android.widget.RelativeLayout/android.support.v7.widget.AppCompatImageView/"
    };

    @Test
    public void testIsValidPredicate() throws Exception {

//        System.out.println(" --- True --- ");
        for (String predicate : PREDICATES) {
//            System.out.println("Testing: " + predicate);
            Assert.assertTrue(PredicateUtils.isValidPredicate(predicate));
        }

//        System.out.println(" --- False --- ");
        for (String predicate : NOT_VALID_PREDICATE) {
//            System.out.println("Testing: " + predicate);
            Assert.assertFalse(PredicateUtils.isValidPredicate(predicate));
        }
    }

    @Test
    public void testIsTextMatch_TwoLinearLayoutsNoContainedStrings_TextMatchVacuousTruth() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch(null, null, null, null);
        Assert.assertTrue(textMatch);
    }

    @Test
    public void testIsTextMatch_TwoEqualTextsNoContainedStrings_TextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch("test", "test", null, null);
        Assert.assertTrue(textMatch);
    }

    @Test
    public void testIsTextMatch_OneTextOneNulllNoContainedStrings_NoTextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch("test", null, null, null);
        Assert.assertFalse(textMatch);
    }

    @Test
    public void testIsTextMatch_OneNullOneTextNoContainedStrings_NoTextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch(null, "test", null, null);
        Assert.assertFalse(textMatch);
    }
    // DRAWER IS OPEN AND CONTAINED TEXTS MATCH
    @Test
    public void testIsTextMatch_TwoLinearLayoutsContainedStringsTrue_TextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch(null, null, null, true);
        Assert.assertTrue(textMatch);
    }

    @Test
    public void testIsTextMatch_TwoEqualTextsContainedStringsTrue_TextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch("test", "test", null, true);
        Assert.assertTrue(textMatch);
    }

    @Test
    public void testIsTextMatch_OneTextOneNulllContainedStringsTrue_NoTextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch("test", null, null, true);
        Assert.assertFalse(textMatch);
    }

    @Test
    public void testIsTextMatch_OneNullOneTextContainedStringsTrue_NoTextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch(null, "test", null, true);
        Assert.assertFalse(textMatch);
    }

    // DRAWER IS OPEN AND CONTAINED TEXTS MATCH

    @Test
    public void testIsTextMatch_TwoLinearLayoutsContainedStringsFalse_TextNotMatchAsContainedArent() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch(null, null, null, false);
        Assert.assertFalse(textMatch);
    }

    @Test
    public void testIsTextMatch_TwoEqualTextsContainedStringsFalse_TextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch("test", "test", null, false);
        Assert.assertTrue(textMatch);
    }

    @Test
    public void testIsTextMatch_OneTextOneNulllContainedStringsFalse_NoTextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch("test", null, null, false);
        Assert.assertFalse(textMatch);
    }

    @Test
    public void testIsTextMatch_OneNullOneTextContainedStringsFalse_NoTextMatch() throws Exception {
        boolean textMatch = PredicateUtils.isTextMatch(null, "test", null, false);
        Assert.assertFalse(textMatch);
    }

    @Test
    public void containedStringsMatch_DrawerIsClosed_ReturnsNull() throws Exception {
        IdentificationData viewIdentificationData = new IdentificationData();
        viewIdentificationData.setTextStrings(new ArrayList<String>());
        IdentificationData lIdentificationData = new IdentificationData();
        lIdentificationData.setTextStrings(new ArrayList<String>());
        Boolean textsMatch = PredicateUtils.containedStringsMatch(viewIdentificationData, lIdentificationData, false);
        Assert.assertNull(textsMatch);
    }

    @Test
    public void containedStringsMatch_DrawerIsOpenNoTextStrings_ReturnTrueVicousTrue() throws Exception {
        IdentificationData viewIdentificationData = new IdentificationData();
        viewIdentificationData.setTextStrings(new ArrayList<String>());
        IdentificationData lIdentificationData = new IdentificationData();
        lIdentificationData.setTextStrings(new ArrayList<String>());
        Boolean textsMatch = PredicateUtils.containedStringsMatch(viewIdentificationData, lIdentificationData, true);
        Assert.assertTrue(textsMatch);
    }

    @Test
    public void containedStringsMatch_DrawerIsOpenOnlyOneHashTextString_ReturnFalse() throws Exception {
        IdentificationData viewIdentificationData = new IdentificationData();
        ArrayList<String> textStrings = new ArrayList<>();
        textStrings.add("test");
        viewIdentificationData.setTextStrings(textStrings);
        IdentificationData lIdentificationData = new IdentificationData();
        lIdentificationData.setTextStrings(new ArrayList<String>());
        Boolean textsMatch = PredicateUtils.containedStringsMatch(viewIdentificationData, lIdentificationData, true);
        Assert.assertFalse(textsMatch);
    }

    @Test
    public void containedStringsMatch_DrawerIsOpenEqualTextStrings_ReturnTrue() throws Exception {
        IdentificationData viewIdentificationData = new IdentificationData();
        ArrayList<String> textStrings = new ArrayList<>();
        textStrings.add("test");
        viewIdentificationData.setTextStrings(textStrings);
        IdentificationData lIdentificationData = new IdentificationData();
        ArrayList<String> textStrings1 = new ArrayList<>();
        textStrings1.add("test");
        lIdentificationData.setTextStrings(textStrings1);
        Boolean textsMatch = PredicateUtils.containedStringsMatch(viewIdentificationData, lIdentificationData, true);
        Assert.assertTrue(textsMatch);
    }

    @Test
    public void containedStringsMatch_DrawerIsOpenNonEqualTextStrings_ReturnFalse() throws Exception {
        IdentificationData viewIdentificationData = new IdentificationData();
        ArrayList<String> textStrings = new ArrayList<>();
        textStrings.add("test");
        viewIdentificationData.setTextStrings(textStrings);
        IdentificationData lIdentificationData = new IdentificationData();
        ArrayList<String> textStrings1 = new ArrayList<>();
        textStrings1.add("test1");
        lIdentificationData.setTextStrings(textStrings1);
        Boolean textsMatch = PredicateUtils.containedStringsMatch(viewIdentificationData, lIdentificationData, true);
        Assert.assertFalse(textsMatch);
    }
*/


}