package sdk.pendo.io.network.responses.validators;

import org.junit.Test;


/**
 * Created by assaf on 5/24/17.
 */
public class JsonWebTokenValidatorTest {

    private final String NONE_ALGO_JWT = "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWV9.2XijNOVI9LXP9nWf-oj2SEWWNlcwmxzlQNGK1WdaWcQ";

    @Test(expected = org.jose4j.jwt.consumer.InvalidJwtException.class)
    public void validate() throws Exception {
        JsonWebTokenValidator.INSTANCE.validate(NONE_ALGO_JWT);
    }

}
