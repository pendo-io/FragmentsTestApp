package sdk.pendo.io.actions;

import junit.framework.Assert;

import org.junit.Test;

import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandFormAction.SUBMIT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandFormAction.UPDATE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.CHANGE_SCREEN;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.DISMISS_INSERT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.IN_ANIMATION_DONE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.NOTIFY_CLOSE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.OPEN_URL;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.OUT_ANIMATION_DONE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.SEND_ANALYTICS;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.SEND_APP_SPECIFIC_ANALYTICS;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandGlobalAction.SHOW_ALERT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPageAction.VALIDATE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPagerAction.CHANGE_PAGE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPagerAction.NEXT_PAGE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandPagerAction.PREVIOUS_PAGE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandRadioButtonAction.SELECT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandRadioGroupAction.SELECT_RADIO_BUTTON;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandRunnableAction.RUN_JAVA_SCRIPT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandTextAction.SET_TEXT;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandVideoAction.PAUSE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandVideoAction.PLAY;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandVideoAction.REWIND;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandVideoAction.SEEK;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandVideoAction.STOP;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.ENABLE;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.ENABLE_ACTION;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.SET_BACKGROUND_COLOR;
import static sdk.pendo.io.actions.InsertCommandAction.InsertCommandViewGeneralAction.SET_VISIBILITY;
import static sdk.pendo.io.actions.InsertCommandAction.InsertInternalAction.PREFETCH_IMAGES;

/**
 * Tests the {@link InsertCommandAction} class.
 *
 * Created by assaf on 3/28/16.
 */
public class InsertCommandActionTest {

    @Test
    public void testGetAction() throws Exception {
        Assert.assertEquals(InsertCommandAction.getAction("prefetchImages"), PREFETCH_IMAGES);
        Assert.assertEquals(InsertCommandAction.getAction("enable"), ENABLE);
        Assert.assertEquals(InsertCommandAction.getAction("enableAction"), ENABLE_ACTION);
        Assert.assertEquals(InsertCommandAction.getAction("setBackgroundColor"), SET_BACKGROUND_COLOR);
        Assert.assertEquals(InsertCommandAction.getAction("setVisibility"), SET_VISIBILITY);
        Assert.assertEquals(InsertCommandAction.getAction("submit"), SUBMIT);
        Assert.assertEquals(InsertCommandAction.getAction("update"), UPDATE);
        Assert.assertEquals(InsertCommandAction.getAction("select"), SELECT);
        Assert.assertEquals(InsertCommandAction.getAction("selectRadioButton"), SELECT_RADIO_BUTTON);
        Assert.assertEquals(InsertCommandAction.getAction("setText"), SET_TEXT);
        Assert.assertEquals(InsertCommandAction.getAction("play"), PLAY);
        Assert.assertEquals(InsertCommandAction.getAction("stop"), STOP);
        Assert.assertEquals(InsertCommandAction.getAction("rewind"), REWIND);
        Assert.assertEquals(InsertCommandAction.getAction("seek"), SEEK);
        Assert.assertEquals(InsertCommandAction.getAction("pause"), PAUSE);
        Assert.assertEquals(InsertCommandAction.getAction("changePage"), CHANGE_PAGE);
        Assert.assertEquals(InsertCommandAction.getAction("nextPage"), NEXT_PAGE);
        Assert.assertEquals(InsertCommandAction.getAction("previousPage"), PREVIOUS_PAGE);
        Assert.assertEquals(InsertCommandAction.getAction("validate"), VALIDATE);
        Assert.assertEquals(InsertCommandAction.getAction("dismissGuide"), DISMISS_INSERT);
        Assert.assertEquals(InsertCommandAction.getAction("changeScreen"), CHANGE_SCREEN);
        Assert.assertEquals(InsertCommandAction.getAction("openLink"), OPEN_URL);
        Assert.assertEquals(InsertCommandAction.getAction("showAlert"), SHOW_ALERT);
        Assert.assertEquals(InsertCommandAction.getAction("sendAnalytics"), SEND_ANALYTICS);
        Assert.assertEquals(InsertCommandAction.getAction("sendAppSpecificAnalytics"), SEND_APP_SPECIFIC_ANALYTICS);

        Assert.assertEquals(InsertCommandAction.getAction("notifyClose"), NOTIFY_CLOSE);
        Assert.assertEquals(InsertCommandAction.getAction("inAnimationDone"), IN_ANIMATION_DONE);
        Assert.assertEquals(InsertCommandAction.getAction("outAnimationDone"), OUT_ANIMATION_DONE);
        Assert.assertEquals(InsertCommandAction.getAction("evaluate"), RUN_JAVA_SCRIPT);

//        Assert.assertEquals(InsertCommandAction.getAction("evaluate"), EVALUATE);
    }
}
