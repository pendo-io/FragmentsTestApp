package sdk.pendo.io.managers;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import sdk.pendo.io.actions.ActivationManager;
import sdk.pendo.io.models.ActivationModel;
import sdk.pendo.io.models.StepLocationModel;

public class ActivationManagerTest {

    @Test
    public void jsonPathSimpleRule() throws Exception {

        String json = "{\"data\": {\"retroactiveScreenData\": {\"retroactiveScreenId\": \"screen\"}}}";
        JSONObject objectData = new JSONObject(json);

        String rule = "$[?(@.data.retroactiveScreenData.retroactiveScreenId == 'screen')]";
        ActivationModel activation = new ActivationModel();
        StepLocationModel stepLocationModel = new StepLocationModel();
        activation.setPageActivationId(1);
        activation.setEvent("view");
        activation.setPageSelector(rule);

        boolean isMatch = ActivationManager.INSTANCE.isMatch(activation, stepLocationModel, objectData, "view");
        Assert.assertTrue(isMatch);
    }


    @Test
    public void jsonPathRuleMatches() throws Exception {

        String json = "{\"data\": {\"retroactiveScreenData\": {\"retroactiveScreenId\": \"screen2\"}}}";
        JSONObject objectData = new JSONObject(json);

        StepLocationModel stepLocationModel = new StepLocationModel();

        String rule1 = "$[?(@.data.retroactiveScreenData.retroactiveScreenId == 'screen1')]";
        ActivationModel activation1 = new ActivationModel();
        activation1.setPageActivationId(20);
        activation1.setEvent("view");
        activation1.setPageSelector(rule1);

        String rule2 = "$[?(@.data.retroactiveScreenData.retroactiveScreenId == 'screen2')]";
        ActivationModel activation2 = new ActivationModel();
        activation2.setPageActivationId(3);
        activation2.setEvent("view");
        activation2.setPageSelector(rule2);

        Assert.assertFalse(ActivationManager.INSTANCE.isMatch(activation1, stepLocationModel, objectData, "view"));    // wrong retroactiveScreenId
        Assert.assertTrue(ActivationManager.INSTANCE.isMatch(activation2, stepLocationModel, objectData, "view"));     // match
        Assert.assertFalse(ActivationManager.INSTANCE.isMatch(activation2, stepLocationModel, objectData, "click"));   // wrong event
        Assert.assertFalse(ActivationManager.INSTANCE.isMatch(activation2, stepLocationModel, objectData, ""));        // empty event

        activation2.setEvent("");
        Assert.assertFalse(ActivationManager.INSTANCE.isMatch(activation2, stepLocationModel, objectData, "view"));    // empty activation event
        Assert.assertFalse(ActivationManager.INSTANCE.isMatch(activation2, stepLocationModel, objectData, ""));    // empty event + activation event

        activation2.setPageSelector(null);
        Assert.assertFalse(ActivationManager.INSTANCE.isMatch(activation2, stepLocationModel, objectData, "view"));     // null activation mobile selector
    }

    @Test
    public void jsonPathRealRule() throws Exception {

        String json = "{\r\n  \"data\": {\r\n    \"retroactiveScreenData\": {\r\n      \"retroactiveScreenId\": \"pnd:///Kickstarter_Framework.RootTabBarViewController/UINavigationController?tabIndex=1&navVisible=Kickstarter_Framework.ActivitiesViewController\",\r\n      \"timestamp\": 1539072551885,\r\n      \"id\": 122286920,\r\n      \"data\": {\r\n        \"name\": \"Kickstarter_Framework.RootTabBarViewController\",\r\n        \"info\": {\r\n          \"selectedController\": {\r\n            \"name\": \"UINavigationController\",\r\n            \"info\": {\r\n              \"kind\": \"UINavigationController\",\r\n              \"visibleControllerTitle\": 10176944571108442000,\r\n              \"visibleController\": {\r\n                \"name\": \"Kickstarter_Framework.ActivitiesViewController\"\r\n              },\r\n              \"stack\": [\r\n                {\r\n                  \"name\": \"Kickstarter_Framework.ActivitiesViewController\"\r\n                }\r\n              ]\r\n            }\r\n          },\r\n          \"textsBase64\": {\r\n            \"view_predicate_base64\": \"textsBase64Truncated256\"\r\n          },\r\n          \"kind\": \"UITabBarController\",\r\n          \"selectedTitle\": 10176944571108442000,\r\n          \"selectedIndex\": \"0\"\r\n        },\r\n        \"childControllers\": [\r\n          {\r\n            \"name\": \"UINavigationController\",\r\n            \"info\": {\r\n              \"kind\": \"UINavigationController\",\r\n              \"visibleControllerTitle\": 10176944571108442000,\r\n              \"visibleController\": {\r\n                \"name\": \"Kickstarter_Framework.ActivitiesViewController\"\r\n              },\r\n              \"stack\": [\r\n                {\r\n                  \"name\": \"Kickstarter_Framework.ActivitiesViewController\"\r\n                }\r\n              ]\r\n            },\r\n            \"childControllers\": [\r\n              {\r\n                \"name\": \"Kickstarter_Framework.ActivitiesViewController\",\r\n                \"childControllers\": [\r\n                  {\r\n                    \"name\": \"Kickstarter_Framework.EmptyStatesViewController\",\r\n                    \"info\": {\r\n                      \"selectedController\": {\r\n                        \"name\": \"UINavigationController\",\r\n                        \"info\": {\r\n                          \"kind\": \"UINavigationController\",\r\n                          \"visibleControllerTitle\": 10176944571108442000,\r\n                          \"visibleController\": {\r\n                            \"name\": \"Kickstarter_Framework.ActivitiesViewController\"\r\n                          },\r\n                          \"stack\": [\r\n                            {\r\n                              \"name\": \"Kickstarter_Framework.ActivitiesViewController\"\r\n                            }\r\n                          ]\r\n                        }\r\n                      },\r\n                      \"kind\": \"UITabBarController\",\r\n                      \"selectedTitle\": 444444444444444,\r\n                      \"selectedIndex\": \"1\"\r\n                    }\r\n                  }\r\n                ]\r\n              }\r\n            ]\r\n          }\r\n        ]\r\n      }\r\n    }\r\n  }\r\n}";
        JSONObject objectData = new JSONObject(json);

        String rule = "$[?(@.data.retroactiveScreenData.retroactiveScreenId == 'pnd:///Kickstarter_Framework.RootTabBarViewController/UINavigationController?tabIndex=1&navVisible=Kickstarter_Framework.ActivitiesViewController' && @.data.retroactiveScreenData.data.childControllers[0].childControllers[0].childControllers[0].info.kind == 'UITabBarController' && @.data.retroactiveScreenData.data.childControllers[0].childControllers[0].childControllers[0].info.selectedIndex == 1 && @.data.retroactiveScreenData.data.info.kind == 'UITabBarController' && @.data.retroactiveScreenData.data.info.selectedIndex == 0 && @.data.retroactiveScreenData.data.childControllers[0].childControllers[0].childControllers[0].info.selectedController.info.kind == 'UINavigationController' && @.data.retroactiveScreenData.data.info.selectedController.info.kind == 'UINavigationController' && @.data.retroactiveScreenData.data.childControllers[0].info.kind == 'UINavigationController')]";
        StepLocationModel stepLocationModel = new StepLocationModel();
        ActivationModel activation = new ActivationModel();
        activation.setPageActivationId(1);
        activation.setEvent("view");
        activation.setPageSelector(rule);

        boolean isMatch = ActivationManager.INSTANCE.isMatch(activation, stepLocationModel, objectData, "view");
        Assert.assertTrue(isMatch);
    }
}
