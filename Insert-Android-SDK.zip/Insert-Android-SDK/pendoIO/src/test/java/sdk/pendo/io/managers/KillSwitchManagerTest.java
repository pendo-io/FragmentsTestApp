package sdk.pendo.io.managers;

import android.support.annotation.NonNull;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.robolectric.annotation.Config;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import sdk.pendo.io.network.killswitch.KillSwitchManager;
import sdk.pendo.io.network.responses.KillSwitchModel;
import sdk.pendo.io.utilities.AndroidUtils;
import sdk.pendo.io.utilities.FileUtils;

import static sdk.pendo.io.constants.Constants.EncodingConsts.ENCODING_UTF_8;

/**
 * Created by nirsegev on 18/12/2016.
 */

@RunWith(PowerMockRunner.class)
@Config(sdk = 21, manifest = "../insertIO/src/main/AndroidManifest.xml")
@PrepareForTest({AndroidUtils.class, FileUtils.class})
public class KillSwitchManagerTest {

    @Test
    public void isKillSwitchOn_noExpirationNullVersions_returnsFalse() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");
        Assert.assertFalse(killSwitchOn);
    }

    @Test
    public void isKillSwitchOn_noExpirationCurrentVersion_returnsTrue() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();
        List<String> affectedVersions = new ArrayList<>();
        affectedVersions.add("1.2.3.4");
        killSwitchModel.setAffectedVersions(affectedVersions);

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");

        Assert.assertTrue(killSwitchOn);
    }

    @Test
    public void isKillSwitchOn_expirationIn1DayNullVersions_returnsFalse() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();
        Calendar calendar = getTomorrowDate();
        killSwitchModel.setExpiration(calendar.getTime().getTime());

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");

        Assert.assertFalse(killSwitchOn);
    }



    @Test
    public void isKillSwitchOn_expiredYesterdayNullVersions_returnsFalse() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();
        Calendar calendar = getYesterdayDate();
        killSwitchModel.setExpiration(calendar.getTime().getTime());

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");

        Assert.assertFalse(killSwitchOn);
    }

    @Test
    public void isKillSwitchOn_DifferentVersionAffected_returnsFalse() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();
        List<String> affectedVersions = new ArrayList<>();
        affectedVersions.add("1");
        killSwitchModel.setAffectedVersions(affectedVersions);
        killSwitchModel.setExpiration(getTomorrowDate().getTime().getTime());

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");

        Assert.assertFalse(killSwitchOn);
    }

    @Test
    public void isKillSwitchOn_VersionAffected_returnsTrue() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();
        List<String> affectedVersions = new ArrayList<>();
        affectedVersions.add("1.2.3.4");
        killSwitchModel.setAffectedVersions(affectedVersions);
        killSwitchModel.setExpiration(getTomorrowDate().getTime().getTime());

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");

        Assert.assertTrue(killSwitchOn);
    }

    @Test
    public void isKillSwitchOn_VersionAffectedButExpired_returnsFalse() throws Exception {

        KillSwitchModel killSwitchModel = new KillSwitchModel();
        List<String> affectedVersions = new ArrayList<>();
        affectedVersions.add("1.2.3.4");
        killSwitchModel.setAffectedVersions(affectedVersions);
        killSwitchModel.setExpiration(getYesterdayDate().getTime().getTime());

        boolean killSwitchOn = Whitebox.invokeMethod(KillSwitchManager.class, "isSDKVersionEffectedByKillSwitchModel", killSwitchModel, "1.2.3.4");

        Assert.assertFalse(killSwitchOn);
    }

    @NonNull
    private Calendar getYesterdayDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        return calendar;
    }

    @NonNull
    private Calendar getTomorrowDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 1);
        return calendar;
    }

    @Test
    public void appVersionChanged_deleteKillSwitch() throws Exception {
        PowerMockito.mockStatic(FileUtils.class);
        PowerMockito.mockStatic(AndroidUtils.class);
        String hostAppVersion = "1.1";
        String newAppVersion = "1.2";
        Mockito.when(FileUtils.getStoredFileAsString(KillSwitchManager.APP_VERSION_FILE_NAME)).thenReturn(hostAppVersion);
        Mockito.when(AndroidUtils.getAppVersionName()).thenReturn(newAppVersion);
        Assert.assertTrue((boolean)Whitebox.invokeMethod(KillSwitchManager.class, "isApplicationVersionChanged"));
        // Verify static method called
        PowerMockito.verifyStatic();
        FileUtils.deleteFile(KillSwitchManager.APP_VERSION_FILE_NAME);
        // Verify static method called
        PowerMockito.verifyStatic();
        FileUtils.deleteFile(KillSwitchManager.KILL_SWITCH_FILE_NAME);
        // Verify static method called
        PowerMockito.verifyStatic();
        FileUtils.createFileFromByteArray(newAppVersion.getBytes(Charset.forName(ENCODING_UTF_8)), KillSwitchManager.APP_VERSION_FILE_NAME);
    }

    @Test
    public void appVersionPersisted_keepKillSwitch() throws Exception {
        PowerMockito.mockStatic(FileUtils.class);
        PowerMockito.mockStatic(AndroidUtils.class);
        String hostAppVersion = "1.1";
        String newAppVersion = "1.1";
        Mockito.when(FileUtils.getStoredFileAsString(KillSwitchManager.APP_VERSION_FILE_NAME)).thenReturn(hostAppVersion);
        Mockito.when(AndroidUtils.getAppVersionName()).thenReturn(newAppVersion);
        Assert.assertFalse((boolean) Whitebox.invokeMethod(KillSwitchManager.class, "isApplicationVersionChanged"));
        // Verify static method called
        PowerMockito.verifyStatic(Mockito.never());
        FileUtils.deleteFile(KillSwitchManager.APP_VERSION_FILE_NAME);
        // Verify static method called
        PowerMockito.verifyStatic(Mockito.never());
        FileUtils.deleteFile(KillSwitchManager.KILL_SWITCH_FILE_NAME);
        // Verify static method called
        PowerMockito.verifyStatic(Mockito.never());
        FileUtils.createFileFromByteArray(newAppVersion.getBytes(Charset.forName(ENCODING_UTF_8)), KillSwitchManager.APP_VERSION_FILE_NAME);
    }

    @Test
    public void appVersionNeverSaved_keepKillSwitch() throws Exception {
        PowerMockito.mockStatic(FileUtils.class);
        PowerMockito.mockStatic(AndroidUtils.class);
        String hostAppVersion = null;
        String newAppVersion = "1.1";
        Mockito.when(FileUtils.getStoredFileAsString(KillSwitchManager.APP_VERSION_FILE_NAME)).thenReturn(hostAppVersion);
        Mockito.when(AndroidUtils.getAppVersionName()).thenReturn(newAppVersion);
        Assert.assertFalse((boolean) Whitebox.invokeMethod(KillSwitchManager.class, "isApplicationVersionChanged"));
        // Verify static method not called
        PowerMockito.verifyStatic(Mockito.never());
        FileUtils.deleteFile(KillSwitchManager.APP_VERSION_FILE_NAME);
        // Verify static method not called
        PowerMockito.verifyStatic(Mockito.never());
        FileUtils.deleteFile(KillSwitchManager.KILL_SWITCH_FILE_NAME);
        // Verify static method called
        PowerMockito.verifyStatic();
        FileUtils.createFileFromByteArray(newAppVersion.getBytes(Charset.forName(ENCODING_UTF_8)), KillSwitchManager.APP_VERSION_FILE_NAME);

    }
}
