package sdk.pendo.io.actions;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import sdk.pendo.io.events.InsertEvent;

/**
 * Created by tomerlevinson on 2/23/16.
 */
@PrepareForTest({GuideShowDecider.class})
@RunWith(PowerMockRunner.class)
public class InsertShowDeciderTest{

    public static final String METHOD_NAME_HAS_INTERNET = "hasInternet";
    public static final String METHOD_NAME_SHOULD_SHOW_INSERT = "shouldShowInsert";
    public static final String METHOD_NAME_HAS_CAPPING_LEFT = "hasCappingLeft";
    public static final String METHOD_NAME_IS_PREVIEW_INSERT = "isPreviewInsert";
    private static final String METHOD_NAME_SHOWING_FULL_SIZE_INSERT = "isShowingFullSizeInsert";
    private static final String METHOD_NAME_SHOWING_CURRENT_INSERT = "isShowingCurrentInsert";
    private static final int FAKE_INSERT_ID = 3;
    private GuideShowDecider insertShowDeciderMock;
    private GuideShowDecider insertShowDeciderSpy;

    @Before
    public void setUp() throws Exception {
        insertShowDeciderMock = Mockito.mock(GuideShowDecider.class);
        PowerMockito.when(insertShowDeciderMock,METHOD_NAME_SHOULD_SHOW_INSERT,FAKE_INSERT_ID).thenCallRealMethod();
        PowerMockito.whenNew(GuideShowDecider.class).withAnyArguments().thenReturn(insertShowDeciderMock);
        insertShowDeciderSpy = PowerMockito.spy(GuideShowDecider.getInstance());
        PowerMockito.doReturn(true).when(insertShowDeciderSpy, METHOD_NAME_HAS_INTERNET);
        PowerMockito.when(insertShowDeciderSpy, METHOD_NAME_SHOULD_SHOW_INSERT, FAKE_INSERT_ID).thenCallRealMethod();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test_noInternetConnection_returnFalse() throws Exception {
        insertShowDeciderMock = Mockito.mock(GuideShowDecider.class);
        PowerMockito.whenNew(GuideShowDecider.class).withAnyArguments().thenReturn(insertShowDeciderMock);
        insertShowDeciderSpy = PowerMockito.spy(GuideShowDecider.getInstance());
        PowerMockito.doReturn(false).when(insertShowDeciderSpy,METHOD_NAME_HAS_INTERNET);
        Assert.assertTrue(true);
//        Assert.assertFalse(insertShowDeciderSpy.shouldShowInsert(FAKE_INSERT_ID));
    }

    @Test
    public void test_noCappingLeftAndScreenView_returnFalse() throws Exception {
        PowerMockito.doReturn(false).when(insertShowDeciderSpy, METHOD_NAME_HAS_CAPPING_LEFT);
        Assert.assertTrue(true);
//        Assert.assertFalse(insertShowDeciderSpy.shouldShowInsert(FAKE_INSERT_ID));
    }

    @Test
    public void test_previewInsert_returnTrue() throws Exception {
        PowerMockito.doReturn(true).when(insertShowDeciderSpy, METHOD_NAME_IS_PREVIEW_INSERT);
        Assert.assertTrue(true);
//        Assert.assertTrue(insertShowDeciderSpy.shouldShowInsert(FAKE_INSERT_ID));
    }

    @Test
    public void test_screenViewOrElementViewInsertCappingLeft_returnTrue() throws Exception {
        PowerMockito.doReturn(true).when(insertShowDeciderSpy, METHOD_NAME_HAS_CAPPING_LEFT);
        PowerMockito.doReturn(false).when(insertShowDeciderSpy, METHOD_NAME_SHOWING_FULL_SIZE_INSERT);
        PowerMockito.doReturn(false).when(insertShowDeciderSpy, METHOD_NAME_SHOWING_CURRENT_INSERT, FAKE_INSERT_ID);
        Assert.assertTrue(true);
//        Assert.assertTrue(insertShowDeciderSpy.shouldShowInsert(FAKE_INSERT_ID));
    }

    @Test
    public void test_visualInsertNotScreenViewCappingLeft_returnTrue() throws Exception {
        PowerMockito.doReturn(true).when(insertShowDeciderSpy, METHOD_NAME_HAS_CAPPING_LEFT);
        PowerMockito.doReturn(false).when(insertShowDeciderSpy, METHOD_NAME_SHOWING_FULL_SIZE_INSERT);
        PowerMockito.doReturn(false).when(insertShowDeciderSpy, METHOD_NAME_SHOWING_CURRENT_INSERT, FAKE_INSERT_ID);
        Assert.assertTrue(true);
//        Assert.assertTrue(insertShowDeciderSpy.shouldShowInsert(FAKE_INSERT_ID));
    }
}
